Helpers for Hypixel SkyBlock's Riftstalker Bloodfiend plus some general QoL.
Open the config with **Insert** (rebindable). UI styles: Vamp or Simple.

## Rift
- Boss warnings (Impels, Twinclaw, Mania, etc.) with custom text & colors
- Boss spawn soon popup
- Blood Ichor tracking + HUD / tracer
- Killer Spring tracking + HUD / tracer
- Blood Effigy beams
- Rift time low warning

## Party
- DM auto-invite (!p,!party,!inv,!invite)
- Party utility commands (!warp,!w,!pt,...)
- Optional "fun" commands (!cf,!dice,!8ball,...)

## QoL
- Player scale, skip front F5 view
- Custom crosshair
- Chat copy, msgs stacking, hide stash msgs / custom hide patterns
- Fullbright & Clear View
- Item rarity outlines
- AH prices: lowest BIN, craft & est. value, trade totals (SkyCofl https://sky.coflnet.com/data)

## Requirements
Minecraft 26.2. Fabric Loader & Fabric API
