package com.vampy.render

import net.minecraft.client.DeltaTracker
import net.minecraft.client.Minecraft
import net.minecraft.client.gui.GuiGraphicsExtractor
import net.minecraft.client.renderer.state.level.CameraRenderState
import net.minecraft.gizmos.GizmoStyle
import net.minecraft.gizmos.Gizmos
import net.minecraft.gizmos.TextGizmo
import net.minecraft.network.chat.Component
import net.minecraft.util.Mth
import net.minecraft.world.phys.AABB
import net.minecraft.world.phys.Vec3
import java.util.concurrent.CopyOnWriteArrayList

/**
 * Unified Render Queue & Dispatcher written in Kotlin (`VampRenderQueue.kt`).
 *
 * Centralizes 3D World Gizmo requests and 2D HUD render requests submitted by modules
 * while preserving 100% of the existing matrix and GPU projection pipeline in
 * [ScreenSpaceEspRenderer] and [VampyRenderer].
 */
object VampRenderQueue {

    data class WorldBoxRequest(
        val box: AABB,
        val rgb: Int,
        val strokeWidth: Float = 2.5f,
        val fillAlpha: Int = 0x26
    )

    data class WorldBeaconRequest(
        val x: Double,
        val y: Double,
        val z: Double,
        val argb: Int,
        val label: String? = null
    )

    data class WorldTracerRequest(
        val start: Vec3,
        val end: Vec3,
        val rgb: Int,
        val width: Float = 2.2f
    )

    data class HudTextRequest(
        val text: Component,
        val x: Int,
        val y: Int,
        val scale: Float = 1.0f,
        val color: Int = 0xFFFFFFFF.toInt(),
        val centered: Boolean = false
    )

    private val worldBoxes = ArrayList<WorldBoxRequest>(32)
    private val worldBeacons = ArrayList<WorldBeaconRequest>(16)
    private val worldTracers = ArrayList<WorldTracerRequest>(16)
    private val hudTexts = ArrayList<HudTextRequest>(32)
    private val customHudCallbacks = CopyOnWriteArrayList<(GuiGraphicsExtractor, DeltaTracker) -> Unit>()

    @JvmStatic
    fun submitWorldBox(box: AABB, rgb: Int, strokeWidth: Float = 2.5f, fillAlpha: Int = 0x26) {
        worldBoxes.add(WorldBoxRequest(box, rgb, strokeWidth, fillAlpha))
    }

    @JvmStatic
    fun submitWorldBeacon(x: Double, y: Double, z: Double, argb: Int, label: String? = null) {
        worldBeacons.add(WorldBeaconRequest(x, y, z, argb, label))
    }

    @JvmStatic
    fun submitWorldTracer(start: Vec3, end: Vec3, rgb: Int, width: Float = 2.2f) {
        worldTracers.add(WorldTracerRequest(start, end, rgb, width))
    }

    @JvmStatic
    fun submitHudText(text: Component, x: Int, y: Int, scale: Float = 1.0f, color: Int = 0xFFFFFFFF.toInt(), centered: Boolean = false) {
        hudTexts.add(HudTextRequest(text, x, y, scale, color, centered))
    }

    @JvmStatic
    fun registerHudLayer(callback: (GuiGraphicsExtractor, DeltaTracker) -> Unit) {
        customHudCallbacks.add(callback)
    }

    /**
     * Single entry point called from `VampyRenderer.render` (BEFORE_GIZMOS).
     * Emits all 3D world gizmos and flushes any queued [WorldBoxRequest],
     * [WorldBeaconRequest], and [WorldTracerRequest] in a single pass.
     */
    @JvmStatic
    fun dispatchWorldGizmos(
        client: Minecraft,
        cameraState: CameraRenderState?,
        cameraPos: Vec3?,
        partialTick: Float
    ) {
        ScreenSpaceEspRenderer.emitWorldGizmos(client, cameraState, cameraPos, partialTick)

        if (cameraPos != null) {
            flushQueuedWorldPrimitives(cameraPos)
        } else {
            clearWorldQueues()
        }
    }

    /**
     * Single entry point for flushing queued 2D HUD overlays & registered HUD layers.
     */
    @JvmStatic
    fun dispatchHudLayer(graphics: GuiGraphicsExtractor, deltaTracker: DeltaTracker) {
        for (i in 0 until customHudCallbacks.size) {
            customHudCallbacks[i].invoke(graphics, deltaTracker)
        }

        if (hudTexts.isNotEmpty()) {
            val mc = Minecraft.getInstance()
            val font = mc?.font
            if (font != null) {
                for (i in 0 until hudTexts.size) {
                    val req = hudTexts[i]
                    drawScaledComponent(graphics, font, req.text, req.x, req.y, req.scale, req.color, req.centered)
                }
            }
            hudTexts.clear()
        }
    }

    private inline fun drawScaledComponent(
        graphics: GuiGraphicsExtractor,
        font: net.minecraft.client.gui.Font,
        text: Component,
        x: Int,
        y: Int,
        scale: Float,
        color: Int,
        centered: Boolean
    ) {
        val pose = graphics.pose()
        pose.pushMatrix()
        pose.translate(x.toFloat(), y.toFloat())
        if (scale != 1.0f) {
            pose.scale(scale, scale)
        }
        val drawX = if (centered) -font.width(text) / 2 else 0
        graphics.text(font, text, drawX, 0, color, true)
        pose.popMatrix()
    }

    private fun flushQueuedWorldPrimitives(camPos: Vec3) {
        for (i in 0 until worldBoxes.size) {
            val req = worldBoxes[i]
            val strokeColor = 0xB8000000.toInt() or (req.rgb and 0xFFFFFF)
            val fillColor = ((req.fillAlpha and 0xFF) shl 24) or (req.rgb and 0xFFFFFF)
            Gizmos.cuboid(req.box, GizmoStyle.strokeAndFill(strokeColor, req.strokeWidth, fillColor)).setAlwaysOnTop()
        }
        worldBoxes.clear()

        for (i in 0 until worldBeacons.size) {
            val req = worldBeacons[i]
            val rgb = req.argb and 0xFFFFFF
            val beamBox = AABB(req.x - 0.2, req.y, req.z - 0.2, req.x + 0.2, req.y + 128.0, req.z + 0.2)
            Gizmos.cuboid(beamBox, GizmoStyle.strokeAndFill((0x90 shl 24) or rgb, 1.8f, (0x28 shl 24) or rgb)).setAlwaysOnTop()
            if (!req.label.isNullOrEmpty()) {
                val dx = req.x - camPos.x
                val dy = (req.y + 1.5) - camPos.y
                val dz = req.z - camPos.z
                val dist = kotlin.math.sqrt(dx * dx + dy * dy + dz * dz)
                val scale = Mth.clamp((dist * 0.045).toFloat(), 0.50f, 2.8f)
                Gizmos.billboardText(
                    req.label,
                    Vec3(req.x, req.y + 2.35, req.z),
                    TextGizmo.Style.forColorAndCentered(req.argb or 0xFF000000.toInt()).withScale(scale)
                ).setAlwaysOnTop()
            }
        }
        worldBeacons.clear()

        for (i in 0 until worldTracers.size) {
            val req = worldTracers[i]
            val lineColor = 0xE0000000.toInt() or (req.rgb and 0xFFFFFF)
            Gizmos.line(req.start, req.end, lineColor, req.width).setAlwaysOnTop()
        }
        worldTracers.clear()
    }

    private fun clearWorldQueues() {
        worldBoxes.clear()
        worldBeacons.clear()
        worldTracers.clear()
    }
}
