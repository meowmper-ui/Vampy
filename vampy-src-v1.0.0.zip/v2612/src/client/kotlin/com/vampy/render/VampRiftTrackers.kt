package com.vampy.render

import com.vampy.VampyMod
import com.vampy.chat.LatencyTracker
import com.vampy.chat.TpsTracker
import com.vampy.chat.VampWebSocketManager
import com.vampy.config.VampyConfig
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents
import net.minecraft.ChatFormatting
import net.minecraft.client.DeltaTracker
import net.minecraft.client.Minecraft
import net.minecraft.client.gui.Font
import net.minecraft.client.gui.GuiGraphicsExtractor
import net.minecraft.client.gui.screens.ChatScreen
import net.minecraft.client.resources.sounds.SimpleSoundInstance
import net.minecraft.network.chat.Component
import net.minecraft.network.chat.MutableComponent
import net.minecraft.network.chat.Style
import net.minecraft.network.chat.TextColor
import net.minecraft.resources.Identifier
import net.minecraft.sounds.SoundEvent
import net.minecraft.util.FormattedCharSequence
import net.minecraft.util.Mth
import net.minecraft.world.entity.Entity
import net.minecraft.world.phys.AABB
import net.minecraft.world.phys.Vec3
import net.minecraft.world.scores.DisplaySlot
import net.minecraft.world.scores.PlayerScoreEntry
import net.minecraft.world.scores.Scoreboard
import java.awt.Color
import java.util.*
import java.util.regex.Pattern
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sqrt

// ============================================================================
// Shared Scoreboard & Timer Utilities (deduplicated across all Rift trackers)
// ============================================================================
internal object RiftScoreboardUtils {
    val TIMER_PATTERN: Pattern = Pattern.compile("(\\d+\\.?\\d*)s")
    val PURE_TIMER_PATTERN: Pattern = Pattern.compile("^\\d+(\\.\\d+)?s$")

    fun plainSidebarLine(sb: Scoreboard, entry: PlayerScoreEntry): String {
        val out = StringBuilder()
        val team = sb.getPlayersTeam(entry.owner())
        if (team != null) team.playerPrefix?.let { out.append(it.string) }
        entry.ownerName()?.let { out.append(it.string) }
        if (team != null) team.playerSuffix?.let { out.append(it.string) }
        return WarningHudRenderer.stripFormatting(out.toString().replace('\u00A0', ' '))
    }

    fun parseTimerSeconds(clean: String, fromIdx: Int): Double {
        val m = TIMER_PATTERN.matcher(clean)
        while (m.find()) {
            if (fromIdx < 0 || m.start() >= fromIdx) {
                return m.group(1).toDoubleOrNull() ?: -1.0
            }
        }
        return -1.0
    }
}

// ============================================================================
// 1. HandRenderTracker
// ============================================================================
object HandRenderTracker {
    @Volatile
    private var renderingHands = false

    @JvmStatic
    fun setRenderingHands(rendering: Boolean) {
        renderingHands = rendering
    }

    @JvmStatic
    fun isRenderingHands(): Boolean = renderingHands
}

// ============================================================================
// 2. NearbyEntityCache
// ============================================================================
object NearbyEntityCache {
    private const val REBUILD_INTERVAL_MS = 50L
    private var entities: List<Entity> = emptyList()
    private var lastRebuildMs = 0L
    private var lastRadius = -1.0
    private var lastWorldIdentity = 0

    @JvmStatic
    fun getEntities(client: Minecraft?): List<Entity> {
        if (client == null || client.level == null || client.player == null) {
            entities = emptyList()
            return entities
        }
        val now = System.currentTimeMillis()
        val worldId = System.identityHashCode(client.level)
        val radius = VampyConfig.getRenderDistance()
        if (worldId == lastWorldIdentity && radius == lastRadius && now - lastRebuildMs < REBUILD_INTERVAL_MS && entities.isNotEmpty()) {
            return entities
        }
        val cam = client.gameRenderer.mainCamera.position()
        val searchArea = AABB(cam.x - radius, cam.y - radius, cam.z - radius, cam.x + radius, cam.y + radius, cam.z + radius)
        entities = Collections.unmodifiableList(client.level!!.getEntities(null as Entity?, searchArea) { true })
        lastRebuildMs = now
        lastRadius = radius
        lastWorldIdentity = worldId
        return entities
    }
}

// ============================================================================
// 3. IchorTracker (with Player - Boss - Ichor Alignment Detection for Twinclaw)
// ============================================================================
object IchorTracker {
    /** Bright magenta-pink color used when Player, Boss, and Blood Ichor are aligned on 1 line. */
    const val ALIGNED_PINK_RGB: Int = 0xFF55FF

    private val activeIchorIds = HashSet<UUID>()
    private val activeIchorMarkerIds = HashSet<UUID>()
    private val activeIchorPositions = ArrayList<Vec3>()
    private val lockedPositionsByMarker = HashMap<UUID, Vec3>()

    @JvmStatic
    fun update(client: Minecraft?, entities: List<Entity>?) {
        activeIchorIds.clear()
        activeIchorMarkerIds.clear()
        activeIchorPositions.clear()
        if (!SlayerProfitTracker.isInStillgoreChateau()) {
            lockedPositionsByMarker.clear()
            return
        }
        if (client == null || client.level == null || client.player == null || entities == null) return

        val allBossAnchors = WarningHudRenderer.findAllBossAnchors(entities)
        val allowedBossAnchors = WarningHudRenderer.findAllowedBossAnchors(entities)
        val ichorMarkers = ArrayList<Entity>()

        for (e in entities) {
            if (e != null && e !== client.player && isRealSpawnedIchorMarker(e, allBossAnchors, entities)) {
                val pos = e.position()
                var allowed = false
                val nearestBoss = WarningHudRenderer.findNearestSpawnedByMarker(entities, pos, 28.0)
                if (nearestBoss != null) {
                    allowed = WarningHudRenderer.isAllowedBossAnchor(nearestBoss)
                } else if (allowedBossAnchors.isNotEmpty()) {
                    for (allowedBoss in allowedBossAnchors) {
                        if (allowedBoss.position().distanceTo(pos) <= 28.0) {
                            allowed = true
                            break
                        }
                    }
                } else if (pos.distanceTo(client.player!!.position()) <= 24.0 && WarningHudRenderer.hasSlayTheBossOnSidebar(client)) {
                    allowed = true
                }
                if (allowed) {
                    val id = e.uuid
                    activeIchorIds.add(id)
                    activeIchorMarkerIds.add(id)
                    ichorMarkers.add(e)

                    var locked = lockedPositionsByMarker[id]
                    if (locked == null) {
                        val structStand = findNearestStructureStand(e, entities)
                        locked = if (structStand != null) {
                            Vec3(structStand.x, pos.y, structStand.z)
                        } else {
                            Vec3(pos.x, pos.y, pos.z)
                        }
                        lockedPositionsByMarker[id] = locked
                    }
                    activeIchorPositions.add(locked)
                }
            }
        }

        lockedPositionsByMarker.keys.retainAll(activeIchorMarkerIds)

        if (ichorMarkers.isNotEmpty()) {
            for (ex in entities) {
                if (ex != null && ex !== client.player && !activeIchorIds.contains(ex.uuid) && isCandidateDisplayEntity(ex)) {
                    val p = ex.position()
                    for (marker in ichorMarkers) {
                        val mp = marker.position()
                        val dx = p.x - mp.x
                        val dz = p.z - mp.z
                        val dy = abs(p.y - mp.y)
                        if (dx * dx + dz * dz <= 2.25 && dy <= 2.8) {
                            activeIchorIds.add(ex.uuid)
                            break
                        }
                    }
                }
            }
        }
    }

    /**
     * Returns true when the player, an active/allowed Bloodfiend boss, and [ichorPos] are colinear
     * in the horizontal plane such that a Twinclaw cast from the boss towards the player (or vice versa)
     * passes directly through the Blood Ichor.
     */
    @JvmStatic
    fun isIchorAligned(ichorPos: Vec3?, client: Minecraft?): Boolean {
        if (ichorPos == null || client == null || client.player == null || client.level == null) return false
        val entities = NearbyEntityCache.getEntities(client)
        var bosses = WarningHudRenderer.findAllowedBossAnchors(entities)
        if (bosses.isEmpty() && WarningHudRenderer.hasSlayTheBossOnSidebar(client)) {
            bosses = WarningHudRenderer.findAllBossAnchors(entities)
        }
        if (bosses.isEmpty()) return false

        val px = client.player!!.x
        val pz = client.player!!.z
        val ix = ichorPos.x
        val iz = ichorPos.z

        for (boss in bosses) {
            if (boss == null) continue
            val bx = boss.x
            val bz = boss.z

            // Vector from Player (P) to Boss (B)
            val pbx = bx - px
            val pbz = bz - pz
            val pbLenSq = pbx * pbx + pbz * pbz
            if (pbLenSq < 0.04) continue
            val pbLen = sqrt(pbLenSq)
            if (pbLen > 32.0) continue

            // Unit direction from P to B
            val ux = pbx / pbLen
            val uz = pbz / pbLen

            // Vector from Player (P) to Ichor (I)
            val pix = ix - px
            val piz = iz - pz

            // Projection of Ichor onto PB line (parameter t where P = 0, B = pbLen)
            val t = pix * ux + piz * uz

            // Allow Ichor to be anywhere along or near the Player-Boss line segment (with 2.5m tolerance past P or B)
            if (t < -2.5 || t > pbLen + 2.5) continue

            // Perpendicular distance from Ichor to PB line
            val perpDist = abs(pix * (-uz) + piz * ux)
            if (perpDist <= 1.45) {
                return true
            }
        }
        return false
    }

    private fun findNearestStructureStand(marker: Entity, allEntities: List<Entity>): Entity? {
        val pos = marker.position()
        var best: Entity? = null
        var bestHorizSq = Double.MAX_VALUE
        for (other in allEntities) {
            if (other != null && other !== marker && !other.hasCustomName() && isCandidateDisplayEntity(other)) {
                val dx = other.x - pos.x
                val dz = other.z - pos.z
                val dy = abs(other.y - pos.y)
                val hSq = dx * dx + dz * dz
                if (hSq <= 1.69 && dy <= 2.8 && hSq < bestHorizSq) {
                    bestHorizSq = hSq
                    best = other
                }
            }
        }
        return best
    }

    @JvmStatic
    fun isRealSpawnedIchorMarker(entity: Entity?, allBossAnchors: List<Entity>, allEntities: List<Entity>): Boolean {
        if (entity == null || !entity.hasCustomName() || entity.customName == null) return false
        val clean = WarningHudRenderer.stripFormatting(entity.customName!!.string)
        if (clean.isEmpty()) return false
        val lower = clean.lowercase(Locale.ROOT)

        if (lower.contains("bloodfiend") || lower.contains("spawned by") || lower.contains("slayer boss")
            || (lower.contains("twinclaw")) || lower.contains("mania") || lower.contains("stonewrath")
            || lower.contains("spring") || lower.contains("beacon")
            || clean.contains("❤") || clean.contains("☠") || clean.contains("🛡")
            || clean.contains("🥩") || clean.contains("\uD83E\uDD69")
        ) {
            return false
        }

        val hasIchorWord = lower.contains("ichor")
        val isPureTimer = RiftScoreboardUtils.PURE_TIMER_PATTERN.matcher(clean).matches()
        if (!hasIchorWord && !isPureTimer) return false

        val timerSec = parseTimerSeconds(clean, if (hasIchorWord) lower.indexOf("ichor") else 0)
        if (isPureTimer && (timerSec <= 0.0 || timerSec > 30.0)) return false

        val pos = entity.position()
        for (bossAnchor in allBossAnchors) {
            val bp = bossAnchor.position()
            val dx = pos.x - bp.x
            val dz = pos.z - bp.z
            val dy = abs(pos.y - bp.y)
            if (dx * dx + dz * dz <= 1.21 && dy <= 3.2) return false
        }

        for (other in allEntities) {
            if (other != null && other !== entity && other.hasCustomName() && other.customName != null) {
                val ol = WarningHudRenderer.stripFormatting(other.customName!!.string).lowercase(Locale.ROOT)
                if (ol.contains("bloodfiend") || ol.contains("slayer boss")) {
                    val dx = pos.x - other.x
                    val dz = pos.z - other.z
                    if (dx * dx + dz * dz <= 1.21 && abs(pos.y - other.y) <= 3.2) return false
                }
                if (ol.contains("spring")) {
                    val dx = pos.x - other.x
                    val dz = pos.z - other.z
                    if (dx * dx + dz * dz <= 2.25 && abs(pos.y - other.y) <= 3.0) return false
                }
            }
        }

        val hasStructureStand = findNearestStructureStand(entity, allEntities) != null
        if (isPureTimer && !hasStructureStand) return false
        if (hasIchorWord && (timerSec < 0.0 || timerSec <= 3.5) && !hasStructureStand) return false
        return true
    }

    @JvmStatic
    fun parseTimerSeconds(clean: String, fromIdx: Int): Double =
        RiftScoreboardUtils.parseTimerSeconds(clean, fromIdx)

    @JvmStatic
    fun isNearBoss(entity: Entity?): Boolean = false

    @JvmStatic
    fun isIchor(entity: Entity?): Boolean = entity != null && activeIchorIds.contains(entity.uuid)

    @JvmStatic
    fun isIchorMarker(entity: Entity?): Boolean = entity != null && activeIchorMarkerIds.contains(entity.uuid)

    @JvmStatic
    fun getActiveIchorPositions(): List<Vec3> = activeIchorPositions

    @JvmStatic
    fun getActiveIchorIds(): Set<UUID> = Collections.unmodifiableSet(activeIchorIds)

    private fun isCandidateDisplayEntity(entity: Entity): Boolean {
        if (entity.hasCustomName() && entity.customName != null) {
            val clean = WarningHudRenderer.stripFormatting(entity.customName!!.string).lowercase(Locale.ROOT)
            if (clean.contains("bloodfiend") || clean.contains("spawned by") || clean.contains("slayer boss")
                || (clean.contains("twinclaw")) || clean.contains("spring")
            ) {
                return false
            }
        }
        val typeName = entity.type.toString().lowercase(Locale.ROOT)
        return typeName.contains("armor_stand") || typeName.contains("display") || typeName.contains("skull") || typeName.contains("interaction")
    }
}

// ============================================================================
// 4. KillerSpringTracker
// ============================================================================
object KillerSpringTracker {
    private const val FULL_HEIGHT = 4.0
    private const val MIN_HEIGHT = 0.75

    private val trackedStands = HashSet<UUID>()
    private val activeTimers = ArrayList<TimerInfo>()
    private val espAnchors = ArrayList<EspAnchor>()
    private val activeSpringPositions = ArrayList<Vec3>()
    private val stateByOwner = HashMap<String, SpringState>()
    private var lastScan = 0L

    class EspAnchor(
        @JvmField val x: Double,
        @JvmField val y: Double,
        @JvmField val z: Double,
        @JvmField val height: Double
    ) {
        fun mid(): Vec3 = Vec3(x, y + height * 0.5, z)
    }

    private class SpringState {
        var primaryBoomId: UUID? = null
        val sideIds = HashSet<UUID>()
        var locked = false
        var firstLockedMs = 0L
        var lastSeenBoomMs = 0L
        var lockedX = 0.0
        var lockedY = 0.0
        var lockedZ = 0.0
        var structureAlive = false
    }

    class TimerInfo(
        @JvmField val x: Double,
        @JvmField val y: Double,
        @JvmField val z: Double,
        @JvmField val seconds: Double,
        @JvmField val entityId: UUID
    ) {
        @JvmField
        val text: String = String.format(Locale.ROOT, "SPRING %.1fs", seconds)
        @JvmField
        val color: Int = if (seconds <= 3.0) -43691 else -16711936

        fun text(): String = text
        fun color(): Int = color
    }

    @JvmStatic
    fun clear() {
        stateByOwner.clear()
        espAnchors.clear()
        activeSpringPositions.clear()
        activeTimers.clear()
        trackedStands.clear()
    }

    @JvmStatic
    fun update(client: Minecraft?, entities: List<Entity>?) {
        if (!SlayerProfitTracker.isInStillgoreChateau()) {
            clear()
            return
        }
        if (client != null && client.player != null && client.level != null && entities != null) {
            val now = System.currentTimeMillis()
            if (now - lastScan >= 50L) {
                lastScan = now
                scanOwnership(client, entities, now)
            }
            rebuildEspAnchors(entities)
        }
    }

    private fun scanOwnership(client: Minecraft, entities: List<Entity>, now: Long) {
        trackedStands.clear()
        activeTimers.clear()
        val allBosses = WarningHudRenderer.findAllBossAnchors(entities)
        val bosses = WarningHudRenderer.findAllowedBossAnchors(entities).toMutableList()

        if (bosses.isEmpty() && WarningHudRenderer.hasSlayTheBossOnSidebar(client)) {
            var closest: Entity? = null
            var bestSq = 400.0
            for (b in allBosses) {
                val dSq = b.distanceToSqr(client.player!!)
                if (dSq <= bestSq) {
                    bestSq = dSq
                    closest = b
                }
            }
            if (closest != null) bosses.add(closest)
        }

        if (bosses.isEmpty()) {
            stateByOwner.entries.removeIf { now - it.value.lastSeenBoomMs > 600L }
            return
        }

        val activeOwners = HashSet<String>()
        for (bossMarker in bosses) {
            var owner = WarningHudRenderer.getBossAnchorOwnerKey(bossMarker)
            if (owner.isNullOrEmpty()) {
                owner = "boss_" + bossMarker.uuid.toString().substring(0, 8)
            }
            val key = owner.lowercase(Locale.ROOT)
            activeOwners.add(key)
            val state = stateByOwner.getOrPut(key) { SpringState() }
            scanBossSpring(entities, allBosses, bossMarker, state, now)
        }

        stateByOwner.entries.removeIf { !activeOwners.contains(it.key) && (now - it.value.lastSeenBoomMs > 600L) }
    }

    private fun belongsToThisBoss(candidate: Entity, targetBoss: Entity, allBosses: List<Entity>): Boolean {
        val distToTarget = candidate.position().distanceTo(targetBoss.position())
        if (distToTarget > 16.5) return false
        for (otherBoss in allBosses) {
            if (otherBoss != null && otherBoss !== targetBoss && otherBoss.uuid != targetBoss.uuid) {
                val distToOther = candidate.position().distanceTo(otherBoss.position())
                if (distToOther <= distToTarget + 1.5) return false
            }
        }
        return true
    }

    private fun isNearForeignSpringTag(candidate: Entity, targetBoss: Entity, entities: List<Entity>): Boolean {
        val cPos = candidate.position()
        val distToTarget = cPos.distanceTo(targetBoss.position())
        for (e in entities) {
            if (e != null && e.hasCustomName() && e.customName != null) {
                val lower = WarningHudRenderer.stripFormatting(e.customName!!.string).lowercase(Locale.ROOT)
                if (lower.contains("spring")) {
                    val distTagToTarget = e.position().distanceTo(targetBoss.position())
                    if (distTagToTarget > 3.5) {
                        val distToForeignTag = cPos.distanceTo(e.position())
                        if (distToForeignTag + 1.0 < distToTarget && distToForeignTag <= 16.5) return true
                    }
                }
            }
        }
        return false
    }

    private fun scanBossSpring(entities: List<Entity>, allBosses: List<Entity>, bossMarker: Entity, state: SpringState, now: Long) {
        val bossPos = bossMarker.position()
        var springTag: Entity? = null
        var bossTimerSeconds = -1.0

        for (e in entities) {
            if (e != null && e.hasCustomName() && e.customName != null) {
                val nameText = WarningHudRenderer.stripFormatting(e.customName!!.string)
                val lower = nameText.lowercase(Locale.ROOT)
                var springIdx = lower.indexOf("killer spring")
                if (springIdx < 0) springIdx = lower.indexOf("spring")
                val dx = e.x - bossPos.x
                val dz = e.z - bossPos.z
                val dy = abs(e.y - bossPos.y)
                if (springIdx >= 0 && (dx * dx + dz * dz <= 9.0) && dy <= 4.5 && belongsToThisBoss(e, bossMarker, allBosses)) {
                    bossTimerSeconds = RiftScoreboardUtils.parseTimerSeconds(nameText, springIdx)
                    springTag = e
                    break
                }
            }
        }

        if (springTag == null && (!state.locked || now - state.lastSeenBoomMs > 600L)) {
            if (now - state.lastSeenBoomMs > 450L) clearStructure(state)
            return
        }

        val boomEntities = ArrayList<Entity>()
        for (ex in entities) {
            if (ex != null && ex.hasCustomName() && ex.customName != null) {
                val cleanName = WarningHudRenderer.stripFormatting(ex.customName!!.string)
                if (cleanName.uppercase(Locale.ROOT).contains("BOOM")
                    && abs(bossMarker.y - ex.y) <= 20.0
                    && belongsToThisBoss(ex, bossMarker, allBosses)
                    && !isNearForeignSpringTag(ex, bossMarker, entities)
                ) {
                    boomEntities.add(ex)
                    if (bossTimerSeconds < 0.0) {
                        bossTimerSeconds = RiftScoreboardUtils.parseTimerSeconds(cleanName, 0)
                    }
                }
            }
        }

        if (boomEntities.isEmpty()) {
            if (now - state.lastSeenBoomMs > 450L) clearStructure(state)
            return
        }

        state.structureAlive = true
        state.lastSeenBoomMs = now
        for (boom in boomEntities) trackedStands.add(boom.uuid)

        val primaryBoom = pickPrimaryBoom(boomEntities, entities, bossMarker, state.primaryBoomId)
        state.primaryBoomId = primaryBoom.uuid

        if (bossTimerSeconds >= 0.0) {
            activeTimers.add(TimerInfo(bossPos.x, bossPos.y, bossPos.z, bossTimerSeconds, primaryBoom.uuid))
        } else {
            if (state.firstLockedMs == 0L) state.firstLockedMs = now
            val rem = max(0.0, 12.0 - (now - state.firstLockedMs) / 1000.0)
            if (rem > 0.1) activeTimers.add(TimerInfo(bossPos.x, bossPos.y, bossPos.z, rem, primaryBoom.uuid))
        }

        val seenSides = HashSet<UUID>()
        for (exx in entities) {
            if (exx != null && exx !== primaryBoom && exx.hasCustomName() && exx.customName != null) {
                val name = WarningHudRenderer.stripFormatting(exx.customName!!.string).uppercase(Locale.ROOT)
                if (name.contains("LEFT") || name.contains("RIGHT") || name.contains("CLICK")) {
                    val dx = exx.x - primaryBoom.x
                    val dz = exx.z - primaryBoom.z
                    if (dx * dx + dz * dz <= 4.0 && abs(exx.y - primaryBoom.y) <= 4.5) {
                        trackedStands.add(exx.uuid)
                        if (name.contains("LEFT") || name.contains("RIGHT")) seenSides.add(exx.uuid)
                    }
                }
            }
        }

        state.sideIds.clear()
        state.sideIds.addAll(seenSides)

        val boomX = primaryBoom.x
        val boomZ = primaryBoom.z
        val boomY = primaryBoom.y

        var topStructStand: Entity? = null
        var bestStructHorizSq = 0.64
        for (other in entities) {
            if (other != null && other !== primaryBoom && !other.hasCustomName()) {
                val typeName = other.type.toString().lowercase(Locale.ROOT)
                if (typeName.contains("armor_stand") || typeName.contains("display")) {
                    val dx = other.x - boomX
                    val dz = other.z - boomZ
                    val dy = boomY - other.y
                    val hSq = dx * dx + dz * dz
                    if (hSq <= bestStructHorizSq && dy in 0.0..4.2) {
                        bestStructHorizSq = hSq
                        topStructStand = other
                    }
                }
            }
        }

        val targetX = topStructStand?.x ?: boomX
        val targetZ = topStructStand?.z ?: boomZ
        val targetBaseY = boomY - FULL_HEIGHT

        if (!state.locked) {
            state.locked = true
            state.firstLockedMs = now
            state.lockedX = targetX
            state.lockedZ = targetZ
            state.lockedY = targetBaseY
        } else {
            val driftSq = (targetX - state.lockedX) * (targetX - state.lockedX) + (targetZ - state.lockedZ) * (targetZ - state.lockedZ)
            if (driftSq > 0.0025) {
                state.lockedX = targetX
                state.lockedZ = targetZ
                state.lockedY = targetBaseY
            }
        }
    }

    private fun clearStructure(state: SpringState) {
        state.locked = false
        state.firstLockedMs = 0L
        state.lastSeenBoomMs = 0L
        state.sideIds.clear()
        state.primaryBoomId = null
        state.structureAlive = false
    }

    private fun pickPrimaryBoom(boomEntities: List<Entity>, allEntities: List<Entity>, bossMarker: Entity, stickyId: UUID?): Entity {
        var bestWithClickOrSides: Entity? = null
        var bestDistSq = Double.MAX_VALUE
        for (boom in boomEntities) {
            var hasCompanion = false
            for (ex in allEntities) {
                if (ex != null && ex !== boom && ex.hasCustomName() && ex.customName != null) {
                    val name = WarningHudRenderer.stripFormatting(ex.customName!!.string).uppercase(Locale.ROOT)
                    if ((name.contains("CLICK") || name.contains("LEFT") || name.contains("RIGHT")) && ex.distanceToSqr(boom) <= 4.0) {
                        hasCompanion = true
                        break
                    }
                }
            }
            val dSq = boom.distanceToSqr(bossMarker)
            if (hasCompanion && dSq < bestDistSq) {
                bestDistSq = dSq
                bestWithClickOrSides = boom
            }
        }
        if (bestWithClickOrSides != null) return bestWithClickOrSides
        if (stickyId != null) {
            boomEntities.firstOrNull { stickyId == it.uuid }?.let { return it }
        }
        return boomEntities.minByOrNull { it.distanceToSqr(bossMarker) } ?: boomEntities[0]
    }

    private fun rebuildEspAnchors(entities: List<Entity>) {
        espAnchors.clear()
        activeSpringPositions.clear()
        if (stateByOwner.isEmpty()) return

        val byId = HashMap<UUID, Entity>(max(16, entities.size * 2))
        for (e in entities) if (e != null) byId[e.uuid] = e

        for (state in stateByOwner.values) {
            if (state.structureAlive && state.locked) {
                val boom = state.primaryBoomId?.let { byId[it] }
                val sides = state.sideIds.mapNotNull { byId[it] }
                if (boom != null) {
                    val bx = boom.x
                    val bz = boom.z
                    val driftSq = (bx - state.lockedX) * (bx - state.lockedX) + (bz - state.lockedZ) * (bz - state.lockedZ)
                    if (driftSq > 0.25) {
                        state.lockedX = bx
                        state.lockedZ = bz
                        state.lockedY = boom.y - FULL_HEIGHT
                    }
                }
                val topY = boom?.let { lerpPos(it).y } ?: (state.lockedY + FULL_HEIGHT)
                var maxSideY = topY
                for (e in sides) {
                    val y = lerpPos(e).y
                    if (y > maxSideY) maxSideY = y
                }
                val height = Mth.clamp(maxSideY - state.lockedY, MIN_HEIGHT, FULL_HEIGHT)
                espAnchors.add(EspAnchor(state.lockedX, state.lockedY, state.lockedZ, height))
                activeSpringPositions.add(Vec3(state.lockedX, state.lockedY, state.lockedZ))
            }
        }
    }

    private fun lerpPos(e: Entity): Vec3 {
        val pt = try {
            Minecraft.getInstance()?.deltaTracker?.getGameTimeDeltaPartialTick(false) ?: 1.0f
        } catch (_: Exception) {
            1.0f
        }
        return Vec3(
            Mth.lerp(pt.toDouble(), e.xo, e.x),
            Mth.lerp(pt.toDouble(), e.yo, e.y),
            Mth.lerp(pt.toDouble(), e.zo, e.z)
        )
    }

    @JvmStatic
    fun isKillerSpringPart(e: Entity?): Boolean = e != null && trackedStands.contains(e.uuid)

    @JvmStatic
    fun isKillerSpring(entity: Entity?): Boolean = isKillerSpringPart(entity)

    @JvmStatic
    fun isKillerSpringMarker(entity: Entity?): Boolean = isKillerSpringPart(entity)

    @JvmStatic
    fun isLocked(): Boolean = stateByOwner.values.any { it.locked }

    @JvmStatic
    fun getEspAnchors(): List<EspAnchor> = espAnchors

    @JvmStatic
    fun getActiveSpringPositions(): List<Vec3> = activeSpringPositions

    @JvmStatic
    fun getActiveTimers(): List<TimerInfo> = activeTimers

    @JvmStatic
    fun getActiveSpringIds(): Set<UUID> = Collections.unmodifiableSet(trackedStands)

    @JvmStatic
    fun hasActiveSpring(): Boolean = espAnchors.isNotEmpty() || activeTimers.isNotEmpty()
}

// ============================================================================
// 5. EffigyTracker
// ============================================================================
object EffigyTracker {
    class Effigy(
        @JvmField val index: Int,
        @JvmField val x: Int,
        @JvmField val y: Int,
        @JvmField val z: Int
    ) {
        @JvmField
        val center: Vec3 = Vec3(x + 0.5, y.toDouble(), z + 0.5)
    }

    private val EFFIGIES = listOf(
        Effigy(1, 150, 74, 95),
        Effigy(2, 193, 88, 119),
        Effigy(3, 235, 105, 147),
        Effigy(4, 293, 91, 134),
        Effigy(5, 262, 94, 94),
        Effigy(6, 240, 124, 118)
    )

    private val sidebarNeedsBreak = BooleanArray(7)
    private val sidebarSlotKnown = BooleanArray(7)
    @Volatile
    private var sidebarPresent = false
    @Volatile
    private var sidebarParsedOk = false
    @Volatile
    private var sidebarSlotCount = 0
    private var lastSidebarScan = 0L
    private var loggedParseFailure = false

    private val worldNeedsBreak = BooleanArray(7)
    private val worldKnown = BooleanArray(7)
    private var lastWorldScan = 0L

    private class ColoredChar(val ch: Char, val legacy: Char, val rgb: Int?)

    @JvmStatic
    fun all(): List<Effigy> = EFFIGIES

    @JvmStatic
    fun updateSidebar(client: Minecraft?) {
        val now = System.currentTimeMillis()
        if (now - lastSidebarScan < 250L) return
        lastSidebarScan = now
        try {
            val level = client?.level ?: run {
                clearSidebar()
                return
            }
            val sb = level.scoreboard
            val obj = sb.getDisplayObjective(DisplaySlot.SIDEBAR) ?: run {
                clearSidebar()
                return
            }

            var chars: List<ColoredChar>? = null
            for (entry in sb.listPlayerScores(obj)) {
                val line = styledLine(sb, entry)
                if (toPlain(line).lowercase(Locale.ROOT).contains("effigies")) {
                    chars = line
                    break
                }
            }
            if (chars == null) {
                clearSidebar()
                return
            }

            sidebarPresent = true
            val needsBreak = arrayOfNulls<Boolean>(7)
            val idx = parseSlots(chars, needsBreak)
            sidebarSlotCount = idx

            if (idx >= 5) {
                for (i in 1..6) {
                    val v = if (i <= idx) needsBreak[i] else null
                    if (v != null) {
                        sidebarNeedsBreak[i] = v
                        sidebarSlotKnown[i] = true
                    } else if (!sidebarSlotKnown[i]) {
                        sidebarNeedsBreak[i] = false
                    }
                }
                sidebarParsedOk = true
                loggedParseFailure = false
            } else {
                sidebarParsedOk = false
            }
        } catch (_: Exception) {
            clearSidebar()
        }
    }

    private fun clearSidebar() {
        sidebarPresent = false
        sidebarParsedOk = false
        sidebarSlotCount = 0
    }

    private fun parseSlots(chars: List<ColoredChar>, needsBreakOut: Array<Boolean?>): Int {
        var i = 0
        val acc = StringBuilder()
        var startMarkers = -1
        while (i < chars.size) {
            val c = chars[i].ch
            if (c == '\u00A7') {
                i += 2
                continue
            }
            acc.append(c.lowercaseChar())
            if (acc.toString().endsWith("effigies")) {
                i++
                while (i < chars.size && chars[i].ch.isWhitespace()) i++
                if (i < chars.size && chars[i].ch == ':') i++
                while (i < chars.size && chars[i].ch.isWhitespace()) i++
                startMarkers = i
                break
            }
            i++
        }
        if (startMarkers < 0) return 0

        var idx = 0
        i = startMarkers
        while (i < chars.size && idx < 6) {
            val cc = chars[i]
            if (cc.ch == '\u00A7') {
                i += 2
                continue
            }
            if (!cc.ch.isWhitespace()) {
                needsBreakOut[idx + 1] = isNeedsBreakColor(cc)
                idx++
            }
            i++
        }
        return idx
    }

    private fun isNeedsBreakColor(cc: ColoredChar): Boolean? {
        when (cc.legacy) {
            '7', '8' -> return true
            'c', '4', '5', 'd', '9', 'b', '3', '1' -> return false
        }
        val rgb = cc.rgb ?: return null
        val r = (rgb shr 16) and 0xFF
        val g = (rgb shr 8) and 0xFF
        val b = rgb and 0xFF
        val maxC = max(r, max(g, b))
        val minC = min(r, min(g, b))
        if (r >= 140 && r > g + 25 && r > b + 25) return false
        if (b > r + 20 || (g < 80 && b >= r && b > 80)) return false
        if (maxC - minC <= 50 && maxC >= 40) return true
        return null
    }

    @JvmStatic
    fun updateWorld(client: Minecraft?) {
        val now = System.currentTimeMillis()
        if (now - lastWorldScan < 500L) return
        lastWorldScan = now
        try {
            val level = client?.level ?: return
            if ("minecraft:the_end" != level.dimension().identifier().toString()) return
            for (eff in EFFIGIES) {
                val area = AABB(
                    eff.center.x - 10, eff.center.y - 10, eff.center.z - 10,
                    eff.center.x + 10, eff.center.y + 12, eff.center.z + 10
                )
                var state: Boolean? = null
                for (e in level.getEntities(null as Entity?, area) { it.hasCustomName() }) {
                    val name = e.customName?.string?.lowercase(Locale.ROOT) ?: continue
                    if (name.contains("respawn")) {
                        state = false
                        break
                    }
                    if (name.contains("break it!")) {
                        state = true
                        break
                    }
                }
                if (state == null) {
                    worldKnown[eff.index] = false
                } else {
                    worldNeedsBreak[eff.index] = state
                    worldKnown[eff.index] = true
                }
            }
        } catch (_: Exception) {
        }
    }

    private fun styledLine(sb: Scoreboard, entry: PlayerScoreEntry): List<ColoredChar> {
        val out = ArrayList<ColoredChar>()
        val team = sb.getPlayersTeam(entry.owner())
        var base = Style.EMPTY
        if (team != null) {
            val teamColor = team.color
            if (teamColor != null && teamColor != ChatFormatting.RESET) {
                base = base.withColor(teamColor)
            }
        }
        if (team != null) appendStyled(out, team.playerPrefix, base)
        appendStyled(out, entry.ownerName(), base)
        if (team != null) appendStyled(out, team.playerSuffix, base)
        return out
    }

    private fun appendStyled(out: MutableList<ColoredChar>, component: Component?, base: Style) {
        if (component == null) return
        component.visit({ style, text ->
            if (text.isNullOrEmpty()) return@visit Optional.empty<Unit>()
            val merged = style.applyTo(base)
            var runLegacy = legacyCode(merged)
            var runRgb = merged.color?.value
            var i = 0
            while (i < text.length) {
                val c = text[i]
                if (c == '\u00A7' && i + 1 < text.length) {
                    val code = text[i + 1].lowercaseChar()
                    i += 2
                    if (code == 'r') {
                        runLegacy = 0.toChar()
                        runRgb = null
                    } else if (code in '0'..'9' || code in 'a'..'f') {
                        runLegacy = code
                        runRgb = rgbForLegacy(code)
                    }
                    continue
                }
                out.add(ColoredChar(c, runLegacy, runRgb))
                i++
            }
            Optional.empty<Unit>()
        }, base)
    }

    private fun rgbForLegacy(code: Char): Int? {
        val fmt = ChatFormatting.getByCode(code) ?: return null
        return TextColor.fromLegacyFormat(fmt)?.value
    }

    private fun legacyCode(style: Style): Char {
        val color = style.color ?: return 0.toChar()
        val rgb = color.value and 0xFFFFFF
        var best: ChatFormatting? = null
        var bestDist = Int.MAX_VALUE
        val r = (rgb shr 16) and 0xFF
        val g = (rgb shr 8) and 0xFF
        val b = rgb and 0xFF
        for (fmt in ChatFormatting.entries) {
            val legacy = TextColor.fromLegacyFormat(fmt) ?: continue
            val lv = legacy.value and 0xFFFFFF
            if (lv == rgb) return fmt.char
            val lr = (lv shr 16) and 0xFF
            val lg = (lv shr 8) and 0xFF
            val lb = lv and 0xFF
            val dist = (r - lr) * (r - lr) + (g - lg) * (g - lg) + (b - lb) * (b - lb)
            if (dist < bestDist) {
                bestDist = dist
                best = fmt
            }
        }
        return if (best != null && bestDist <= 1600) best.char else 0.toChar()
    }

    private fun toPlain(chars: List<ColoredChar>): String {
        val sb = StringBuilder(chars.size)
        for (cc in chars) if (cc.ch != '\u00A7') sb.append(cc.ch)
        return sb.toString()
    }

    @JvmStatic
    fun isSidebarPresent(): Boolean = sidebarPresent

    @JvmStatic
    fun hasRenderSignal(): Boolean = sidebarParsedOk || (1..6).any { worldKnown[it] }

    @JvmStatic
    fun isSpotNeedsBreak(spotIndex: Int): Boolean {
        if (spotIndex !in 1..6) return false
        if (worldKnown[spotIndex]) return worldNeedsBreak[spotIndex]
        return if (sidebarParsedOk) sidebarNeedsBreak[spotIndex] else false
    }
}

// ============================================================================
// 6. RiftTimeReminderTracker
// ============================================================================
object RiftTimeReminderTracker {
    const val WARNING_TEXT = "ONLY 4 MINS LEFT"
    const val WARNING_COLOR = 0xFFFF5555.toInt()
    const val WARNING_LINGER_MS = 2000L
    const val WARNING_FADE_MS = 400L

    private const val THRESHOLD_SECONDS = 240
    private const val SCAN_INTERVAL_MS = 250L
    private const val MAX_XP_LEVEL_SECONDS = 8 * 3600

    private val TIME_HM_S = Pattern.compile("(?:(\\d+)\\s*h\\s*)?(\\d+)\\s*m\\s*(\\d+)\\s*s", Pattern.CASE_INSENSITIVE)
    private val TIME_LEFT_ONLY = Pattern.compile("(\\d+)\\s*s\\s*Left", Pattern.CASE_INSENSITIVE)
    private val TIME_S_ONLY = Pattern.compile("(?<![\\dmh])(\\d+)\\s*s(?:\\s*Left)?\\b", Pattern.CASE_INSENSITIVE)

    private val ANVIL_LAND = SoundEvent.createVariableRangeEvent(
        Identifier.fromNamespaceAndPath("minecraft", "block.anvil.land")
    )

    private var lastScanMs = 0L
    private var lastActionBar = ""
    private var lastSeconds = -1
    private var wasAtOrBelow = false
    private var pendingTrigger = false
    private var inRift = false

    @JvmStatic
    fun onActionBar(plainText: String?) {
        if (plainText == null) return
        lastActionBar = WarningHudRenderer.stripFormatting(plainText.replace('\u00A0', ' '))
    }

    @JvmStatic
    fun update(client: Minecraft?) {
        if (!VampyConfig.isRiftTimeReminder()) {
            wasAtOrBelow = false
            pendingTrigger = false
            return
        }
        if (client == null || client.level == null || client.player == null) {
            wasAtOrBelow = false
            pendingTrigger = false
            inRift = false
            return
        }
        val now = System.currentTimeMillis()
        if (now - lastScanMs < SCAN_INTERVAL_MS) return
        lastScanMs = now

        inRift = detectInRift(client)
        if (!inRift) {
            wasAtOrBelow = false
            pendingTrigger = false
            lastSeconds = -1
            return
        }

        val seconds = parseRemainingSeconds(client)
        lastSeconds = seconds
        if (seconds < 0) return

        val atOrBelow = seconds <= THRESHOLD_SECONDS
        if (atOrBelow && !wasAtOrBelow) {
            pendingTrigger = true
            try {
                client.soundManager.play(SimpleSoundInstance.forUI(ANVIL_LAND, 1.0f))
            } catch (_: Exception) {
            }
        }
        wasAtOrBelow = atOrBelow
    }

    @JvmStatic
    fun consumeTrigger(): Boolean {
        if (!pendingTrigger) return false
        pendingTrigger = false
        return true
    }

    @JvmStatic
    fun isInRift(): Boolean = inRift

    @JvmStatic
    fun getLastSeconds(): Int = lastSeconds

    private fun detectInRift(client: Minecraft): Boolean {
        if (SlayerProfitTracker.isInStillgoreChateau()) return true
        return try {
            val sb = client.level!!.scoreboard
            val obj = sb.getDisplayObjective(DisplaySlot.SIDEBAR) ?: return false
            var hasRiftDimension = WarningHudRenderer.stripFormatting(obj.displayName.string).lowercase(Locale.ROOT).contains("rift dimension")
            var hasMotes = false
            for (entry in sb.listPlayerScores(obj)) {
                val plain = RiftScoreboardUtils.plainSidebarLine(sb, entry).lowercase(Locale.ROOT)
                if (plain.contains("rift dimension")) hasRiftDimension = true
                if (plain.contains("motes")) hasMotes = true
                if (hasRiftDimension && hasMotes) return true
            }
            hasRiftDimension && hasMotes
        } catch (_: Exception) {
            false
        }
    }

    private fun parseRemainingSeconds(client: Minecraft): Int {
        val fromBar = parseTimeSeconds(lastActionBar)
        if (fromBar >= 0) return fromBar
        val level = client.player?.experienceLevel ?: 0
        return if (level in 1..MAX_XP_LEVEL_SECONDS) level else -1
    }

    @JvmStatic
    fun parseTimeSeconds(text: String?): Int {
        if (text.isNullOrEmpty()) return -1
        val plain = WarningHudRenderer.stripFormatting(text.replace('\u00A0', ' '))
        if (plain.isEmpty()) return -1

        val hm = TIME_HM_S.matcher(plain)
        if (hm.find()) {
            val h = hm.group(1)?.toIntOrNull() ?: 0
            val m = hm.group(2)?.toIntOrNull() ?: return -1
            val s = hm.group(3)?.toIntOrNull() ?: return -1
            return h * 3600 + m * 60 + s
        }
        val left = TIME_LEFT_ONLY.matcher(plain)
        if (left.find()) return left.group(1)?.toIntOrNull() ?: -1
        val sOnly = TIME_S_ONLY.matcher(plain)
        if (sOnly.find()) return sOnly.group(1)?.toIntOrNull() ?: -1
        return -1
    }
}

// ============================================================================
// 7. SlayerSidebarTracker
// ============================================================================
object SlayerSidebarTracker {
    const val BOSS_SOON_TEXT = "Boss spawn soon!"
    const val BOSS_SOON_COLOR = -43691

    private val KILLS = Pattern.compile("([\\d,]+(?:\\.\\d+)?[kKmM]?)\\s*/\\s*([\\d,]+(?:\\.\\d+)?[kKmM]?)\\s*Kills", Pattern.CASE_INSENSITIVE)
    private val XP = Pattern.compile("\\(?\\s*([\\d,]+(?:\\.\\d+)?[kKmM]?)\\s*/\\s*([\\d,]+(?:\\.\\d+)?[kKmM]?)\\s*\\)?\\s*Combat\\s*XP", Pattern.CASE_INSENSITIVE)

    private var lastScanMs = 0L
    private var bossSoon = false
    private var wasBossSoon = false
    private var pendingTrigger = false

    @JvmStatic
    fun update(client: Minecraft?) {
        val now = System.currentTimeMillis()
        if (now - lastScanMs >= 50L) {
            lastScanMs = now
            val soon = detectBossSoon(client)
            if (soon && !wasBossSoon) pendingTrigger = true
            wasBossSoon = soon
            bossSoon = soon
        }
    }

    @JvmStatic
    fun isBossSoon(): Boolean = bossSoon

    @JvmStatic
    fun consumeBossSoonTrigger(): Boolean {
        if (!pendingTrigger) return false
        pendingTrigger = false
        return true
    }

    private fun detectBossSoon(client: Minecraft?): Boolean {
        val level = client?.level ?: return false
        return try {
            val sb = level.scoreboard
            val obj = sb.getDisplayObjective(DisplaySlot.SIDEBAR) ?: return false
            val entries = ArrayList(sb.listPlayerScores(obj))
            entries.sortWith(Comparator.comparingInt(PlayerScoreEntry::value).reversed())
            var inSlayerSection = false
            var linesAfterHeader = 0

            for (entry in entries) {
                val plain = RiftScoreboardUtils.plainSidebarLine(sb, entry)
                if (plain.isEmpty()) continue
                val lower = plain.lowercase(Locale.ROOT)
                if (lower.contains("motes") || lower.contains("purse") || lower.contains("bits")) {
                    inSlayerSection = false
                } else if (lower.contains("slayer quest")) {
                    inSlayerSection = true
                    linesAfterHeader = 0
                } else if (inSlayerSection) {
                    if (++linesAfterHeader > 4) {
                        inSlayerSection = false
                    } else {
                        val kills = KILLS.matcher(plain)
                        if (kills.find()) {
                            val cur = parseNumber(kills.group(1))
                            val maxN = parseNumber(kills.group(2))
                            return maxN > 0.0 && cur >= 0.0 && cur < maxN && cur / maxN > 0.75
                        }
                        val xp = XP.matcher(plain)
                        if (xp.find()) {
                            val cur = parseNumber(xp.group(1))
                            val maxN = parseNumber(xp.group(2))
                            return maxN > 0.0 && cur >= 0.0 && cur < maxN && cur / maxN > 0.75
                        }
                    }
                }
            }
            false
        } catch (_: Exception) {
            false
        }
    }

    private fun parseNumber(raw: String?): Double {
        if (raw.isNullOrEmpty()) return -1.0
        var s = raw.replace(",", "").trim().lowercase(Locale.ROOT)
        var mult = 1.0
        if (s.endsWith("k")) {
            mult = 1_000.0
            s = s.dropLast(1)
        } else if (s.endsWith("m")) {
            mult = 1_000_000.0
            s = s.dropLast(1)
        }
        return (s.toDoubleOrNull() ?: return -1.0) * mult
    }
}

// ============================================================================
// 8. CustomCrosshairRenderer
// ============================================================================
object CustomCrosshairRenderer {
    private const val OUTLINE = 0xFF000000.toInt()
    private const val CHROMA_PERIOD_MS = 3000L

    private class Metrics(val arm: Int, val gap: Int, val thick: Int, val outline: Int, val half: Int) {
        companion object {
            fun forScale(scale: Float): Metrics {
                val s = scale.coerceIn(0.25f, 3f)
                var thick = max(1, (2f * s).roundToInt())
                val gap = max(1, (2f * s).roundToInt())
                val outline = if (s < 0.6f || thick > 3) 0 else 1
                var arm = max((6f * s).roundToInt(), gap + thick + max(1, s.roundToInt()))
                if (thick > 1 && (thick and 1) != 0) thick++
                arm = max(arm, gap + thick + max(1, max(s, 0.25f).roundToInt()))
                if (arm <= gap) arm = gap + 1
                return Metrics(arm, gap, thick, outline, thick / 2)
            }
        }
    }

    @JvmStatic
    fun render(graphics: GuiGraphicsExtractor) {
        renderAt(graphics, graphics.guiWidth() / 2f, graphics.guiHeight() / 2f)
    }

    @JvmStatic
    fun renderAt(graphics: GuiGraphicsExtractor, cx: Int, cy: Int) {
        renderAt(graphics, cx.toFloat(), cy.toFloat())
    }

    @JvmStatic
    fun renderAt(graphics: GuiGraphicsExtractor, cx: Float, cy: Float) {
        val color = resolveColor()
        val m = Metrics.forScale(VampyConfig.getCrosshairScale().toFloat())
        graphics.pose().pushMatrix()
        graphics.pose().translate(cx, cy)
        try {
            when (VampyConfig.getCrosshairStyleEnum()) {
                VampyConfig.CrosshairStyle.DOT -> drawDot(graphics, m, color)
                VampyConfig.CrosshairStyle.CIRCLE -> drawCircle(graphics, m, color)
                VampyConfig.CrosshairStyle.CROSS_DOT -> {
                    drawCross(graphics, m, color, m.arm, m.gap, m.thick)
                    drawDot(graphics, m, color)
                }
                VampyConfig.CrosshairStyle.T_SHAPE -> drawT(graphics, m, color)
                VampyConfig.CrosshairStyle.CORNERS -> drawCorners(graphics, m, color)
                VampyConfig.CrosshairStyle.OPEN_CROSS -> {
                    val openGap = max(m.gap + 1, m.arm / 2)
                    val openArm = max(m.arm, openGap + max(1, m.thick))
                    drawCross(graphics, m, color, openArm, openGap, m.thick)
                }
                VampyConfig.CrosshairStyle.DIAGONAL_X -> drawDiagonalX(graphics, m, color)
                VampyConfig.CrosshairStyle.BOX -> drawBox(graphics, m, color)
                VampyConfig.CrosshairStyle.CHEVRONS -> drawChevrons(graphics, m, color)
                VampyConfig.CrosshairStyle.HOLLOW_CROSS -> drawHollowCross(graphics, m, color)
                VampyConfig.CrosshairStyle.TRIPLE_DOT -> drawTripleDot(graphics, m, color)
                else -> drawCross(graphics, m, color, m.arm, m.gap, m.thick)
            }
        } finally {
            graphics.pose().popMatrix()
        }
    }

    @JvmStatic
    fun resolveColor(): Int {
        if (VampyConfig.isCrosshairChroma()) {
            val hue = (System.currentTimeMillis() % CHROMA_PERIOD_MS) / CHROMA_PERIOD_MS.toFloat()
            return 0xFF000000.toInt() or (Color.HSBtoRGB(hue, 0.95f, 1f) and 0x00FFFFFF)
        }
        return VampyConfig.getCrosshairColor()
    }

    private fun drawCross(g: GuiGraphicsExtractor, m: Metrics, color: Int, armIn: Int, gapIn: Int, thick: Int) {
        val half = thick / 2
        val gap = max(0, gapIn)
        val arm = if (armIn <= gap) gap + 1 else armIn
        if (m.outline > 0) drawCrossLayer(g, arm, gap, thick, half, OUTLINE, m.outline)
        drawCrossLayer(g, arm, gap, thick, half, color, 0)
    }

    private fun drawCrossLayer(g: GuiGraphicsExtractor, arm: Int, gap: Int, thick: Int, half: Int, color: Int, o: Int) {
        val y0 = -half - o
        val y1 = -half + thick + o
        fill(g, gap - o, y0, arm + o, y1, color)
        fill(g, -arm - o, y0, -gap + o, y1, color)
        val x0 = -half - o
        val x1 = -half + thick + o
        fill(g, x0, gap - o, x1, arm + o, color)
        fill(g, x0, -arm - o, x1, -gap + o, color)
    }

    private fun drawT(g: GuiGraphicsExtractor, m: Metrics, color: Int) {
        if (m.outline > 0) drawTLayer(g, m.arm, m.thick, m.half, OUTLINE, m.outline)
        drawTLayer(g, m.arm, m.thick, m.half, color, 0)
    }

    private fun drawTLayer(g: GuiGraphicsExtractor, arm: Int, thick: Int, half: Int, color: Int, o: Int) {
        fill(g, -arm - o, -half - o, arm + o, -half + thick + o, color)
        fill(g, -half - o, -arm - o, -half + thick + o, -half + o, color)
    }

    private fun drawDot(g: GuiGraphicsExtractor, m: Metrics, color: Int) {
        val r = max(1, (m.thick + 1) / 2)
        if (m.outline > 0) fill(g, -r - 1, -r - 1, r + 1, r + 1, OUTLINE)
        fill(g, -r, -r, r, r, color)
    }

    private fun drawCircle(g: GuiGraphicsExtractor, m: Metrics, color: Int) {
        val r = max(2, m.arm - max(0, m.arm / 6))
        if (m.outline > 0) stampRing(g, r + 1, OUTLINE)
        stampRing(g, r, color)
    }

    private fun stampRing(g: GuiGraphicsExtractor, r: Int, color: Int) {
        val r2 = r * r
        val inner = max(0, r - 1)
        val inner2 = inner * inner
        for (y in -r..r) {
            for (x in -r..r) {
                val d2 = x * x + y * y
                if (d2 in inner2..r2) fill(g, x, y, x + 1, y + 1, color)
            }
        }
    }

    private fun drawCorners(g: GuiGraphicsExtractor, m: Metrics, color: Int) {
        val d = max(2, m.gap + 1)
        val len = max(2, m.arm - d)
        if (m.outline > 0) drawCornersLayer(g, d, len, m.thick, OUTLINE, m.outline)
        drawCornersLayer(g, d, len, m.thick, color, 0)
    }

    private fun drawCornersLayer(g: GuiGraphicsExtractor, d: Int, len: Int, thick: Int, color: Int, o: Int) {
        fill(g, -d - len - o, -d - o, -d + o, -d + thick + o, color)
        fill(g, -d - o, -d - len - o, -d + thick + o, -d + o, color)
        fill(g, d - o, -d - o, d + len + o, -d + thick + o, color)
        fill(g, d - thick - o, -d - len - o, d + o, -d + o, color)
        fill(g, -d - len - o, d - thick - o, -d + o, d + o, color)
        fill(g, -d - o, d - o, -d + thick + o, d + len + o, color)
        fill(g, d - o, d - thick - o, d + len + o, d + o, color)
        fill(g, d - thick - o, d - o, d + o, d + len + o, color)
    }

    private fun drawDiagonalX(g: GuiGraphicsExtractor, m: Metrics, color: Int) {
        if (m.outline > 0) stampDiagonalX(g, m.arm, m.gap, m.thick + 2, OUTLINE)
        stampDiagonalX(g, m.arm, m.gap, m.thick, color)
    }

    private fun stampDiagonalX(g: GuiGraphicsExtractor, arm: Int, gap: Int, thick: Int, color: Int) {
        val half = thick / 2
        for (i in gap..arm) {
            fill(g, i - half, i - half, i - half + thick, i - half + thick, color)
            fill(g, -i - half, -i - half, -i - half + thick, -i - half + thick, color)
            fill(g, i - half, -i - half, i - half + thick, -i - half + thick, color)
            fill(g, -i - half, i - half, -i - half + thick, i - half + thick, color)
        }
    }

    private fun drawBox(g: GuiGraphicsExtractor, m: Metrics, color: Int) {
        val r = max(2, m.arm)
        val t = m.thick
        if (m.outline > 0) {
            fill(g, -r - 1, -r - 1, r + 1, -r + t, OUTLINE)
            fill(g, -r - 1, r - t, r + 1, r + 1, OUTLINE)
            fill(g, -r - 1, -r - 1, -r + t, r + 1, OUTLINE)
            fill(g, r - t, -r - 1, r + 1, r + 1, OUTLINE)
        }
        fill(g, -r, -r, r, -r + t, color)
        fill(g, -r, r - t, r, r, color)
        fill(g, -r, -r, -r + t, r, color)
        fill(g, r - t, -r, r, r, color)
    }

    private fun drawChevrons(g: GuiGraphicsExtractor, m: Metrics, color: Int) {
        val d = max(2, m.gap + 1)
        val len = max(2, m.arm - d + 1)
        if (m.outline > 0) stampChevrons(g, d, len, m.thick + 2, OUTLINE)
        stampChevrons(g, d, len, m.thick, color)
    }

    private fun stampChevrons(g: GuiGraphicsExtractor, d: Int, len: Int, thick: Int, color: Int) {
        val half = thick / 2
        for (i in 0..len) {
            fill(g, -i - half, -d - i - half, -i - half + thick, -d - i - half + thick, color)
            fill(g, i - half, -d - i - half, i - half + thick, -d - i - half + thick, color)
            fill(g, -i - half, d + i - half, -i - half + thick, d + i - half + thick, color)
            fill(g, i - half, d + i - half, i - half + thick, d + i - half + thick, color)
            fill(g, -d - i - half, -i - half, -d - i - half + thick, -i - half + thick, color)
            fill(g, -d - i - half, i - half, -d - i - half + thick, i - half + thick, color)
            fill(g, d + i - half, -i - half, d + i - half + thick, -i - half + thick, color)
            fill(g, d + i - half, i - half, d + i - half + thick, i - half + thick, color)
        }
    }

    private fun drawHollowCross(g: GuiGraphicsExtractor, m: Metrics, color: Int) {
        var arm = m.arm
        val tip = max(m.thick + 1, max(1, m.arm / 3))
        val inner = max(m.gap, arm - tip)
        if (arm <= inner) arm = inner + tip
        if (m.outline > 0) drawCrossLayer(g, arm, inner, m.thick, m.half, OUTLINE, m.outline)
        drawCrossLayer(g, arm, inner, m.thick, m.thick / 2, color, 0)
    }

    private fun drawTripleDot(g: GuiGraphicsExtractor, m: Metrics, color: Int) {
        val r = max(1, (m.thick + 1) / 2)
        val spacing = max(r * 2 + 1, m.gap + r)
        for (x in intArrayOf(-spacing, 0, spacing)) {
            if (m.outline > 0) fill(g, x - r - 1, -r - 1, x + r + 1, r + 1, OUTLINE)
            fill(g, x - r, -r, x + r, r, color)
        }
    }

    private inline fun fill(g: GuiGraphicsExtractor, x1: Int, y1: Int, x2: Int, y2: Int, color: Int) {
        if (x2 > x1 && y2 > y1) g.fill(x1, y1, x2, y2, color)
    }
}

// ============================================================================
// 9. PerfHudRenderer
// ============================================================================
object PerfHudRenderer {
    private const val PING_REFRESH_NS = 200_000_000L
    private const val WS_DOT = "●"
    private const val WS_CONNECTED_RGB = 0x55FF55
    private const val WS_DISCONNECTED_RGB = 0xFF5555

    private var lastPingRefreshNs = 0L
    private var cachedTps = "--.-"
    private var cachedPing = "--ms"
    private var cachedFps = -1
    private var cachedWsConnected = false
    private var cachedLabelColor = 0
    private var cachedLine: Component = Component.literal("TPS: --.-  FPS: 0  Ping: --ms  ●")

    @JvmStatic
    fun register() {
        val id = Identifier.fromNamespaceAndPath(VampyMod.MOD_ID, "perf_hud")
        HudElementRegistry.addLast(id, PerfHudRenderer::renderHud)
    }

    private fun renderHud(graphics: GuiGraphicsExtractor, deltaTracker: DeltaTracker) {
        try {
            if (!VampyConfig.isPerfHudEnabled() || WarningHudRenderer.hudDragOpen) return
            val client = Minecraft.getInstance()
            if (client == null || client.level == null || client.player == null) return

            refreshCaches(client)
            val s = VampyConfig.getPerfHudScale().toFloat().coerceIn(0.5f, 3f)
            val x = (VampyConfig.getPerfHudX() * graphics.guiWidth()).roundToInt()
            val y = (VampyConfig.getPerfHudY() * graphics.guiHeight()).roundToInt()

            if (abs(s - 1.0f) < 0.01f) {
                graphics.text(client.font, cachedLine, x, y, 0xFFFFFFFF.toInt(), true)
            } else {
                graphics.pose().pushMatrix()
                graphics.pose().translate(x.toFloat(), y.toFloat())
                graphics.pose().scale(s, s)
                graphics.text(client.font, cachedLine, 0, 0, 0xFFFFFFFF.toInt(), true)
                graphics.pose().popMatrix()
            }
        } catch (_: Exception) {
        }
    }

    private fun refreshCaches(client: Minecraft?) {
        val now = System.nanoTime()
        val tps = formatTps()
        val fps = client?.fps ?: 0
        val wsConnected = VampyConfig.isWebsocketEnabled() && VampWebSocketManager.isConnected()
        val labelColor = VampyConfig.getPerfHudColor() or 0xFF000000.toInt()
        val pingDue = now - lastPingRefreshNs >= PING_REFRESH_NS
        if (pingDue) {
            lastPingRefreshNs = now
            cachedPing = formatPing()
        }
        if (tps != cachedTps || fps != cachedFps || wsConnected != cachedWsConnected || labelColor != cachedLabelColor || pingDue) {
            cachedTps = tps
            cachedFps = fps
            cachedWsConnected = wsConnected
            cachedLabelColor = labelColor
            cachedLine = buildLine(cachedTps, cachedFps.toString(), cachedPing, labelColor, wsConnected)
        }
    }

    @JvmStatic
    fun liveTps(): String = formatTps()

    @JvmStatic
    fun liveFps(client: Minecraft?): String = (client?.fps ?: 0).toString()

    @JvmStatic
    fun livePing(): String = formatPing()

    private fun formatTps(): String {
        val tps = TpsTracker.getTps()
        return if (tps < 0.0) "--.-" else String.format(Locale.ROOT, "%.1f", tps)
    }

    private fun formatPing(): String {
        val ms = LatencyTracker.getPingMs()
        return if (ms < 0) "--ms" else "${ms}ms"
    }

    private fun buildLine(tps: String, fps: String, ping: String, labelArgb: Int, wsConnected: Boolean): Component {
        val label = Style.EMPTY.withColor(TextColor.fromRgb(labelArgb and 0xFFFFFF))
        val value = Style.EMPTY.withColor(TextColor.fromRgb(0xFFFFFF))
        val dotStyle = Style.EMPTY.withColor(TextColor.fromRgb(if (wsConnected) WS_CONNECTED_RGB else WS_DISCONNECTED_RGB))
        val gap = "  "
        val line: MutableComponent = Component.empty()
        line.append(Component.literal("TPS: ").setStyle(label))
        line.append(Component.literal(tps + gap).setStyle(value))
        line.append(Component.literal("FPS: ").setStyle(label))
        line.append(Component.literal(fps + gap).setStyle(value))
        line.append(Component.literal("Ping: ").setStyle(label))
        line.append(Component.literal("$ping ").setStyle(value))
        line.append(Component.literal(WS_DOT).setStyle(dotStyle))
        return line
    }

    @JvmStatic
    fun drawLine(
        graphics: GuiGraphicsExtractor,
        font: Font,
        x: Float,
        y: Float,
        tps: String,
        fps: String,
        ping: String,
        labelArgb: Int,
        scale: Float
    ) {
        val wsConnected = VampyConfig.isWebsocketEnabled() && VampWebSocketManager.isConnected()
        val line = buildLine(tps, fps, ping, labelArgb, wsConnected)
        val s = scale.coerceIn(0.5f, 3f)
        if (abs(s - 1.0f) < 0.01f) {
            graphics.text(font, line, x.roundToInt(), y.roundToInt(), 0xFFFFFFFF.toInt(), true)
            return
        }
        graphics.pose().pushMatrix()
        graphics.pose().translate(x, y)
        graphics.pose().scale(s, s)
        graphics.text(font, line, 0, 0, 0xFFFFFFFF.toInt(), true)
        graphics.pose().popMatrix()
    }

    @JvmStatic
    fun measureWidth(font: Font, tps: String, fps: String, ping: String, scale: Float): Int {
        val s = scale.coerceIn(0.5f, 3f)
        val w = font.width("TPS: $tps  FPS: $fps  Ping: $ping $WS_DOT")
        return (w * s).roundToInt()
    }

    @JvmStatic
    fun measureHeight(scale: Float): Int = (9 * scale.coerceIn(0.5f, 3f)).roundToInt()

    private fun sampleTps(): String = liveTps().let { if (it == "--.-") "20.0" else it }
    private fun sampleFps(): String = Minecraft.getInstance()?.fps?.takeIf { it > 0 }?.toString() ?: "240"
    private fun samplePing(): String = livePing().let { if (it == "--ms") "150ms" else it }

    @JvmStatic
    fun panelWidth(font: Font): Int =
        measureWidth(font, sampleTps(), sampleFps(), samplePing(), VampyConfig.getPerfHudScale().toFloat())

    @JvmStatic
    fun panelHeight(font: Font): Int = measureHeight(VampyConfig.getPerfHudScale().toFloat())

    @JvmStatic
    fun renderSample(context: GuiGraphicsExtractor, font: Font, x: Int, y: Int) {
        val scale = VampyConfig.getPerfHudScale().toFloat()
        val color = VampyConfig.getPerfHudColor() or 0xFF000000.toInt()
        drawLine(context, font, x.toFloat(), y.toFloat(), sampleTps(), sampleFps(), samplePing(), color, scale)
    }
}

// ============================================================================
// 10. ChatCopyNotificationOverlay
// ============================================================================
object ChatCopyNotificationOverlay {
    private val HUD_ID = Identifier.fromNamespaceAndPath(VampyMod.MOD_ID, "chat_copy_toast")
    private const val SLIDE_IN_MS = 180L
    private const val HOLD_MS = 2100L
    private const val SLIDE_OUT_MS = 240L
    private const val TOTAL_DURATION_MS = SLIDE_IN_MS + HOLD_MS + SLIDE_OUT_MS

    private var copiedText: String? = null
    private var shownAtMs = 0L

    @JvmStatic
    fun register() {
        HudElementRegistry.addLast(HUD_ID) { context, _ ->
            if (Minecraft.getInstance().screen !is ChatScreen) renderToast(context)
        }
        ScreenEvents.AFTER_INIT.register { _, screen, _, _ ->
            if (screen is ChatScreen) {
                ScreenEvents.afterExtract(screen).register { _, context, _, _, _ -> renderToast(context) }
            }
        }
    }

    @JvmStatic
    fun show(text: String?) {
        if (text.isNullOrBlank()) return
        copiedText = text.trim()
        shownAtMs = System.currentTimeMillis()
    }

    private fun renderToast(context: GuiGraphicsExtractor) {
        val txt = copiedText ?: return
        val elapsed = System.currentTimeMillis() - shownAtMs
        if (elapsed < 0L || elapsed >= TOTAL_DURATION_MS) {
            copiedText = null
            return
        }
        val client = Minecraft.getInstance()
        if (client == null || client.font == null || client.options.hideGui) return
        val font = client.font

        val progress = when {
            elapsed < SLIDE_IN_MS -> {
                val t = elapsed.toFloat() / SLIDE_IN_MS.toFloat()
                1.0f - (1.0f - t) * (1.0f - t) * (1.0f - t)
            }
            elapsed < SLIDE_IN_MS + HOLD_MS -> 1.0f
            else -> {
                val t = (elapsed - SLIDE_IN_MS - HOLD_MS).toFloat() / SLIDE_OUT_MS.toFloat()
                1.0f - t * t * t
            }
        }.coerceIn(0.0f, 1.0f)

        val titleComp = Component.literal("Message copied to clipboard").withStyle(ChatFormatting.WHITE, ChatFormatting.BOLD)
        val previewStr = if (txt.length > 96) txt.substring(0, 93) + "..." else txt
        var bodyLines: List<FormattedCharSequence> = font.split(Component.literal(previewStr).withStyle(ChatFormatting.GRAY), 175)
        if (bodyLines.size > 2) bodyLines = bodyLines.subList(0, 2)

        var contentW = font.width(titleComp)
        for (line in bodyLines) contentW = max(contentW, font.width(line))

        val padX = 8
        val padY = 6
        val lineStep = 10
        val boxW = contentW + padX * 2
        val boxH = padY * 2 + 11 + bodyLines.size * lineStep + 3

        val sw = context.guiWidth()
        val sh = context.guiHeight()
        val marginY = if (client.screen is ChatScreen) 22 else 8

        val x = Mth.lerp(progress, (sw + 8).toFloat(), (sw - boxW - 8).toFloat()).roundToInt()
        val y = sh - boxH - marginY

        val vampStyle = VampyConfig.getGuiStyle() == VampyConfig.GuiStyle.VAMP
        val bgColor = if (vampStyle) 0xEB120912.toInt() else 0xE6141619.toInt()
        val borderColor = if (vampStyle) 0xFFE03050.toInt() else 0xFF3A3F47.toInt()
        val barFillColor = if (vampStyle) 0xFFE03050.toInt() else 0xFF55FF55.toInt()

        context.fill(x, y, x + boxW, y + boxH, bgColor)
        context.fill(x, y, x + boxW, y + 1, borderColor)
        context.fill(x, y + boxH - 1, x + boxW, y + boxH, borderColor)
        context.fill(x, y + 1, x + 1, y + boxH - 1, borderColor)
        context.fill(x + boxW - 1, y + 1, x + boxW, y + boxH - 1, borderColor)

        var ty = y + padY
        context.text(font, titleComp, x + padX, ty, 0xFFFFFFFF.toInt(), true)
        ty += 12
        for (line in bodyLines) {
            context.text(font, line, x + padX, ty, 0xFFAAAAAA.toInt(), true)
            ty += lineStep
        }

        val lifeFraction = 1.0f - (elapsed.toFloat() / TOTAL_DURATION_MS.toFloat()).coerceIn(0.0f, 1.0f)
        val barW = ((boxW - 2) * lifeFraction).roundToInt()
        context.fill(x + 1, y + boxH - 3, x + boxW - 1, y + boxH - 1, 0x55000000)
        if (barW > 0) context.fill(x + 1, y + boxH - 3, x + 1 + barW, y + boxH - 1, barFillColor)
    }
}
