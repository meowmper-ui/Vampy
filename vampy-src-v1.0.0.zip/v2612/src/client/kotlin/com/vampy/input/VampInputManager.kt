package com.vampy.input

import com.mojang.blaze3d.platform.InputConstants
import com.mojang.blaze3d.platform.Window
import com.vampy.VampyMod
import com.vampy.chat.VampWebSocketManager
import com.vampy.config.CommandHotkeyEntry
import com.vampy.config.VampyConfig
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper
import net.fabricmc.fabric.impl.command.client.ClientCommandInternals
import net.minecraft.client.KeyMapping
import net.minecraft.client.Minecraft
import net.minecraft.network.chat.Component
import net.minecraft.resources.Identifier
import org.lwjgl.glfw.GLFW
import java.util.ArrayDeque
import java.util.Deque
import java.util.HashSet

object KeyBindings {
    @JvmField
    var OPEN_GUI: KeyMapping? = null

    @JvmStatic
    fun register() {
        val category = KeyMapping.Category.register(
            Identifier.fromNamespaceAndPath(VampyMod.MOD_ID, "general")
        )
        OPEN_GUI = KeyMappingHelper.registerKeyMapping(
            KeyMapping(
                "key.vampy.open_gui",
                InputConstants.Type.KEYSYM,
                GLFW.GLFW_KEY_INSERT,
                category
            )
        )
    }
}

object CommandHotkeys {
    private val HELD: MutableSet<Int> = HashSet()
    private val STILL_HELD: MutableSet<Int> = HashSet()
    private val CHAIN_QUEUE: Deque<String> = ArrayDeque()
    private var lastChainStepMs: Long = 0L
    private const val CHAIN_STEP_DELAY_MS: Long = 250L

    private var cacheGen: Int = -1
    private var cachedKeys: Array<InputConstants.Key?> = emptyArray()
    private var cachedCmds: Array<String?> = emptyArray()
    private var cachedEnabled: BooleanArray = BooleanArray(0)
    private var cachedCtrl: BooleanArray = BooleanArray(0)
    private var cachedShift: BooleanArray = BooleanArray(0)
    private var cachedAlt: BooleanArray = BooleanArray(0)

    @JvmStatic
    fun tick(client: Minecraft?) {
        if (client == null || client.player == null || client.connection == null) {
            HELD.clear()
            CHAIN_QUEUE.clear()
            return
        }

        if (!CHAIN_QUEUE.isEmpty()) {
            val now = System.currentTimeMillis()
            if (now - lastChainStepMs >= CHAIN_STEP_DELAY_MS) {
                val nextCmd = CHAIN_QUEUE.pollFirst()
                lastChainStepMs = now
                if (nextCmd != null && nextCmd.isNotBlank()) {
                    executeSingleCommand(client, nextCmd)
                }
            }
        }

        if (client.screen != null) {
            HELD.clear()
            return
        }
        if (!VampyConfig.hasCommandHotkeys()) {
            HELD.clear()
            return
        }
        refreshCacheIfNeeded()
        if (cachedKeys.isEmpty()) {
            HELD.clear()
            return
        }

        val win = client.window
        val handle = win.handle()
        val ctrlDown = client.hasControlDown()
        val shiftDown = client.hasShiftDown()
        val altDown = client.hasAltDown()

        STILL_HELD.clear()
        for (i in cachedKeys.indices) {
            if (!cachedEnabled[i]) continue
            val key = cachedKeys[i]
            val cmd = cachedCmds[i]
            if (key == null || key === InputConstants.UNKNOWN || cmd.isNullOrEmpty()) continue

            if (cachedCtrl[i] && !ctrlDown) continue
            if (cachedShift[i] && !shiftDown) continue
            if (cachedAlt[i] && !altDown) continue

            val down = isDown(win, handle, key)
            if (down) {
                STILL_HELD.add(i)
                if (HELD.add(i)) {
                    run(client, cmd)
                }
            }
        }
        HELD.retainAll(STILL_HELD)
    }

    private fun refreshCacheIfNeeded() {
        val gen = VampyConfig.getCommandHotkeyGeneration()
        if (gen == cacheGen) return
        cacheGen = gen

        val list = VampyConfig.getCommandHotkeys()
        val n = list.size
        cachedKeys = arrayOfNulls(n)
        cachedCmds = arrayOfNulls(n)
        cachedEnabled = BooleanArray(n)
        cachedCtrl = BooleanArray(n)
        cachedShift = BooleanArray(n)
        cachedAlt = BooleanArray(n)

        for (i in 0 until n) {
            val e = list[i] ?: continue
            cachedEnabled[i] = e.enabled
            cachedCmds[i] = e.command?.trim() ?: ""
            cachedCtrl[i] = e.ctrl
            cachedShift[i] = e.shift
            cachedAlt[i] = e.alt
            val kn = e.key
            if (kn.isNullOrBlank()) {
                cachedKeys[i] = InputConstants.UNKNOWN
            } else {
                cachedKeys[i] = try {
                    InputConstants.getKey(kn.trim())
                } catch (_: IllegalArgumentException) {
                    InputConstants.UNKNOWN
                }
            }
        }
        HELD.clear()
    }

    private fun isDown(win: Window, handle: Long, key: InputConstants.Key): Boolean {
        val code = key.value
        if (code < 0) return false
        return when (key.type) {
            InputConstants.Type.KEYSYM -> InputConstants.isKeyDown(win, code)
            InputConstants.Type.MOUSE -> GLFW.glfwGetMouseButton(handle, code) == GLFW.GLFW_PRESS
            else -> false
        }
    }

    @JvmStatic
    fun isModifierKeyCode(keyCode: Int): Boolean {
        return keyCode == GLFW.GLFW_KEY_LEFT_CONTROL || keyCode == GLFW.GLFW_KEY_RIGHT_CONTROL ||
                keyCode == GLFW.GLFW_KEY_LEFT_SHIFT || keyCode == GLFW.GLFW_KEY_RIGHT_SHIFT ||
                keyCode == GLFW.GLFW_KEY_LEFT_ALT || keyCode == GLFW.GLFW_KEY_RIGHT_ALT ||
                keyCode == GLFW.GLFW_KEY_LEFT_SUPER || keyCode == GLFW.GLFW_KEY_RIGHT_SUPER
    }

    @JvmStatic
    fun keyLabel(keyName: String?): Component = keyLabel(keyName, false, false, false)

    @JvmStatic
    fun keyLabel(e: CommandHotkeyEntry?): Component {
        if (e == null) return Component.translatable("screen.vampy.hotkeys.unbound")
        return keyLabel(e.key, e.ctrl, e.shift, e.alt)
    }

    @JvmStatic
    fun keyLabel(keyName: String?, ctrl: Boolean, shift: Boolean, alt: Boolean): Component {
        if (keyName.isNullOrBlank()) {
            return Component.translatable("screen.vampy.hotkeys.unbound")
        }
        return try {
            val k = InputConstants.getKey(keyName.trim())
            if (k == null || k === InputConstants.UNKNOWN) {
                return Component.translatable("screen.vampy.hotkeys.unbound")
            }
            val prefix = StringBuilder()
            if (ctrl) prefix.append("Ctrl + ")
            if (shift) prefix.append("Shift + ")
            if (alt) prefix.append("Alt + ")
            if (prefix.isEmpty()) k.displayName else Component.literal(prefix.toString()).append(k.displayName)
        } catch (_: IllegalArgumentException) {
            Component.literal(keyName)
        }
    }

    @JvmStatic
    fun keyNameOf(key: InputConstants.Key?): String {
        if (key == null || key === InputConstants.UNKNOWN) return ""
        return key.name
    }

    private fun run(client: Minecraft, raw: String?) {
        if (raw.isNullOrBlank()) return
        if (raw.contains(";")) {
            val parts = raw.split(";")
            var first = true
            for (part in parts) {
                val sub = part.trim()
                if (sub.isEmpty()) continue
                if (first) {
                    first = false
                    lastChainStepMs = System.currentTimeMillis()
                    executeSingleCommand(client, sub)
                } else {
                    CHAIN_QUEUE.addLast(sub)
                }
            }
            return
        }
        executeSingleCommand(client, raw)
    }

    private fun executeSingleCommand(client: Minecraft, raw: String) {
        val cmd = if (raw.startsWith("/")) raw.substring(1).trim() else raw.trim()
        if (cmd.isEmpty()) return
        if (client.player == null || client.connection == null) return

        if (VampWebSocketManager.onOutgoingCommand(cmd)) {
            return
        }
        try {
            if (ClientCommandInternals.executeCommand(cmd)) {
                return
            }
        } catch (t: Throwable) {
            VampyMod.LOGGER.debug("[Vampy] client command exec failed: {}", t.toString())
        }
        try {
            client.connection!!.sendCommand(cmd)
        } catch (e: Exception) {
            VampyMod.LOGGER.warn("[Vampy] command hotkey failed for '{}': {}", cmd, e.toString())
        }
    }
}
