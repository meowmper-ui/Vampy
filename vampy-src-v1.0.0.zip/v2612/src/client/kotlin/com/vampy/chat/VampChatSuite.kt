package com.vampy.chat

import com.vampy.VampyMod
import com.vampy.config.VampyConfig
import com.vampy.mixin.client.ChatMixin
import com.vampy.render.SlayerProfitTracker
import com.vampy.render.WarningHudRenderer
import net.minecraft.ChatFormatting
import net.minecraft.client.Minecraft
import net.minecraft.client.multiplayer.chat.GuiMessage
import net.minecraft.network.chat.Component
import net.minecraft.network.chat.MutableComponent
import net.minecraft.network.chat.Style
import net.minecraft.network.chat.TextColor
import net.minecraft.network.protocol.ping.ServerboundPingRequestPacket
import net.minecraft.util.Util
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.*
import java.util.concurrent.ThreadLocalRandom
import java.util.regex.Pattern
import kotlin.math.max
import kotlin.math.min

// ============================================================================
// 1. ClientModChat
// ============================================================================
object ClientModChat {
    const val CRIMSON_ASH: Int = 0xB0403C

    @JvmStatic
    @JvmOverloads
    fun info(message: String?, personalBest: Boolean = false, previousPbFormatted: String? = null) {
        val client = Minecraft.getInstance()
        if (client?.player == null || message.isNullOrEmpty()) return
        val ash = Style.EMPTY.withColor(TextColor.fromRgb(CRIMSON_ASH))
        val line: MutableComponent = Component.literal("[").withStyle(ash)
            .append(Component.literal(VampyMod.MOD_NAME).withStyle(ash))
            .append(Component.literal("] ").withStyle(ash))
            .append(Component.literal(message).withStyle(ChatFormatting.WHITE))
        if (personalBest) {
            line.append(Component.literal(" (Personal Best!)").withStyle(ChatFormatting.GREEN))
            if (!previousPbFormatted.isNullOrEmpty()) {
                line.append(Component.literal(" previous was ").withStyle(ChatFormatting.GRAY))
                line.append(Component.literal(previousPbFormatted).withStyle(ChatFormatting.GRAY))
            }
        }
        client.player!!.sendSystemMessage(line)
    }
}

// ============================================================================
// 2. LatencyTracker
// ============================================================================
object LatencyTracker {
    private const val PING_INTERVAL_TICKS = 40
    private var tickCounter = 0
    private var smoothedMs = -1L
    private var lastSampleMs = -1L

    @JvmStatic
    fun onClientTick() {
        val client = Minecraft.getInstance()
        if (client?.connection == null || client.player == null) return
        if (++tickCounter < PING_INTERVAL_TICKS) return
        tickCounter = 0
        try {
            client.connection!!.send(ServerboundPingRequestPacket(Util.getMillis()))
        } catch (_: Exception) {
        }
    }

    @JvmStatic
    fun onPong(sentTime: Long) {
        val rtt = Util.getMillis() - sentTime
        if (rtt !in 0L..15_000L) return
        lastSampleMs = rtt
        smoothedMs = if (smoothedMs < 0L) rtt else (smoothedMs * 3L + rtt) / 4L
    }

    @JvmStatic
    fun getPingMs(): Int {
        if (smoothedMs >= 0L) return smoothedMs.toInt()
        if (lastSampleMs >= 0L) return lastSampleMs.toInt()
        val client = Minecraft.getInstance()
        val player = client?.player ?: return -1
        val conn = client.connection ?: return -1
        val info = conn.getPlayerInfo(player.uuid) ?: conn.getPlayerInfoIgnoreCase(player.gameProfile.name()) ?: return -1
        val tab = info.latency
        return if (tab > 1) tab else -1
    }

    @JvmStatic
    fun reset() {
        tickCounter = 0
        smoothedMs = -1L
        lastSampleMs = -1L
    }
}

// ============================================================================
// 3. TpsTracker
// ============================================================================
object TpsTracker {
    private const val MAX_TPS = 20.0f
    private const val PACKET_TICKS_MS = 20_000.0f

    @Volatile
    private var prevTimeMs = 0L
    @Volatile
    private var currentTps = -1.0f

    @JvmStatic
    fun onSetTimePacket() {
        val now = System.currentTimeMillis()
        val prev = prevTimeMs
        if (prev != 0L) {
            currentTps = (PACKET_TICKS_MS / (now - prev + 1L).toFloat()).coerceIn(0.0f, MAX_TPS)
        }
        prevTimeMs = now
    }

    @JvmStatic
    fun getTps(): Double = currentTps.toDouble()

    @JvmStatic
    fun formatTps(): String {
        val tps = currentTps
        return if (tps < 0.0f) "tps unavailable" else String.format(Locale.ROOT, "%.1f TPS", tps)
    }

    @JvmStatic
    fun reset() {
        prevTimeMs = 0L
    }

    @JvmStatic
    fun hardReset() {
        prevTimeMs = 0L
        currentTps = -1.0f
    }
}

// ============================================================================
// 4. ChatMessageHider
// ============================================================================
object ChatMessageHider {
    @JvmStatic
    fun hideClickedMessage(rawMessage: String?): Boolean {
        val pattern = ChatTextPatterns.stackKey(rawMessage)
        if (pattern.isEmpty()) return false
        VampyConfig.addHiddenChatMessage(pattern)
        removeMatchingFromLive(pattern)
        return true
    }

    @JvmStatic
    fun removeMatchingFromLive(pattern: String?) {
        val chat = Minecraft.getInstance()?.gui?.chat ?: return
        val ruleKey = ChatTextPatterns.stackKey(pattern)
        if (ruleKey.isEmpty()) return
        val accessor = chat as ChatMixin.ComponentAccessor
        val all = accessor.`vampy$getAllMessages`()
        var removed = false
        for (i in all.size - 1 downTo 0) {
            val msg = all[i]
            val content = msg?.content() ?: continue
            if (VampyConfig.matchesHiddenChatPattern(content.string, ruleKey)) {
                ChatStackSession.untrack(msg)
                all.removeAt(i)
                removed = true
            }
        }
        if (removed) {
            accessor.`vampy$refreshTrimmedMessages`()
            ChatHistoryStore.markDirty()
        }
    }

    @JvmStatic
    fun reapplyAfterRulesChanged() {
        ChatHistoryStore.reapplyHideRules()
    }
}

// ============================================================================
// 5. ChatStackSession
// ============================================================================
object ChatStackSession {
    private const val BANNER_BURST_MS = 800L
    private val byKey = HashMap<String, MutableSet<GuiMessage>>()
    private val keyOf = IdentityHashMap<GuiMessage, String>()
    private var bannerBurstUntilMs = 0L

    @JvmStatic
    fun beginNewSession() {
        byKey.clear()
        keyOf.clear()
        bannerBurstUntilMs = 0L
    }

    @JvmStatic
    fun noteAndShouldSkipBannerStack(raw: String?): Boolean {
        val now = System.currentTimeMillis()
        if (ChatTextPatterns.isSeparatorLine(raw) || now < bannerBurstUntilMs) {
            bannerBurstUntilMs = now + BANNER_BURST_MS
            return true
        }
        return false
    }

    @JvmStatic
    fun track(message: GuiMessage?, stackKey: String?) {
        if (message == null || stackKey.isNullOrEmpty()) return
        val prev = keyOf.put(message, stackKey)
        if (prev != null && prev != stackKey) removeFromBucket(prev, message)
        byKey.getOrPut(stackKey) { Collections.newSetFromMap(IdentityHashMap()) }.add(message)
    }

    @JvmStatic
    fun isLive(message: GuiMessage?): Boolean = message != null && keyOf.containsKey(message)

    @JvmStatic
    fun untrack(message: GuiMessage?) {
        if (message == null) return
        val key = keyOf.remove(message)
        if (key != null) removeFromBucket(key, message)
    }

    @JvmStatic
    fun takeMatches(stackKey: String?): List<GuiMessage> {
        if (stackKey.isNullOrEmpty()) return emptyList()
        val set = byKey.remove(stackKey) ?: return emptyList()
        if (set.isEmpty()) return emptyList()
        val out = ArrayList<GuiMessage>(set.size)
        for (msg in set) {
            keyOf.remove(msg)
            out.add(msg)
        }
        return out
    }

    @JvmStatic
    fun pruneTo(allMessages: Collection<GuiMessage>?) {
        val indexed = keyOf.size
        if (indexed == 0) return
        val liveSize = allMessages?.size ?: 0
        if (indexed <= liveSize + 1024) return

        val present = Collections.newSetFromMap<GuiMessage>(IdentityHashMap())
        if (allMessages != null) {
            for (msg in allMessages) if (msg != null) present.add(msg)
        }
        val stale = ArrayList<GuiMessage>()
        for (msg in keyOf.keys) if (!present.contains(msg)) stale.add(msg)
        for (msg in stale) untrack(msg)
    }

    @JvmStatic
    fun indexedCount(): Int = keyOf.size

    private fun removeFromBucket(key: String, message: GuiMessage) {
        val set = byKey[key] ?: return
        set.remove(message)
        if (set.isEmpty()) byKey.remove(key)
    }
}

// ============================================================================
// 6. FunnyDropChat
// ============================================================================
object FunnyDropChat {
    private val DROP = Pattern.compile(
        "^(VERY RARE DROP!|CRAZY RARE DROP!) \\((Enchanted Book Bundle|Unfanged Vampire Part|McGrubber's Burger)\\)(.*)$",
        Pattern.DOTALL
    )
    private const val RGB_GOLD = 0xFFAA00
    private const val RGB_INSANE_RED = 0xFF5555
    private val INSANE_DROP_STYLE = Style.EMPTY.applyFormat(ChatFormatting.RED)

    private class Piece(val style: Style, val text: String)

    @JvmStatic
    fun maybeRewrite(content: Component?): Component? {
        if (content == null || !SlayerProfitTracker.isInStillgoreChateau()) return content
        val quick = content.string
        if (quick.isNullOrEmpty() || (!quick.contains("RARE DROP!") && !quick.contains("DROP!"))) return content

        val pieces = flatten(content)
        if (pieces.isEmpty()) return content
        val flat = buildString { for (p in pieces) append(p.text) }
        val trimmed = flat.trim()
        if (trimmed.isEmpty()) return content

        val m = DROP.matcher(trimmed)
        if (!m.matches()) return content
        val rarity = m.group(1)
        val item = m.group(2)

        val trimPad = max(0, flat.indexOf(trimmed))
        val rarityIdx = trimPad + trimmed.indexOf(rarity)
        val rarityEnd = rarityIdx + rarity.length
        val itemIdx = flat.indexOf(item, rarityEnd)
        if (itemIdx < 0) return content
        val itemEnd = itemIdx + item.length

        var rarityStyle = styleAt(pieces, rarityIdx) ?: Style.EMPTY.applyFormat(ChatFormatting.AQUA)
        val itemStyle = styleAt(pieces, itemIdx) ?: Style.EMPTY.applyFormat(ChatFormatting.GOLD)

        val isBundle = item.equals("Enchanted Book Bundle", ignoreCase = true)
        val theOne = isBundle && isTheOneBundleColor(itemStyle)
        if (isBundle && !theOne) return content

        val displayItem = if (isBundle) "THE ONE IV" else item
        val funny = funnyRarity(rarity, item) ?: return content

        val insaneRed = theOne || item.equals("Unfanged Vampire Part", ignoreCase = true)
        if (insaneRed) rarityStyle = INSANE_DROP_STYLE

        WarningHudRenderer.showFunnyDrop(
            funny,
            displayItem,
            if (insaneRed) RGB_INSANE_RED else rgbFromStyle(rarityStyle, 0x55FFFF),
            rgbFromStyle(itemStyle, 0xFFAA00)
        )

        return rebuild(pieces, rarityIdx, rarityEnd, funny, rarityStyle, itemIdx, itemEnd, displayItem)
    }

    private fun isTheOneBundleColor(itemStyle: Style): Boolean {
        val rgb = rgbFromStyle(itemStyle, -1)
        if (rgb < 0) return false
        val dr = ((rgb shr 16) and 0xFF) - ((RGB_GOLD shr 16) and 0xFF)
        val dg = ((rgb shr 8) and 0xFF) - ((RGB_GOLD shr 8) and 0xFF)
        val db = (rgb and 0xFF) - (RGB_GOLD and 0xFF)
        return dr * dr + dg * dg + db * db <= 48 * 48
    }

    private fun rebuild(
        pieces: List<Piece>,
        rarityIdx: Int,
        rarityEnd: Int,
        funny: String,
        rarityStyle: Style,
        itemIdx: Int,
        itemEnd: Int,
        displayItem: String
    ): Component {
        val out: MutableComponent = Component.empty()
        var emittedFunny = false
        var emittedItem = false
        var cursor = 0
        for (p in pieces) {
            val start = cursor
            val stop = cursor + p.text.length
            appendSlice(out, p, start, stop, start, rarityIdx)
            if (!emittedFunny && start < rarityEnd && rarityIdx < stop) {
                out.append(Component.literal(funny).withStyle(rarityStyle))
                emittedFunny = true
            }
            appendSlice(out, p, start, stop, rarityEnd, itemIdx)
            if (start < itemEnd && itemIdx < stop && !emittedItem) {
                val itemStyle = styleAt(pieces, itemIdx) ?: p.style
                out.append(Component.literal(displayItem).withStyle(itemStyle))
                emittedItem = true
            }
            appendSlice(out, p, start, stop, itemEnd, Int.MAX_VALUE)
            cursor = stop
        }
        return out
    }

    private fun appendSlice(out: MutableComponent, p: Piece, start: Int, stop: Int, keepFrom: Int, keepTo: Int) {
        val a = max(start, keepFrom)
        val b = min(stop, keepTo)
        if (b > a) out.append(Component.literal(p.text.substring(a - start, b - start)).withStyle(p.style))
    }

    private fun styleAt(pieces: List<Piece>, index: Int): Style? {
        if (index < 0) return null
        var cursor = 0
        for (p in pieces) {
            val stop = cursor + p.text.length
            if (index in cursor until stop) return p.style
            cursor = stop
        }
        return null
    }

    private fun rgbFromStyle(style: Style?, fallbackRgb: Int): Int {
        val c = style?.color ?: return fallbackRgb
        return c.value and 0xFFFFFF
    }

    private fun funnyRarity(rarity: String, item: String): String? {
        val crazy = rarity.regionMatches(0, "CRAZY", 0, 5, ignoreCase = true)
        return when (item.lowercase(Locale.ROOT)) {
            "mcgrubber's burger" -> if (crazy) "Burger..." else "BURGER!?"
            "enchanted book bundle", "unfanged vampire part" -> if (crazy) "ROBBED!" else "RNGESUS DESCENDS!"
            else -> null
        }
    }

    private fun flatten(content: Component): List<Piece> {
        val pieces = ArrayList<Piece>()
        content.visit({ style, text ->
            if (!text.isNullOrEmpty()) pieces.add(Piece(style ?: Style.EMPTY, text))
            Optional.empty<Unit>()
        }, Style.EMPTY)
        return pieces
    }
}

// ============================================================================
// 7. PartyChatCommands
// ============================================================================
object PartyChatCommands {
    private val FROM_MSG = Pattern.compile("^From (?:\\[[^]]*]? ?)?(\\w{1,16}): ?(.+)$")
    private val PARTY_MSG = Pattern.compile("^Party > (?:\\[[^]]*]? ?)?(\\w{1,16})(?: [^:]*)?: ?(.+)$")
    private val PRIVATE_INVITE = Pattern.compile("^!(?:invite|inv|party|p)(?:\\s+.*)?$", Pattern.CASE_INSENSITIVE)

    private val EIGHTBALL = arrayOf(
        "It is certain.", "It is decidedly so.", "Without a doubt.", "Yes — definitely.",
        "You may rely on it.", "As I see it, yes.", "Most likely.", "Outlook good.",
        "Yes.", "Signs point to yes.", "Reply hazy, try again.", "Ask again later.",
        "Better not tell you now.", "Cannot predict now.", "Concentrate and ask again.",
        "Don't count on it.", "My reply is no.", "My sources say no.", "Outlook not so good.",
        "Very doubtful.", "Absolutely not.", "The blood moon says yes.",
        "The château whispers no.", "Skill issue — try again.", "The RNG gods approve.",
        "Only if you warp first.", "Ask your party leader.", "In another timeline, yes.",
        "L + ratio + no.", "The voices say maybe.", "Touch grass, then ask again.",
        "That's a yikes from me.", "Built different — so yes.", "Nah fam.",
        "The rift rejects this fate.", "Stillgore approves.", "Cope harder.",
        "It's giving yes.", "It's giving no.", "Mid idea, mid answer: maybe.",
        "Roll again, champ.", "The crystal ball blue-screened.", "Trust the process (no).",
        "Your ancestors are laughing.", "Hypixel said leave me alone.",
        "Party chat consensus: doubtful.", "Yes, but make it awkward.",
        "No, and that's on period.", "The stars aligned… for someone else.",
        "Manifesting a hard maybe.", "Bro asked the void; void shrugged.",
        "If you have to ask, it's a no.", "Green flag energy — yes.",
        "Red flag energy — absolutely not.", "The dice landed on cope.",
        "Ask after the next warp.", "Fate is AFK.", "Certified W.",
        "Certified L.", "The universe is buffering.", "Try pinging reality.",
        "Only on a full moon and a full party.", "Sounds like a you problem.",
        "I'm locking in: yes.", "I'm locking in: no.", "50/50 but spiritually no.",
        "The oracle is on cooldown.", "Yes, but you'll regret the wording.",
        "No — and the scoreboard agrees.", "Maybe, if the TPS holds.",
        "Ask again when you're not mid-skill-issue.", "The spirits said 'bruh'.",
        "Positive vibes only: yes.", "Negative aura detected: no.",
        "The answer is yes, said with malice.", "The answer is no, said lovingly.",
        "Queue that thought for later.", "Denied by the dungeon queue.",
        "Approved by the blood rush.", "Rejected by the door puzzle.",
        "Yes, speedrun it.", "No, go touch the warp pad first.",
        "The magic 8-ball filed a complaint.", "Consult your healer (it's a no).",
        "Consult your bers (it's a yes).", "Fate rolled a natural 1.",
        "Fate rolled a natural 20.", "The lobby NPC nodded slowly: yes.",
        "The lobby NPC walked away: no.", "I'm contractually obliged to say maybe.",
        "Yes, but mute party chat first.", "No — not even in creative.",
        "The crystal ball shows a W.", "The crystal ball shows an L montage.",
        "Ask your future self; they're laughing.", "The rift timer says hurry up (yes).",
        "The rift timer says you're cooked (no).", "Statistically improbable, spiritually yes.",
        "Guaranteed… on an alt account.", "Not even with a full set of secrets.",
        "Yes if you bring snacks.", "No if you keep yapping.",
        "The answer is behind a wither door.", "Divine intervention: still no.",
        "Divine intervention: begrudging yes.", "RNG whispered 'sure, whatever'.",
        "Party leader override: denied.", "Party leader override: forced yes.",
        "I'm seeing a clear green flag.", "I'm seeing seven red flags and a kick.",
        "Yes, but make it everyone's problem.", "No, and document it for the lore."
    )

    private val ROASTS = arrayOf(
        "plays like they're mining with a wooden pick forever",
        "has the reaction time of a sleeping villager",
        "could miss a Stillgore target from 2 blocks",
        "treats the rift like a tutorial world",
        "has ping that arrived by boat",
        "clicks terminals with their elbows",
        "needs a GPS for a straight hallway",
        "died to fall damage on flat ground (allegedly)",
        "buffs the wrong person on purpose (probably)",
        "has inventory management from 2013",
        "wars like CAPS LOCK is a weapon",
        "is allergic to holding W",
        "snaps to the wrong leap pad every time",
        "brings a spoon to a bloodfiend fight",
        "got outplayed by a mushroom",
        "has aimbot… for the floor",
        "loads in already mid skill-issue",
        "has pathfinding sponsored by a lost sheep",
        "clears slower than a potato server",
        "thought shift-click was a personality",
        "has hotbar setup from a fever dream",
        "dies to mechanics labeled 'don't stand here'",
        "needs subtitles for their own footsteps",
        "warps in and immediately becomes a hazard",
        "has the game sense of a decorative armor stand",
        "peeks corners like they're allergic to info",
        "plays support by emotionally supporting the enemy",
        "has timing so late it needs a calendar",
        "is one misclick away from a highlight reel (enemy POV)",
        "brings 'main character' energy to a side quest",
        "got hardstuck in the tutorial vibes",
        "has FOV set to 'can't see the play'",
        "treats callouts as optional DLC",
        "is buffering in 4K regret",
        "has DPS of a friendly snow golem",
        "clears rooms like they're paying rent per tick",
        "got body-blocked by their own armor stand",
        "uses the map as a fashion accessory only",
        "has leap accuracy rivaling a blind bat",
        "opens chests like they're solving a murder mystery",
        "is the reason 'stay together' was invented",
        "brings a bow to a puzzle fight (wrong energy)",
        "has secret count measured in vibes, not numbers",
        "stands in wither key spawn for the aesthetic",
        "dies to the same trap twice and calls it lag",
        "has movement tech from a PowerPoint",
        "needs a loading screen between thoughts",
        "got lost in a 2x2 room (impressive)",
        "is allergic to green candles and good decisions",
        "has 'trust me bro' as their only strategy",
        "pegs every wrong lever like it's a speedrun category",
        "is the final boss of wasted time",
        "has aim so bad it needs a support ticket",
        "plays healer by healing the enemy's ego",
        "has tank energy with glass cannon durability",
        "mages like the mana bar is a suggestion",
        "berserks everything except the actual boss",
        "archers arrows into the void for lore reasons",
        "has callouts that arrive after the wipe",
        "is a walking skill-check with no answers",
        "got out-micro'd by an NPC shopkeeper",
        "treats death messages as a personal diary",
        "has inventory full of unfinished thoughts",
        "is the human embodiment of a rubber-band lag spike",
        "warps the party into a highlight of mistakes",
        "has pathing that would make a GPS cry",
        "clicks so slow the server sends a get-well card",
        "is carrying… the enemy win condition",
        "has game sense shipped separately (lost in mail)",
        "got cooked so hard they need a food license",
        "is stuck in the tutorial of their own ego",
        "has 'I got it' energy and then immediately doesn't",
        "plays like the WASD keys are rumors",
        "has timing so off it needs daylight savings",
        "is the reason cooldowns feel personal",
        "brings main-character monologues to a 5-man",
        "has clutch potential measured in imaginary numbers",
        "dies facing the wrong direction with confidence",
        "is a menace to the concept of 'simple mechanics'",
        "has the aura of a disconnected controller",
        "got ratio'd by a dungeon puzzle",
        "is softlocked in bad takes",
        "has FOV, IQ, and awareness all set to potato",
        "treats the party as unpaid tech support",
        "is one warp away from a documentary about failure",
        "has secrets lower than their self-awareness",
        "plays defense by offending everyone in chat",
        "is the loading tooltip of skill issues",
        "has a PhD in standing in the wrong place",
        "got outplayed by gravity again",
        "is built different (different = worse)",
        "has highlight reels exclusively from enemy cams"
    )

    private val COMPLIMENTS = arrayOf(
        "is carrying harder than the bloodfiend",
        "has aura that blinds the whole château",
        "is built different (and the servers know it)",
        "makes Stillgore look like a parkour lobby",
        "has main-character energy tonight",
        "is the reason the party clears",
        "has aim sponsored by the RNG gods",
        "is lowkey cracked",
        "is highkey cracked",
        "makes it look easy (it's not)",
        "is the silent carry we needed",
        "has movement from a montage",
        "is cooking with the gas on high",
        "turns every fight into a cutscene win",
        "has callouts cleaner than a speedrun route",
        "is locked in like rent is due",
        "has clutch insurance as a personality",
        "is the human skip button for bad RNG",
        "makes the lobby look underleveled",
        "has aura so loud it needs a volume slider",
        "is carrying and still being humble (sus, but ok)",
        "has game sense from three patches ahead",
        "is the W in 'we cleared'",
        "has hands of a montage editor",
        "is the reason 'ez' is allowed tonight",
        "has timing so clean it should be illegal",
        "is built for this exact moment",
        "has the softest landings and hardest carries",
        "is rewriting the clear time for fun",
        "has aim that files taxes correctly",
        "makes mechanics look like etiquette",
        "is the party's unofficial skip ticket",
        "has aura that buffs nearby allies",
        "is cooking gourmet Ws tonight",
        "has leap lines cleaner than a tutorial route",
        "is the reason the boss HP bar feels nervous",
        "has callouts with cinematic timing",
        "is cracked in 4K and still polite",
        "has the clutch gene fully expressed",
        "is a walking green flag with DPS",
        "makes the dungeon queue worth it",
        "has movement so smooth it needs anti-aliasing",
        "is carrying with style points enabled",
        "has game sense like spoilers for the fight",
        "is the silent protagonist who still solos",
        "has timing that belongs in a museum",
        "is the final form of 'I got this'",
        "has aura debt the whole lobby owes them",
        "is turning RNG into a paid actor",
        "has hands insured by the clear gods",
        "is the reason party chat said 'gg' early",
        "has aim sponsored by competence",
        "is locked in harder than a wither door",
        "makes every room a personal montage scene",
        "has support so good it feels illegal",
        "is the human S+ PB",
        "has chill vibes and unchill performance",
        "is cooking while the rest of us watch MasterChef",
        "has the cleanest W energy in the instance",
        "is built different and patch-notes agree",
        "has main-character plot armor that works",
        "is the soft carry with hard numbers",
        "has callouts that prevent disasters (and ego deaths)",
        "is the reason 'diff' is a compliment tonight",
        "has aura brighter than the blood room",
        "is cracked, composed, and still funny",
        "has the clutch of a season finale"
    )

    private val VIBES = arrayOf(
        "chaotic good", "sleep-deprived legend", "main character", "NPC energy",
        "final boss", "tutorial skipper", "rng blessed", "rng cursed",
        "silent carry", "loud support", "speedrunner brainrot", "cozy gamer",
        "menace to society", "certified yapper", "chronic lurker", "aura farmer",
        "doomscroller", "locked in", "unlocked out", "side quest enjoyer",
        "patch-notes scholar", "lobby philosopher", "clutch merchant",
        "hopeless romantic (for wins)", "professional warper", "accidental tank",
        "emotional support DPS", "chaos coordinator", "calm before the throw",
        "post-clear comedian", "pre-clear anxiety", "mid-fight podcast host",
        "softlocked in the vibes", "hardstuck in the sauce", "seasonal menace",
        "unspoken rizz", "negative aura collection", "positive delusion",
        "competitive yap", "competitive silence", "goofy ahh legend",
        "professional warper (unlicensed)", "certified floor-taster",
        "blood-room poet", "terminal whisperer", "leap-pad romantic",
        "secret goblin", "scoreboard philosopher", "party-chat novelist",
        "quiet menace", "loud blessing", "chronic 'one more run'",
        "speedclear gremlin", "chill clears only", "tryhard in denial",
        "vibes-based navigator", "map enjoyer", "puzzle hater (valid)",
        "boss-room standup comic", "pregame hype machine",
        "postgame cope artist", "midgame doom prophet",
        "aura minimalist", "aura maximalist", "rizz on cooldown",
        "sigma in the mines", "softlocked in party finder",
        "hardstuck in the bit", "seasonal final boss",
        "tutorial NPC who snapped", "lobby legend (self-proclaimed)",
        "dungeon historian", "clear-time conspiracy theorist",
        "friendly neighborhood thrower", "unofficial raid leader",
        "professional 'I got it'", "amateur 'I don't got it'",
        "chronically online cleardown", "offline in spirit, online in DPS",
        "main-plot relevant", "filler-arc icon", "comedy relief with clutch DLC"
    )

    private val COOK_LINES = arrayOf(
        "is cooking", "is getting cooked", "left the stove on", "burnt the water",
        "served a 5-star dish", "served cold leftovers", "is in the kitchen",
        "got microwave'd", "is raw", "is well done", "burned the recipe book",
        "plated a masterpiece", "forgot the seasoning (skill)", "is sous-chef of the throw",
        "got deep-fried by RNG", "is air-frying the competition", "served mid with confidence",
        "opened a food truck of Ws", "opened a food truck of Ls", "is chef's kiss",
        "is chef's miss", "seasoned with cope", "braised in the sauce",
        "got sent back to the kitchen", "is tasting menu only (exclusive carry)",
        "is flambéing the boss", "got sous-vided by mechanics",
        "burned the garlic (and the clear)", "is plating Ls with garnish",
        "opened a pop-up restaurant of skill issues", "is meal-prepping Ws",
        "got delivered cold (doorDash of doom)", "is spice-rack overconfident",
        "seasoned to perfection", "seasoned to humiliation",
        "is baking a PB", "is baking a wipe", "forgot they left the oven on (ego)",
        "is stir-frying the lobby", "got pressure-cooked in P3",
        "is serving tasting notes: mid", "is serving tasting notes: godlike",
        "has the kitchen on fire (complimentary)", "has the kitchen on fire (literal skill issue)",
        "is plating with tweezers and trauma", "got health-inspected by the boss",
        "is michelin-starring this clear", "is michelin-starring this throw",
        "whipped up a clutch from scraps", "whipped up a disaster from scraps",
        "is the head chef of cope kitchen", "is catering an L banquet",
        "put too much sauce (still a W)", "put too much sauce (criminal)",
        "is cooking with cast-iron hands", "got burned by their own recipe"
    )

    private val SUS_LINES = arrayOf(
        "vented (probably)", "was in electrical", "didn't do tasks", "is looking sus",
        "faked a scan", "is the impostor vibes", "cleared… suspiciously fast",
        "self-reported too confidently", "stood still during a body report",
        "has alibi written in Comic Sans", "was 'afk' at the perfect time",
        "stacked with the wrong crowd", "said 'I'm not sus' unprompted",
        "watched the killcam like homework", "has among-us walking animation IRL",
        "voted first, explained never", "is giving emergency meeting energy",
        "sabotaged the vibe (lights out)", "was quiet… too quiet",
        "cleared themselves with a meme", "was last seen near the body (and the snacks)",
        "has an alibi that needs a wiki page", "said 'trust' in a way that decreased trust",
        "did a task with suspicious flair", "was scanning while the crime happened (alleged)",
        "has vent-shaped footprints", "called a meeting to deflect",
        "is visually innocent, spiritually guilty", "has the walk of someone who pressed a button",
        "blamed lag for a moral failing", "was in cams… alone… smiling",
        "has crewmate drip and impostor timing", "stacked, scanned, and still sus",
        "said 'I was doing wires' from medbay", "has an emergency meeting addiction",
        "voted in alphabetical order (chaos)", "is the reason we need body reports",
        "cleared too hard — red flag", "was AFK with perfect camera angles",
        "has sus meter in the red", "brought a knife to a task list (metaphorically)",
        "is giving 'I saw them vent' with no proof", "self-reported via party chat",
        "has alibi DLC that doesn't install", "was quiet in chat, loud in crimes",
        "is the final suspect in every timeline"
    )

    private val RIZZ_TAGS = arrayOf(
        "unspoken rizz", "negative aura", "rizzler certified", "rizz bankrupt",
        "awkward silence merchant", "smooth like lag", "main-character charm",
        "NPC dialogue tree", "soft-spoken menace", "loud and incorrect",
        "mysterious lobby energy", "cringe but committed", "aura debt collector",
        "certified yap-to-rizz pipeline", "eye contact speedrun fail",
        "rizz on ping 300", "charm with packet loss", "aura in airplane mode",
        "smooth operator (demo version)", "dialogue options: all wrong",
        "rizzler with skill issues", "aura farmer, zero harvest",
        "softlocked in the friendzone dungeon", "hardstuck in the bit",
        "mysterious until they speak", "speaks and the mystery dies",
        "lobby heartthrob (self-vote)", "party-chat poet",
        "unspoken tension with the warp pad", "rizz so mid it loops",
        "certified green-flag distributor", "certified red-flag museum",
        "aura so loud it needs subtitles", "quiet rizz, loud results",
        "failed the vibe check, passed the bit", "passed the vibe check, failed the bit",
        "main-character intro, side-quest ending", "rizz buffer underrun",
        "charm exported as a .zip of cope", "eye contact: connection timed out"
    )

    private val RATIO_LINES = arrayOf(
        "L + ratio + fell off", "L + ratio + no bitches + touch grass",
        "L + ratio + skill issue + mid take", "L + ratio + cope + seethe",
        "L + ratio + bozo + clown shoes", "L + ratio + didn't ask + didn't care",
        "L + ratio + W for everyone else", "L + ratio + unread + ignored",
        "L + ratio + bad take + worse timing", "L + ratio + go next",
        "L + ratio + packet loss + ego loss", "L + ratio + dogwater + evaporated",
        "L + ratio + tutorial incomplete", "L + ratio + patch notes ignored",
        "L + ratio + aura debt + collections", "L + ratio + NPC dialogue + no skip",
        "L + ratio + downbad + downevenworse", "L + ratio + fumbled + recorded",
        "L + ratio + mid opinion + expired", "L + ratio + touch warp pad + try again",
        "L + ratio + skill issue DLC + microtransactions", "L + ratio + comedy without the timing",
        "L + ratio + main character delusion", "L + ratio + side character performance",
        "L + ratio + mute + move on", "L + ratio + bozo certified + notarized",
        "L + ratio + W's for the opposition", "L + ratio + chat logged for the roast reel",
        "L + ratio + copeium overdose", "L + ratio + please update your takes"
    )

    private val SIGMA_LINES = arrayOf(
        "lone wolf grindset", "rejects party chat, still reads it",
        "wakes up and chooses discipline", "eats cereal with water (alleged)",
        "silent carry mindset", "looks at the camera after every W",
        "doesn't chase clout, clout chases them", "schedule: grind, hydrate, ignore drama",
        "main character in a side quest world", "unbothered. moisturized. in the rift.",
        "quotes themselves in the third person", "left the group chat spiritually",
        "meditates on the warp pad", "journals only in clear times",
        "owns one emote: silence", "trains in the rain (and in the blood room)",
        "rejects the meta, becomes the meta", "sleeps 4 hours, dreams of PBs",
        "doesn't flex — the scoreboard does", "walks into the lobby like a thesis",
        "grindset: ignore, improve, invent", "has a vision board of boss HP bars",
        "unbothered by ratios, bothered by bad routes", "drinks respect from the fountain of Ws",
        "sigma stare through the loading screen", "left the toxic party, kept the clear time",
        "schedules emotions for after the run", "built a temple to consistency",
        "doesn't chase highlights; highlights chase them", "spiritually offline, mechanically online",
        "wrote 'discipline' on a sticky note and ascended", "rejects yap, accepts facts",
        "has a 10-year plan and a 10-second clutch", "sigma enough to mute, kind enough to carry",
        "looks at the moon, queues another run", "the grind whispered back"
    )

    private val SKILLISSUE_LINES = arrayOf(
        "classic skill issue", "terminal skill issue", "skill issue with DLC",
        "skill issue (untreated)", "skill issue spreading to allies",
        "skill issue but make it fashion", "skill issue confirmed by lab results",
        "skill issue — please update drivers", "skill issue in 4K HDR",
        "skill issue so loud it needs earplugs", "skill issue: chronic, stage 4",
        "skill issue disguised as 'bad ping'", "skill issue with season pass", "skill issue early access",
        "skill issue (stacking debuff)", "skill issue proc'd on hit",
        "skill issue critically hit", "skill issue resisted (barely)",
        "skill issue in cinematic ultrawide", "skill issue with ray tracing",
        "skill issue: please insert coin", "skill issue: contact support",
        "skill issue notarized by a notary public", "skill issue hanging in the Louvre",
        "skill issue speedrun any%", "skill issue with commentary track",
        "skill issue bundled with cope", "skill issue patch notes: still broken",
        "skill issue so clean it looks intentional", "skill issue leaking into the lobby",
        "skill issue: endemic to this loadout", "skill issue behind a paywall (of pride)",
        "skill issue with surround sound", "skill issue — doctors hate this one trick",
        "skill issue evolving into its final form", "skill issue starring in a documentary"
    )

    private val SHIP_VERDICTS = arrayOf(
        "destined", "mid pairing", "toxic yaoi/yuri energy", "lobby teammates forever",
        "doomed by the narrative", "cute but cursed", "speedrun divorce",
        "power couple", "chaos couple", "NPC x PC romance", "enemies to mid",
        "situationship detected", "main plot relevant", "filler-arc romance",
        "enemies to lovers (patch delayed)", "lovers to enemies (hotfix)",
        "arranged by party finder", "meet-cute at the warp pad",
        "slow burn (like a 40m clear)", "fast burn (like a 1s wipe)",
        "will they / won't they / shouldn't they", "canon in my heart, fanon in the chat",
        "doomed by the scoreboard", "blessed by the blood room",
        "one braincell shared tastefully", "two braincells fighting",
        "rizz deficit pairing", "aura surplus pairing",
        "toxic but entertaining", "wholesome but mid",
        "endgame material", "tutorial romance only",
        "season finale coded", "pilot episode energy",
        "will clear together, argue forever", "OTP until the next patch",
        "narratively illegal, spiritually peak", "lobby-approved, parents-concerned",
        "city hall wedding after one good run", "restraining order after one bad callout"
    )

    private val FLIP_YES = arrayOf(
        "YES", "YES.", "YES!!", "absolutely YES", "green light YES",
        "it's a YES from me", "YES (don't ask again)", "YES — locked in",
        "YES with confidence", "YES with consequences", "YES, send it",
        "YES, full send", "YES, queue it", "YES, I'm convinced",
        "YES — notarized", "YES — carved in bedrock", "YES (party agrees)",
        "YES, and make it everyone's problem", "YES, speedrun edition",
        "YES — the vibes passed inspection", "hard YES", "soft YES but still YES",
        "YES before you finish asking", "YES, no notes", "YES, highlight reel incoming"
    )

    private val FLIP_NO = arrayOf(
        "NO", "NO.", "absolutely NO", "hard NO", "red light NO",
        "it's a NO from me", "NO (and that's final)", "NO — go next",
        "NO with prejudice", "NO, touch grass", "NO, touch warp pad",
        "NO — denied by the oracle", "NO — scoreboard veto", "NO (unanimous)",
        "NO, and log off", "NO, try a different bit", "soft NO that still stings",
        "NO — filed under 'never'", "NO, the vibes failed inspection",
        "NO before you finish asking", "NO, no notes needed",
        "NO — highlight reel cancelled", "NO, respectfully", "NO, disrespectfully",
        "NO and that's on periodt"
    )

    private val GAY_LINES = arrayOf(
        "rainbow aura certified", "spectrum maxed out", "closet door off its hinges",
        "certified boykisser energy", "pride month all year round", "radar is pinging off the charts",
        "fruity pebbles in the hotbar", "caught kissing the homies goodnight",
        "zesty movement detected in Stillgore", "verified by the Château council"
    )

    private val FURRY_LINES = arrayOf(
        "OwO detected on radar", "fursuit hidden in wardrobe slot 9", "barked at the Bloodfiend",
        "tail wagging during Mania", "certified pathOwOgen carrier", "howling at the Stillgore moon",
        "cat ears permanently enchanted with Binding", "paws on the keyboard right now",
        "sniffing for Coven Seals", "rawr x3 in party chat"
    )

    private val FEMBOY_LINES = arrayOf(
        "thigh highs equipped in wardrobe slot 1", "monster energy IV drip active",
        "skirt go spinny during Twinclaw", "voice training in the Rift",
        "pink headset with cat ears confirmed", "astolfo skin preset loaded",
        "programming socks +100 Magic Find", ":3 typed 47 times today",
        "certified cutie patootie of the party", "leg warmers carrying the DPS"
    )

    private val FLOOR_NAMES = arrayOf("one", "two", "three", "four", "five", "six", "seven")
    private val RPS_MOVES = arrayOf("rock", "paper", "scissors")
    private val MAWI_MEOW_LINES = arrayOf(
        "meow", "meow~", "mrrp~", "nya~", "meow :3", "mrrrow~", "mew~",
        "nyaa~ :3", "purrrr~", "meowww", "mrrp :3", "mew :3", "nya!", "meow? :3", "mlem~ meow"
    )

    private const val PICK_HISTORY = 12
    private val RECENT_PICKS = IdentityHashMap<Array<String>, ArrayDeque<Int>>()

    private const val INVITE_COOLDOWN_MS = 400L
    private var lastInviteMs = 0L
    private var lastInviteIgn = ""

    private const val CMD_COOLDOWN_MS = 350L
    private const val PARTY_HANDLE_DELAY_TICKS = 2
    private var lastCmdMs = 0L

    private var pendingCommand: String? = null
    private var pendingTicks = -1
    private var pendingPartyIgn: String? = null
    private var pendingPartyMsg: String? = null
    private var pendingPartyTicks = -1

    private const val EASTER_EGG_TARGET_IGN = "MawiSofteh"
    private const val MIN_MEOW_INTERVAL_MS = 10L * 60L * 1000L
    private const val MAX_MEOW_INTERVAL_MS = 30L * 60L * 1000L
    private var nextMeowTimestampMs = -1L

    @JvmStatic
    fun onClientTick(client: Minecraft?) {
        LatencyTracker.onClientTick()
        tickMawiMeowEasterEgg(client)

        if (pendingPartyTicks >= 0) {
            pendingPartyTicks--
            if (pendingPartyTicks == 0 && pendingPartyMsg != null) {
                val ign = pendingPartyIgn
                val msg = pendingPartyMsg
                pendingPartyIgn = null
                pendingPartyMsg = null
                runPartyCommand(ign, msg)
            }
        }
        if (pendingTicks >= 0) {
            pendingTicks--
            if (pendingTicks == 0 && pendingCommand != null) {
                val cmd = pendingCommand!!
                pendingCommand = null
                sendCommand(cmd)
            }
        }
    }

    private fun tickMawiMeowEasterEgg(client: Minecraft?) {
        if (client?.player == null || client.level == null || client.connection == null) return
        if (!isMawiSofteh(client)) return
        val now = System.currentTimeMillis()
        if (nextMeowTimestampMs <= 0L) {
            nextMeowTimestampMs = now + ThreadLocalRandom.current().nextLong(MIN_MEOW_INTERVAL_MS, MAX_MEOW_INTERVAL_MS + 1L)
            return
        }
        if (now >= nextMeowTimestampMs) {
            nextMeowTimestampMs = now + ThreadLocalRandom.current().nextLong(MIN_MEOW_INTERVAL_MS, MAX_MEOW_INTERVAL_MS + 1L)
            val meow = pick(MAWI_MEOW_LINES)
            if (meow.isNotEmpty()) sendCommand("ac $meow")
        }
    }

    private fun isMawiSofteh(client: Minecraft): Boolean {
        return try {
            if (client.user != null && EASTER_EGG_TARGET_IGN.equals(client.user.name, ignoreCase = true)) return true
            val p = client.player ?: return false
            if (p.gameProfile?.name()?.trim()?.equals(EASTER_EGG_TARGET_IGN, ignoreCase = true) == true) return true
            val clean = ChatFormatting.stripFormatting(p.name.string)?.trim()
            EASTER_EGG_TARGET_IGN.equals(clean, ignoreCase = true)
        } catch (_: Throwable) {
            false
        }
    }

    @JvmStatic
    fun onChatMessage(raw: String?) {
        if (raw.isNullOrEmpty()) return
        val text = ChatFormatting.stripFormatting(raw)?.trim() ?: return
        if (text.isEmpty()) return

        if (text.startsWith("From ")) {
            if (VampyConfig.isPartyInviteCommands()) handlePrivate(text)
            return
        }
        if ((text.startsWith("Party > ") || text.startsWith("VA Party > ") || text.contains("VA Party > ")) && (VampyConfig.isPartyChatCommands() || VampyConfig.isPartyFunCommands())) {
            handleParty(text)
        }
    }

    private fun handlePrivate(text: String) {
        val m = FROM_MSG.matcher(text)
        if (!m.matches()) return
        val ign = m.group(1) ?: return
        val msg = m.group(2)?.trim() ?: return
        if (ign.isEmpty() || msg.isEmpty() || !PRIVATE_INVITE.matcher(msg).matches()) return
        invitePlayer(ign)
    }

    private fun handleParty(text: String) {
        val m = PARTY_MSG.matcher(text)
        if (!m.matches()) return
        val ign = m.group(1) ?: return
        val msg = m.group(2)?.trim() ?: return
        if (ign.isEmpty() || !msg.startsWith("!")) return

        val body = msg.substring(1).trim()
        if (body.isEmpty()) return
        val words = body.lowercase(Locale.ROOT).split(Regex("\\s+")).toTypedArray()
        if (words.isEmpty() || words[0].isEmpty()) return
        val cmd = words[0]

        if (tryGameCommand(cmd, words, ign)) return

        val now = System.currentTimeMillis()
        if (now - lastCmdMs < CMD_COOLDOWN_MS) return
        lastCmdMs = now
        pendingPartyIgn = ign
        pendingPartyMsg = body
        pendingPartyTicks = PARTY_HANDLE_DELAY_TICKS
    }

    private fun runPartyCommand(ign: String?, body: String?) {
        if (ign == null || body.isNullOrEmpty()) return
        val words = body.lowercase(Locale.ROOT).split(Regex("\\s+")).toTypedArray()
        if (words.isEmpty() || words[0].isEmpty()) return
        val cmd = words[0]

        if (cmd == "help" || cmd == "h") {
            replyHelp()
            return
        }
        if (tryChatUtilityCommand(cmd)) return
        if (VampyConfig.isPartyFunCommands()) tryFunCommand(cmd, words, ign)
    }

    private fun replyHelp() {
        val cmds = ArrayList<String>()
        if (VampyConfig.isPartyChatCommands()) {
            for (id in VampyConfig.PARTY_UTIL_CMD_IDS) if (VampyConfig.isPartyCmdEnabled(id)) cmds.add(id)
        }
        if (VampyConfig.isPartyFunCommands()) {
            for (id in VampyConfig.PARTY_FUN_CMD_IDS) if (VampyConfig.isPartyCmdEnabled(id)) cmds.add(id)
        }
        reply(if (cmds.isEmpty()) "no commands enabled" else cmds.joinToString(", "))
    }

    private fun utilOn(id: String): Boolean = VampyConfig.isPartyChatCommands() && VampyConfig.isPartyCmdEnabled(id)
    private fun funOn(id: String): Boolean = VampyConfig.isPartyCmdEnabled(id)

    private fun tryGameCommand(cmd: String, words: Array<String>, ign: String): Boolean {
        when (cmd) {
            "warp", "w" -> if (utilOn("warp") || utilOn("w")) sendCommand("party warp")
            "wt", "warptransfer" -> if (utilOn("w") || utilOn("warp")) {
                sendCommand("party warp")
                pendingCommand = "party transfer $ign"
                pendingTicks = 12
            }
            "allinvite", "allinv" -> if (utilOn("allinv")) sendCommand("party settings allinvite")
            "pt", "ptme", "transfer" -> if (utilOn("pt")) sendCommand("party transfer ${if (words.size > 1) words[1] else ign}")
            "kick", "k" -> if (utilOn("kick") && words.size >= 2) sendCommand("party kick ${words[1]}")
            "promote" -> if (utilOn("promote")) sendCommand("party promote $ign")
            "demote" -> if (utilOn("demote")) sendCommand("party demote $ign")
            "f1", "f2", "f3", "f4", "f5", "f6", "f7" -> if (utilOn("f?")) joinInstanceId(cmd)?.let { sendCommand("joininstance $it") }
            "m1", "m2", "m3", "m4", "m5", "m6", "m7" -> if (utilOn("m?")) joinInstanceId(cmd)?.let { sendCommand("joininstance $it") }
            else -> return false
        }
        return true
    }

    private fun tryChatUtilityCommand(cmd: String): Boolean {
        when (cmd) {
            "coords", "co" -> if (utilOn("coords")) {
                Minecraft.getInstance().player?.let { p ->
                    reply(String.format(Locale.ROOT, "x: %.0f, y: %.0f, z: %.0f", p.x, p.y, p.z))
                }
            }
            "ping" -> if (utilOn("ping")) {
                val ms = LatencyTracker.getPingMs()
                reply(if (ms < 0) "ping unavailable" else "${ms}ms")
            }
            "tps" -> if (utilOn("tps")) reply(TpsTracker.formatTps())
            "fps" -> if (utilOn("fps")) reply("${Minecraft.getInstance()?.fps ?: 0} FPS")
            "time" -> if (utilOn("time")) reply(LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")))
            "f?" -> if (utilOn("f?")) reply("floors: !f1–!f7")
            "m?" -> if (utilOn("m?")) reply("masters: !m1–!m7")
            else -> return false
        }
        return true
    }

    private fun joinInstanceId(cmd: String): String? {
        if (cmd.length != 2) return null
        val n = cmd[1].digitToIntOrNull() ?: return null
        if (n !in 1..7) return null
        val floor = FLOOR_NAMES[n - 1]
        return when (cmd[0]) {
            'f' -> "catacombs_floor_$floor"
            'm' -> "master_catacombs_floor_$floor"
            else -> null
        }
    }

    private fun tryFunCommand(cmd: String, words: Array<String>, ign: String) {
        val rng = ThreadLocalRandom.current()
        val target = if (words.size > 1) words[1] else ign
        when (cmd) {
            "cf" -> if (funOn("cf")) reply(if (rng.nextBoolean()) "heads" else "tails")
            "dice" -> if (funOn("dice")) reply(rng.nextInt(1, 7).toString())
            "8ball", "eightball" -> if (funOn("8ball")) reply(pick(EIGHTBALL))
            "rps" -> if (funOn("rps")) reply("$ign vs RNG → ${pick(RPS_MOVES)}")
            "flip" -> if (funOn("flip")) reply(if (rng.nextBoolean()) pick(FLIP_YES) else pick(FLIP_NO))
            "rate" -> if (funOn("rate")) reply("$target is ${rng.nextInt(0, 101)}/100")
            "rizz" -> if (funOn("rizz")) reply("$target's rizz: ${rng.nextInt(0, 101)}% — ${pick(RIZZ_TAGS)}")
            "iq" -> if (funOn("iq")) reply("$target's IQ: ${rng.nextInt(40, 161)}")
            "vibe" -> if (funOn("vibe")) reply("$target vibe check: ${pick(VIBES)}")
            "roast" -> if (funOn("roast")) reply("$target ${pick(ROASTS)}")
            "praise", "flex" -> if (funOn("praise")) reply("$target ${pick(COMPLIMENTS)}")
            "ship" -> if (funOn("ship")) {
                val a = if (words.size > 1) words[1] else ign
                val b = if (words.size > 2) words[2] else "RNG"
                reply("$a × $b = ${rng.nextInt(0, 101)}% — ${pick(SHIP_VERDICTS)}")
            }
            "cook" -> if (funOn("cook")) reply("$target ${pick(COOK_LINES)} (${rng.nextInt(1, 101)}%)")
            "aura" -> if (funOn("aura")) reply("$target aura: ${if (rng.nextBoolean()) "+" else "-"}${rng.nextInt(1, 1000)}")
            "sigma" -> if (funOn("sigma")) reply("$target sigma: ${rng.nextInt(0, 101)}% — ${pick(SIGMA_LINES)}")
            "skillissue", "si" -> if (funOn("skillissue")) reply("diagnosis for $target: ${pick(SKILLISSUE_LINES)} (${rng.nextInt(70, 101)}% confidence)")
            "sus" -> if (funOn("sus")) reply("$target ${pick(SUS_LINES)} — ${rng.nextInt(0, 101)}% sus")
            "ratio" -> if (funOn("ratio")) reply("${pick(RATIO_LINES)} + $target")
            "gay" -> if (funOn("gay")) reply("$target is ${rng.nextInt(0, 101)}% gay — ${pick(GAY_LINES)}")
            "furry" -> if (funOn("furry")) reply("$target is ${rng.nextInt(0, 101)}% furry — ${pick(FURRY_LINES)}")
            "femboy" -> if (funOn("femboy")) reply("$target is ${rng.nextInt(0, 101)}% femboy — ${pick(FEMBOY_LINES)}")
        }
    }

    private fun pick(options: Array<String>): String {
        if (options.isEmpty()) return ""
        if (options.size == 1) return options[0]
        val recent = RECENT_PICKS.getOrPut(options) { ArrayDeque() }
        val history = min(PICK_HISTORY, options.size - 1)
        val rng = ThreadLocalRandom.current()
        for (attempt in 0 until 24) {
            val i = rng.nextInt(options.size)
            if (!recent.contains(i)) {
                recent.addLast(i)
                while (recent.size > history) recent.removeFirst()
                return options[i]
            }
        }
        var i = rng.nextInt(options.size)
        val last = recent.peekLast()
        if (last != null && i == last) i = (i + 1) % options.size
        recent.addLast(i)
        while (recent.size > history) recent.removeFirst()
        return options[i]
    }

    private fun invitePlayer(ign: String) {
        val now = System.currentTimeMillis()
        if (ign.equals(lastInviteIgn, ignoreCase = true) && now - lastInviteMs < INVITE_COOLDOWN_MS) return
        if (now - lastInviteMs < 400L) return
        lastInviteMs = now
        lastInviteIgn = ign
        sendCommand("party invite $ign")
    }

    private fun reply(message: String) {
        sendCommand("pc $message")
    }

    private fun sendCommand(command: String) {
        val client = Minecraft.getInstance() ?: return
        client.execute {
            try {
                Minecraft.getInstance().connection?.sendCommand(command)
            } catch (_: Exception) {
            }
        }
    }
}
