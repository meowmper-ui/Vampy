package com.vampy.item

import com.google.gson.JsonArray
import com.google.gson.JsonElement
import com.google.gson.JsonNull
import com.google.gson.JsonObject
import com.google.gson.JsonPrimitive
import net.minecraft.ChatFormatting
import net.minecraft.core.component.DataComponents
import net.minecraft.nbt.CompoundTag
import net.minecraft.nbt.ListTag
import net.minecraft.nbt.Tag
import net.minecraft.world.item.ItemStack
import java.util.LinkedHashMap

object SkyblockItemIds {
    @JvmStatic
    fun from(stack: ItemStack?): String? {
        if (stack == null || stack.isEmpty) return null
        val custom = stack.get(DataComponents.CUSTOM_DATA)
        if (custom == null || custom.isEmpty) return null

        val root = custom.copyTag()
        var id = root.getStringOr("id", "")
        if (id.isNotEmpty()) return resolveVariant(root, id)

        val ea = root.getCompoundOrEmpty("ExtraAttributes")
        if (ea.isEmpty) return null
        id = ea.getStringOr("id", "")
        return if (id.isEmpty()) null else resolveVariant(ea, id)
    }

    private fun resolveVariant(attrs: CompoundTag, id: String): String {
        if (id == "RUNE" || id.endsWith("_RUNE")) {
            val runes = attrs.getCompoundOrEmpty("runes")
            if (!runes.isEmpty) {
                for (key in runes.keySet()) {
                    val tier = runes.getIntOr(key, -1)
                    if (tier >= 0) return "$key;$tier"
                }
            }
        }
        return id
    }
}

object SkyblockItemData {
    @JvmStatic
    fun extraAttributes(stack: ItemStack?): CompoundTag? {
        if (stack == null || stack.isEmpty) return null
        val custom = stack.get(DataComponents.CUSTOM_DATA)
        if (custom == null || custom.isEmpty) return null
        val root = custom.copyTag()
        if (root.contains("ExtraAttributes")) {
            return root.getCompoundOrEmpty("ExtraAttributes")
        }
        return if (root.contains("id")) root else null
    }

    @JvmStatic
    fun plainName(stack: ItemStack?): String {
        if (stack == null || stack.isEmpty) return ""
        return (ChatFormatting.stripFormatting(stack.hoverName.string) ?: "").trim()
    }

    @JvmStatic
    fun extraAttributesJson(stack: ItemStack?): JsonObject {
        val ea = extraAttributes(stack)
        if (ea == null || ea.isEmpty) return JsonObject()
        val el = tagToJson(ea)
        return if (el.isJsonObject) el.asJsonObject else JsonObject()
    }

    @JvmStatic
    fun enchantments(stack: ItemStack?): Map<String, Int> {
        val out = LinkedHashMap<String, Int>()
        val ea = extraAttributes(stack) ?: return out
        val ench = ea.getCompoundOrEmpty("enchantments")
        if (ench.isEmpty) return out
        for (key in ench.keySet()) {
            val lvl = ench.getIntOr(key, -1)
            if (lvl > 0) out[key] = lvl
        }
        return out
    }

    @JvmStatic
    fun tagToJson(tag: Tag?): JsonElement {
        if (tag == null) return JsonNull.INSTANCE
        return when (tag.id) {
            Tag.TAG_BYTE, Tag.TAG_SHORT, Tag.TAG_INT ->
                JsonPrimitive(tag.asNumber().map { it.toInt() }.orElse(0))
            Tag.TAG_LONG ->
                JsonPrimitive(tag.asNumber().map { it.toLong() }.orElse(0L))
            Tag.TAG_FLOAT, Tag.TAG_DOUBLE ->
                JsonPrimitive(tag.asNumber().map { it.toDouble() }.orElse(0.0))
            Tag.TAG_STRING ->
                JsonPrimitive(tag.asString().orElse(""))
            Tag.TAG_BYTE_ARRAY, Tag.TAG_INT_ARRAY, Tag.TAG_LONG_ARRAY ->
                JsonNull.INSTANCE
            Tag.TAG_LIST -> {
                val list = tag as ListTag
                val arr = JsonArray()
                for (i in 0 until list.size) {
                    val child = tagToJson(list.get(i))
                    if (!child.isJsonNull) arr.add(child)
                }
                arr
            }
            Tag.TAG_COMPOUND -> {
                val compound = tag as CompoundTag
                val obj = JsonObject()
                compound.forEach { key, value ->
                    if (key == "uid" || key == "uuid") {
                        value.asString().ifPresent { v -> obj.addProperty(key, v) }
                        return@forEach
                    }
                    val child = tagToJson(value)
                    if (!child.isJsonNull) obj.add(key, child)
                }
                obj
            }
            else -> JsonNull.INSTANCE
        }
    }
}
