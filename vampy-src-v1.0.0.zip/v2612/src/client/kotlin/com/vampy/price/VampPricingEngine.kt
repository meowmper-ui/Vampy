package com.vampy.price

import com.google.gson.JsonArray
import com.google.gson.JsonObject
import com.google.gson.JsonParser
import com.vampy.VampyMod
import com.vampy.config.VampyConfig
import com.vampy.item.SkyblockItemData
import com.vampy.item.SkyblockItemIds
import com.vampy.render.SlayerProfitTracker
import net.fabricmc.fabric.api.client.item.v1.ItemTooltipCallback
import net.minecraft.ChatFormatting
import net.minecraft.client.Minecraft
import net.minecraft.client.gui.GuiGraphicsExtractor
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen
import net.minecraft.core.component.DataComponents
import net.minecraft.core.registries.BuiltInRegistries
import net.minecraft.network.chat.Component
import net.minecraft.network.chat.MutableComponent
import net.minecraft.world.entity.player.Inventory
import net.minecraft.world.item.ItemStack
import java.net.URI
import java.net.URLEncoder
import java.net.http.HttpClient
import java.net.http.HttpRequest
import java.net.http.HttpResponse
import java.nio.charset.StandardCharsets
import java.time.Duration
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.regex.Pattern
import kotlin.math.max
import kotlin.math.roundToLong

/**
 * Unified, compact Kotlin pricing engine for Vampy:
 * - CoflnetItemValueCache: Cached & dynamic Craft Price, Est. Value (including Soulbound / Dungeon / Kuudra modified items), and 7d Avg Price
 * - AhLowestBinTooltip: Clean 4-line item price tooltip (AH Lowest BIN, 7d Avg Price, Craft Price, Est. Value) without SkyCofl footer
 * - ItemPriceEstimate: Accurate item stack valuation (coins, Enchanted Books, pets, runes, Bazaar/AH fallback)
 * - TradeValueOverlay: Fixed player-trade overlay that ignores player inventory slots and decorative panes
 */
object CoflnetItemValueCache {
    private const val BREAKDOWN_URL = "https://sky.coflnet.com/api/mod/pricing/breakdown"
    private const val ACQUIRE_URL = "https://sky.coflnet.com/api/craft/acquisition/"
    private const val ITEM_PRICE_URL = "https://sky.coflnet.com/api/item/price/"
    private const val CACHE_TTL_MS = 5L * 60L * 1000L
    private const val AVG_TTL_MS = 10L * 60L * 1000L
    private const val FAIL_TTL_MS = 45L * 1000L

    private val JUNK_ATTRS = setOf(
        "id", "uuid", "uid", "timestamp", "date", "spawnedfor", "bossid",
        "pickonimbus_durability", "edition", "recipient_id", "sender_id",
        "donated_museum", "museum", "originTag", "origintag"
    )

    private val VALUABLE_MODIFIER_KEYS = setOf(
        "modifier", "upgrade_level", "dungeon_item_level", "rarity_upgrades",
        "hot_potato_count", "art_of_war_count", "art_of_peace_applied",
        "farming_for_dummies_count", "polarvoid", "jalapeno_count",
        "mana_disintegrator_count", "tuned_transmission", "ethermerge",
        "winning_bid", "wood_singularity_count", "divan_powder_coating",
        "power_ability_scroll", "ability_scroll", "gems", "attributes",
        "talisman_enrichment", "skin", "dye_item", "hecatomb_s_runs",
        "champion_combat_xp", "expertise_kills", "compact_blocks", "cultivating_crops"
    )

    private val HTTP: HttpClient = HttpClient.newBuilder()
        .connectTimeout(Duration.ofSeconds(8))
        .followRedirects(HttpClient.Redirect.NORMAL)
        .build()

    private val POOL = Executors.newFixedThreadPool(3) { r ->
        Thread(r, "vampy-pricing").apply { isDaemon = true }
    }

    data class Value(
        @JvmField val craftPrice: Long?,
        @JvmField val estimatedValue: Long?,
        @JvmField val avg7dPrice: Long?
    ) {
        fun craftPrice(): Long? = craftPrice
        fun estimatedValue(): Long? = estimatedValue
        fun avg7dPrice(): Long? = avg7dPrice
        fun isEmpty(): Boolean = craftPrice == null && estimatedValue == null && avg7dPrice == null
    }

    private data class Entry(val value: Value, val expiresAt: Long, val failed: Boolean)
    private data class AvgEntry(val avgPrice: Long?, val tradable: Boolean, val expiresAt: Long)

    private val CACHE = ConcurrentHashMap<String, Entry>()
    private val INFLIGHT = ConcurrentHashMap<String, Boolean>()
    private val AVG_CACHE = ConcurrentHashMap<String, AvgEntry>()

    @JvmStatic
    fun getOrRequest(stack: ItemStack?): Value? {
        if (stack == null || stack.isEmpty) return null
        if (!VampyConfig.isAhLowestBin() && !VampyConfig.isTradeValueOverlay()) return null

        val rawId = SkyblockItemIds.from(stack) ?: return null
        val lookupId = resolvePriceLookupId(stack, rawId)
        val name = SkyblockItemData.plainName(stack)
        val attrs = SkyblockItemData.extraAttributesJson(stack)
        val enchants = SkyblockItemData.enchantments(stack)
        val key = fingerprint(lookupId, attrs, enchants)

        val now = System.currentTimeMillis()
        val cached = CACHE[key]
        if (cached != null && now < cached.expiresAt) {
            return if (cached.failed) null else cached.value
        }

        if (INFLIGHT.putIfAbsent(key, true) == null) {
            POOL.execute { fetch(key, rawId, lookupId, name, attrs, enchants) }
        }
        return if (cached != null && !cached.failed) cached.value else null
    }

    @JvmStatic
    fun isLoading(stack: ItemStack?): Boolean {
        if (stack == null || stack.isEmpty) return false
        if (!VampyConfig.isAhLowestBin() && !VampyConfig.isTradeValueOverlay()) return false
        val rawId = SkyblockItemIds.from(stack) ?: return false
        val lookupId = resolvePriceLookupId(stack, rawId)
        val key = fingerprint(lookupId, SkyblockItemData.extraAttributesJson(stack), SkyblockItemData.enchantments(stack))
        return INFLIGHT[key] != null
    }

    /**
     * Resolves Enchanted Books (e.g. ENCHANTED_BOOK with {ultimate_legion: 5} -> ENCHANTMENT_ULTIMATE_LEGION_5)
     * so single enchanted books get accurate LBIN / 7d Avg / Trade Value.
     */
    @JvmStatic
    fun resolvePriceLookupId(stack: ItemStack, rawId: String): String {
        if (rawId == "ENCHANTED_BOOK") {
            val enchants = SkyblockItemData.enchantments(stack)
            if (enchants.size == 1) {
                val (enchKey, lvl) = enchants.entries.first()
                val upper = enchKey.uppercase(Locale.ROOT)
                return if (upper.startsWith("ENCHANTMENT_")) "${upper}_$lvl" else "ENCHANTMENT_${upper}_$lvl"
            }
        }
        return rawId
    }

    private fun hasValuableModifiers(attrs: JsonObject?, enchants: Map<String, Int>?): Boolean {
        if (!enchants.isNullOrEmpty()) return true
        if (attrs == null) return false
        for (k in attrs.keySet()) {
            if (k != null && VALUABLE_MODIFIER_KEYS.contains(k.lowercase(Locale.ROOT))) {
                return true
            }
        }
        return false
    }

    private fun fetch(
        key: String,
        rawId: String,
        lookupId: String,
        name: String,
        attrs: JsonObject,
        enchants: Map<String, Int>
    ) {
        try {
            val craft = fetchAcquireCost(rawId)
            val avgEntry = getOrFetch7dAvgAndTradable(lookupId)
            val lbin = AhLowestBinCache.getLowestBin(lookupId) ?: AhLowestBinCache.getLowestBin(rawId)
            val hasMods = hasValuableModifiers(attrs, enchants)

            // Estimate item value whenever:
            // 1) Item has live LBIN or market trade volume, OR
            // 2) Item has a known craft/acquisition cost (e.g. Diamond Necron Head), OR
            // 3) Item has SkyBlock upgrades/modifiers (enchants, stars, recomb, reforge, etc. — even if Co-op Soulbound!)
            val shouldEstimate = (lbin != null && lbin > 0) || avgEntry.tradable || (craft != null && craft > 0) || hasMods
            val estimate = if (shouldEstimate) {
                fetchEstimated(rawId, lookupId, name, attrs, enchants, craft, lbin, avgEntry.avgPrice)
            } else {
                null
            }

            val filteredAvg7d = if (hasMods && avgEntry.avgPrice != null) (if (avgEntry.avgPrice > 0L) avgEntry.avgPrice else null) else avgEntry.avgPrice
            val value = Value(craft, estimate, filteredAvg7d)
            CACHE[key] = Entry(value, System.currentTimeMillis() + CACHE_TTL_MS, value.isEmpty())
        } catch (e: Exception) {
            VampyMod.LOGGER.warn("[Vampy] Pricing fetch failed for {}: {}", lookupId, e.toString())
            CACHE[key] = Entry(Value(null, null, null), System.currentTimeMillis() + FAIL_TTL_MS, true)
        } finally {
            INFLIGHT.remove(key)
        }
    }

    private fun getOrFetch7dAvgAndTradable(id: String): AvgEntry {
        val now = System.currentTimeMillis()
        val cached = AVG_CACHE[id]
        if (cached != null && now < cached.expiresAt) return cached

        var avg7d: Long? = null
        var tradable = false

        // 1) Fetch 7-day history from /api/item/price/{id}/history/week (volume-weighted average)
        try {
            val weekUrl = ITEM_PRICE_URL + URLEncoder.encode(id, StandardCharsets.UTF_8) + "/history/week"
            val req = HttpRequest.newBuilder(URI.create(weekUrl))
                .timeout(Duration.ofSeconds(10))
                .header("User-Agent", "Vampy/" + VampyMod.MOD_ID)
                .header("Accept", "application/json")
                .GET()
                .build()
            val resp = HTTP.send(req, HttpResponse.BodyHandlers.ofString())
            if (resp.statusCode() in 200..299) {
                val el = JsonParser.parseString(resp.body())
                if (el.isJsonArray) {
                    var weightedSum = 0.0
                    var totalVol = 0.0
                    var simpleSum = 0.0
                    var simpleCount = 0
                    for (item in el.asJsonArray) {
                        if (!item.isJsonObject) continue
                        val row = item.asJsonObject
                        val avg = if (row.has("avg") && row.get("avg").isJsonPrimitive) row.get("avg").asDouble else 0.0
                        val vol = if (row.has("volume") && row.get("volume").isJsonPrimitive) row.get("volume").asDouble else 0.0
                        if (avg > 0.0) {
                            if (vol > 0.0) {
                                weightedSum += avg * vol
                                totalVol += vol
                            }
                            simpleSum += avg
                            simpleCount++
                        }
                    }
                    if (totalVol > 0.0) {
                        avg7d = (weightedSum / totalVol).roundToLong()
                        tradable = true
                    } else if (simpleCount > 0) {
                        avg7d = (simpleSum / simpleCount).roundToLong()
                        tradable = true
                    }
                }
            }
        } catch (_: Exception) {
        }

        // 2) Fallback / supplement from /api/item/price/{id} (median / mean)
        try {
            val priceUrl = ITEM_PRICE_URL + URLEncoder.encode(id, StandardCharsets.UTF_8)
            val req = HttpRequest.newBuilder(URI.create(priceUrl))
                .timeout(Duration.ofSeconds(10))
                .header("User-Agent", "Vampy/" + VampyMod.MOD_ID)
                .header("Accept", "application/json")
                .GET()
                .build()
            val resp = HTTP.send(req, HttpResponse.BodyHandlers.ofString())
            if (resp.statusCode() in 200..299) {
                val obj = JsonParser.parseString(resp.body()).asJsonObject
                val volume = if (obj.has("volume") && obj.get("volume").isJsonPrimitive) obj.get("volume").asDouble else 0.0
                val median = if (obj.has("median") && obj.get("median").isJsonPrimitive) obj.get("median").asDouble.roundToLong() else 0L
                val mean = if (obj.has("mean") && obj.get("mean").isJsonPrimitive) obj.get("mean").asDouble.roundToLong() else 0L
                if (volume > 0 && (median > 0 || mean > 0)) {
                    tradable = true
                    if (avg7d == null || avg7d <= 0L) {
                        avg7d = if (median > 0) median else mean
                    }
                }
            }
        } catch (_: Exception) {
        }

        val entry = AvgEntry(if (avg7d != null && avg7d > 0) avg7d else null, tradable, now + AVG_TTL_MS)
        AVG_CACHE[id] = entry
        return entry
    }

    private fun fetchAcquireCost(id: String): Long? {
        return try {
            val url = ACQUIRE_URL + URLEncoder.encode(id, StandardCharsets.UTF_8)
            val req = HttpRequest.newBuilder(URI.create(url))
                .timeout(Duration.ofSeconds(12))
                .header("User-Agent", "Vampy/" + VampyMod.MOD_ID)
                .header("Accept", "application/json")
                .GET()
                .build()
            val resp = HTTP.send(req, HttpResponse.BodyHandlers.ofString())
            if (resp.statusCode() !in 200..299) return null
            val obj = JsonParser.parseString(resp.body()).asJsonObject
            val cost = if (obj.has("cost") && obj.get("cost").isJsonPrimitive) obj.get("cost").asDouble.roundToLong() else 0L
            val craftCost = if (obj.has("craftCost") && obj.get("craftCost").isJsonPrimitive) obj.get("craftCost").asDouble.roundToLong() else 0L

            // Also sum ingredients in case Coflnet partial-zeroed one branch
            var ingSum = 0L
            if (obj.has("ingredients") && obj.get("ingredients").isJsonArray) {
                for (el in obj.getAsJsonArray("ingredients")) {
                    if (el.isJsonObject) {
                        val ing = el.asJsonObject
                        val ic = when {
                            ing.has("cost") && ing.get("cost").isJsonPrimitive && ing.get("cost").asDouble > 0 -> ing.get("cost").asDouble.roundToLong()
                            ing.has("directBuyCost") && ing.get("directBuyCost").isJsonPrimitive && ing.get("directBuyCost").asDouble > 0 -> ing.get("directBuyCost").asDouble.roundToLong()
                            ing.has("craftCost") && ing.get("craftCost").isJsonPrimitive && ing.get("craftCost").asDouble > 0 -> ing.get("craftCost").asDouble.roundToLong()
                            else -> 0L
                        }
                        ingSum += ic
                    }
                }
            }
            val best = max(max(cost, craftCost), ingSum)
            if (best > 0L) best else null
        } catch (_: Exception) {
            null
        }
    }

    private fun fetchEstimated(
        rawId: String,
        lookupId: String,
        name: String,
        attrs: JsonObject,
        enchants: Map<String, Int>,
        craftCost: Long?,
        lbin: Long?,
        avg7d: Long?
    ): Long? {
        val cleanAttrs = sanitizeAttrs(attrs)
        val item = JsonObject().apply {
            addProperty("tag", rawId)
            addProperty("itemName", name.ifEmpty { rawId })
            addProperty("count", 1)
            add("extraAttributes", cleanAttrs)
            val enchObj = JsonObject()
            for ((k, v) in enchants) {
                enchObj.addProperty(k, v)
            }
            add("enchantments", enchObj)
        }
        val body = JsonArray().apply { add(item) }

        val req = HttpRequest.newBuilder(URI.create(BREAKDOWN_URL))
            .timeout(Duration.ofSeconds(18))
            .header("User-Agent", "Vampy/" + VampyMod.MOD_ID)
            .header("Accept", "application/json")
            .header("Content-Type", "application/json")
            .POST(HttpRequest.BodyPublishers.ofString(body.toString()))
            .build()
        val resp = HTTP.send(req, HttpResponse.BodyHandlers.ofString())
        if (resp.statusCode() !in 200..299) return null

        val root = JsonParser.parseString(resp.body())
        if (!root.isJsonArray || root.asJsonArray.isEmpty) return null
        val first = root.asJsonArray[0].asJsonObject
        if (!first.has("craftPrice") || !first.get("craftPrice").isJsonArray) return null

        var coflBase = 0L
        var mods = 0L
        for (el in first.getAsJsonArray("craftPrice")) {
            if (!el.isJsonObject) continue
            val row = el.asJsonObject
            if (!row.has("price") || !row.get("price").isJsonPrimitive) continue
            val price = row.get("price").asDouble.roundToLong()
            if (price <= 0) continue

            val attr = if (row.has("attribute") && !row.get("attribute").isJsonNull) row.get("attribute").asString else null
            val reason = if (row.has("formattedReson") && !row.get("formattedReson").isJsonNull) row.get("formattedReson").asString else ""

            // Base item line (attribute is null and reason is "Base Item price")
            if (attr.isNullOrEmpty()) {
                if (reason.contains("Base Item", ignoreCase = true) || coflBase == 0L) {
                    coflBase = max(coflBase, price)
                } else if (cleanAttrs.has("modifier") && reason.contains("Modifier", ignoreCase = true)) {
                    // Reforge stone cost (e.g. PRECURSOR_GEAR for Ancient has attribute=null and formattedReson="Modifier =")
                    mods += price
                }
                continue
            }

            val attrKey = attr.lowercase(Locale.ROOT)
            if (JUNK_ATTRS.contains(attrKey) || JUNK_ATTRS.contains(attr)) continue

            if (attrKey == "unlocked_slots" && !cleanAttrs.has("unlocked_slots") && !cleanAttrs.has("gems")) {
                continue
            }

            if (!attrKey.startsWith("enchant")
                && !cleanAttrs.has(attr)
                && !cleanAttrs.has(attrKey)
                && !(attrKey == "upgrade_level" && cleanAttrs.has("dungeon_item_level"))
            ) {
                continue
            }

            mods += price
        }

        // Determine the most accurate base price:
        // 1) Live AH Lowest BIN (if available)
        // 2) Craft Price (for craftable / upgraded Soulbound items like Diamond Necron Head)
        // 3) 7d Avg Price (if available)
        // 4) Coflnet breakdown Base Item price (only when item actually has modifiers or craft/market presence)
        val base = when {
            lbin != null && lbin > 0 -> lbin
            craftCost != null && craftCost > 0 -> max(craftCost, coflBase)
            avg7d != null && avg7d > 0 -> avg7d
            mods > 0 && coflBase > 0 -> coflBase
            else -> 0L
        }

        val total = base + mods
        return if (total > 0L) total else null
    }

    private fun sanitizeAttrs(attrs: JsonObject?): JsonObject {
        val out = JsonObject()
        if (attrs == null) return out
        for ((key, value) in attrs.entrySet()) {
            if (key == null) continue
            val lower = key.lowercase(Locale.ROOT)
            if (JUNK_ATTRS.contains(key) || JUNK_ATTRS.contains(lower)) continue
            out.add(key, value)
        }
        return out
    }

    private fun fingerprint(id: String, attrs: JsonObject?, enchants: Map<String, Int>?): String {
        return "$id|${attrs?.toString() ?: "{}"}|$enchants"
    }
}

object AhLowestBinTooltip {
    @JvmStatic
    fun register() {
        ItemTooltipCallback.EVENT.register { stack, _, _, lines -> append(stack, lines) }
    }

    private fun append(stack: ItemStack?, lines: MutableList<Component>) {
        if (!VampyConfig.isAhLowestBin()) return
        if (stack == null || stack.isEmpty) return

        val rawId = SkyblockItemIds.from(stack) ?: return
        val lookupId = CoflnetItemValueCache.resolvePriceLookupId(stack, rawId)

        val lbin = AhLowestBinCache.getLowestBin(lookupId) ?: AhLowestBinCache.getLowestBin(rawId)
        val value = CoflnetItemValueCache.getOrRequest(stack)
        val loading = CoflnetItemValueCache.isLoading(stack)

        // 1. AH Lowest BIN
        if (lbin != null && lbin > 0) {
            lines.add(labeled("AH Lowest BIN: ", "${AhLowestBinCache.formatCoins(lbin)} coins", ChatFormatting.GOLD, ChatFormatting.YELLOW))
        } else if (!AhLowestBinCache.isReady()) {
            lines.add(
                Component.literal("AH Lowest BIN: ").withStyle(ChatFormatting.GOLD)
                    .append(Component.literal(if (AhLowestBinCache.isRefreshing()) "Loading..." else "…").withStyle(ChatFormatting.GRAY))
            )
        }

        // 2. 7d Avg Price (4th line requested by user, cached & dynamic)
        val avg7d = value?.avg7dPrice
        if (avg7d != null && avg7d > 0) {
            lines.add(labeled("7d Avg Price: ", "${AhLowestBinCache.formatCoins(avg7d)} coins", ChatFormatting.GOLD, ChatFormatting.WHITE))
        } else if (loading && lbin != null) {
            lines.add(
                Component.literal("7d Avg Price: ").withStyle(ChatFormatting.GOLD)
                    .append(Component.literal("Loading…").withStyle(ChatFormatting.GRAY))
            )
        }

        // 3. Craft Price
        val craft = value?.craftPrice
        if (craft != null && craft > 0) {
            lines.add(labeled("Craft Price: ", "${AhLowestBinCache.formatCoins(craft)} coins", ChatFormatting.GOLD, ChatFormatting.AQUA))
        }

        // 4. Est. Value (works for both tradable and Soulbound items like Diamond Necron Head!)
        val est = value?.estimatedValue
        if (est != null && est > 0) {
            lines.add(labeled("Est. Value: ", "${AhLowestBinCache.formatCoins(est)} coins", ChatFormatting.GOLD, ChatFormatting.GREEN))
        } else if (loading) {
            lines.add(
                Component.literal("Est. Value: ").withStyle(ChatFormatting.GOLD)
                    .append(Component.literal("Loading…").withStyle(ChatFormatting.GRAY))
            )
        }
    }

    private fun labeled(label: String, value: String, labelColor: ChatFormatting, valueColor: ChatFormatting): MutableComponent {
        return Component.literal(label).withStyle(labelColor)
            .append(Component.literal(value).withStyle(valueColor))
    }
}

object ItemPriceEstimate {
    private val COIN_AMOUNT_PATTERN = Pattern.compile("(?i)^\\+?([\\d,]+(?:\\.\\d+)?)\\s*([kmb])?\\s*coins?\\b")
    private val LUMP_NUMBER_PATTERN = Pattern.compile("([\\d,]+(?:\\.\\d+)?)\\s*([kmbKMB])?")

    @JvmStatic
    fun estimateCoins(stack: ItemStack?): Long {
        if (stack == null || stack.isEmpty) return 0L

        val lump = parseTradeCoinLump(stack)
        if (lump != null && lump > 0) return lump

        val rawId = SkyblockItemIds.from(stack) ?: return 0L
        val lookupId = CoflnetItemValueCache.resolvePriceLookupId(stack, rawId)
        val count = max(1, stack.count).toLong()

        val v = CoflnetItemValueCache.getOrRequest(stack)
        if (v != null) {
            val est = v.estimatedValue
            if (est != null && est > 0) return est * count
        }

        val lbin = AhLowestBinCache.getLowestBin(lookupId) ?: AhLowestBinCache.getLowestBin(rawId)
        if (lbin != null && lbin > 0) return lbin * count

        if (v != null) {
            val craft = v.craftPrice
            if (craft != null && craft > 0) return craft * count
            val avg = v.avg7dPrice
            if (avg != null && avg > 0) return avg * count
        }

        val dropType = SlayerProfitTracker.identifyDropStack(stack)
        if (dropType != null) {
            val unit = SlayerProfitTracker.getUnitPrice(dropType)
            if (unit > 0) return unit * count
        }

        return 0L
    }

    @JvmStatic
    fun isLoading(stack: ItemStack?): Boolean {
        if (stack == null || stack.isEmpty) return false
        if (parseTradeCoinLump(stack) != null) return false
        val rawId = SkyblockItemIds.from(stack) ?: return false
        val lookupId = CoflnetItemValueCache.resolvePriceLookupId(stack, rawId)
        val v = CoflnetItemValueCache.getOrRequest(stack)
        if (v != null && (v.estimatedValue != null || v.craftPrice != null || v.avg7dPrice != null)) return false
        val lbin = AhLowestBinCache.getLowestBin(lookupId) ?: AhLowestBinCache.getLowestBin(rawId)
        if (lbin != null) return false
        return CoflnetItemValueCache.isLoading(stack) || !AhLowestBinCache.isReady()
    }

    /**
     * Parses Hypixel trade coin offers from hover name ("5,000,000 Coins", "50M Coins")
     * or lore ("Lump-sum amount"). Never matches non-coin items unless they have no SkyBlock ID.
     */
    @JvmStatic
    fun parseTradeCoinLump(stack: ItemStack?): Long? {
        if (stack == null || stack.isEmpty) return null
        val sbId = SkyblockItemIds.from(stack)
        // Real SkyBlock items have an ExtraAttributes id; trade coin stacks either have no id or "COIN_ITEM"
        if (sbId != null && sbId.isNotEmpty() && !sbId.contains("COIN", ignoreCase = true)) {
            return null
        }

        val itemIdStr = BuiltInRegistries.ITEM.getKey(stack.item).path.lowercase(Locale.ROOT)
        if (itemIdStr.contains("glass_pane") || itemIdStr.contains("barrier")) {
            return null
        }

        val hoverPlain = ChatFormatting.stripFormatting(stack.hoverName.string)?.trim() ?: ""
        if (hoverPlain.isNotEmpty()) {
            val hm = COIN_AMOUNT_PATTERN.matcher(hoverPlain)
            if (hm.find()) {
                val parsed = parseScaledCoins(hm.group(1), hm.group(2))
                if (parsed != null && parsed > 0) return parsed
            }
        }

        val lore = stack.get(DataComponents.LORE) ?: return null
        val lines = lore.lines()
        var isLump = false
        for (line in lines) {
            val plain = ChatFormatting.stripFormatting(line.string)?.trim() ?: continue
            if (plain.contains("lump-sum amount", ignoreCase = true) || plain.contains("transaction", ignoreCase = true)) {
                isLump = true
            }
            val lm = COIN_AMOUNT_PATTERN.matcher(plain)
            if (lm.find()) {
                val parsed = parseScaledCoins(lm.group(1), lm.group(2))
                if (parsed != null && parsed > 0) return parsed
            }
        }
        if (!isLump || lines.isEmpty()) return null

        for (i in lines.indices.reversed()) {
            val plain = ChatFormatting.stripFormatting(lines[i].string)?.replace(" ", "") ?: continue
            val m = LUMP_NUMBER_PATTERN.matcher(plain)
            if (m.find()) {
                val parsed = parseScaledCoins(m.group(1), m.group(2))
                if (parsed != null && parsed > 0) return parsed
            }
        }
        return null
    }

    private fun parseScaledCoins(numPart: String?, suffixPart: String?): Long? {
        if (numPart.isNullOrBlank()) return null
        return try {
            val base = numPart.replace(",", "").toDouble()
            if (base <= 0.0) return null
            val mult = when (suffixPart?.lowercase(Locale.ROOT)) {
                "k" -> 1_000.0
                "m" -> 1_000_000.0
                "b" -> 1_000_000_000.0
                else -> 1.0
            }
            (base * mult).roundToLong()
        } catch (_: NumberFormatException) {
            null
        }
    }
}

object TradeValueOverlay {
    /** Your offer: cols 0–3, rows 0–3 in the top trade container. */
    private val YOUR_SLOTS: Set<Int> = buildSlots(0, 3)
    /** Their offer: cols 5–8, rows 0–3 in the top trade container. */
    private val OTHER_SLOTS: Set<Int> = buildSlots(5, 8)

    @JvmStatic
    fun render(
        screen: AbstractContainerScreen<*>?,
        graphics: GuiGraphicsExtractor,
        leftPos: Int,
        topPos: Int,
        imageWidth: Int
    ) {
        if (!VampyConfig.isTradeValueOverlay()) return
        if (screen == null) return

        // Ensure LBIN cache is warmed up even if AH tooltip toggle is off
        if (!AhLowestBinCache.isReady() && !AhLowestBinCache.isRefreshing()) {
            AhLowestBinCache.forceRefreshForTrade()
        }

        val menu = screen.menu ?: return
        val title = ChatFormatting.stripFormatting(screen.title.string) ?: ""
        if (!isTradeContainer(title, menu.slots)) return

        var yourTotal = 0L
        var otherTotal = 0L
        var loading = false

        for (slot in menu.slots) {
            // CRITICAL BUG FIX: Ignore the player's own bottom inventory slots!
            // Previously slot.getContainerSlot() matched 0..35 in BOTH the top trade chest AND the player's own inventory!
            if (slot.container is Inventory) continue

            val idx = slot.containerSlot
            val stack = slot.item
            if (stack.isEmpty) continue

            val yours = YOUR_SLOTS.contains(idx)
            val theirs = OTHER_SLOTS.contains(idx)
            if (!yours && !theirs) continue

            if (ItemPriceEstimate.isLoading(stack)) loading = true
            val value = ItemPriceEstimate.estimateCoins(stack)
            if (yours) yourTotal += value else otherTotal += value
        }

        val client = Minecraft.getInstance()
        val font = client.font
        val screenW = client.window.guiScaledWidth
        val gap = 10
        val totalsY = topPos - 22
        val diffY = topPos - 11

        val yourText = "You: " + AhLowestBinCache.formatCoins(yourTotal) + if (loading) " …" else ""
        val otherText = "Them: " + AhLowestBinCache.formatCoins(otherTotal) + if (loading) " …" else ""

        val yourW = font.width(yourText)
        val otherW = font.width(otherText)

        var yourX = leftPos - gap - yourW
        if (yourX < 4) yourX = 4
        var otherX = leftPos + imageWidth + gap
        if (otherX + otherW > screenW - 4) {
            otherX = max(4, screenW - 4 - otherW)
        }

        graphics.text(font, Component.literal(yourText).withStyle(ChatFormatting.GREEN), yourX, totalsY, 0xFFFFFFFF.toInt())
        graphics.text(font, Component.literal(otherText).withStyle(ChatFormatting.AQUA), otherX, totalsY, 0xFFFFFFFF.toInt())

        val diff = yourTotal - otherTotal
        val (diffText, diffColor) = when {
            diff > 0 -> "You +" + AhLowestBinCache.formatCoins(diff) to ChatFormatting.GREEN
            diff < 0 -> "Them +" + AhLowestBinCache.formatCoins(-diff) to ChatFormatting.RED
            else -> "Even" to ChatFormatting.GRAY
        }
        val diffW = font.width(diffText)
        val diffX = leftPos + (imageWidth - diffW) / 2
        graphics.text(font, Component.literal(diffText).withStyle(diffColor), diffX, diffY, 0xFFFFFFFF.toInt())
    }

    private fun isTradeContainer(title: String, slots: List<net.minecraft.world.inventory.Slot>): Boolean {
        val clean = title.trim()
        if (clean.startsWith("You") && clean.length >= 5 && clean[3] == ' ') {
            return true
        }
        // Fallback detection by checking the middle divider column (slot 4) and confirm button (slot 39) in a 45-slot chest
        for (slot in slots) {
            if (slot.container is Inventory) continue
            if (slot.containerSlot == 39 && !slot.item.isEmpty) {
                val hover = ChatFormatting.stripFormatting(slot.item.hoverName.string)?.lowercase(Locale.ROOT) ?: ""
                if (hover.contains("trading!") || hover.contains("deal!") || hover.contains("warning!") || hover.contains("trade ")) {
                    return true
                }
            }
        }
        return false
    }

    private fun buildSlots(colStart: Int, colEnd: Int): Set<Int> {
        val set = HashSet<Int>()
        for (x in colStart..colEnd) {
            for (y in 0..3) {
                set.add(x + 9 * y)
            }
        }
        return set
    }
}
