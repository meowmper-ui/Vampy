package com.vampy.screen.crimson

import com.vampy.chat.ChatMessageHider
import com.vampy.config.VampyConfig
import com.vampy.screen.CommandHotkeysScreen
import com.vampy.screen.HudDragScreen
import net.minecraft.client.Minecraft
import net.minecraft.client.gui.GuiGraphicsExtractor
import net.minecraft.client.gui.screens.Screen
import net.minecraft.network.chat.Component
import net.minecraft.network.chat.Style
import net.minecraft.network.chat.TextColor
import net.minecraft.resources.Identifier
import java.util.*
import java.util.function.*
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

// ============================================================================
// 1. CrimsonColorMath
// ============================================================================
object CrimsonColorMath {
    @JvmField
    val PRESETS = intArrayOf(
        0xFFB33A3A.toInt(), // crimson
        0xFFD04848.toInt(), // bright blood
        0xFF8B2828.toInt(), // dark wine
        0xFFE8E0E0.toInt(), // bone
        0xFFFFAA33.toInt(), // warning amber
        0xFF55FFAA.toInt(), // ichor mint
        0xFF4488FF.toInt(), // spring blue
        0xFFFFFFFF.toInt()  // white
    )

    @JvmStatic
    fun rgbToHsv(r: Int, g: Int, b: Int): FloatArray {
        val rf = r / 255f
        val gf = g / 255f
        val bf = b / 255f
        val maxC = max(rf, max(gf, bf))
        val minC = min(rf, min(gf, bf))
        val d = maxC - minC
        var h = 0f
        if (d > 1e-6f) {
            h = when (maxC) {
                rf -> 60f * (((gf - bf) / d) % 6f)
                gf -> 60f * (((bf - rf) / d) + 2f)
                else -> 60f * (((rf - gf) / d) + 4f)
            }
        }
        if (h < 0f) h += 360f
        val s = if (maxC <= 1e-6f) 0f else d / maxC
        return floatArrayOf(h, s, maxC)
    }

    @JvmStatic
    fun hsvToRgb(hIn: Float, sIn: Float, vIn: Float): Int {
        val h = ((hIn % 360f) + 360f) % 360f
        val s = sIn.coerceIn(0f, 1f)
        val v = vIn.coerceIn(0f, 1f)
        val c = v * s
        val x = c * (1f - abs((h / 60f) % 2f - 1f))
        val m = v - c
        var r = 0f
        var g = 0f
        var b = 0f
        when {
            h < 60f -> { r = c; g = x }
            h < 120f -> { r = x; g = c }
            h < 180f -> { g = c; b = x }
            h < 240f -> { g = x; b = c }
            h < 300f -> { r = x; b = c }
            else -> { r = c; b = x }
        }
        val ri = ((r + m) * 255f).roundToInt().coerceIn(0, 255)
        val gi = ((g + m) * 255f).roundToInt().coerceIn(0, 255)
        val bi = ((b + m) * 255f).roundToInt().coerceIn(0, 255)
        return 0xFF000000.toInt() or (ri shl 16) or (gi shl 8) or bi
    }

    @JvmStatic
    fun hueToRgb(h: Float): Int = hsvToRgb(h, 1f, 1f)

    @JvmStatic
    fun parseHex(raw: String?): Int? {
        if (raw == null) return null
        var s = raw.trim().removePrefix("#")
        if (s.length == 3) {
            s = "${s[0]}${s[0]}${s[1]}${s[1]}${s[2]}${s[2]}"
        }
        if (s.length != 6) return null
        return s.toIntOrNull(16)?.let { 0xFF000000.toInt() or it }
    }
}

// ============================================================================
// 2. CrimsonTheme
// ============================================================================
object CrimsonTheme {
    private val VAMP_V2_BG = Identifier.fromNamespaceAndPath("vampy", "textures/gui/chateau_v2_bg.png")
    private const val VAMP_V2_BG_ASPECT = 1040f / 680f
    private const val VAMP_V2_SCRIM = 0x780A0614

    @JvmField var BG = 0xCC050E0A.toInt()
    @JvmField var WINDOW = 0xFF0A140F.toInt()
    @JvmField var WINDOW_INNER = 0xFF0E1A14.toInt()
    @JvmField var PANEL = 0xFF0C1712.toInt()
    @JvmField var PANEL_BORDER = 0xFF059669.toInt()
    @JvmField var FRAME = 0xFF10B981.toInt()
    @JvmField var FRAME_DIM = 0xFF047857.toInt()
    @JvmField var FLOURISH = 0xFF34D399.toInt()
    @JvmField var ROW = 0xFF0F1C16.toInt()
    @JvmField var ROW_HOVER = 0xFF14241C.toInt()
    @JvmField var ROW_SELECTED = 0xFF182E24.toInt()
    @JvmField var ROW_BORDER = 0xFF133827.toInt()
    @JvmField var ROW_BORDER_HOVER = 0xFF059669.toInt()
    @JvmField var SIDEBAR = 0xFF09120D.toInt()
    @JvmField var SIDEBAR_BTN = 0xFF0D1A13.toInt()
    @JvmField var SIDEBAR_BTN_HOVER = 0xFF13271D.toInt()
    @JvmField var SIDEBAR_SELECTED = 0xFF163225.toInt()
    @JvmField var SIDEBAR_BORDER = 0xFF064E3B.toInt()
    @JvmField var SIDEBAR_BORDER_SEL = 0xFF10B981.toInt()
    @JvmField var ACCENT = 0xFF10B981.toInt()
    @JvmField var ACCENT_SOFT = 0xFF059669.toInt()
    @JvmField var ACCENT_DIM = 0x6610B981
    @JvmField var ACCENT_BRIGHT = 0xFF34D399.toInt()
    @JvmField var TAB_UNDERLINE = 0xFF10B981.toInt()
    @JvmField var TEXT = 0xFFE6F4EA.toInt()
    @JvmField var TEXT_DIM = 0xFF8AA895.toInt()
    @JvmField var TEXT_ACCENT = 0xFF34D399.toInt()
    @JvmField var TOGGLE_OFF = 0xFF1B2E24.toInt()
    @JvmField var TOGGLE_ON = 0xFF10B981.toInt()
    @JvmField var BUTTON = 0xFF0E1C15.toInt()
    @JvmField var BUTTON_HOVER = 0xFF152A20.toInt()
    @JvmField var BUTTON_PRIMARY = 0xFF059669.toInt()
    @JvmField var BUTTON_PRIMARY_HOVER = 0xFF10B981.toInt()
    @JvmField var SAVE_FILL = 0xFF064E3B.toInt()
    @JvmField var SAVE_FILL_HOVER = 0xFF059669.toInt()
    @JvmField var SAVE_BORDER = 0xFF10B981.toInt()
    @JvmField var SAVE_BORDER_HOVER = 0xFF34D399.toInt()
    @JvmField var SAVE_TEXT = 0xFFE6F4EA.toInt()
    const val BLOOD_DROP = 0xFF047857.toInt()
    const val BLOOD_DROP_SHADE = 0xFF064E3B.toInt()
    const val BLOOD_DROP_HIGHLIGHT = 0xFF10B981.toInt()

    private var currentStyle = VampyConfig.GuiStyle.SIMPLIFIED
    private var accentRgb = 0x10B981

    @JvmStatic
    fun sync() {
        BG = 0xE6080C0A.toInt()
        WINDOW = 0xFF0B100E.toInt()
        WINDOW_INNER = 0xFF0E1411.toInt()
        PANEL = 0xFF0D1210.toInt()
        PANEL_BORDER = 0xFF182921.toInt()
        FRAME = 0xFF1D382B.toInt()
        FRAME_DIM = 0xFF14261D.toInt()
        FLOURISH = 0xFF059669.toInt()
        ROW = 0xFF101714.toInt()
        ROW_HOVER = 0xFF15221C.toInt()
        ROW_SELECTED = 0xFF192A22.toInt()
        ROW_BORDER = 0xFF182921.toInt()
        ROW_BORDER_HOVER = 0xFF059669.toInt()
        SIDEBAR = 0xFF090D0B.toInt()
        SIDEBAR_BTN = 0xFF0F1612.toInt()
        SIDEBAR_BTN_HOVER = 0xFF16221C.toInt()
        SIDEBAR_SELECTED = 0xFF1B2C23.toInt()
        SIDEBAR_BORDER = 0xFF16261E.toInt()
        SIDEBAR_BORDER_SEL = 0xFF10B981.toInt()
        ACCENT = 0xFF10B981.toInt()
        ACCENT_SOFT = 0xFF059669.toInt()
        ACCENT_DIM = 0x55059669
        ACCENT_BRIGHT = 0xFF34D399.toInt()
        TAB_UNDERLINE = 0xFF10B981.toInt()
        TEXT = 0xFFE2E8E4.toInt()
        TEXT_DIM = 0xFF7D9486.toInt()
        TEXT_ACCENT = 0xFF10B981.toInt()
        TOGGLE_OFF = 0xFF18261F.toInt()
        TOGGLE_ON = 0xFF10B981.toInt()
        BUTTON = 0xFF121B16.toInt()
        BUTTON_HOVER = 0xFF18261F.toInt()
        BUTTON_PRIMARY = 0xFF064E3B.toInt()
        BUTTON_PRIMARY_HOVER = 0xFF059669.toInt()
        SAVE_FILL = 0xFF064E3B.toInt()
        SAVE_FILL_HOVER = 0xFF059669.toInt()
        SAVE_BORDER = 0xFF10B981.toInt()
        SAVE_BORDER_HOVER = 0xFF34D399.toInt()
        SAVE_TEXT = 0xFFE2E8E4.toInt()
        accentRgb = 0x10B981
    }

    @JvmStatic fun style(): VampyConfig.GuiStyle = VampyConfig.GuiStyle.SIMPLIFIED
    @JvmStatic fun isSimplified(): Boolean = true
    @JvmStatic fun isVampV2(): Boolean = false
    @JvmStatic fun showIcons(): Boolean = false

    @JvmStatic
    fun accentLabel(base: Component): Component =
        base.copy().withStyle { it.withColor(TextColor.fromRgb(accentRgb)) }

    @JvmStatic
    fun accentStyle(): Style = Style.EMPTY.withColor(TextColor.fromRgb(accentRgb))

    @JvmStatic
    fun paintScreenBackground(graphics: GuiGraphicsExtractor, width: Int, height: Int) {
        graphics.fill(0, 0, width, height, BG)
    }

    @JvmStatic
    fun paintOrnateWindow(graphics: GuiGraphicsExtractor, x: Int, y: Int, w: Int, h: Int) {
        graphics.fill(x, y, x + w, y + h, WINDOW)
        graphics.fill(x + 2, y + 2, x + w - 2, y + h - 2, WINDOW_INNER)
        graphics.outline(x, y, w, h, PANEL_BORDER)
        graphics.outline(x + 1, y + 1, w - 2, h - 2, FRAME_DIM)
    }

    @JvmStatic
    fun paintSpikedCorners(graphics: GuiGraphicsExtractor, x: Int, y: Int, w: Int, h: Int) {
        val c = FRAME
        graphics.fill(x - 3, y + 3, x, y + 12, c); graphics.fill(x + 3, y - 3, x + 12, y, c)
        graphics.fill(x + w, y + 3, x + w + 3, y + 12, c); graphics.fill(x + w - 12, y - 3, x + w - 3, y, c)
        graphics.fill(x - 3, y + h - 12, x, y + h - 3, c); graphics.fill(x + 3, y + h, x + 12, y + h + 3, c)
        graphics.fill(x + w, y + h - 12, x + w + 3, y + h - 3, c); graphics.fill(x + w - 12, y + h, x + w - 3, y + h + 3, c)
    }

    @JvmStatic
    fun paintCornerFlourishes(graphics: GuiGraphicsExtractor, x: Int, y: Int, w: Int, h: Int) {
        val c = FLOURISH
        graphics.fill(x + 3, y + 3, x + 11, y + 4, c); graphics.fill(x + 3, y + 3, x + 4, y + 11, c)
        graphics.fill(x + w - 11, y + 3, x + w - 3, y + 4, c); graphics.fill(x + w - 4, y + 3, x + w - 3, y + 11, c)
        graphics.fill(x + 3, y + h - 4, x + 11, y + h - 3, c); graphics.fill(x + 3, y + h - 11, x + 4, y + h - 3, c)
        graphics.fill(x + w - 11, y + h - 4, x + w - 3, y + h - 3, c); graphics.fill(x + w - 4, y + h - 11, x + w - 3, y + h - 3, c)
        if (isVampV2()) {
            graphics.fill(x + 8, y + 3, x + 16, y + 4, FRAME); graphics.fill(x + 3, y + 8, x + 4, y + 16, FRAME)
            graphics.fill(x + w - 16, y + 3, x + w - 8, y + 4, FRAME); graphics.fill(x + w - 4, y + 8, x + w - 3, y + 16, FRAME)
            graphics.fill(x + 8, y + h - 4, x + 16, y + h - 3, FRAME); graphics.fill(x + 3, y + h - 16, x + 4, y + h - 8, FRAME)
            graphics.fill(x + w - 16, y + h - 4, x + w - 8, y + h - 3, FRAME); graphics.fill(x + w - 4, y + h - 16, x + w - 3, y + h - 8, FRAME)
            graphics.outline(x + 2, y + 2, w - 4, h - 4, FRAME_DIM)
        }
    }

    @JvmStatic
    fun paintPanel(graphics: GuiGraphicsExtractor, x: Int, y: Int, w: Int, h: Int) {
        graphics.fill(x, y, x + w, y + h, PANEL)
        graphics.outline(x, y, w, h, PANEL_BORDER)
        if (isVampV2()) {
            graphics.outline(x + 1, y + 1, w - 2, h - 2, withAlpha(ROW_BORDER, 0xAA))
            graphics.fill(x + 2, y + 2, x + 8, y + 3, FRAME); graphics.fill(x + 2, y + 2, x + 3, y + 8, FRAME)
            graphics.fill(x + w - 8, y + 2, x + w - 2, y + 3, FRAME); graphics.fill(x + w - 3, y + 2, x + w - 2, y + 8, FRAME)
            graphics.fill(x + 2, y + h - 3, x + 8, y + h - 2, FRAME); graphics.fill(x + 2, y + h - 8, x + 3, y + h - 2, FRAME)
            graphics.fill(x + w - 8, y + h - 3, x + w - 2, y + h - 2, FRAME); graphics.fill(x + w - 3, y + h - 8, x + w - 2, y + h - 2, FRAME)
            graphics.fill(x + 10, y + 2, x + w - 10, y + 3, FRAME_DIM)
        } else {
            graphics.fill(x, y, x + 1, y + h, ACCENT_DIM)
        }
    }

    @JvmStatic
    fun paintTitleFlourish(graphics: GuiGraphicsExtractor, cx: Int, y: Int, halfW: Int) {
        val c = if (isVampV2()) FRAME else FLOURISH
        graphics.fill(cx - halfW, y, cx + halfW, y + 1, c)
        graphics.fill(cx - halfW + 4, y + 1, cx + halfW - 4, y + 2, if (isVampV2()) FRAME_DIM else ACCENT_DIM)
        graphics.fill(cx - 3, y - 1, cx + 3, y + 2, if (isVampV2()) ACCENT else ACCENT_BRIGHT)
        graphics.fill(cx - 1, y - 2, cx + 1, y + 3, c)
        val tip = if (isVampV2()) FRAME else ACCENT_BRIGHT
        val tipSoft = if (isVampV2()) FRAME_DIM else ACCENT_SOFT
        graphics.fill(cx - halfW, y, cx - halfW + 4, y + 1, tip)
        graphics.fill(cx + halfW - 4, y, cx + halfW, y + 1, tip)
        graphics.fill(cx - halfW - 2, y, cx - halfW, y + 1, tipSoft)
        graphics.fill(cx + halfW, y, cx + halfW + 2, y + 1, tipSoft)
    }

    @JvmStatic
    fun paintSidebarButton(graphics: GuiGraphicsExtractor, x: Int, y: Int, w: Int, h: Int, hovered: Boolean, selected: Boolean) {
        val fill = if (selected) SIDEBAR_SELECTED else if (hovered) SIDEBAR_BTN_HOVER else SIDEBAR_BTN
        val border = if (selected) SIDEBAR_BORDER_SEL else if (hovered) ROW_BORDER_HOVER else SIDEBAR_BORDER
        graphics.fill(x, y, x + w, y + h, fill)
        graphics.outline(x, y, w, h, border)
    }

    @JvmStatic
    fun paintSidebarButtonV2(graphics: GuiGraphicsExtractor, x: Int, y: Int, w: Int, h: Int, hovered: Boolean, selected: Boolean) =
        paintSidebarButton(graphics, x, y, w, h, hovered, selected)

    @JvmStatic
    fun paintRow(graphics: GuiGraphicsExtractor, x: Int, y: Int, w: Int, h: Int, hovered: Boolean, selected: Boolean) {
        val fill = if (selected) ROW_SELECTED else if (hovered) ROW_HOVER else ROW
        val border = if (hovered || selected) ROW_BORDER_HOVER else ROW_BORDER
        graphics.fill(x, y, x + w, y + h, fill)
        graphics.outline(x, y, w, h, border)
        if (selected) graphics.fill(x, y + h - 1, x + w, y + h, ACCENT_DIM)
    }

    @JvmStatic
    fun paintButton(graphics: GuiGraphicsExtractor, x: Int, y: Int, w: Int, h: Int, hovered: Boolean) {
        graphics.fill(x, y, x + w, y + h, if (hovered) BUTTON_HOVER else BUTTON)
        graphics.outline(x, y, w, h, if (hovered) ROW_BORDER_HOVER else ROW_BORDER)
    }

    @JvmStatic
    fun paintPrimaryButton(graphics: GuiGraphicsExtractor, x: Int, y: Int, w: Int, h: Int, hovered: Boolean) {
        graphics.fill(x, y, x + w, y + h, if (hovered) BUTTON_PRIMARY_HOVER else BUTTON_PRIMARY)
        graphics.outline(x, y, w, h, if (hovered) ACCENT_BRIGHT else ACCENT)
    }

    @JvmStatic
    fun paintSaveButton(graphics: GuiGraphicsExtractor, x: Int, y: Int, w: Int, h: Int, hovered: Boolean) {
        graphics.fill(x, y, x + w, y + h, if (hovered) SAVE_FILL_HOVER else SAVE_FILL)
        graphics.outline(x, y, w, h, if (hovered) SAVE_BORDER_HOVER else SAVE_BORDER)
    }

    @JvmStatic
    fun withAlpha(rgb: Int, alpha: Int): Int = ((alpha and 0xFF) shl 24) or (rgb and 0x00FFFFFF)

    @JvmStatic
    fun toHex(argb: Int): String = String.format("#%06X", argb and 0xFFFFFF)
}

// ============================================================================
// 3. ConfigEntry
// ============================================================================
class ConfigEntry(
    @JvmField val kind: Kind,
    @JvmField val id: String,
    @JvmField val name: Component,
    @JvmField var description: Component = Component.empty(),
    @JvmField var groupId: String = "",
    @JvmField var boolGet: BooleanSupplier? = null,
    @JvmField var boolSet: Consumer<Boolean>? = null,
    @JvmField var defaultBool: Boolean? = null,
    @JvmField var doubleGet: DoubleSupplier? = null,
    @JvmField var doubleSet: DoubleConsumer? = null,
    @JvmField var min: Double = 0.0,
    @JvmField var max: Double = 1.0,
    @JvmField var step: Double = 0.1,
    @JvmField var defaultDouble: Double? = null,
    @JvmField var format: DoubleFunction<Component>? = null,
    @JvmField var cycleIndexGet: Supplier<Int>? = null,
    @JvmField var cycleIndexSet: Consumer<Int>? = null,
    @JvmField var cycleLabels: Array<Component> = emptyArray(),
    @JvmField var defaultCycleIndex: Int = 0,
    @JvmField var colorGet: IntSupplier? = null,
    @JvmField var colorSet: IntConsumer? = null,
    @JvmField var defaultColor: Int? = null,
    @JvmField var stringGet: Supplier<String>? = null,
    @JvmField var stringSet: Consumer<String>? = null,
    @JvmField var defaultString: String? = null,
    @JvmField var warningTextGet: Supplier<String>? = null,
    @JvmField var warningTextSet: Consumer<String>? = null,
    @JvmField var warningColorGet: IntSupplier? = null,
    @JvmField var warningColorSet: IntConsumer? = null,
    @JvmField var defaultWarningText: String? = null,
    @JvmField var defaultWarningColor: Int? = null,
    @JvmField var listGet: Supplier<List<String>>? = null,
    @JvmField var listSet: Consumer<List<String>>? = null,
    @JvmField var action: Runnable? = null,
    @JvmField var actionLabel: Component? = null,
    @JvmField var childEntries: List<ConfigEntry> = emptyList(),
    @JvmField var onReset: Runnable? = null
) {
    enum class Kind {
        SECTION, TOGGLE, SLIDER, CYCLE, COLOR, STRING, WARNING_LINE, STRING_LIST, ACTION, SUBGROUP
    }

    // Self-chaining builder methods directly on ConfigEntry (eliminates separate ConfigEntry$Builder class!)
    fun group(g: String): ConfigEntry = apply { this.groupId = g }
    fun onReset(r: Runnable): ConfigEntry = apply { this.onReset = r }
    fun build(): ConfigEntry = this

    fun resetToDefault() {
        onReset?.let {
            it.run()
            return
        }
        when (kind) {
            Kind.TOGGLE -> if (defaultBool != null) boolSet?.accept(defaultBool!!)
            Kind.SLIDER -> if (defaultDouble != null) doubleSet?.accept(defaultDouble!!)
            Kind.CYCLE -> cycleIndexSet?.accept(defaultCycleIndex)
            Kind.COLOR -> if (defaultColor != null) colorSet?.accept(defaultColor!!)
            Kind.STRING -> if (defaultString != null) stringSet?.accept(defaultString!!)
            Kind.WARNING_LINE -> {
                if (defaultWarningText != null) warningTextSet?.accept(defaultWarningText!!)
                if (defaultWarningColor != null) warningColorSet?.accept(defaultWarningColor!!)
            }
            Kind.STRING_LIST -> listSet?.accept(emptyList())
            Kind.SUBGROUP -> for (child in childEntries) child.resetToDefault()
            else -> {}
        }
    }

    companion object {
        @JvmStatic
        fun section(id: String, name: Component): ConfigEntry = ConfigEntry(Kind.SECTION, id, name)

        @JvmStatic
        fun toggle(id: String, name: Component, desc: Component, get: BooleanSupplier, set: Consumer<Boolean>, def: Boolean): ConfigEntry =
            ConfigEntry(Kind.TOGGLE, id, name, description = desc, boolGet = get, boolSet = set, defaultBool = def)

        @JvmStatic
        fun slider(
            id: String, name: Component, desc: Component,
            get: DoubleSupplier, set: DoubleConsumer,
            min: Double, max: Double, step: Double, def: Double,
            format: DoubleFunction<Component>
        ): ConfigEntry = ConfigEntry(
            Kind.SLIDER, id, name, description = desc,
            doubleGet = get, doubleSet = set, min = min, max = max, step = step, defaultDouble = def, format = format
        )

        @JvmStatic
        fun cycle(
            id: String, name: Component, desc: Component,
            get: Supplier<Int>, set: Consumer<Int>,
            labels: Array<Component>, defIndex: Int
        ): ConfigEntry = ConfigEntry(
            Kind.CYCLE, id, name, description = desc,
            cycleIndexGet = get, cycleIndexSet = set, cycleLabels = labels, defaultCycleIndex = defIndex
        )

        @JvmStatic
        fun color(id: String, name: Component, desc: Component, get: IntSupplier, set: IntConsumer, def: Int): ConfigEntry =
            ConfigEntry(Kind.COLOR, id, name, description = desc, colorGet = get, colorSet = set, defaultColor = def)

        @JvmStatic
        fun string(id: String, name: Component, desc: Component, get: Supplier<String>, set: Consumer<String>, def: String): ConfigEntry =
            ConfigEntry(Kind.STRING, id, name, description = desc, stringGet = get, stringSet = set, defaultString = def)

        @JvmStatic
        fun warningLine(
            id: String, name: Component, desc: Component,
            textGet: Supplier<String>, textSet: Consumer<String>,
            colorGet: IntSupplier, colorSet: IntConsumer,
            defText: String, defColor: Int
        ): ConfigEntry = ConfigEntry(
            Kind.WARNING_LINE, id, name, description = desc,
            warningTextGet = textGet, warningTextSet = textSet,
            warningColorGet = colorGet, warningColorSet = colorSet,
            defaultWarningText = defText, defaultWarningColor = defColor
        )

        @JvmStatic
        fun stringList(id: String, name: Component, desc: Component, get: Supplier<List<String>>, set: Consumer<List<String>>): ConfigEntry =
            ConfigEntry(Kind.STRING_LIST, id, name, description = desc, listGet = get, listSet = set)

        @JvmStatic
        fun action(id: String, name: Component, desc: Component, button: Component, run: Runnable): ConfigEntry =
            ConfigEntry(Kind.ACTION, id, name, description = desc, action = run, actionLabel = button)

        @JvmStatic
        fun subgroup(id: String, name: Component, desc: Component, children: List<ConfigEntry>): ConfigEntry =
            ConfigEntry(Kind.SUBGROUP, id, name, description = desc, childEntries = children.toList())
    }
}

// ============================================================================
// 4. ConfigCatalog
// ============================================================================
object ConfigCatalog {
    class Tab(
        @JvmField val id: String,
        @JvmField val name: Component,
        @JvmField val categories: List<Category>
    ) {
        fun id(): String = id
        fun name(): Component = name
        fun categories(): List<Category> = categories

        fun allEntries(): List<ConfigEntry> {
            val out = ArrayList<ConfigEntry>()
            for (c in categories) {
                out.addAll(c.entries)
            }
            return out
        }
    }

    class Category(
        @JvmField val id: String,
        @JvmField val name: Component,
        @JvmField val description: Component,
        @JvmField val icon: CrimsonIcons.Id,
        @JvmField val entries: List<ConfigEntry>
    ) {
        fun id(): String = id
        fun name(): Component = name
        fun description(): Component = description
        fun icon(): CrimsonIcons.Id = icon
        fun entries(): List<ConfigEntry> = entries
    }

    private inline fun lit(s: String): Component = Component.literal(s)
    private inline fun tr(k: String): Component = Component.translatable(k)
    private inline fun tr(k: String, vararg args: Any): Component = Component.translatable(k, *args)

    @JvmStatic
    fun buildTabs(host: Screen?): List<Tab> {
        val tabs = ArrayList<Tab>()
        tabs.add(Tab("utility", tr("screen.vampy.category.utility"), utilityCategories(host)))
        if (VampyConfig.isShowQolTab()) {
            tabs.add(Tab("qol", tr("screen.vampy.category.qol"), qolCategories(host)))
        }
        tabs.add(Tab("party", tr("screen.vampy.category.party"), partyCategories()))
        return tabs
    }

    private fun utilityCategories(host: Screen?): List<Category> {
        val cats = ArrayList<Category>()
        val warningsMain = ArrayList<ConfigEntry>()
        warningsMain.add(ConfigEntry.toggle("warnings_enabled", tr("screen.vampy.warnings_enabled"), tr("screen.vampy.warnings_enabled.desc"), VampyConfig::isWarningsEnabled, VampyConfig::setWarningsEnabled, true))
        warningsMain.add(ConfigEntry.slider("warning_size", tr("screen.vampy.warning_size"), tr("screen.vampy.warning_size.desc"), VampyConfig::getWarningSize, VampyConfig::setWarningSize, 0.5, 5.0, 0.25, 2.0) { v -> lit(String.format("%.2fx", v)) })
        warningsMain.add(ConfigEntry.string("warning_preview", tr("screen.vampy.warning_preview"), tr("screen.vampy.warning_preview.desc"), VampyConfig::getWarningPreview, VampyConfig::setWarningPreview, "SNEAK 1.4s"))

        val warnLines = ArrayList<ConfigEntry>()
        for (key in warningTriggers()) {
            val defText = VampyConfig.resolveWarningDisplay(key)
            val defColor = VampyConfig.getWarningColor(key)
            warnLines.add(ConfigEntry.warningLine(
                "warn_$key", lit(key), tr("screen.vampy.warning_line.desc", key),
                { VampyConfig.resolveWarningDisplay(key) },
                { text -> VampyConfig.setWarningRule(key, text) },
                { VampyConfig.getWarningColor(key) },
                { color -> VampyConfig.setWarningColor(key, color) },
                defText, defColor
            ))
        }
        warningsMain.add(ConfigEntry.subgroup("sub_midboss_text_replacements", lit("Midboss Text Replacements"), lit("Display text and color replacements for each boss warning trigger."), warnLines))
        cats.add(Category("warnings", tr("screen.vampy.group.warnings"), lit("Boss popup warnings, size, and text replacements."), CrimsonIcons.Id.EYE, warningsMain))

        val ichor = ArrayList<ConfigEntry>()
        ichor.add(ConfigEntry.toggle("ichor_helper", tr("screen.vampy.ichor_helper"), tr("screen.vampy.ichor_helper.desc"), VampyConfig::isIchorHelper, VampyConfig::setIchorHelper, true))
        ichor.add(ConfigEntry.color("ichor_color", tr("screen.vampy.ichor_markers_color"), tr("screen.vampy.ichor_markers_color.desc"), VampyConfig::getIchorEspColor, VampyConfig::setIchorEspColor, -5636096))
        cats.add(Category("ichor", tr("screen.vampy.group.ichor"), lit("Blood Ichor box, tracer, and countdown HUD."), CrimsonIcons.Id.DROPLET, ichor))

        val spring = ArrayList<ConfigEntry>()
        spring.add(ConfigEntry.toggle("spring_helper", tr("screen.vampy.killer_spring_helper"), tr("screen.vampy.killer_spring_helper.desc"), VampyConfig::isKillerSpringHelper, VampyConfig::setKillerSpringHelper, true))
        spring.add(ConfigEntry.color("spring_color", tr("screen.vampy.killer_spring_tracers_color"), tr("screen.vampy.killer_spring_tracers_color.desc"), VampyConfig::getKillerSpringEspColor, VampyConfig::setKillerSpringEspColor, -16711936))
        cats.add(Category("spring", tr("screen.vampy.group.killer_spring"), lit("Killer Spring column, tracer, and countdown."), CrimsonIcons.Id.COMPASS, spring))

        val mania = ArrayList<ConfigEntry>()
        mania.add(ConfigEntry.toggle("mania_helper", lit("Mania Safe Spot Helper"), lit("Reconstructs your Bloodfiend's Mania pattern in memory and highlights safe/danger rings on uneven terrain or overlapping bosses."), VampyConfig::isManiaHelper, VampyConfig::setManiaHelper, true))
        mania.add(ConfigEntry.toggle("mania_hud_enabled", lit("Mania Status HUD"), lit("Show SAFE / MOVE IN / MOVE OUT and time until coal during your Mania."), VampyConfig::isManiaHudEnabled, VampyConfig::setManiaHudEnabled, true))

        val maniaStyleAndFilters = ArrayList<ConfigEntry>()
        maniaStyleAndFilters.add(ConfigEntry.toggle("mania_render_style", lit("Block Tint Mode (OFF = Plane)"), lit("OFF = 2D flat squares on the ground (Plane); ON = tints full block collision boxes (Block Tint)."),
            { "block_tint".equals(VampyConfig.getManiaRenderStyle(), ignoreCase = true) },
            { v -> VampyConfig.setManiaRenderStyle(if (v) "block_tint" else "plane") }, false))
        maniaStyleAndFilters.add(ConfigEntry.slider("mania_square_size", lit("Plane Square Size"), lit("Side length of the flat squares when using Plane style."), VampyConfig::getManiaSquareSize, VampyConfig::setManiaSquareSize, 0.1, 1.0, 0.05, 0.5) { v -> lit(String.format("%.2f", v)) })
        maniaStyleAndFilters.add(ConfigEntry.slider("mania_render_radius", lit("Render Radius"), lit("Only render columns this close to you (30 renders the whole pattern)."),
            { VampyConfig.getManiaRenderRadius().toDouble() },
            { v -> VampyConfig.setManiaRenderRadius(v.roundToInt()) }, 3.0, 30.0, 1.0, 30.0) { v -> lit(String.format("%.0f blocks", v)) })
        maniaStyleAndFilters.add(ConfigEntry.toggle("mania_safe_only", lit("Safe Ring Only"), lit("Only render the safe (green) ring."), VampyConfig::isManiaSafeOnly, VampyConfig::setManiaSafeOnly, false))
        maniaStyleAndFilters.add(ConfigEntry.toggle("mania_only_different", lit("Only Where Different"), lit("Skip columns where the real ground block already shows the expected Mania block."), VampyConfig::isManiaOnlyDifferent, VampyConfig::setManiaOnlyDifferent, false))
        mania.add(ConfigEntry.subgroup("sub_mania_style", lit("Mania Render & Filters"), lit("Plane vs Block Tint style, square size, radius, and ring filters."), maniaStyleAndFilters))

        val maniaColors = ArrayList<ConfigEntry>()
        maniaColors.add(ConfigEntry.color("mania_safe_color", lit("Safe Ring Color"), lit("Color for the safe (green) ring."), VampyConfig::getManiaSafeColor, VampyConfig::setManiaSafeColor, -1723279728))
        maniaColors.add(ConfigEntry.color("mania_terracotta_color", lit("Red Terracotta Color"), lit("Color for unsafe rings during the terracotta phase."), VampyConfig::getManiaTerracottaColor, VampyConfig::setManiaTerracottaColor, -2135665860))
        maniaColors.add(ConfigEntry.color("mania_redstone_color", lit("Redstone Phase Color"), lit("Color for unsafe rings during the redstone phase."), VampyConfig::getManiaRedstoneColor, VampyConfig::setManiaRedstoneColor, -2130763744))
        maniaColors.add(ConfigEntry.color("mania_coal_color", lit("Coal Phase Color"), lit("Color for coal rings, core, and border."), VampyConfig::getManiaCoalColor, VampyConfig::setManiaCoalColor, -1726342630))
        mania.add(ConfigEntry.subgroup("sub_mania_colors", lit("Mania Phase Colors"), lit("Customize colors for safe, terracotta, redstone, and coal rings."), maniaColors))
        cats.add(Category("mania_helper", lit("Mania Helper"), lit("Safe ring ground highlight, centre fitting, and status HUD."), CrimsonIcons.Id.ESP, mania))

        val effigy = ArrayList<ConfigEntry>()
        effigy.add(ConfigEntry.toggle("effigy", tr("screen.vampy.effigy_enabled"), tr("screen.vampy.effigy_enabled.desc"), VampyConfig::isEffigyEnabled, VampyConfig::setEffigyEnabled, true))
        cats.add(Category("effigy", tr("screen.vampy.group.effigy"), lit("Beacon beams for Blood Effigy slots in the Rift."), CrimsonIcons.Id.EFFIGY, effigy))

        val riftTime = ArrayList<ConfigEntry>()
        riftTime.add(ConfigEntry.toggle("rift_time_reminder", tr("screen.vampy.rift_time_reminder"), tr("screen.vampy.rift_time_reminder.desc"), VampyConfig::isRiftTimeReminder, VampyConfig::setRiftTimeReminder, true))
        cats.add(Category("rift_time", tr("screen.vampy.group.rift_time"), lit("Anvil + warning when Rift time drops to 4 minutes."), CrimsonIcons.Id.CLOCK, riftTime))

        val combatFeatures = ArrayList<ConfigEntry>()
        combatFeatures.add(ConfigEntry.toggle("boss_steak_alert", lit("Boss STEAK NOW Alert"), lit("Center-screen STEAK NOW! popup + sound when Boss can be steaked."), VampyConfig::isBossSteakAlert, VampyConfig::setBossSteakAlert, true))
        combatFeatures.add(ConfigEntry.toggle("lootshare_boss_callout", lit("Lootshare Boss Callout & Waypoint"), lit("Auto-send '/pc Lootsharable T4/T5 boss at X Y Z' (<=1200 HP T5 / <=1080 HP T4) and show party waypoint."), VampyConfig::isLootshareBossCallout, VampyConfig::setLootshareBossCallout, true))
        combatFeatures.add(ConfigEntry.toggle("item_cooldown_overlay", lit("Hotbar Cooldown Timer"), lit("Display ability cooldown timer directly on hotbar slots after item use."), VampyConfig::isItemCooldownOverlay, VampyConfig::setItemCooldownOverlay, true))

        val combatHighlights = ArrayList<ConfigEntry>()
        combatHighlights.add(ConfigEntry.toggle("party_member_glow_combat", lit("Party Member Glow"), lit("Highlight party members through walls with custom color or Dungeon class color."), VampyConfig::isPartyMemberGlow, VampyConfig::setPartyMemberGlow, true))
        combatHighlights.add(ConfigEntry.toggle("steakable_highlight", lit("Steakable Mob Highlight"), lit("Highlight low-HP mobs ready to be finished with Steak (line of sight only)."), VampyConfig::isSteakableHighlight, VampyConfig::setSteakableHighlight, true))
        combatHighlights.add(ConfigEntry.toggle("slayer_boss_highlight", lit("Slayer Boss Highlight"), lit("Highlight all SkyBlock Slayer bosses (Bloodfiend, Revenant, Tarantula, Sven, Voidgloom, Inferno)."), VampyConfig::isSlayerBossHighlight, VampyConfig::setSlayerBossHighlight, true))
        combatHighlights.add(ConfigEntry.toggle("auto_chat_waypoints", lit("Auto Chat Coord Waypoints"), lit("Automatically outline the block when coordinates (X Y Z) appear in chat. Off by default (you can always left-click coordinates in chat to toggle a waypoint)."), VampyConfig::isAutoChatWaypoints, VampyConfig::setAutoChatWaypoints, false))
        combatFeatures.add(ConfigEntry.subgroup("sub_combat_highlights", lit("Entity & Waypoint Highlights"), lit("Party member glow, Slayer boss highlight, steakable mobs, and chat waypoints."), combatHighlights))
        cats.add(Category("combat_highlights", lit("Combat & Cooldowns"), lit("Legit highlights, STEAK NOW alert, and hotbar ability cooldowns."), CrimsonIcons.Id.ESP, combatFeatures))

        val profitEntries = ArrayList<ConfigEntry>()
        profitEntries.add(ConfigEntry.toggle("slayer_profit_enabled", lit("Slayer Profit Tracker (Master)"), lit("Master toggle for the Slayer Profit Tracker HUD."), VampyConfig::isSlayerProfitTrackerEnabled, VampyConfig::setSlayerProfitTrackerEnabled, true))

        val perBossTrackers = ArrayList<ConfigEntry>()
        perBossTrackers.add(ConfigEntry.toggle("track_vampire_slayer", lit("Vampire Tracker (Bloodfiend)"), lit("Enable Profit Tracker for Riftstalker Bloodfiend in Stillgore Chateau."), VampyConfig::isTrackVampireSlayer, VampyConfig::setTrackVampireSlayer, true))
        perBossTrackers.add(ConfigEntry.toggle("track_zombie_slayer", lit("Zombie Tracker (Revenant / Atoned)"), lit("Enable Profit Tracker for Revenant Horror & Atoned Horror."), VampyConfig::isTrackZombieSlayer, VampyConfig::setTrackZombieSlayer, true))
        perBossTrackers.add(ConfigEntry.toggle("track_spider_slayer", lit("Spider Tracker (Tarantula)"), lit("Enable Profit Tracker for Tarantula Broodfather."), VampyConfig::isTrackSpiderSlayer, VampyConfig::setTrackSpiderSlayer, true))
        perBossTrackers.add(ConfigEntry.toggle("track_wolf_slayer", lit("Wolf Tracker (Sven Packmaster)"), lit("Enable Profit Tracker for Sven Packmaster."), VampyConfig::isTrackWolfSlayer, VampyConfig::setTrackWolfSlayer, true))
        perBossTrackers.add(ConfigEntry.toggle("track_enderman_slayer", lit("Enderman Tracker (Voidgloom Seraph)"), lit("Enable Profit Tracker for Voidgloom Seraph."), VampyConfig::isTrackEndermanSlayer, VampyConfig::setTrackEndermanSlayer, true))
        perBossTrackers.add(ConfigEntry.toggle("track_blaze_slayer", lit("Blaze Tracker (Inferno Demonlord)"), lit("Enable Profit Tracker for Inferno Demonlord."), VampyConfig::isTrackBlazeSlayer, VampyConfig::setTrackBlazeSlayer, true))
        profitEntries.add(ConfigEntry.subgroup("sub_profit_bosses", lit("Enabled Slayer Trackers"), lit("Toggle Profit Tracker individually for each Slayer boss type."), perBossTrackers))

        val profitPricing = ArrayList<ConfigEntry>()
        profitPricing.add(ConfigEntry.toggle("bazaar_insta_buy", lit("Use Bazaar Insta-Buy Price"), lit("ON = Bazaar Insta-Buy (Buy Order) price; OFF = Bazaar Insta-Sell (Sell Offer) price."), VampyConfig::isBazaarUseInstaBuy, VampyConfig::setBazaarUseInstaBuy, false))
        profitPricing.add(ConfigEntry.slider("unfanged_relic_pct", lit("Unfanged Price (% of Relic)"), lit("Percentage of Vampire Dentist Relic price used for Unfanged Vampire Part."), VampyConfig::getUnfangedRelicPercent, VampyConfig::setUnfangedRelicPercent, 0.0, 100.0, 1.0, 85.0) { v -> lit(String.format("%.0f%%", v)) })
        profitPricing.add(ConfigEntry.slider("slayer_profit_scale", lit("Tracker HUD Scale"), lit("Size of the Slayer Profit Tracker overlay."), VampyConfig::getSlayerProfitScale, VampyConfig::setSlayerProfitScale, 0.5, 2.5, 0.05, 1.0) { v -> lit(String.format("%.2fx", v)) })
        profitEntries.add(ConfigEntry.subgroup("sub_profit_options", lit("Tracker Pricing & Scale"), lit("Bazaar price mode, Unfanged Relic valuation, and HUD scale."), profitPricing))
        cats.add(Category("slayer_profit", lit("Profit Tracker"), lit("Per-Slayer profit trackers, Bazaar mode, and Unfanged Relic valuation."), CrimsonIcons.Id.CLOCK, profitEntries))

        val slayerTimers = ArrayList<ConfigEntry>()
        slayerTimers.add(ConfigEntry.toggle("slayer_timers", tr("screen.vampy.slayer_timers"), tr("screen.vampy.slayer_timers.desc"), VampyConfig::isSlayerTimersEnabled, VampyConfig::setSlayerTimersEnabled, true))
        slayerTimers.add(ConfigEntry.action("slayer_pb_reset", tr("screen.vampy.slayer_pb_reset"), tr("screen.vampy.slayer_pb_reset.desc"), lit("Click!"), VampyConfig::resetSlayerPersonalBests))
        cats.add(Category("slayer_timers", tr("screen.vampy.group.slayer_timers"), lit("Boss kill / quest timers and personal bests."), CrimsonIcons.Id.CLOCK, slayerTimers))

        val hud = ArrayList<ConfigEntry>()
        hud.add(ConfigEntry.action("hud_drag", tr("screen.vampy.hud_drag"), tr("screen.vampy.hud_drag.desc"), lit("Click!")) {
            Minecraft.getInstance().setScreenAndShow(HudDragScreen(host))
        })
        cats.add(Category("hud", tr("screen.vampy.group.hud_layout"), lit("Drag Ichor and Spring HUD positions on screen."), CrimsonIcons.Id.CLOCK, hud))

        val general = ArrayList<ConfigEntry>()
        general.add(ConfigEntry.toggle("show_qol", tr("screen.vampy.show_qol_tab"), tr("screen.vampy.show_qol_tab.desc"), VampyConfig::isShowQolTab, { value ->
            VampyConfig.setShowQolTab(value)
            if (host is CrimsonConfigScreen) {
                host.reloadTabsPreserveSelection()
            }
        }, false))
        cats.add(Category("general", lit("General"), lit("Config screen and tab visibility."), CrimsonIcons.Id.GEAR, general))
        return cats
    }

    private fun qolCategories(host: Screen?): List<Category> {
        val cats = ArrayList<Category>()
        val player = ArrayList<ConfigEntry>()
        player.add(ConfigEntry.slider("self_scale", tr("screen.vampy.self_scale"), tr("screen.vampy.self_scale.desc"), VampyConfig::getSelfPlayerScale, { v ->
            VampyConfig.setSelfPlayerScale(v)
            VampyConfig.save()
        }, 0.1, 3.0, 0.05, 1.0) { v -> lit(String.format("%.2fx", v)) })
        player.add(ConfigEntry.slider("other_scale", tr("screen.vampy.other_scale"), tr("screen.vampy.other_scale.desc"), VampyConfig::getOtherPlayerScale, { v ->
            VampyConfig.setOtherPlayerScale(v)
            VampyConfig.save()
        }, 0.1, 3.0, 0.05, 1.0) { v -> lit(String.format("%.2fx", v)) })
        player.add(ConfigEntry.toggle("skip_face", tr("screen.vampy.skip_face_view"), tr("screen.vampy.skip_face_view.desc"), VampyConfig::isSkipFaceView, { v ->
            VampyConfig.setSkipFaceView(v)
            VampyConfig.save()
        }, false))
        cats.add(Category("player", lit("Player"), lit("Model scale and camera cycle tweaks."), CrimsonIcons.Id.GEAR, player))

        val perfHud = ArrayList<ConfigEntry>()
        perfHud.add(ConfigEntry.toggle("perf_hud", tr("screen.vampy.perf_hud"), tr("screen.vampy.perf_hud.desc"), VampyConfig::isPerfHudEnabled, VampyConfig::setPerfHudEnabled, false))
        val perfHudAppearance = ArrayList<ConfigEntry>()
        perfHudAppearance.add(ConfigEntry.color("perf_hud_color", tr("screen.vampy.perf_hud_color"), tr("screen.vampy.perf_hud_color.desc"), VampyConfig::getPerfHudColor, VampyConfig::setPerfHudColor, -5226436))
        perfHudAppearance.add(ConfigEntry.slider("perf_hud_scale", tr("screen.vampy.perf_hud_scale"), tr("screen.vampy.perf_hud_scale.desc"), VampyConfig::getPerfHudScale, VampyConfig::setPerfHudScale, 0.5, 3.0, 0.05, 1.0) { v -> lit(String.format("%.2fx", v)) })
        perfHudAppearance.add(ConfigEntry.action("perf_hud_drag", tr("screen.vampy.perf_hud_drag"), tr("screen.vampy.perf_hud_drag.desc"), lit("Click!")) {
            Minecraft.getInstance().setScreenAndShow(HudDragScreen(host))
        })
        perfHud.add(ConfigEntry.subgroup("sub_perf_hud_appearance", lit("Performance HUD Style"), lit("Color, scale, and screen position for the Performance HUD."), perfHudAppearance))
        cats.add(Category("perf_hud", tr("screen.vampy.group.perf_hud"), lit("On-screen FPS, TPS, and ping."), CrimsonIcons.Id.CLOCK, perfHud))

        val cross = ArrayList<ConfigEntry>()
        cross.add(ConfigEntry.toggle("tp_crosshair", tr("screen.vampy.tp_crosshair"), tr("screen.vampy.tp_crosshair.desc"), VampyConfig::isThirdPersonCrosshair, { v ->
            VampyConfig.setThirdPersonCrosshair(v)
            VampyConfig.save()
        }, false))
        cross.add(ConfigEntry.toggle("custom_crosshair", tr("screen.vampy.custom_crosshair"), tr("screen.vampy.custom_crosshair.desc"), VampyConfig::isCustomCrosshair, { v ->
            VampyConfig.setCustomCrosshair(v)
            VampyConfig.save()
        }, false))
        val styles = VampyConfig.CrosshairStyle.values()
        val styleLabels = Array(styles.size) { i -> tr("screen.vampy.crosshair_style." + styles[i].id) }
        val crossCustomization = ArrayList<ConfigEntry>()
        crossCustomization.add(ConfigEntry.cycle("crosshair_style", tr("screen.vampy.crosshair_style"), tr("screen.vampy.crosshair_style.desc"),
            { VampyConfig.getCrosshairStyleEnum().ordinal },
            { idx ->
                val i = idx.coerceIn(0, styles.size - 1)
                VampyConfig.setCrosshairStyleEnum(styles[i])
                VampyConfig.save()
            }, styleLabels, VampyConfig.CrosshairStyle.CROSS.ordinal))
        crossCustomization.add(ConfigEntry.slider("crosshair_scale", tr("screen.vampy.crosshair_scale"), tr("screen.vampy.crosshair_scale.desc"), VampyConfig::getCrosshairScale, { v ->
            VampyConfig.setCrosshairScale(v)
            VampyConfig.save()
        }, 0.25, 3.0, 0.05, 1.0) { v -> lit(String.format("%.2fx", v)) })
        crossCustomization.add(ConfigEntry.color("crosshair_color", tr("screen.vampy.crosshair_color"), tr("screen.vampy.crosshair_color.desc"), VampyConfig::getCrosshairColor, { v ->
            VampyConfig.setCrosshairColor(v)
            VampyConfig.save()
        }, -1))
        crossCustomization.add(ConfigEntry.toggle("crosshair_chroma", tr("screen.vampy.crosshair_chroma"), tr("screen.vampy.crosshair_chroma.desc"), VampyConfig::isCrosshairChroma, { v ->
            VampyConfig.setCrosshairChroma(v)
            VampyConfig.save()
        }, false))
        cross.add(ConfigEntry.subgroup("sub_crosshair_customization", lit("Crosshair Appearance"), lit("Customize crosshair shape, scale, color, and chroma."), crossCustomization))
        cats.add(Category("crosshair", lit("Crosshair"), lit("Custom crosshair style, size, color, and chroma."), CrimsonIcons.Id.CROSSHAIR, cross))

        val chat = ArrayList<ConfigEntry>()
        chat.add(ConfigEntry.toggle("chat_copy", tr("screen.vampy.chat_copy"), tr("screen.vampy.chat_copy.desc"), VampyConfig::isChatCtrlClickCopy, { v ->
            VampyConfig.setChatCtrlClickCopy(v)
            VampyConfig.save()
        }, false))
        chat.add(ConfigEntry.toggle("chat_stacking", tr("screen.vampy.chat_stacking"), tr("screen.vampy.chat_stacking.desc"), VampyConfig::isChatStacking, VampyConfig::setChatStacking, false))
        chat.add(ConfigEntry.toggle("hide_stash", tr("screen.vampy.hide_stash"), tr("screen.vampy.hide_stash.desc"), VampyConfig::isHideStashMessages, { v ->
            VampyConfig.setHideStashMessages(v)
            ChatMessageHider.reapplyAfterRulesChanged()
        }, false))
        chat.add(ConfigEntry.stringList("hidden_chat", tr("screen.vampy.hidden_chat"), tr("screen.vampy.hidden_chat.desc"), VampyConfig::getHiddenChatMessages) { listVal ->
            VampyConfig.setHiddenChatMessages(listVal)
            ChatMessageHider.reapplyAfterRulesChanged()
        })
        chat.add(ConfigEntry.toggle("persistent_chat", tr("screen.vampy.persistent_chat"), tr("screen.vampy.persistent_chat.desc"), VampyConfig::isPersistentChatHistory, VampyConfig::setPersistentChatHistory, false))
        chat.add(ConfigEntry.toggle("auto_chat_waypoints_qol", lit("Auto Chat Coord Waypoints"), lit("Automatically outline the block when coordinates (X Y Z) appear in chat. Off by default (left-click any coords in chat to toggle manually)."), VampyConfig::isAutoChatWaypoints, VampyConfig::setAutoChatWaypoints, false))
        cats.add(Category("chat", lit("Chat"), lit("Stacking, hide patterns, copy, and history."), CrimsonIcons.Id.CHAT, chat))

        val vision = ArrayList<ConfigEntry>()
        vision.add(ConfigEntry.toggle("fullbright", tr("screen.vampy.fullbright"), tr("screen.vampy.fullbright.desc"), VampyConfig::isFullbright, VampyConfig::setFullbright, false))
        vision.add(ConfigEntry.toggle("clear_overlays", tr("screen.vampy.clear_overlays"), tr("screen.vampy.clear_overlays.desc"), VampyConfig::isClearOverlays, { v ->
            VampyConfig.setClearOverlays(v)
            VampyConfig.save()
        }, false))
        vision.add(ConfigEntry.toggle("particles_hearts", tr("screen.vampy.particles_hearts"), tr("screen.vampy.particles_hearts.desc"), VampyConfig::isParticlesOnlyHearts, { v ->
            VampyConfig.setParticlesOnlyHearts(v)
            VampyConfig.save()
        }, false))
        cats.add(Category("vision", tr("screen.vampy.group.clearview"), lit("Fullbright, overlays, and particle filtering."), CrimsonIcons.Id.VISION, vision))

        val drops = ArrayList<ConfigEntry>()
        drops.add(ConfigEntry.toggle("item_rarity", tr("screen.vampy.item_rarity_outline"), tr("screen.vampy.item_rarity_outline.desc"), VampyConfig::isItemRarityOutline, VampyConfig::setItemRarityOutline, false))
        drops.add(ConfigEntry.toggle("ah_lowest_bin", tr("screen.vampy.ah_lowest_bin"), tr("screen.vampy.ah_lowest_bin.desc"), VampyConfig::isAhLowestBin, { v ->
            VampyConfig.setAhLowestBin(v)
            if (v) {
                com.vampy.price.AhLowestBinCache.requestRefresh()
            }
        }, false))
        drops.add(ConfigEntry.toggle("scrollable_tooltips", tr("screen.vampy.scrollable_tooltips"), tr("screen.vampy.scrollable_tooltips.desc"), VampyConfig::isScrollableTooltips, VampyConfig::setScrollableTooltips, true))
        drops.add(ConfigEntry.toggle("trade_value", tr("screen.vampy.trade_value"), tr("screen.vampy.trade_value.desc"), VampyConfig::isTradeValueOverlay, VampyConfig::setTradeValueOverlay, false))
        cats.add(Category("drops", tr("screen.vampy.group.item_drops"), lit("Outline dropped items by rarity."), CrimsonIcons.Id.BOX, drops))


        return cats
    }

    private fun partyCategories(): List<Category> {
        val cats = ArrayList<Category>()
        val wsEntries = ArrayList<ConfigEntry>()
        wsEntries.add(ConfigEntry.toggle("websocket_enabled_party", lit("Vampy WebSocket (Chat & Far Party Sync)"), lit("Enabled by default. Generates a unique SHA-256 auth hash for your account and enables /chat va, /chat vap, /va msg <ign> <msg>, /va r <msg>, and far-away party member 3D sync."), VampyConfig::isWebsocketEnabled, { value ->
            VampyConfig.setWebsocketEnabled(value)
            com.vampy.chat.VampWebSocketManager.onWebsocketSettingChanged(value)
        }, true))
        cats.add(Category("party_websocket", lit("WebSocket Chat & Sync"), lit("Real-time /chat va, /chat vap, /va msg, /va r & far party coordinates."), CrimsonIcons.Id.CHAT, wsEntries))

        val partyEsp = ArrayList<ConfigEntry>()
        partyEsp.add(ConfigEntry.toggle("party_member_glow", lit("Party Member Glow"), lit("Highlight party members through walls and show their nametag & distance."), VampyConfig::isPartyMemberGlow, VampyConfig::setPartyMemberGlow, true))
        partyEsp.add(ConfigEntry.color("party_member_color", lit("Party Member Highlight Color"), lit("Default 3D outline and nametag color for party members outside Dungeons."), VampyConfig::getPartyMemberColor, VampyConfig::setPartyMemberColor, -13388289))
        partyEsp.add(ConfigEntry.toggle("dungeon_class_colors", lit("Dungeon Class Colors"), lit("Automatically color party members by their Catacombs class (Healer, Mage, Berserk, Archer, Tank) when inside Dungeons."), VampyConfig::isDungeonClassColors, VampyConfig::setDungeonClassColors, true))

        val classColorEntries = ArrayList<ConfigEntry>()
        classColorEntries.add(ConfigEntry.color("class_healer_color", lit("Healer Color [H]"), lit("Highlight & nametag color for Healer in Dungeons."), VampyConfig::getClassHealerColor, VampyConfig::setClassHealerColor, -43521))
        classColorEntries.add(ConfigEntry.color("class_mage_color", lit("Mage Color [M]"), lit("Highlight & nametag color for Mage in Dungeons."), VampyConfig::getClassMageColor, VampyConfig::setClassMageColor, -11141121))
        classColorEntries.add(ConfigEntry.color("class_berserk_color", lit("Berserk Color [B]"), lit("Highlight & nametag color for Berserk in Dungeons."), VampyConfig::getClassBerserkColor, VampyConfig::setClassBerserkColor, -43691))
        classColorEntries.add(ConfigEntry.color("class_archer_color", lit("Archer Color [A]"), lit("Highlight & nametag color for Archer in Dungeons."), VampyConfig::getClassArcherColor, VampyConfig::setClassArcherColor, -22016))
        classColorEntries.add(ConfigEntry.color("class_tank_color", lit("Tank Color [T]"), lit("Highlight & nametag color for Tank in Dungeons."), VampyConfig::getClassTankColor, VampyConfig::setClassTankColor, -11141291))
        partyEsp.add(ConfigEntry.subgroup("sub_dungeon_class_colors", lit("Customize Dungeon Class Colors"), lit("Configure individual colors for Healer, Mage, Berserk, Archer, and Tank."), classColorEntries))
        cats.add(Category("party_sync_highlights_colors", lit("Party & Dungeon Class Colors"), lit("Custom party highlight color & per-class colors in Catacombs."), CrimsonIcons.Id.VISION, partyEsp))

        val whisper = ArrayList<ConfigEntry>()
        whisper.add(ConfigEntry.toggle("party_invite_cmds", tr("screen.vampy.party_invite_cmds"), tr("screen.vampy.party_invite_cmds.desc"), VampyConfig::isPartyInviteCommands, VampyConfig::setPartyInviteCommands, false))
        cats.add(Category("party_whisper", tr("screen.vampy.group.party_whisper"), lit("Auto-invite from private messages."), CrimsonIcons.Id.CHAT, whisper))

        val party = ArrayList<ConfigEntry>()
        party.add(ConfigEntry.toggle("party_chat_cmds", tr("screen.vampy.party_chat_cmds"), tr("screen.vampy.party_chat_cmds.desc"), VampyConfig::isPartyChatCommands, VampyConfig::setPartyChatCommands, false))
        val partyCmdToggles = ArrayList<ConfigEntry>()
        for (cmdId in VampyConfig.PARTY_UTIL_CMD_IDS) {
            partyCmdToggles.add(ConfigEntry.toggle("pcmd_$cmdId", lit("!$cmdId"), tr("screen.vampy.party_cmd_toggle.desc", "!$cmdId"),
                { VampyConfig.isPartyCmdEnabled(cmdId) },
                { v -> VampyConfig.setPartyCmdEnabled(cmdId, v) }, true))
        }
        party.add(ConfigEntry.subgroup("sub_party_util_cmds", lit("Allowed Utility Commands"), lit("Toggle individual !warp, !ptme, !allinv, and other utility commands."), partyCmdToggles))
        cats.add(Category("party_cmds", tr("screen.vampy.group.party_cmds"), lit("Leader / utility bang-commands in party chat."), CrimsonIcons.Id.SPEAKER, party))

        val funEntries = ArrayList<ConfigEntry>()
        funEntries.add(ConfigEntry.toggle("party_fun_cmds", tr("screen.vampy.party_fun_cmds"), tr("screen.vampy.party_fun_cmds.desc"), VampyConfig::isPartyFunCommands, VampyConfig::setPartyFunCommands, false))
        val funCmdToggles = ArrayList<ConfigEntry>()
        for (cmdId in VampyConfig.PARTY_FUN_CMD_IDS) {
            funCmdToggles.add(ConfigEntry.toggle("pcmd_$cmdId", lit("!$cmdId"), tr("screen.vampy.party_cmd_toggle.desc", "!$cmdId"),
                { VampyConfig.isPartyCmdEnabled(cmdId) },
                { v -> VampyConfig.setPartyCmdEnabled(cmdId, v) }, true))
        }
        funEntries.add(ConfigEntry.subgroup("sub_party_fun_cmds", lit("Allowed Fun Commands"), lit("Toggle individual fun bang-commands (!dice, !coin, !8ball, etc.)."), funCmdToggles))
        cats.add(Category("party_fun", tr("screen.vampy.group.party_fun"), lit("Random funny replies in party chat."), CrimsonIcons.Id.CHAT, funEntries))
        return cats
    }

    private fun warningTriggers(): List<String> {
        val all = ArrayList<String>()
        for (rawKey in VampyConfig.getWarningRuleKeys()) {
            val key = if ("TWINCLAW <=0.8s" == rawKey) "TWINCLAW <0.8s" else rawKey
            if (!all.contains(key)) {
                all.add(key)
            }
        }
        if (!all.contains("TWINCLAW")) all.add("TWINCLAW")
        if (!all.contains("TWINCLAW <0.8s")) all.add("TWINCLAW <0.8s")
        if (!all.contains("Mania Over")) all.add("Mania Over")
        return all
    }
}
