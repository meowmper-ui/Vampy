package com.vampy.chat;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.vampy.config.VampyConfig;
import com.vampy.render.LootshareBossTracker;
import com.vampy.render.WarningHudRenderer;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.ClickEvent;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.HoverEvent;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.world.scores.DisplaySlot;
import net.minecraft.world.scores.Objective;
import net.minecraft.world.scores.PlayerScoreEntry;
import net.minecraft.world.scores.PlayerTeam;
import net.minecraft.world.scores.Scoreboard;

import java.io.ByteArrayOutputStream;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.WebSocket;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.time.Duration;
import java.util.Collections;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.CompletionStage;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * WebSocket client for Vampy:
 * 1) Real-time "/chat va" & "/chat vap" channel mode + "/vac <msg>" & "/vap <msg>" WebSocket chat.
 * 2) Private Direct Messages between mod users: "/va m <ign> <msg>", "/va msg <ign> <msg>", and "/va r <msg>".
 * 3) SHA-256 per-player authentication hash generated at startup & verified by the WebSocket network.
 * 4) Real-time long-distance party member coordinates sync (>64 blocks / outside entity render distance).
 * 5) Multi-channel resilient transport (HTTP/1.1 forced for WebSocket upgrade):
 *    - Direct WebSocket (/ws)
 *    - Global ntfy WebSocket Relay (backward-compatible with v6.6.0+)
 *    - Global HiveMQ MQTT-over-WebSocket Relay (zero-downtime during backend restarts)
 * 6) Live status dot in Performance HUD (green = connected, red = disconnected) + chat alert only on failure.
 */
public final class VampWebSocketManager {

    private static final String DEFAULT_SHARED_WS_URL = "wss://ais-pre-dgbmhth4s3gkehb25raph4-473922278305.europe-west2.run.app/ws";
    private static final String DEFAULT_DEV_WS_URL = "wss://ais-dev-dgbmhth4s3gkehb25raph4-473922278305.europe-west2.run.app/ws";
    private static final String PUBLIC_RELAY_WS_URL = "wss://ntfy.sh/vampy_v6_hub_9f8a7b6c5d4e/ws";
    private static final String PUBLIC_RELAY_POST_URL = "https://ntfy.sh/vampy_v6_hub_9f8a7b6c5d4e";
    private static final String MQTT_RELAY_WS_URL = "wss://broker.hivemq.com:8884/mqtt";
    private static final String MQTT_RELAY_TOPIC = "vampy/v6/hub/9f8a7b6c5d4e";
    private static final String WS_SHARED_SALT = "Vampy-WS-Auth-Salt-2026-v6";

    private static volatile String customWsUrl = "";

    /**
     * True when the player switched their active chat channel to Vampy chat via "/chat va" or "/chat vap".
     * Automatically turns off when the player switches back via "/chat p", "/chat a", "/chat g", "/chat c", etc.
     */
    private static volatile boolean vaChatChannelActive = false;
    private static volatile boolean vaPartyScope = false;

    /** Last player IGN we received a DM from or sent a DM to, used by "/va r <msg>". */
    private static volatile String lastDmPartnerIgn = "";

    /** Cached SHA-256 auth hash for the current player session. */
    private static volatile String cachedAuthIgn = "";
    private static volatile String cachedAuthUuid = "";
    private static volatile String cachedAuthHash = "";

    /** Online verified Vampy users (ignLower -> lastSeenEpochMs) & display map (ignLower -> displayIgn). */
    private static final Map<String, Long> ONLINE_MOD_USERS_LAST_SEEN = new ConcurrentHashMap<>();
    private static final Map<String, String> ONLINE_MOD_USERS_DISPLAY = new ConcurrentHashMap<>();

    /** Join notification state so we notify the player in chat ONLY if connection fails after joining a server. */
    private static volatile boolean pendingJoinStatusNotification = false;

    public static final class RemotePartyMemberPos {
        public final String ign;
        public final String serverId;
        public volatile double prevX;
        public volatile double prevY;
        public volatile double prevZ;
        public volatile double x;
        public volatile double y;
        public volatile double z;
        public volatile long lastUpdateMs;

        public RemotePartyMemberPos(String ign, String serverId, double x, double y, double z, long now) {
            this.ign = ign;
            this.serverId = serverId;
            this.prevX = x;
            this.prevY = y;
            this.prevZ = z;
            this.x = x;
            this.y = y;
            this.z = z;
            this.lastUpdateMs = now;
        }
    }

    private static final Map<String, RemotePartyMemberPos> REMOTE_PARTY_POSITIONS = new ConcurrentHashMap<>();
    private static final Set<String> SEEN_CHAT_IDS = ConcurrentHashMap.newKeySet();

    /**
     * CRITICAL: Force HTTP_1_1 so Java's HttpClient never negotiates ALPN h2 on TLS,
     * which caused RFC 6455 WebSocket Upgrade handshakes to fail against Cloudflare/nginx/Cloud Run!
     */
    private static final HttpClient HTTP_CLIENT = HttpClient.newBuilder()
            .version(HttpClient.Version.HTTP_1_1)
            .connectTimeout(Duration.ofSeconds(6))
            .build();
    private static final ScheduledExecutorService EXECUTOR = Executors.newScheduledThreadPool(2, r -> {
        Thread t = new Thread(r, "Vampy-WS");
        t.setDaemon(true);
        return t;
    });

    private static volatile WebSocket activeSocket = null;
    private static volatile WebSocket relaySocket = null;
    private static volatile WebSocket mqttSocket = null;
    private static volatile boolean connectingPrimary = false;
    private static volatile boolean connectingRelay = false;
    private static volatile boolean connectingMqtt = false;
    private static volatile boolean primaryUseDevUrl = false;
    private static volatile long lastConnectAttemptMs = 0L;
    private static volatile long lastPosSendMs = 0L;
    private static volatile long lastPingMs = 0L;
    private static volatile String cachedServerId = "";
    private static volatile long lastServerIdScanMs = 0L;

    private static final Pattern SERVER_ID_PATTERN = Pattern.compile("\\b([mM]\\d+[A-Za-z0-9]{1,4}|mega\\d+[A-Za-z0-9]*)\\b");
    private static final Pattern SERVER_CHANNEL_SWITCH_PATTERN = Pattern.compile(
            "^You are now in the (ALL|PARTY|GUILD|OFFICER|CO-OP|SKYBLOCK CO-OP) channel",
            Pattern.CASE_INSENSITIVE
    );

    private VampWebSocketManager() {}

    /**
     * Generates and caches the deterministic SHA-256 authentication hash for the current player at startup / session init.
     */
    public static synchronized String getOrComputeAuthHash() {
        Minecraft mc = Minecraft.getInstance();
        String ign = getPlayerIgn(mc);
        String uuid = getPlayerUuid(mc);
        if (!ign.isEmpty() && !uuid.isEmpty()
                && ign.equalsIgnoreCase(cachedAuthIgn)
                && uuid.equalsIgnoreCase(cachedAuthUuid)
                && !cachedAuthHash.isEmpty()) {
            return cachedAuthHash;
        }
        String cleanIgn = ign.trim().toLowerCase(Locale.ROOT);
        String cleanUuid = uuid.trim().toLowerCase(Locale.ROOT).replace("-", "");
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] digest = md.digest((cleanIgn + ":" + cleanUuid + ":" + WS_SHARED_SALT).getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder(digest.length * 2);
            for (byte b : digest) {
                sb.append(String.format("%02x", b & 0xFF));
            }
            cachedAuthIgn = ign;
            cachedAuthUuid = uuid;
            cachedAuthHash = sb.toString();
            return cachedAuthHash;
        } catch (Exception e) {
            return "";
        }
    }

    /**
     * Verifies an incoming payload's SHA-256 authHash so peer-to-peer relay messages are cryptographically verified,
     * while preserving full backward compatibility for all clients starting from v6.6.0+.
     */
    private static boolean verifyPeerAuthHash(String ign, String uuid, String authHash) {
        if (ign == null || ign.isBlank()) {
            return false;
        }
        if (authHash != null && authHash.length() == 64 && uuid != null && !uuid.isBlank()) {
            String cleanIgn = ign.trim().toLowerCase(Locale.ROOT);
            String cleanUuid = uuid.trim().toLowerCase(Locale.ROOT).replace("-", "");
            try {
                MessageDigest md = MessageDigest.getInstance("SHA-256");
                byte[] digest = md.digest((cleanIgn + ":" + cleanUuid + ":" + WS_SHARED_SALT).getBytes(StandardCharsets.UTF_8));
                StringBuilder sb = new StringBuilder(digest.length * 2);
                for (byte b : digest) {
                    sb.append(String.format("%02x", b & 0xFF));
                }
                return sb.toString().equalsIgnoreCase(authHash.trim());
            } catch (Exception e) {
                return false;
            }
        }
        // Backward compatibility for v6.6.0+ clients during early handshake
        return (authHash != null && authHash.length() == 64) || ign.trim().length() >= 2;
    }

    private static void markPeerOnline(String ign) {
        if (ign == null || ign.isBlank()) return;
        String trimmed = ign.trim();
        String key = trimmed.toLowerCase(Locale.ROOT);
        ONLINE_MOD_USERS_LAST_SEEN.put(key, System.currentTimeMillis());
        ONLINE_MOD_USERS_DISPLAY.put(key, trimmed);
    }

    private static boolean isPeerRecentlyOnline(String ign) {
        if (ign == null || ign.isBlank()) return false;
        Long ts = ONLINE_MOD_USERS_LAST_SEEN.get(ign.trim().toLowerCase(Locale.ROOT));
        return ts != null && (System.currentTimeMillis() - ts) <= 65_000L;
    }

    private static String getPlayerIgn(Minecraft mc) {
        if (mc == null) return "Player";
        if (mc.player != null) {
            return mc.player.getName().getString().trim();
        }
        if (mc.getUser() != null && mc.getUser().getName() != null) {
            return mc.getUser().getName().trim();
        }
        return "Player";
    }

    private static String getPlayerUuid(Minecraft mc) {
        if (mc == null) return "";
        if (mc.player != null) {
            return mc.player.getUUID().toString();
        }
        if (mc.getUser() != null && mc.getUser().getProfileId() != null) {
            return mc.getUser().getProfileId().toString();
        }
        return "";
    }

    private static void attachAuthFields(JsonObject obj, Minecraft mc) {
        String ign = getPlayerIgn(mc);
        String uuid = getPlayerUuid(mc);
        String authHash = getOrComputeAuthHash();
        obj.addProperty("ign", ign);
        obj.addProperty("uuid", uuid);
        obj.addProperty("authHash", authHash);
        obj.addProperty("protocolVersion", 1);
        obj.addProperty("modVersion", "1.0.0");
    }

    public static Set<String> getOnlineModUsers() {
        long now = System.currentTimeMillis();
        ONLINE_MOD_USERS_LAST_SEEN.entrySet().removeIf(e -> {
            if (now - e.getValue() > 65_000L) {
                ONLINE_MOD_USERS_DISPLAY.remove(e.getKey());
                return true;
            }
            return false;
        });
        return Collections.unmodifiableSet(Set.copyOf(ONLINE_MOD_USERS_DISPLAY.values()));
    }

    public static String getLastDmPartnerIgn() {
        return lastDmPartnerIgn;
    }

    public static boolean isConnected() {
        return activeSocket != null || relaySocket != null || mqttSocket != null;
    }

    public static boolean isVaChatChannelActive() {
        return vaChatChannelActive;
    }

    public static boolean isVaPartyScope() {
        return vaPartyScope;
    }

    /**
     * Called when the player joins a server/world.
     * Since the Performance HUD now shows a live green/red status circle, we only print a chat message if connection FAILS.
     */
    public static void onServerJoin() {
        clearRemotePositions();
        getOrComputeAuthHash();
        if (!VampyConfig.isWebsocketEnabled()) {
            pendingJoinStatusNotification = false;
            return;
        }
        if (isConnected()) {
            pendingJoinStatusNotification = false;
            sendHandshakeAuth();
        } else {
            pendingJoinStatusNotification = true;
            lastConnectAttemptMs = 0L;
            ensureConnectedAsync();
            EXECUTOR.schedule(() -> {
                if (pendingJoinStatusNotification) {
                    pendingJoinStatusNotification = false;
                    if (!isConnected()) {
                        notifyConnectionFailed();
                    }
                }
            }, 6500L, TimeUnit.MILLISECONDS);
        }
    }

    private static void notifyConnectionFailed() {
        Minecraft mc = Minecraft.getInstance();
        if (mc == null) return;
        mc.execute(() -> {
            if (mc.player == null) return;
            ClientModChat.info("§cFailed to connect to §dVampy WebSocket§c. §7Retrying in background...");
        });
    }

    public static void setVaChatChannelActive(boolean active, boolean partyOnly) {
        if (active && !VampyConfig.isWebsocketEnabled()) {
            ClientModChat.info("§cVampy WebSocket is disabled in settings! Enable it in §e/va§c -> §eParty / WebSocket§c.");
            return;
        }
        vaChatChannelActive = active;
        vaPartyScope = partyOnly;
        if (active) {
            if (partyOnly) {
                ClientModChat.info("§aYou are now in the §dVampy Party Chat (VAP)§a channel! §7(Only mod users in your party see messages; use §e/chat a§7 or §e/chat p§7 to leave)");
            } else {
                ClientModChat.info("§aYou are now in the §5Vampy Global Chat (VA)§a channel! §7(Use §e/chat vap§7 for party-only, or §e/chat a§7 / §e/chat p§7 to leave)");
            }
            ensureConnectedAsync();
        } else {
            ClientModChat.info("§eSwitched out of Vampy Chat channel.");
        }
    }

    public static Map<String, RemotePartyMemberPos> getRemotePartyPositions() {
        return REMOTE_PARTY_POSITIONS;
    }

    public static String getCurrentServerId() {
        return cachedServerId;
    }

    public static void clearRemotePositions() {
        REMOTE_PARTY_POSITIONS.clear();
    }

    public static void disconnectNow() {
        REMOTE_PARTY_POSITIONS.clear();
        ONLINE_MOD_USERS_LAST_SEEN.clear();
        ONLINE_MOD_USERS_DISPLAY.clear();
        vaChatChannelActive = false;
        pendingJoinStatusNotification = false;
        WebSocket ws1 = activeSocket;
        WebSocket ws2 = relaySocket;
        WebSocket ws3 = mqttSocket;
        activeSocket = null;
        relaySocket = null;
        mqttSocket = null;
        EXECUTOR.execute(() -> {
            if (ws1 != null) {
                try {
                    ws1.sendClose(WebSocket.NORMAL_CLOSURE, "Disabled");
                } catch (Exception ignored) {
                }
            }
            if (ws2 != null) {
                try {
                    ws2.sendClose(WebSocket.NORMAL_CLOSURE, "Disabled");
                } catch (Exception ignored) {
                }
            }
            if (ws3 != null) {
                try {
                    ws3.sendClose(WebSocket.NORMAL_CLOSURE, "Disabled");
                } catch (Exception ignored) {
                }
            }
        });
    }

    /**
     * Called when WebSocket setting is toggled in Config GUI.
     */
    public static void onWebsocketSettingChanged(boolean enabled) {
        if (!enabled) {
            disconnectNow();
            ClientModChat.info("§cDisconnected from §dVampy WebSocket§c (disabled in settings).");
        } else {
            getOrComputeAuthHash();
            pendingJoinStatusNotification = true;
            lastConnectAttemptMs = 0L;
            ensureConnectedAsync();
            EXECUTOR.schedule(() -> {
                if (pendingJoinStatusNotification) {
                    pendingJoinStatusNotification = false;
                    if (!isConnected()) {
                        notifyConnectionFailed();
                    }
                }
            }, 6500L, TimeUnit.MILLISECONDS);
        }
    }

    public static void onPartyDisbanded() {
        if (vaChatChannelActive && vaPartyScope) {
            vaChatChannelActive = false;
            ClientModChat.info("§cParty disbanded/left. §7Switched back to standard All chat.");
        }
    }

    /**
     * Intercepts outgoing "/chat ..." and "/vchat" commands safely.
     */
    public static boolean onOutgoingCommand(String commandNoSlash) {
        if (commandNoSlash == null) return false;
        String trimmed = commandNoSlash.trim();
        String lower = trimmed.toLowerCase(Locale.ROOT);

        // Dedicated independent commands that NEVER touch Hypixel server
        if (lower.equals("vchat") || lower.equals("vc")) {
            setVaChatChannelActive(!vaChatChannelActive, false);
            return true;
        }
        if (lower.equals("vchat party") || lower.equals("vchat p") || lower.equals("vcp")) {
            setVaChatChannelActive(true, true);
            return true;
        }
        if (lower.equals("vchat all") || lower.equals("vchat a")) {
            setVaChatChannelActive(true, false);
            return true;
        }
        if (lower.equals("vchat off") || lower.equals("vchat leave") || lower.equals("vchat stop")) {
            setVaChatChannelActive(false, false);
            return true;
        }
        if (lower.startsWith("vc ")) {
            sendChatMessage(trimmed.substring(3).trim(), false);
            return true;
        }
        if (lower.startsWith("vcp ")) {
            sendChatMessage(trimmed.substring(4).trim(), true);
            return true;
        }

        // Catch any variant of /chat va... so it NEVER leaks to the server
        if (lower.equals("chat va") || lower.startsWith("chat va ")
                || lower.equals("chat vamp") || lower.startsWith("chat vamp ")
                || lower.equals("chat vampy") || lower.startsWith("chat vampy ")) {
            boolean party = lower.contains("vap") || lower.contains("party") || lower.contains("vp");
            setVaChatChannelActive(true, party);
            return true;
        }
        if (lower.equals("chat vap") || lower.startsWith("chat vap ")
                || lower.equals("chat vampparty") || lower.startsWith("chat vampparty ")
                || lower.equals("chat vp") || lower.startsWith("chat vp ")) {
            setVaChatChannelActive(true, true);
            return true;
        }

        if (lower.startsWith("chat ") || lower.equals("pchat") || lower.equals("achat") || lower.equals("gchat") || lower.equals("cchat")) {
            if (vaChatChannelActive) {
                vaChatChannelActive = false;
                ClientModChat.info("§7Left §dVampy Chat§7 channel.");
            }
            return false;
        }

        return false;
    }

    public static void onServerChatReceived(String raw) {
        if (!vaChatChannelActive || raw == null || raw.isEmpty()) return;
        String clean = WarningHudRenderer.stripFormatting(raw);
        if (SERVER_CHANNEL_SWITCH_PATTERN.matcher(clean).find()) {
            vaChatChannelActive = false;
            ClientModChat.info("§7Left §dVampy Chat§7 channel (switched to server channel).");
        }
    }

    public static boolean onOutgoingChatMessage(String message) {
        if (!vaChatChannelActive || message == null || message.isBlank()) {
            return false;
        }
        if (!VampyConfig.isWebsocketEnabled()) {
            vaChatChannelActive = false;
            return false;
        }
        // Auto-revert if no party or if disconnected:
        if (vaPartyScope && !com.vampy.render.LootshareBossTracker.hasPartyMembers()) {
            vaChatChannelActive = false;
            ClientModChat.info("§cYou are not in a party! §7Switched back to standard All chat.");
            return false;
        }
        if (!isConnected()) {
            vaChatChannelActive = false;
            ClientModChat.info("§cWebSocket is offline. §7Switched back to standard All chat.");
            return false;
        }
        sendChatMessage(message, vaPartyScope);
        return true;
    }

    /**
     * Transmits a JSON packet across all active transports (Direct WS, MQTT Relay, and ntfy Relay for 6.6.0+ compatibility).
     */
    private static void broadcastPacket(JsonObject obj) {
        String payload = obj.toString();
        WebSocket ws = activeSocket;
        if (ws != null) {
            try {
                ws.sendText(payload, true);
            } catch (Exception ignored) {
            }
        }
        WebSocket mqtt = mqttSocket;
        if (mqtt != null) {
            try {
                mqtt.sendBinary(buildMqttPublishPacket(MQTT_RELAY_TOPIC, payload), true);
            } catch (Exception ignored) {
            }
        }
        if (relaySocket != null) {
            try {
                HttpRequest req = HttpRequest.newBuilder(URI.create(PUBLIC_RELAY_POST_URL))
                        .timeout(Duration.ofSeconds(5))
                        .header("Content-Type", "text/plain; charset=utf-8")
                        .POST(HttpRequest.BodyPublishers.ofString(payload, StandardCharsets.UTF_8))
                        .build();
                HTTP_CLIENT.sendAsync(req, HttpResponse.BodyHandlers.discarding());
            } catch (Exception ignored) {
            }
        }
    }

    public static void sendChatMessage(String text, boolean partyScope) {
        if (text == null || text.isBlank()) return;
        if (!VampyConfig.isWebsocketEnabled()) {
            ClientModChat.info("§cVampy WebSocket is disabled in settings! Enable it in §e/va§c -> §eParty / WebSocket§c.");
            return;
        }
        Minecraft mc = Minecraft.getInstance();
        String ign = getPlayerIgn(mc);
        Set<String> partyIgns = LootshareBossTracker.getPartyMemberIgns();
        if (partyScope && partyIgns.isEmpty()) {
            ClientModChat.info("§cYou are not in a party (or party list not synced yet — run §e/pl§c)!");
            return;
        }
        String msgId = UUID.randomUUID().toString();
        String cleanText = text.trim();

        ensureConnectedAsync();
        EXECUTOR.execute(() -> {
            long deadline = System.currentTimeMillis() + 2500L;
            while (!isConnected() && (connectingPrimary || connectingRelay || connectingMqtt) && System.currentTimeMillis() < deadline) {
                try {
                    Thread.sleep(50L);
                } catch (InterruptedException ie) {
                    Thread.currentThread().interrupt();
                    break;
                }
            }
            if (!isConnected()) {
                ClientModChat.info("§cNot connected to §dVampy WebSocket§c! Message was not sent (retrying connection...)");
                lastConnectAttemptMs = 0L;
                ensureConnectedAsync();
                return;
            }
            try {
                SEEN_CHAT_IDS.add(msgId);
                displayIncomingChat(ign, cleanText, partyScope ? "party" : "global");

                JsonObject obj = new JsonObject();
                obj.addProperty("type", "chat");
                obj.addProperty("id", msgId);
                attachAuthFields(obj, mc);
                obj.addProperty("scope", partyScope ? "party" : "global");
                obj.addProperty("text", cleanText);
                JsonArray arr = new JsonArray();
                for (String p : partyIgns) {
                    arr.add(p);
                }
                obj.add("party", arr);
                broadcastPacket(obj);
            } catch (Exception ignored) {
            }
        });
    }

    /**
     * Sends a private message (DM) to another Vampy user via "/va m <ign> <msg>" or "/va msg <ign> <msg>".
     */
    public static void sendDirectMessage(String targetIgn, String text) {
        if (targetIgn == null || targetIgn.isBlank() || text == null || text.isBlank()) {
            ClientModChat.info("§cUsage: §e/va msg <ign> <message>");
            return;
        }
        if (!VampyConfig.isWebsocketEnabled()) {
            ClientModChat.info("§cVampy WebSocket is disabled in settings! Enable it in §e/va§c -> §eParty / WebSocket§c.");
            return;
        }
        Minecraft mc = Minecraft.getInstance();
        String cleanTarget = targetIgn.trim();
        String cleanText = text.trim();
        String msgId = UUID.randomUUID().toString();
        lastDmPartnerIgn = cleanTarget;

        ensureConnectedAsync();
        EXECUTOR.execute(() -> {
            long deadline = System.currentTimeMillis() + 3000L;
            while (!isConnected() && (connectingPrimary || connectingRelay || connectingMqtt) && System.currentTimeMillis() < deadline) {
                try {
                    Thread.sleep(50L);
                } catch (InterruptedException ie) {
                    Thread.currentThread().interrupt();
                    break;
                }
            }
            if (!isConnected()) {
                ClientModChat.info("§cNot connected to Vampy WebSocket server yet. Retrying connection...");
                lastConnectAttemptMs = 0L;
                ensureConnectedAsync();
                return;
            }
            try {
                JsonObject obj = new JsonObject();
                obj.addProperty("type", "dm");
                obj.addProperty("id", msgId);
                attachAuthFields(obj, mc);
                obj.addProperty("to", cleanTarget);
                obj.addProperty("text", cleanText);
                broadcastPacket(obj);

                // If only connected via peer-to-peer relay (no central server dm_status), check ACK or online presence
                if (activeSocket == null) {
                    EXECUTOR.schedule(() -> {
                        if (SEEN_CHAT_IDS.contains("ack:" + msgId)) {
                            return; // Already confirmed via dm_ack
                        }
                        if (isPeerRecentlyOnline(cleanTarget)) {
                            displayDirectMessage(cleanTarget, cleanText, false);
                        } else {
                            ClientModChat.info("§cPlayer §e" + cleanTarget + "§c is not currently online with Vampy WebSocket enabled.");
                        }
                    }, 1200L, TimeUnit.MILLISECONDS);
                }
            } catch (Exception ignored) {
            }
        });
    }

    public static void replyDirectMessage(String text) {
        if (text == null || text.isBlank()) {
            ClientModChat.info("§cUsage: §e/va r <message>");
            return;
        }
        String target = lastDmPartnerIgn;
        if (target == null || target.isBlank()) {
            ClientModChat.info("§cNobody has messaged you via Vampy DM yet! Use §e/va msg <ign> <message>§c first.");
            return;
        }
        sendDirectMessage(target, text);
    }

    private static void displayIncomingChat(String senderIgn, String text, String scope) {
        Minecraft mc = Minecraft.getInstance();
        if (mc == null) return;
        mc.execute(() -> {
            if (mc.player == null) return;
            if ("party".equalsIgnoreCase(scope)) {
                String myIgn = mc.player.getName().getString().trim();
                if (!senderIgn.equalsIgnoreCase(myIgn) && !LootshareBossTracker.isPartyMember(senderIgn)) {
                    return;
                }
            }
            String prefix = "party".equalsIgnoreCase(scope)
                    ? "§d§lVA Party §8> §b"
                    : "§5§lVA Chat §8> §b";
            Component line = Component.literal(prefix + senderIgn + "§f: " + text);
            mc.player.sendSystemMessage(line);
        });
    }

    private static void displayDirectMessage(String partnerIgn, String text, boolean incoming) {
        Minecraft mc = Minecraft.getInstance();
        if (mc == null) return;
        lastDmPartnerIgn = partnerIgn;
        mc.execute(() -> {
            if (mc.player == null) return;
            String header = incoming
                    ? "§d§lVA From §b" + partnerIgn + "§7: §f" + text
                    : "§d§lVA To §b" + partnerIgn + "§7: §f" + text;
            MutableComponent comp = Component.literal(header).withStyle(style -> style
                    .withClickEvent(new ClickEvent.SuggestCommand("/va m " + partnerIgn + " "))
                    .withHoverEvent(new HoverEvent.ShowText(Component.literal("§7Click to message §b" + partnerIgn + "\n§7Or use §e/va r <msg>")))
            );
            mc.player.sendSystemMessage(comp);
        });
    }

    public static void onClientTick(Minecraft client) {
        if (!VampyConfig.isWebsocketEnabled()) {
            if (isConnected() || !REMOTE_PARTY_POSITIONS.isEmpty()) {
                disconnectNow();
            }
            return;
        }
        if (client == null || client.level == null || client.player == null) {
            return;
        }
        long now = System.currentTimeMillis();

        // Prune stale remote party positions older than 6 seconds
        if (!REMOTE_PARTY_POSITIONS.isEmpty()) {
            REMOTE_PARTY_POSITIONS.entrySet().removeIf(e -> now - e.getValue().lastUpdateMs > 6_000L);
        }

        ensureConnectedAsync();

        if (now - lastServerIdScanMs >= 1_000L) {
            lastServerIdScanMs = now;
            cachedServerId = detectServerIdFromScoreboard(client);
        }

        boolean hasParty = !LootshareBossTracker.getPartyMemberIgns().isEmpty();

        // Broadcast our coordinates (every 200ms over primary/MQTT WS, or every 500ms over HTTP relay) whenever we have party members
        long posInterval = (activeSocket != null || mqttSocket != null) ? 200L : 500L;
        if (hasParty && isConnected() && now - lastPosSendMs >= posInterval) {
            lastPosSendMs = now;
            final String srv = cachedServerId;
            final double px = client.player.getX();
            final double py = client.player.getY();
            final double pz = client.player.getZ();
            final Set<String> partyIgns = LootshareBossTracker.getPartyMemberIgns();

            EXECUTOR.execute(() -> {
                if (!isConnected()) return;
                try {
                    JsonObject obj = new JsonObject();
                    obj.addProperty("type", "pos");
                    attachAuthFields(obj, client);
                    obj.addProperty("serverId", srv);
                    obj.addProperty("x", Math.round(px * 100.0) / 100.0);
                    obj.addProperty("y", Math.round(py * 100.0) / 100.0);
                    obj.addProperty("z", Math.round(pz * 100.0) / 100.0);
                    JsonArray arr = new JsonArray();
                    for (String p : partyIgns) {
                        arr.add(p);
                    }
                    obj.add("party", arr);
                    broadcastPacket(obj);
                } catch (Exception ignored) {
                }
            });
        }

        // Keepalive ping + auth sync every 20 seconds
        if (isConnected() && now - lastPingMs >= 20_000L) {
            lastPingMs = now;
            sendHandshakeAuth();
            WebSocket mqtt = mqttSocket;
            if (mqtt != null) {
                try {
                    mqtt.sendBinary(ByteBuffer.wrap(new byte[]{(byte) 0xC0, 0x00}), true);
                } catch (Exception ignored) {
                }
            }
        }
    }

    private static String detectServerIdFromScoreboard(Minecraft client) {
        if (client == null || client.level == null) return "";
        try {
            Scoreboard sb = client.level.getScoreboard();
            Objective obj = sb.getDisplayObjective(DisplaySlot.SIDEBAR);
            if (obj == null) return "";
            for (PlayerScoreEntry entry : sb.listPlayerScores(obj)) {
                String plain = plainScoreLine(sb, entry);
                Matcher m = SERVER_ID_PATTERN.matcher(plain);
                if (m.find()) {
                    return m.group(1).toLowerCase(Locale.ROOT);
                }
            }
        } catch (Exception ignored) {
        }
        return "";
    }

    private static String plainScoreLine(Scoreboard sb, PlayerScoreEntry entry) {
        if (entry.display() != null) {
            return WarningHudRenderer.stripFormatting(entry.display().getString());
        }
        StringBuilder out = new StringBuilder();
        PlayerTeam team = sb.getPlayersTeam(entry.owner());
        if (team != null && team.getPlayerPrefix() != null) {
            out.append(team.getPlayerPrefix().getString());
        }
        if (entry.ownerName() != null) {
            out.append(entry.ownerName().getString());
        } else if (entry.owner() != null) {
            out.append(entry.owner());
        }
        if (team != null && team.getPlayerSuffix() != null) {
            out.append(team.getPlayerSuffix().getString());
        }
        return WarningHudRenderer.stripFormatting(out.toString());
    }

    private static String resolvePrimaryWsUrl() {
        if (customWsUrl != null && !customWsUrl.isBlank()) {
            return customWsUrl.trim();
        }
        return primaryUseDevUrl ? DEFAULT_DEV_WS_URL : DEFAULT_SHARED_WS_URL;
    }

    private static void onAnySocketConnected() {
        pendingJoinStatusNotification = false;
        sendHandshakeAuth();
    }

    public static void ensureConnectedAsync() {
        if (!VampyConfig.isWebsocketEnabled()) return;
        if (activeSocket != null && relaySocket != null && mqttSocket != null) return;
        long now = System.currentTimeMillis();
        if (now - lastConnectAttemptMs < 5_000L) return;
        lastConnectAttemptMs = now;

        // 1) Connect to global ntfy WebSocket Relay (backward-compatible with v6.6.0+ clients)
        if (relaySocket == null && !connectingRelay) {
            connectingRelay = true;
            EXECUTOR.execute(() -> {
                try {
                    HTTP_CLIENT.newWebSocketBuilder()
                            .connectTimeout(Duration.ofSeconds(6))
                            .buildAsync(URI.create(PUBLIC_RELAY_WS_URL), new RelayListenerImpl())
                            .whenComplete((ws, err) -> {
                                connectingRelay = false;
                                if (err != null || ws == null) {
                                    relaySocket = null;
                                } else {
                                    relaySocket = ws;
                                    onAnySocketConnected();
                                }
                            });
                } catch (Exception e) {
                    connectingRelay = false;
                    relaySocket = null;
                }
            });
        }

        // 2) Connect to global HiveMQ MQTT-over-WebSocket Relay (never drops during app updates & zero rate limits)
        if (mqttSocket == null && !connectingMqtt) {
            connectingMqtt = true;
            EXECUTOR.execute(() -> {
                try {
                    HTTP_CLIENT.newWebSocketBuilder()
                            .subprotocols("mqtt")
                            .connectTimeout(Duration.ofSeconds(6))
                            .buildAsync(URI.create(MQTT_RELAY_WS_URL), new MqttRelayListenerImpl())
                            .whenComplete((ws, err) -> {
                                connectingMqtt = false;
                                if (err != null || ws == null) {
                                    mqttSocket = null;
                                } else {
                                    mqttSocket = ws;
                                    onAnySocketConnected();
                                }
                            });
                } catch (Exception e) {
                    connectingMqtt = false;
                    mqttSocket = null;
                }
            });
        }

        // 3) Connect to primary WebSocket server if reachable
        if (activeSocket == null && !connectingPrimary) {
            connectingPrimary = true;
            EXECUTOR.execute(() -> {
                String targetUrl = resolvePrimaryWsUrl();
                try {
                    HTTP_CLIENT.newWebSocketBuilder()
                            .connectTimeout(Duration.ofSeconds(6))
                            .buildAsync(URI.create(targetUrl), new PrimaryListenerImpl())
                            .whenComplete((ws, err) -> {
                                connectingPrimary = false;
                                if (err != null || ws == null) {
                                    activeSocket = null;
                                    primaryUseDevUrl = !primaryUseDevUrl;
                                } else {
                                    activeSocket = ws;
                                    onAnySocketConnected();
                                }
                            });
                } catch (Exception e) {
                    connectingPrimary = false;
                    activeSocket = null;
                }
            });
        }
    }

    private static void sendHandshakeAuth() {
        if (!isConnected()) return;
        EXECUTOR.execute(() -> {
            try {
                Minecraft mc = Minecraft.getInstance();
                String ign = getPlayerIgn(mc);
                markPeerOnline(ign);
                JsonObject obj = new JsonObject();
                obj.addProperty("type", "auth");
                attachAuthFields(obj, mc);
                obj.addProperty("serverId", cachedServerId);
                broadcastPacket(obj);
            } catch (Exception ignored) {
            }
        });
    }

    private static void writeMqttVarInt(ByteArrayOutputStream out, int len) {
        do {
            int digit = len % 128;
            len /= 128;
            if (len > 0) digit |= 0x80;
            out.write(digit);
        } while (len > 0);
    }

    private static ByteBuffer buildMqttConnectPacket(String clientId) throws Exception {
        byte[] idBytes = clientId.getBytes(StandardCharsets.UTF_8);
        ByteArrayOutputStream body = new ByteArrayOutputStream();
        body.write(new byte[]{0x00, 0x04, 0x4d, 0x51, 0x54, 0x54, 0x04, 0x02, 0x00, 0x3c});
        body.write((idBytes.length >> 8) & 0xFF);
        body.write(idBytes.length & 0xFF);
        body.write(idBytes);
        ByteArrayOutputStream pkt = new ByteArrayOutputStream();
        pkt.write(0x10);
        writeMqttVarInt(pkt, body.size());
        body.writeTo(pkt);
        return ByteBuffer.wrap(pkt.toByteArray());
    }

    private static ByteBuffer buildMqttSubscribePacket(String topic) throws Exception {
        byte[] tBytes = topic.getBytes(StandardCharsets.UTF_8);
        ByteArrayOutputStream body = new ByteArrayOutputStream();
        body.write(0x00);
        body.write(0x01);
        body.write((tBytes.length >> 8) & 0xFF);
        body.write(tBytes.length & 0xFF);
        body.write(tBytes);
        body.write(0x00);
        ByteArrayOutputStream pkt = new ByteArrayOutputStream();
        pkt.write(0x82);
        writeMqttVarInt(pkt, body.size());
        body.writeTo(pkt);
        return ByteBuffer.wrap(pkt.toByteArray());
    }

    private static ByteBuffer buildMqttPublishPacket(String topic, String payload) throws Exception {
        byte[] tBytes = topic.getBytes(StandardCharsets.UTF_8);
        byte[] pBytes = payload.getBytes(StandardCharsets.UTF_8);
        ByteArrayOutputStream body = new ByteArrayOutputStream();
        body.write((tBytes.length >> 8) & 0xFF);
        body.write(tBytes.length & 0xFF);
        body.write(tBytes);
        body.write(pBytes);
        ByteArrayOutputStream pkt = new ByteArrayOutputStream();
        pkt.write(0x30);
        writeMqttVarInt(pkt, body.size());
        body.writeTo(pkt);
        return ByteBuffer.wrap(pkt.toByteArray());
    }

    private static void parseAndHandleMqttFrames(byte[] data) {
        if (data == null || data.length < 2) return;
        int offset = 0;
        while (offset < data.length) {
            int header = data[offset] & 0xFF;
            int packetType = (header & 0xF0) >> 4;
            int qos = (header & 0x06) >> 1;
            int idx = offset + 1;
            int mult = 1;
            int remLen = 0;
            while (idx < data.length) {
                int b = data[idx++] & 0xFF;
                remLen += (b & 0x7F) * mult;
                mult *= 128;
                if ((b & 0x80) == 0) break;
            }
            int packetEnd = idx + remLen;
            if (packetEnd > data.length) break;
            if (packetType == 3 && idx + 2 <= packetEnd) {
                int topicLen = ((data[idx] & 0xFF) << 8) | (data[idx + 1] & 0xFF);
                int payloadStart = idx + 2 + topicLen + (qos > 0 ? 2 : 0);
                if (payloadStart <= packetEnd) {
                    String json = new String(data, payloadStart, packetEnd - payloadStart, StandardCharsets.UTF_8);
                    handleIncomingJson(json, true);
                }
            }
            offset = packetEnd;
        }
    }

    private static final class PrimaryListenerImpl implements WebSocket.Listener {
        private final StringBuilder buffer = new StringBuilder();

        @Override
        public void onOpen(WebSocket webSocket) {
            activeSocket = webSocket;
            webSocket.request(1);
        }

        @Override
        public CompletionStage<?> onText(WebSocket webSocket, CharSequence data, boolean last) {
            buffer.append(data);
            if (last) {
                String json = buffer.toString();
                buffer.setLength(0);
                handleIncomingJson(json, false);
            }
            webSocket.request(1);
            return null;
        }

        @Override
        public CompletionStage<?> onClose(WebSocket webSocket, int statusCode, String reason) {
            if (activeSocket == webSocket) {
                activeSocket = null;
            }
            return null;
        }

        @Override
        public void onError(WebSocket webSocket, Throwable error) {
            if (activeSocket == webSocket) {
                activeSocket = null;
            }
        }
    }

    private static final class RelayListenerImpl implements WebSocket.Listener {
        private final StringBuilder buffer = new StringBuilder();

        @Override
        public void onOpen(WebSocket webSocket) {
            relaySocket = webSocket;
            webSocket.request(1);
        }

        @Override
        public CompletionStage<?> onText(WebSocket webSocket, CharSequence data, boolean last) {
            buffer.append(data);
            if (last) {
                String raw = buffer.toString();
                buffer.setLength(0);
                handleRelayFrame(raw);
            }
            webSocket.request(1);
            return null;
        }

        @Override
        public CompletionStage<?> onClose(WebSocket webSocket, int statusCode, String reason) {
            if (relaySocket == webSocket) {
                relaySocket = null;
            }
            return null;
        }

        @Override
        public void onError(WebSocket webSocket, Throwable error) {
            if (relaySocket == webSocket) {
                relaySocket = null;
            }
        }
    }

    private static final class MqttRelayListenerImpl implements WebSocket.Listener {
        private final ByteArrayOutputStream acc = new ByteArrayOutputStream();

        @Override
        public void onOpen(WebSocket webSocket) {
            mqttSocket = webSocket;
            try {
                String clientId = "va-" + UUID.randomUUID().toString().substring(0, 12);
                webSocket.sendBinary(buildMqttConnectPacket(clientId), true);
                webSocket.sendBinary(buildMqttSubscribePacket(MQTT_RELAY_TOPIC), true);
            } catch (Exception ignored) {
            }
            webSocket.request(1);
        }

        @Override
        public CompletionStage<?> onBinary(WebSocket webSocket, ByteBuffer data, boolean last) {
            byte[] chunk = new byte[data.remaining()];
            data.get(chunk);
            acc.write(chunk, 0, chunk.length);
            if (last) {
                byte[] full = acc.toByteArray();
                acc.reset();
                parseAndHandleMqttFrames(full);
            }
            webSocket.request(1);
            return null;
        }

        @Override
        public CompletionStage<?> onClose(WebSocket webSocket, int statusCode, String reason) {
            if (mqttSocket == webSocket) {
                mqttSocket = null;
            }
            return null;
        }

        @Override
        public void onError(WebSocket webSocket, Throwable error) {
            if (mqttSocket == webSocket) {
                mqttSocket = null;
            }
        }
    }

    private static void handleRelayFrame(String raw) {
        try {
            JsonElement outerEl = JsonParser.parseString(raw);
            if (!outerEl.isJsonObject()) return;
            JsonObject outer = outerEl.getAsJsonObject();
            String event = outer.has("event") ? outer.get("event").getAsString() : "";
            if (!"message".equals(event)) return;
            if (!outer.has("message") || !outer.get("message").isJsonPrimitive()) return;
            String innerJson = outer.get("message").getAsString();
            handleIncomingJson(innerJson, true);
        } catch (Exception ignored) {
        }
    }

    private static void updateOnlinePlayersList(JsonObject obj) {
        if (obj.has("players") && obj.get("players").isJsonArray()) {
            JsonArray arr = obj.getAsJsonArray("players");
            for (JsonElement e : arr) {
                if (e.isJsonPrimitive()) {
                    String name = e.getAsString().trim();
                    if (!name.isEmpty()) {
                        markPeerOnline(name);
                    }
                }
            }
        }
    }

    private static void handleIncomingJson(String rawJson, boolean fromRelay) {
        try {
            JsonElement el = JsonParser.parseString(rawJson);
            if (!el.isJsonObject()) return;
            JsonObject obj = el.getAsJsonObject();
            String type = obj.has("type") ? obj.get("type").getAsString() : "";

            // When receiving peer packets over a public relay, verify the sender's SHA-256 authHash!
            if (fromRelay) {
                String peerIgn = obj.has("ign") ? obj.get("ign").getAsString().trim() : "";
                String peerUuid = obj.has("uuid") ? obj.get("uuid").getAsString().trim() : "";
                String peerHash = obj.has("authHash") ? obj.get("authHash").getAsString().trim() : "";
                if (!verifyPeerAuthHash(peerIgn, peerUuid, peerHash)) {
                    return;
                }
                markPeerOnline(peerIgn);
            }

            if ("auth".equals(type)) {
                return;
            } else if ("auth_ok".equals(type) || "online_list".equals(type) || "pong".equals(type)) {
                updateOnlinePlayersList(obj);
            } else if ("pos_update".equals(type) || "pos".equals(type)) {
                String ign = obj.has("ign") ? obj.get("ign").getAsString().trim() : "";
                if (ign.isEmpty()) return;
                Minecraft mc = Minecraft.getInstance();
                String myIgn = getPlayerIgn(mc);
                if (ign.equalsIgnoreCase(myIgn)) return;
                if (!LootshareBossTracker.isPartyMember(ign)) return;

                String srv = obj.has("serverId") ? obj.get("serverId").getAsString().trim() : "";
                double x = obj.has("x") ? obj.get("x").getAsDouble() : 0.0;
                double y = obj.has("y") ? obj.get("y").getAsDouble() : 0.0;
                double z = obj.has("z") ? obj.get("z").getAsDouble() : 0.0;
                long now = System.currentTimeMillis();

                String key = ign.toLowerCase(Locale.ROOT);
                RemotePartyMemberPos existing = REMOTE_PARTY_POSITIONS.get(key);
                if (existing != null) {
                    existing.prevX = existing.x;
                    existing.prevY = existing.y;
                    existing.prevZ = existing.z;
                    existing.x = x;
                    existing.y = y;
                    existing.z = z;
                    existing.lastUpdateMs = now;
                } else {
                    REMOTE_PARTY_POSITIONS.put(key, new RemotePartyMemberPos(ign, srv, x, y, z, now));
                }
            } else if ("chat".equals(type)) {
                String id = obj.has("id") ? obj.get("id").getAsString() : "";
                if (!id.isEmpty() && !SEEN_CHAT_IDS.add(id)) {
                    return;
                }
                if (SEEN_CHAT_IDS.size() > 512) {
                    SEEN_CHAT_IDS.clear();
                }
                String ign = obj.has("ign") ? obj.get("ign").getAsString() : "Player";
                String text = obj.has("text") ? obj.get("text").getAsString() : "";
                String scope = obj.has("scope") ? obj.get("scope").getAsString() : "global";
                if (!text.isEmpty()) {
                    displayIncomingChat(ign, text, scope);
                }
            } else if ("dm".equals(type)) {
                String id = obj.has("id") ? obj.get("id").getAsString() : "";
                String from = obj.has("from")
                        ? obj.get("from").getAsString().trim()
                        : (obj.has("ign") ? obj.get("ign").getAsString().trim() : "");
                String to = obj.has("to") ? obj.get("to").getAsString().trim() : "";
                String text = obj.has("text") ? obj.get("text").getAsString().trim() : "";
                Minecraft mc = Minecraft.getInstance();
                String myIgn = getPlayerIgn(mc);

                if (!to.isEmpty() && !to.equalsIgnoreCase(myIgn)) {
                    return;
                }
                if (!id.isEmpty() && !SEEN_CHAT_IDS.add("in:" + id)) {
                    return;
                }
                if (!from.isEmpty() && !text.isEmpty()) {
                    displayDirectMessage(from, text, true);
                    if (fromRelay && !id.isEmpty()) {
                        EXECUTOR.execute(() -> {
                            try {
                                JsonObject ack = new JsonObject();
                                ack.addProperty("type", "dm_ack");
                                ack.addProperty("id", id);
                                attachAuthFields(ack, mc);
                                ack.addProperty("from", from);
                                ack.addProperty("to", myIgn);
                                ack.addProperty("text", text);
                                broadcastPacket(ack);
                            } catch (Exception ignored) {
                            }
                        });
                    }
                }
            } else if ("dm_ack".equals(type)) {
                String id = obj.has("id") ? obj.get("id").getAsString() : "";
                String from = obj.has("from") ? obj.get("from").getAsString().trim() : "";
                String to = obj.has("to")
                        ? obj.get("to").getAsString().trim()
                        : (obj.has("ign") ? obj.get("ign").getAsString().trim() : "");
                String text = obj.has("text") ? obj.get("text").getAsString().trim() : "";
                Minecraft mc = Minecraft.getInstance();
                String myIgn = getPlayerIgn(mc);
                if (from.equalsIgnoreCase(myIgn) && !id.isEmpty() && SEEN_CHAT_IDS.add("ack:" + id)) {
                    displayDirectMessage(to, text, false);
                }
            } else if ("dm_status".equals(type)) {
                String id = obj.has("id") ? obj.get("id").getAsString() : "";
                String to = obj.has("to") ? obj.get("to").getAsString().trim() : "";
                String text = obj.has("text") ? obj.get("text").getAsString().trim() : "";
                boolean delivered = obj.has("delivered") && obj.get("delivered").getAsBoolean();
                if (delivered) {
                    if (id.isEmpty() || SEEN_CHAT_IDS.add("ack:" + id)) {
                        displayDirectMessage(to, text, false);
                    }
                } else {
                    ClientModChat.info("§cPlayer §e" + to + "§c is not currently online with Vampy WebSocket enabled.");
                }
            }
        } catch (Exception ignored) {
        }
    }
}
