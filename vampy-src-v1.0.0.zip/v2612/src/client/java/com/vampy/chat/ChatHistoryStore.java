package com.vampy.chat;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.mojang.serialization.JsonOps;
import com.vampy.VampyMod;
import com.vampy.config.VampyConfig;
import com.vampy.mixin.client.ChatMixin;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.ChatComponent;
import net.minecraft.client.multiplayer.chat.GuiMessage;
import net.minecraft.client.multiplayer.chat.GuiMessageSource;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.ComponentSerialization;

import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Disk-backed chat history so messages survive disconnects and full client restarts.
 */
public final class ChatHistoryStore {
    public static final int EXPANDED_MAX_HISTORY = 32768;

    private static final int APPLY_BATCH = 256;

    private static final Gson GSON = new GsonBuilder().disableHtmlEscaping().create();
    private static final Path PATH = FabricLoader.getInstance()
            .getConfigDir()
            .resolve(VampyMod.MOD_ID + "-chat-history.json");
    private static final Path LEGACY_PATH = FabricLoader.getInstance()
            .getConfigDir()
            .resolve("vampaddons-chat-history.json");
    private static final Path PATH_TMP = PATH.resolveSibling(PATH.getFileName().toString() + ".tmp");

    private static final ExecutorService IO = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "vampy-chat-history");
        t.setDaemon(true);
        t.setPriority(Thread.NORM_PRIORITY - 1);
        return t;
    });

    private static final List<StoredMessage> cached = new ArrayList<>();
    private static final List<StoredMessage> pendingWhileLoading = new ArrayList<>();

    private static final AtomicBoolean loadStarted = new AtomicBoolean(false);
    private static volatile boolean loadReady;
    private static volatile boolean dirty;
    private static boolean applying;
    private static volatile long lastSaveMs;

    private static boolean restoreWanted;
    private static int restoreIndex;
    private static final AtomicLong cacheEpoch = new AtomicLong();
    private static final AtomicBoolean writing = new AtomicBoolean(false);
    private static final AtomicBoolean writeQueued = new AtomicBoolean(false);

    private ChatHistoryStore() {
    }

    public static boolean isApplying() {
        return applying;
    }

    public static void startLoadAsync() {
        if (!VampyConfig.isPersistentChatHistory()) {
            loadReady = true;
            return;
        }
        if (!loadStarted.compareAndSet(false, true)) return;
        IO.execute(() -> {
            List<StoredMessage> loaded = readFromDisk();
            Minecraft mc = Minecraft.getInstance();
            Runnable apply = () -> finishLoadOnClient(loaded);
            if (mc != null) {
                mc.execute(apply);
            } else {
                apply.run();
            }
        });
    }

    private static void finishLoadOnClient(List<StoredMessage> loaded) {
        cached.clear();
        cached.addAll(pendingWhileLoading);
        pendingWhileLoading.clear();
        cached.addAll(loaded);
        trimCache();
        loadReady = true;
        cacheEpoch.incrementAndGet();
        VampyMod.LOGGER.info("Loaded {} chat history line(s) from {}", cached.size(), PATH.getFileName());
        if (restoreWanted) {
            beginChunkedRestore();
        }
        if (dirty || writeQueued.get()) {
            scheduleFlush(false);
        }
    }

    private static List<StoredMessage> readFromDisk() {
        List<StoredMessage> out = new ArrayList<>();
        Path targetPath = Files.exists(PATH) ? PATH : (Files.exists(LEGACY_PATH) ? LEGACY_PATH : null);
        if (targetPath == null) return out;
        try (Reader reader = Files.newBufferedReader(targetPath)) {
            JsonObject root = GSON.fromJson(reader, JsonObject.class);
            if (root == null || !root.has("messages") || !root.get("messages").isJsonArray()) return out;
            for (JsonElement el : root.getAsJsonArray("messages")) {
                if (!el.isJsonObject()) continue;
                JsonObject obj = el.getAsJsonObject();
                if (!obj.has("text")) continue;
                Component text = ComponentSerialization.CODEC
                        .parse(JsonOps.INSTANCE, obj.get("text"))
                        .resultOrPartial(err -> VampyMod.LOGGER.warn("Skip chat history entry: {}", err))
                        .orElse(null);
                if (text == null) continue;
                GuiMessageSource source = GuiMessageSource.SYSTEM_SERVER;
                if (obj.has("source")) {
                    try {
                        source = GuiMessageSource.valueOf(obj.get("source").getAsString());
                    } catch (Exception ignored) {
                    }
                }
                out.add(new StoredMessage(text, source));
            }
            if (out.size() > EXPANDED_MAX_HISTORY) {
                out.subList(EXPANDED_MAX_HISTORY, out.size()).clear();
            }
        } catch (Exception e) {
            VampyMod.LOGGER.warn("Failed to load chat history from {}", PATH, e);
            out.clear();
        }
        return out;
    }

    public static void recordMessage(Component content, GuiMessageSource source) {
        if (!VampyConfig.isPersistentChatHistory() || applying || content == null) return;
        GuiMessageSource src = source != null ? source : GuiMessageSource.SYSTEM_SERVER;
        StoredMessage msg = new StoredMessage(content, src);
        if (!loadReady) {
            pendingWhileLoading.add(0, msg);
            if (pendingWhileLoading.size() > EXPANDED_MAX_HISTORY) {
                pendingWhileLoading.subList(EXPANDED_MAX_HISTORY, pendingWhileLoading.size()).clear();
            }
            dirty = true;
            startLoadAsync();
            return;
        }
        cached.add(0, msg);
        trimCache();
        cacheEpoch.incrementAndGet();
        dirty = true;
    }

    public static void markDirty() {
        if (!VampyConfig.isPersistentChatHistory() || applying) return;
        dirty = true;
    }

    public static void saveFromChat(ChatComponent chat) {
        if (!VampyConfig.isPersistentChatHistory() || applying) return;
        if (!loadReady) {
            startLoadAsync();
            dirty = true;
            return;
        }
        List<GuiMessage> all = ((ChatMixin.ComponentAccessor) chat).vampy$getAllMessages();
        if (all.isEmpty()) {
            if (cached.isEmpty()) return;
            dirty = true;
            scheduleFlush(true);
            return;
        }
        List<StoredMessage> preservedHidden = new ArrayList<>();
        Set<String> preservedKeys = new HashSet<>();
        for (StoredMessage msg : cached) {
            String key = msg.text.getString();
            if (!VampyConfig.isChatMessageHidden(key)) continue;
            if (preservedKeys.add(key)) {
                preservedHidden.add(msg);
            }
        }

        cached.clear();
        Set<String> liveKeys = new HashSet<>(Math.max(16, all.size() * 2));
        for (GuiMessage msg : all) {
            if (msg == null || msg.content() == null) continue;
            GuiMessageSource source = msg.source() != null ? msg.source() : GuiMessageSource.SYSTEM_SERVER;
            cached.add(new StoredMessage(msg.content(), source));
            liveKeys.add(msg.content().getString());
        }
        for (StoredMessage msg : preservedHidden) {
            if (liveKeys.contains(msg.text.getString())) continue;
            cached.add(msg);
        }
        trimCache();
        cacheEpoch.incrementAndGet();
        dirty = true;
        scheduleFlush(true);
    }

    public static void clearStored() {
        pendingWhileLoading.clear();
        cached.clear();
        loadReady = true;
        loadStarted.set(true);
        cacheEpoch.incrementAndGet();
        dirty = true;
        restoreWanted = false;
        applying = false;
        scheduleFlush(true);
    }

    public static void requestRestore() {
        if (!VampyConfig.isPersistentChatHistory()) return;
        restoreWanted = true;
        startLoadAsync();
        if (loadReady) {
            beginChunkedRestore();
        }
    }

    private static void beginChunkedRestore() {
        if (!VampyConfig.isPersistentChatHistory() || !loadReady) return;
        if (cached.isEmpty()) {
            restoreWanted = false;
            return;
        }
        Minecraft mc = Minecraft.getInstance();
        ChatComponent chat = chatOrNull(mc);
        if (chat == null) return;

        ChatMixin.ComponentAccessor accessor = (ChatMixin.ComponentAccessor) chat;
        List<GuiMessage> all = accessor.vampy$getAllMessages();
        if (all.size() >= Math.min(cached.size(), EXPANDED_MAX_HISTORY)) {
            restoreWanted = false;
            return;
        }
        restoreIndex = 0;
        applying = true;
        restoreWanted = true;
    }

    public static void tick() {
        maybeAutosave();
        tickChunkedRestore();
    }

    private static void tickChunkedRestore() {
        if (!restoreWanted || !loadReady || !VampyConfig.isPersistentChatHistory()) return;
        Minecraft mc = Minecraft.getInstance();
        ChatComponent chat = chatOrNull(mc);
        if (chat == null) return;

        ChatMixin.ComponentAccessor accessor = (ChatMixin.ComponentAccessor) chat;
        List<GuiMessage> all = accessor.vampy$getAllMessages();
        int ticks = currentGuiTicks();

        applying = true;
        try {
            Set<String> liveKeys = null;
            if (!all.isEmpty()) {
                liveKeys = new HashSet<>(Math.max(16, all.size() * 2));
                for (GuiMessage msg : all) {
                    if (msg != null && msg.content() != null) {
                        liveKeys.add(msg.content().getString());
                    }
                }
            }

            int added = 0;
            while (restoreIndex < cached.size() && added < APPLY_BATCH) {
                StoredMessage stored = cached.get(restoreIndex++);
                String key = stored.text.getString();
                if (VampyConfig.isChatMessageHidden(key)) continue;
                if (liveKeys != null && liveKeys.contains(key)) continue;
                all.add(new GuiMessage(ticks, stored.text, null, stored.source, null));
                if (liveKeys != null) liveKeys.add(key);
                added++;
            }
            trimLive(all);

            if (restoreIndex >= cached.size()) {
                accessor.vampy$refreshTrimmedMessages();
                restoreWanted = false;
                applying = false;
            } else if (added > 0 && (restoreIndex % (APPLY_BATCH * 4) == 0)) {
                accessor.vampy$refreshTrimmedMessages();
            }
        } catch (Exception e) {
            VampyMod.LOGGER.warn("Failed to restore chat history", e);
            restoreWanted = false;
            applying = false;
        }
    }

    public static void reapplyHideRules() {
        Minecraft mc = Minecraft.getInstance();
        ChatComponent chat = chatOrNull(mc);
        if (chat == null || !loadReady) return;

        ChatMixin.ComponentAccessor accessor = (ChatMixin.ComponentAccessor) chat;
        List<GuiMessage> all = accessor.vampy$getAllMessages();
        applying = true;
        try {
            int ticks = currentGuiTicks();
            all.removeIf(msg -> msg != null && msg.content() != null
                    && VampyConfig.isChatMessageHidden(msg.content().getString()));

            Set<String> liveKeys = new HashSet<>(Math.max(16, all.size() * 2));
            for (GuiMessage msg : all) {
                if (msg != null && msg.content() != null) {
                    liveKeys.add(msg.content().getString());
                }
            }
            for (StoredMessage stored : cached) {
                String key = stored.text.getString();
                if (VampyConfig.isChatMessageHidden(key)) continue;
                if (liveKeys.contains(key)) continue;
                all.add(new GuiMessage(ticks, stored.text, null, stored.source, null));
                liveKeys.add(key);
            }
            trimLive(all);
            accessor.vampy$refreshTrimmedMessages();
        } finally {
            applying = false;
        }
    }

    public static void captureLiveIfPresent() {
        if (!VampyConfig.isPersistentChatHistory()) return;
        Minecraft mc = Minecraft.getInstance();
        ChatComponent chat = chatOrNull(mc);
        if (chat == null) return;
        List<GuiMessage> all = ((ChatMixin.ComponentAccessor) chat).vampy$getAllMessages();
        if (all.isEmpty() && !dirty) return;
        saveFromChat(chat);
    }

    public static void ensureAppliedToLiveChat() {
        requestRestore();
    }

    public static void maybeAutosave() {
        if (!dirty || !VampyConfig.isPersistentChatHistory() || !loadReady) return;
        long now = System.currentTimeMillis();
        if (now - lastSaveMs < 5000L) return;
        scheduleFlush(false);
    }

    public static void flushAndAwait(long timeoutMs) {
        if (!VampyConfig.isPersistentChatHistory() && !dirty) return;
        scheduleFlush(true);
        long deadline = System.nanoTime() + TimeUnit.MILLISECONDS.toNanos(Math.max(0L, timeoutMs));
        while ((dirty || writing.get()) && System.nanoTime() < deadline) {
            try {
                Thread.sleep(10L);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                break;
            }
            if (!writing.get() && dirty) {
                scheduleFlush(true);
            }
        }
    }

    private static void scheduleFlush(boolean force) {
        if (!dirty && !force) return;
        if (!VampyConfig.isPersistentChatHistory() && !force) return;
        if (!loadReady) {
            writeQueued.set(true);
            startLoadAsync();
            return;
        }

        if (!writing.compareAndSet(false, true)) {
            writeQueued.set(true);
            return;
        }

        final List<StoredMessage> snapshot = List.copyOf(cached);
        final long epoch = cacheEpoch.get();

        IO.execute(() -> {
            boolean ok = false;
            try {
                writeSnapshot(snapshot);
                ok = true;
            } catch (Exception e) {
                VampyMod.LOGGER.warn("Failed to save chat history to {}", PATH, e);
            } finally {
                if (ok && cacheEpoch.get() == epoch) {
                    dirty = false;
                    lastSaveMs = System.currentTimeMillis();
                }
                writing.set(false);
                boolean again = writeQueued.getAndSet(false) || dirty;
                if (again) {
                    Minecraft mc = Minecraft.getInstance();
                    if (mc != null) {
                        mc.execute(() -> scheduleFlush(false));
                    } else {
                        scheduleFlush(false);
                    }
                }
            }
        });
    }

    private static void writeSnapshot(List<StoredMessage> snapshot) throws Exception {
        Files.createDirectories(PATH.getParent());
        JsonObject root = new JsonObject();
        JsonArray arr = new JsonArray();
        for (StoredMessage msg : snapshot) {
            JsonElement textJson = ComponentSerialization.CODEC
                    .encodeStart(JsonOps.INSTANCE, msg.text)
                    .resultOrPartial(err -> VampyMod.LOGGER.warn("Skip saving chat line: {}", err))
                    .orElse(null);
            if (textJson == null) continue;
            JsonObject obj = new JsonObject();
            obj.add("text", textJson);
            obj.addProperty("source", msg.source.name());
            arr.add(obj);
        }
        root.add("messages", arr);
        try (Writer writer = Files.newBufferedWriter(PATH_TMP)) {
            GSON.toJson(root, writer);
        }
        try {
            Files.move(PATH_TMP, PATH, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
        } catch (Exception atomicFailed) {
            Files.move(PATH_TMP, PATH, StandardCopyOption.REPLACE_EXISTING);
        }
    }

    private static void trimCache() {
        int max = EXPANDED_MAX_HISTORY;
        if (cached.size() > max) {
            cached.subList(max, cached.size()).clear();
        }
    }

    private static void trimLive(List<GuiMessage> all) {
        int max = EXPANDED_MAX_HISTORY;
        while (all.size() > max) {
            all.remove(all.size() - 1);
        }
    }

    private static ChatComponent chatOrNull(Minecraft mc) {
        if (mc == null || mc.gui == null) return null;
        return mc.gui.getChat();
    }

    private static int currentGuiTicks() {
        try {
            Minecraft mc = Minecraft.getInstance();
            if (mc != null && mc.gui != null) {
                return mc.gui.getGuiTicks();
            }
        } catch (Exception ignored) {
        }
        return 0;
    }

    private record StoredMessage(Component text, GuiMessageSource source) {
    }
}
