package com.vampy.mixin.client;

import com.mojang.authlib.GameProfile;
import com.mojang.blaze3d.vertex.PoseStack;
import com.vampy.config.VampyConfig;
import com.vampy.render.HandRenderTracker;
import com.vampy.render.LootshareBossTracker;
import com.vampy.render.OutlineEspManager;
import com.vampy.render.SkyblockCombatFeatures;
import com.vampy.util.ItemScaleHolder;
import net.minecraft.client.CameraType;
import net.minecraft.client.Minecraft;
import net.minecraft.client.OptionInstance;
import net.minecraft.client.gui.Font;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.renderer.ItemInHandRenderer;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.ItemEntityRenderer;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.client.renderer.entity.state.EntityRenderState;
import net.minecraft.client.renderer.entity.state.ItemEntityRenderState;
import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;
import net.minecraft.client.renderer.state.level.CameraRenderState;
import net.minecraft.client.resources.DefaultPlayerSkin;
import net.minecraft.core.BlockPos;
import net.minecraft.core.ClientAsset;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.player.PlayerModelType;
import net.minecraft.world.entity.player.PlayerSkin;
import org.joml.Matrix4fc;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.UUID;

/**
 * Unified RenderMixin grouping all 3D world, entity, hand, camera, skin, gizmo text, and gamma rendering mixins:
 * - EntityRenderer (ESP outlines for bosses, spectral bats, steakable mobs, party members, and items)
 * - LevelRenderer (keep outlined entities visible even when their chunk section is occluded)
 * - DrawableGizmoPrimitives$Group (render 3D gizmo billboard text in Font.DisplayMode.SEE_THROUGH so it is always visible through walls)
 * - ItemEntityRenderState & ItemEntityRenderer (dropped item scaling & rarity outline)
 * - ItemInHandRenderer (hand render tracking so self player scale skips first-person viewmodel)
 * - LivingEntityRenderer (player model scaling for self and others)
 * - DefaultPlayerSkin (custom default skin override)
 * - CameraType (skip front camera perspective)
 * - OptionInstance (fullbright gamma override)
 */
public final class RenderMixin {

    private RenderMixin() {}

    @Mixin(EntityRenderer.class)
    public static abstract class EntityOutlineMixin {

        @Unique
        private static int vampy$resolveCustomOutlineColor(Entity entity) {
            if (entity == null) return 0;
            int id = entity.getId();
            int c = OutlineEspManager.getOutlineColorFast(id);
            if (c != 0) return c | 0xFF000000;
            int fastBoss = SkyblockCombatFeatures.getFastBossOutlineColor(id);
            if (fastBoss != 0) return fastBoss | 0xFF000000;
            return 0;
        }

        @Inject(
                method = "extractRenderState(Lnet/minecraft/world/entity/Entity;Lnet/minecraft/client/renderer/entity/state/EntityRenderState;F)V",
                at = @At("TAIL")
        )
        private void vampy$applyOutlineColor(Entity entity, EntityRenderState state, float partialTick, CallbackInfo ci) {
            if (entity instanceof Player p && !LootshareBossTracker.getPartyMemberIgns().isEmpty()) {
                if (SkyblockCombatFeatures.isPartyMemberHumanEntity(Minecraft.getInstance(), p, null)) {
                    state.nameTag = null;
                }
            }
            int color = vampy$resolveCustomOutlineColor(entity);
            if (color != 0) {
                state.outlineColor = color;
            } else if (state.outlineColor != 0 && com.vampy.render.SlayerProfitTracker.isInStillgoreChateau()) {
                // Only suppress foreign boss glowing outlines inside Stillgore Chateau (Rift),
                // so other mods (e.g. NoammAddons starred mobs in Dungeons) are never interfered with!
                state.outlineColor = 0;
            }
        }
    }

    @Mixin(net.minecraft.client.renderer.OutlineBufferSource.class)
    public static abstract class OutlineBufferSourceColorMixin {

        @org.spongepowered.asm.mixin.Shadow
        private int outlineColor;

        @Inject(method = "setColor(I)V", at = @At("TAIL"))
        private void vampy$makeBuggedForeignBossColorTransparent(int color, CallbackInfo ci) {
            if (!com.vampy.render.SlayerProfitTracker.isInStillgoreChateau()) {
                return;
            }
            int rgb = color & 0xFFFFFF;
            // Specifically make the bugged foreign boss outline color (Dark Aqua 0x00AAAA / RGB(0,170,170),
            // Aqua 0x55FFFF, or default White 0xFFFFFF) 100% transparent (0x00000000) in Stillgore Chateau!
            if (rgb == 0x00AAAA || rgb == 0x55FFFF || rgb == 0xFFFFFF) {
                this.outlineColor = 0x00000000;
            }
        }
    }

    @Mixin(Minecraft.class)
    public static abstract class MinecraftOutlineMixin {

        @Inject(
                method = "shouldEntityAppearGlowing(Lnet/minecraft/world/entity/Entity;)Z",
                at = @At("HEAD"),
                cancellable = true
        )
        private void vampy$shouldEntityAppearGlowing(Entity entity, CallbackInfoReturnable<Boolean> cir) {
            if (entity == null) return;
            int id = entity.getId();
            if (OutlineEspManager.getOutlineColorFast(id) != 0 || SkyblockCombatFeatures.getFastBossOutlineColor(id) != 0) {
                cir.setReturnValue(true);
            } else if (com.vampy.render.SlayerProfitTracker.isInStillgoreChateau()
                    && (entity instanceof Player || entity instanceof LivingEntity)) {
                // Only block foreign boss/player glowing inside Stillgore Chateau so Dungeons starred mobs work normally!
                cir.setReturnValue(false);
            }
        }
    }

    @Mixin(LevelRenderer.class)
    public static abstract class LevelRendererOutlineVisibilityMixin {

        @Redirect(
                method = "extractVisibleEntities",
                at = @At(
                        value = "INVOKE",
                        target = "Lnet/minecraft/client/renderer/LevelRenderer;isSectionCompiledAndVisible(Lnet/minecraft/core/BlockPos;)Z"
                )
        )
        private boolean vampy$keepOutlinedEntitiesVisibleThroughWalls(LevelRenderer instance, BlockPos pos) {
            if (instance.isSectionCompiledAndVisible(pos)) {
                return true;
            }
            return SkyblockCombatFeatures.isThroughWallOutlinedPos(pos) || OutlineEspManager.isThroughWallItemPos(pos);
        }
    }

    @Mixin(targets = "net.minecraft.client.renderer.gizmos.DrawableGizmoPrimitives$Group")
    public static abstract class GizmoTextSeeThroughMixin {

        @Redirect(
                method = "renderTexts",
                at = @At(
                        value = "INVOKE",
                        target = "Lnet/minecraft/client/gui/Font;drawInBatch(Ljava/lang/String;FFIZLorg/joml/Matrix4fc;Lnet/minecraft/client/renderer/MultiBufferSource;Lnet/minecraft/client/gui/Font$DisplayMode;II)V"
                )
        )
        private void vampy$drawGizmoTextSeeThrough(
                Font font,
                String text,
                float x,
                float y,
                int color,
                boolean dropShadow,
                Matrix4fc pose,
                MultiBufferSource bufferSource,
                Font.DisplayMode displayMode,
                int backgroundColor,
                int packedLightCoords
        ) {
            font.drawInBatch(
                    text,
                    x,
                    y,
                    color | 0xFF000000,
                    true,
                    pose,
                    bufferSource,
                    Font.DisplayMode.SEE_THROUGH,
                    0x40000000,
                    packedLightCoords
            );
        }
    }

    @Mixin(ItemEntityRenderState.class)
    public static class ItemEntityStateMixin implements ItemScaleHolder {

        @Unique
        private float vampy$itemScale = 1.0f;

        @Override
        public float vampy$getItemScale() {
            return this.vampy$itemScale;
        }

        @Override
        public void vampy$setItemScale(float scale) {
            this.vampy$itemScale = scale;
        }
    }

    @Mixin(ItemEntityRenderer.class)
    public static abstract class ItemEntityScaleMixin {

        @Inject(
                method = "extractRenderState(Lnet/minecraft/world/entity/item/ItemEntity;Lnet/minecraft/client/renderer/entity/state/ItemEntityRenderState;F)V",
                at = @At("TAIL")
        )
        private void vampy$captureScale(ItemEntity entity, ItemEntityRenderState state, float partialTick, CallbackInfo ci) {
            if (!com.vampy.render.SlayerProfitTracker.isInSlayerLocation()) {
                ((ItemScaleHolder) state).vampy$setItemScale(1.0f);
                return;
            }
            ((ItemScaleHolder) state).vampy$setItemScale(VampyConfig.getDroppedItemScale());
            Integer outline = OutlineEspManager.getOutlineColor(entity);
            if (outline != null) {
                state.outlineColor = outline;
            }
        }

        @Inject(
                method = "submit(Lnet/minecraft/client/renderer/entity/state/ItemEntityRenderState;Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/SubmitNodeCollector;Lnet/minecraft/client/renderer/state/level/CameraRenderState;)V",
                at = @At("HEAD")
        )
        private void vampy$applyScale(
                ItemEntityRenderState state,
                PoseStack poseStack,
                SubmitNodeCollector submitNodeCollector,
                CameraRenderState camera,
                CallbackInfo ci
        ) {
            float scale = ((ItemScaleHolder) state).vampy$getItemScale();
            if (scale != 1.0f && scale > 0.01f) {
                poseStack.scale(scale, scale, scale);
            }
        }
    }

    @Mixin(ItemInHandRenderer.class)
    public static abstract class ItemInHandMixin {

        @Inject(method = "renderHandsWithItems", at = @At("HEAD"))
        private void vampy$beginHandRender(
                float partialTick,
                PoseStack poseStack,
                SubmitNodeCollector collector,
                LocalPlayer player,
                int packedLight,
                CallbackInfo ci
        ) {
            HandRenderTracker.setRenderingHands(true);
        }

        @Inject(method = "renderHandsWithItems", at = @At("TAIL"))
        private void vampy$endHandRender(
                float partialTick,
                PoseStack poseStack,
                SubmitNodeCollector collector,
                LocalPlayer player,
                int packedLight,
                CallbackInfo ci
        ) {
            HandRenderTracker.setRenderingHands(false);
        }
    }

    @Mixin(LivingEntityRenderer.class)
    public static abstract class PlayerScaleMixin {

        @Inject(
                method = "extractRenderState(Lnet/minecraft/world/entity/LivingEntity;Lnet/minecraft/client/renderer/entity/state/LivingEntityRenderState;F)V",
                at = @At("TAIL")
        )
        private void vampy$scalePlayer(LivingEntity entity, LivingEntityRenderState state, float partialTick, CallbackInfo ci) {
            if (entity == Minecraft.getInstance().player) {
                if (!HandRenderTracker.isRenderingHands()) {
                    double scale = VampyConfig.getSelfPlayerScale();
                    if (scale != 1.0) {
                        state.scale *= (float) scale;
                    }
                }
            } else {
                double scale = VampyConfig.getOtherPlayerScale();
                if (scale != 1.0 && VampyConfig.isRealPlayer(entity)) {
                    state.scale *= (float) scale;
                }
            }
        }
    }

    @Mixin(DefaultPlayerSkin.class)
    public static abstract class DefaultSkinOverrideMixin {

        @Unique
        private static PlayerSkin vampy$customDefaultSkin;

        @Unique
        private static PlayerSkin vampy$getCustomSkin() {
            if (vampy$customDefaultSkin == null) {
                ClientAsset.ResourceTexture texture = new ClientAsset.ResourceTexture(
                        Identifier.fromNamespaceAndPath("vampy", "skins/default"));
                vampy$customDefaultSkin = new PlayerSkin(
                        texture, null, null, PlayerModelType.WIDE, false);
            }
            return vampy$customDefaultSkin;
        }

        @Inject(
                method = "get(Lcom/mojang/authlib/GameProfile;)Lnet/minecraft/world/entity/player/PlayerSkin;",
                at = @At("HEAD"),
                cancellable = true
        )
        private static void vampy$overrideProfileSkin(GameProfile profile, CallbackInfoReturnable<PlayerSkin> cir) {
            cir.setReturnValue(vampy$getCustomSkin());
        }

        @Inject(
                method = "get(Ljava/util/UUID;)Lnet/minecraft/world/entity/player/PlayerSkin;",
                at = @At("HEAD"),
                cancellable = true
        )
        private static void vampy$overrideUuidSkin(UUID uuid, CallbackInfoReturnable<PlayerSkin> cir) {
            cir.setReturnValue(vampy$getCustomSkin());
        }
    }

    @Mixin(CameraType.class)
    public static abstract class OptionsRenderMixin {

        @Inject(method = "cycle", at = @At("HEAD"), cancellable = true)
        private void vampy$skipFrontCamera(CallbackInfoReturnable<CameraType> cir) {
            if (!VampyConfig.isSkipFaceView()) {
                return;
            }
            CameraType self = (CameraType) (Object) this;
            cir.setReturnValue(self == CameraType.FIRST_PERSON ? CameraType.THIRD_PERSON_BACK : CameraType.FIRST_PERSON);
        }
    }

    @Mixin(OptionInstance.class)
    public static abstract class GammaOverrideMixin {

        @Inject(method = "get", at = @At("RETURN"), cancellable = true)
        private void vampy$overrideGamma(CallbackInfoReturnable<Double> cir) {
            @SuppressWarnings("unchecked")
            OptionInstance<Double> self = (OptionInstance<Double>) (Object) this;
            if (Minecraft.getInstance().options != null && self == Minecraft.getInstance().options.gamma()) {
                if (VampyConfig.isFullbright()) {
                    cir.setReturnValue(cir.getReturnValue() * 10.0);
                }
            }
        }
    }
}
