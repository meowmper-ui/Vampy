package com.vampy.mixin.client;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.mojang.blaze3d.platform.InputConstants;
import com.vampy.chat.ChatHistoryStore;
import com.vampy.chat.ChatMessageHider;
import com.vampy.chat.ChatStackSession;
import com.vampy.chat.ChatTextPatterns;
import com.vampy.chat.FunnyDropChat;
import com.vampy.chat.PartyChatCommands;
import com.vampy.config.VampyConfig;
import com.vampy.render.HotbarCooldownOverlay;
import com.vampy.render.LootshareBossTracker;
import com.vampy.render.SkyblockCombatFeatures;
import com.vampy.render.SlayerProfitTracker;
import com.vampy.render.SlayerTimerTracker;
import com.vampy.screen.ChatCopyFinder;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.ChatComponent;
import net.minecraft.client.gui.screens.ChatScreen;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.client.multiplayer.chat.GuiMessage;
import net.minecraft.client.multiplayer.chat.GuiMessageSource;
import net.minecraft.client.multiplayer.chat.GuiMessageTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MessageSignature;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.util.ArrayListDeque;
import net.minecraft.util.FormattedCharSequence;
import net.minecraft.util.Mth;
import org.lwjgl.glfw.GLFW;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.Collections;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Set;
import java.util.regex.Pattern;

/**
 * Unified ChatMixin grouping all chat-related mixins into a single file:
 * - ChatMixin.ComponentAccessor (accessors & invokers for ChatComponent)
 * - ChatMixin.ComponentMixin (stacking, history expansion/persistence, scroll preservation)
 * - ChatMixin.ScreenMixin (Right Shift + LMB hide & Ctrl + LMB copy on ChatScreen)
 */
public final class ChatMixin {

    private ChatMixin() {}

    @Mixin(ChatComponent.class)
    public interface ComponentAccessor {

        @Accessor("allMessages")
        List<GuiMessage> vampy$getAllMessages();

        @Accessor("trimmedMessages")
        List<GuiMessage.Line> vampy$getTrimmedMessages();

        @Invoker("refreshTrimmedMessages")
        void vampy$refreshTrimmedMessages();

        @Invoker("addMessage")
        void vampy$invokeAddMessage(Component content, MessageSignature signature, GuiMessageSource source, GuiMessageTag tag);
    }

    @Mixin(ChatComponent.class)
    public static abstract class ComponentMixin {

        @Shadow
        @Final
        private Minecraft minecraft;

        @Shadow
        private int chatScrollbarPos;

        @Shadow
        public abstract void scrollChat(int dir);

        @Unique
        private int vampy$savedScroll;

        @WrapOperation(
                method = "<init>",
                at = @At(value = "NEW", args = "class=net/minecraft/util/ArrayListDeque")
        )
        private ArrayListDeque<String> vampy$expandRecentChatCapacity(
                int capacity,
                Operation<ArrayListDeque<String>> original
        ) {
            return original.call(ChatHistoryStore.EXPANDED_MAX_HISTORY);
        }

        @ModifyExpressionValue(
                method = {"addMessageToDisplayQueue", "addMessageToQueue", "addRecentChat"},
                at = @At(value = "CONSTANT", args = "intValue=100")
        )
        private int vampy$expandMaxHistory(int original) {
            return ChatHistoryStore.EXPANDED_MAX_HISTORY;
        }

        @Inject(method = "<init>", at = @At("RETURN"))
        private void vampy$restoreOnCreate(Minecraft minecraft, CallbackInfo ci) {
            if (!VampyConfig.isPersistentChatHistory()) return;
            ChatHistoryStore.requestRestore();
        }

        @Inject(method = "clearMessages", at = @At("HEAD"), cancellable = true)
        private void vampy$persistOrWipeOnClear(boolean clearSentHistory, CallbackInfo ci) {
            if (!VampyConfig.isPersistentChatHistory() || ChatHistoryStore.isApplying()) return;

            if (!clearSentHistory) {
                ChatHistoryStore.clearStored();
                return;
            }

            try {
                this.minecraft.getChatListener().flushQueue();
            } catch (Exception ignored) {
            }
            ChatHistoryStore.saveFromChat((ChatComponent) (Object) this);
            ci.cancel();
        }

        @Inject(
                method = "addMessage(Lnet/minecraft/network/chat/Component;Lnet/minecraft/network/chat/MessageSignature;Lnet/minecraft/client/multiplayer/chat/GuiMessageSource;Lnet/minecraft/client/multiplayer/chat/GuiMessageTag;)V",
                at = @At("RETURN")
        )
        private void vampy$markHistoryDirty(
                Component content,
                MessageSignature signature,
                GuiMessageSource source,
                GuiMessageTag tag,
                CallbackInfo ci
        ) {
            if (ChatHistoryStore.isApplying()) return;
            ChatHistoryStore.recordMessage(content, source);
        }

        @Inject(method = "refreshTrimmedMessages", at = @At("HEAD"))
        private void vampy$saveScrollBeforeRefresh(CallbackInfo ci) {
            this.vampy$savedScroll = this.chatScrollbarPos;
            this.chatScrollbarPos = 0;
        }

        @Inject(method = "refreshTrimmedMessages", at = @At("RETURN"))
        private void vampy$restoreScrollAfterRefresh(CallbackInfo ci) {
            int saved = this.vampy$savedScroll;
            this.vampy$savedScroll = 0;
            if (saved > 0) {
                this.scrollChat(saved);
            }
        }

        @Unique
        private static boolean vampy$stacking = false;

        @Unique
        private static boolean vampy$rewritingFunny = false;

        @Inject(method = "addMessage(Lnet/minecraft/network/chat/Component;Lnet/minecraft/network/chat/MessageSignature;Lnet/minecraft/client/multiplayer/chat/GuiMessageSource;Lnet/minecraft/client/multiplayer/chat/GuiMessageTag;)V",
                at = @At("HEAD"), cancellable = true)
        private void vampy$stackDuplicates(Component content, MessageSignature sig, GuiMessageSource src, GuiMessageTag tag, CallbackInfo ci) {
            if (vampy$stacking) return;

            String raw = content == null ? "" : content.getString();
            if (VampyConfig.isChatMessageHidden(raw)) {
                ci.cancel();
                return;
            }

            if (!vampy$rewritingFunny) {
                Component funny = FunnyDropChat.maybeRewrite(content);
                if (funny != null && funny != content) {
                    // Record rare drop in SlayerProfitTracker ONCE from the original message before re-invoking with the funny rewritten component!
                    SlayerProfitTracker.onChatComponent(content);
                    ci.cancel();
                    vampy$rewritingFunny = true;
                    try {
                        ((ComponentAccessor) (Object) this).vampy$invokeAddMessage(funny, sig, src, tag);
                    } finally {
                        vampy$rewritingFunny = false;
                    }
                    return;
                }
            }

            if (ChatHistoryStore.isApplying()) {
                return;
            }

            PartyChatCommands.onChatMessage(raw);
            if (LootshareBossTracker.onChatMessage(raw)) {
                ci.cancel();
                return;
            }
            SlayerTimerTracker.onChatMessage(raw);
            if (!vampy$rewritingFunny) {
                SlayerProfitTracker.onChatComponent(content);
            }
            SkyblockCombatFeatures.onChatMessage(raw);
            HotbarCooldownOverlay.onChatMessage(raw);
            if (com.vampy.chat.VampWebSocketManager.isVaChatChannelActive()
                    && raw.startsWith("You are now in the ")
                    && raw.endsWith(" channel")
                    && !raw.contains("Vampy")) {
                com.vampy.chat.VampWebSocketManager.setVaChatChannelActive(false, false);
            }

            if (!VampyConfig.isChatStacking()) return;
            if (ChatTextPatterns.isWhisperOrPartyMessage(raw)) return;
            if (ChatTextPatterns.isMultilineMessage(raw)) return;
            if (ChatStackSession.noteAndShouldSkipBannerStack(raw)) return;

            String base = ChatTextPatterns.stackKey(raw);

            if (base.isEmpty()) {
                if (ChatTextPatterns.isBlankOrOrphanCount(raw)) {
                    ci.cancel();
                }
                return;
            }

            List<GuiMessage> matches = ChatStackSession.takeMatches(base);
            if (matches.isEmpty()) return;

            ComponentAccessor chat = (ComponentAccessor) (Object) this;
            List<GuiMessage> allMessages = chat.vampy$getAllMessages();

            int totalCount = 0;
            Set<GuiMessage> removed = Collections.newSetFromMap(new IdentityHashMap<>());
            for (GuiMessage existing : matches) {
                if (existing == null || existing.content() == null) continue;
                totalCount += ChatTextPatterns.parseStackCount(existing.content().getString());
                removed.add(existing);
            }

            if (totalCount == 0 || removed.isEmpty()) return;

            allMessages.removeIf(removed::contains);

            List<GuiMessage.Line> trimmed = chat.vampy$getTrimmedMessages();
            trimmed.removeIf(line -> removed.contains(line.parent()));
            chat.vampy$refreshTrimmedMessages();

            ci.cancel();

            MutableComponent stacked = Component.empty().append(content.copy());
            stacked.append(Component.literal(" (x" + (totalCount + 1) + ")").withStyle(ChatFormatting.GRAY));

            if (ChatTextPatterns.stackKey(stacked.getString()).isEmpty()) {
                return;
            }

            vampy$stacking = true;
            try {
                chat.vampy$invokeAddMessage(stacked, sig, src, tag);
            } finally {
                vampy$stacking = false;
            }
        }

        @Inject(method = "addMessage(Lnet/minecraft/network/chat/Component;Lnet/minecraft/network/chat/MessageSignature;Lnet/minecraft/client/multiplayer/chat/GuiMessageSource;Lnet/minecraft/client/multiplayer/chat/GuiMessageTag;)V",
                at = @At("RETURN"))
        private void vampy$trackLiveStackMessage(Component content, MessageSignature sig, GuiMessageSource src, GuiMessageTag tag, CallbackInfo ci) {
            if (ci.isCancelled()) return;
            if (ChatHistoryStore.isApplying()) return;
            ComponentAccessor chat = (ComponentAccessor) (Object) this;
            List<GuiMessage> all = chat.vampy$getAllMessages();
            if (all.isEmpty()) return;
            GuiMessage newest = all.getFirst();
            if (newest == null || newest.content() == null) return;
            String key = ChatTextPatterns.stackKey(newest.content().getString());
            if (!key.isEmpty()) {
                ChatStackSession.track(newest, key);
            }
            ChatStackSession.pruneTo(all);
        }
    }

    @Mixin(ChatScreen.class)
    public static abstract class ScreenMixin extends Screen {

        @Shadow
        private ChatComponent.DisplayMode displayMode;

        protected ScreenMixin(Component title) {
            super(title);
        }

        @Unique
        private static final Pattern FORMATTING = Pattern.compile("\\u00A7[0-9a-fk-or]", Pattern.CASE_INSENSITIVE);
        @Unique
        private static final Pattern COORD_PATTERN = Pattern.compile("(-?\\d+)\\s*[,/\\s]+\\s*(-?\\d+)\\s*[,/\\s]+\\s*(-?\\d+)");
        @Unique
        private static final Pattern NUM_PATTERN = Pattern.compile("\\b\\d[\\d,.]*[kKmMbB]?\\b");

        @Inject(method = "mouseClicked", at = @At("HEAD"), cancellable = true)
        private void vampy$chatClickActions(MouseButtonEvent event, boolean doubled, CallbackInfoReturnable<Boolean> cir) {
            if (event.button() != 0) {
                return;
            }
            Minecraft mc = Minecraft.getInstance();
            boolean rightShift = InputConstants.isKeyDown(mc.getWindow(), GLFW.GLFW_KEY_RIGHT_SHIFT);
            boolean ctrlCopy = VampyConfig.isChatCtrlClickCopy() && mc.hasControlDown();

            int mouseX = Mth.floor(event.x());
            int mouseY = Mth.floor(event.y());
            ChatComponent chat = mc.gui.getChat();
            ChatCopyFinder finder = new ChatCopyFinder(this.font, mouseX, mouseY);
            int screenHeight = mc.getWindow().getGuiScaledHeight();
            int ticks = mc.gui.getGuiTicks();
            chat.captureClickableText(finder, screenHeight, ticks, this.displayMode);
            FormattedCharSequence line = finder.matchedLine();
            if (line == null) {
                return;
            }

            String full = resolveFullMessage(chat, line);
            if (full == null || full.isEmpty()) {
                return;
            }

            if (rightShift) {
                String plain = FORMATTING.matcher(full).replaceAll("").trim();
                if (!plain.isEmpty() && ChatMessageHider.hideClickedMessage(plain)) {
                    cir.setReturnValue(true);
                }
                return;
            }

            if (ctrlCopy) {
                String plain = FORMATTING.matcher(full).replaceAll("").trim();
                if (!plain.isEmpty()) {
                    String toCopy = plain;
                    if (mc.hasShiftDown()) {
                        java.util.regex.Matcher coordMatcher = COORD_PATTERN.matcher(plain);
                        if (coordMatcher.find()) {
                            toCopy = coordMatcher.group(1) + " " + coordMatcher.group(2) + " " + coordMatcher.group(3);
                        } else {
                            java.util.regex.Matcher numMatcher = NUM_PATTERN.matcher(plain);
                            if (numMatcher.find()) {
                                toCopy = numMatcher.group(0);
                            }
                        }
                    }
                    mc.keyboardHandler.setClipboard(toCopy);
                    com.vampy.render.ChatCopyNotificationOverlay.show(toCopy);
                    cir.setReturnValue(true);
                }
                return;
            }

            String plain = FORMATTING.matcher(full).replaceAll("").trim();
            if (!plain.isEmpty() && LootshareBossTracker.handleClickedChatLineForWaypoint(plain)) {
                cir.setReturnValue(true);
            }
        }

        @Unique
        private static String resolveFullMessage(ChatComponent chat, FormattedCharSequence line) {
            for (GuiMessage.Line trimmed : ((ComponentAccessor) chat).vampy$getTrimmedMessages()) {
                if (trimmed.content() == line) {
                    return trimmed.parent().content().getString();
                }
            }
            StringBuilder builder = new StringBuilder();
            line.accept((index, style, codePoint) -> {
                builder.appendCodePoint(codePoint);
                return true;
            });
            return builder.toString();
        }
    }
}
