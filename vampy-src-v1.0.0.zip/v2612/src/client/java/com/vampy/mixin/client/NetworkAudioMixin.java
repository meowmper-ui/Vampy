package com.vampy.mixin.client;

import com.mojang.blaze3d.audio.Library;
import com.vampy.VampyMod;
import com.vampy.chat.LatencyTracker;
import com.vampy.chat.TpsTracker;
import com.vampy.config.VampyConfig;
import com.vampy.render.RiftTimeReminderTracker;
import com.vampy.render.WarningHudRenderer;
import io.netty.channel.ChannelHandlerContext;
import net.minecraft.client.multiplayer.ClientPacketListener;
import net.minecraft.network.Connection;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientboundSetActionBarTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetSubtitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTimePacket;
import net.minecraft.network.protocol.game.ClientboundSetTitleTextPacket;
import net.minecraft.network.protocol.ping.ClientboundPongResponsePacket;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.Map;

/**
 * Unified NetworkAudioMixin grouping network packets (Title/Subtitle/ActionBar/Pong/TPS) and OpenAL audio pool:
 * - ClientPacketListener (Title/Subtitle/ActionBar warning intercept + Rift time tracker + Pong latency)
 * - Connection (TPS wire packet tracking)
 * - Library (OpenAL 256 sound channel pool expansion)
 */
public final class NetworkAudioMixin {

    private NetworkAudioMixin() {}

    @Mixin(ClientPacketListener.class)
    public static class PacketListenerMixin {

        @Inject(method = "sendCommand", at = @At("HEAD"), cancellable = true)
        private void vampy$onSendCommand(String command, CallbackInfo ci) {
            if (com.vampy.chat.VampWebSocketManager.onOutgoingCommand(command)) {
                ci.cancel();
            }
        }

        @Inject(method = "sendChat", at = @At("HEAD"), cancellable = true)
        private void vampy$onSendChat(String message, CallbackInfo ci) {
            if (com.vampy.chat.VampWebSocketManager.onOutgoingChatMessage(message)) {
                ci.cancel();
            }
        }

        @Inject(method = "handlePongResponse", at = @At("TAIL"))
        private void vampy$trackPong(ClientboundPongResponsePacket packet, CallbackInfo ci) {
            LatencyTracker.onPong(packet.time());
        }

        @Inject(method = "setTitleText", at = @At("HEAD"), cancellable = true)
        private void onSetTitleText(ClientboundSetTitleTextPacket packet, CallbackInfo ci) {
            if (handleTitleIntercept(packet.text(), ci)) return;
        }

        @Inject(method = "setSubtitleText", at = @At("HEAD"), cancellable = true)
        private void onSetSubtitleText(ClientboundSetSubtitleTextPacket packet, CallbackInfo ci) {
            if (handleTitleIntercept(packet.text(), ci)) return;
        }

        @Inject(method = "setActionBarText", at = @At("HEAD"), cancellable = true)
        private void onSetActionBarText(ClientboundSetActionBarTextPacket packet, CallbackInfo ci) {
            try {
                if (packet != null && packet.text() != null) {
                    RiftTimeReminderTracker.onActionBar(packet.text().getString());
                }
            } catch (Exception ignored) {
            }
            if (handleTitleIntercept(packet.text(), ci)) return;
        }

        private boolean handleTitleIntercept(Component text, CallbackInfo ci) {
            if (text == null) return false;
            try {
                String plainText = text.getString();
                if (plainText == null || plainText.isEmpty()) return false;

                String lower = plainText.toLowerCase();
                if (!VampyConfig.isWarningsEnabled()) return false;

                for (Map.Entry<String, String> rule : VampyConfig.getWarningRules().entrySet()) {
                    String trigger = rule.getKey();
                    if (VampyConfig.isBuiltInBossWarning(trigger)) continue;
                    if (lower.contains(trigger.toLowerCase())) {
                        WarningHudRenderer.triggerMessage(plainText);
                        ci.cancel();
                        return true;
                    }
                }

                for (String keyword : VampyConfig.getTextReplacements().keySet()) {
                    if (lower.contains(keyword.toLowerCase())) {
                        WarningHudRenderer.triggerMessage(plainText);
                        ci.cancel();
                        return true;
                    }
                }
            } catch (Exception e) {
                VampyMod.LOGGER.error("[Vampy] Error in title interceptor", e);
            }
            return false;
        }
    }

    @Mixin(Connection.class)
    public static abstract class TpsConnectionMixin {

        @Inject(
                method = "channelRead0(Lio/netty/channel/ChannelHandlerContext;Lnet/minecraft/network/protocol/Packet;)V",
                at = @At("HEAD"))
        private void vampy$onSetTimePacket(ChannelHandlerContext ctx, Packet<?> packet, CallbackInfo ci) {
            if (packet instanceof ClientboundSetTimePacket) {
                TpsTracker.onSetTimePacket();
            }
            com.vampy.render.ManiaHelper.onNetworkPacket(packet);
        }
    }

    @Mixin(Library.class)
    public static abstract class SoundChannelPoolMixin {

        @Inject(method = "getChannelCount", at = @At("HEAD"), cancellable = true)
        private void vampy$expandPool(CallbackInfoReturnable<Integer> cir) {
            cir.setReturnValue(256);
        }
    }
}
