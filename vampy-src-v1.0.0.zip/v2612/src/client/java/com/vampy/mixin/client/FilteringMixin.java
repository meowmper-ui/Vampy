package com.vampy.mixin.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.vampy.config.VampyConfig;
import net.minecraft.client.Minecraft;
import net.minecraft.client.particle.HeartParticle;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleEngine;
import net.minecraft.client.particle.SpellParticle;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.ScreenEffectRenderer;
import net.minecraft.client.renderer.fog.environment.BlindnessFogEnvironment;
import net.minecraft.client.renderer.fog.environment.DarknessFogEnvironment;
import net.minecraft.client.renderer.fog.environment.MobEffectFogEnvironment;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.client.sounds.SoundEngine;
import net.minecraft.core.Holder;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.material.FogType;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.Set;

/**
 * Unified FilteringMixin grouping all visual/audio/effect filtering mixins:
 * - MobEffectFogEnvironment (blindness/darkness fog applicability gate)
 * - BlindnessFogEnvironment & DarknessFogEnvironment (darkness factor pass-through)
 * - LivingEntity (nausea blend factor suppression)
 * - ParticleEngine (particles-only-hearts + spell particles filter)
 * - ScreenEffectRenderer (fire/water overlay filtering)
 * - SoundEngine (wither spawn sound filtering)
 */
public final class FilteringMixin {

    private FilteringMixin() {}

    @Mixin(MobEffectFogEnvironment.class)
    public static abstract class FogApplicabilityMixin {

        @Inject(method = "isApplicable", at = @At("HEAD"), cancellable = true)
        private void vampy$clearEffectFog(FogType fogType, Entity entity, CallbackInfoReturnable<Boolean> cir) {
            if (VampyConfig.isClearOverlays()) {
                cir.setReturnValue(false);
            }
        }
    }

    @Mixin({BlindnessFogEnvironment.class, DarknessFogEnvironment.class})
    public static abstract class FogDarknessMixin {

        @Inject(method = "getModifiedDarkness", at = @At("RETURN"), cancellable = true)
        private void vampy$clearDarknessFactor(LivingEntity entity, float darkness, float partialTick, CallbackInfoReturnable<Float> cir) {
            if (VampyConfig.isClearOverlays()) {
                cir.setReturnValue(darkness);
            }
        }
    }

    @Mixin(LivingEntity.class)
    public static abstract class NauseaFactorMixin {

        @Inject(method = "getEffectBlendFactor", at = @At("HEAD"), cancellable = true)
        private void vampy$clearNausea(Holder<MobEffect> effect, float partialTick, CallbackInfoReturnable<Float> cir) {
            if (VampyConfig.isClearOverlays() && effect == MobEffects.NAUSEA) {
                cir.setReturnValue(0f);
            }
        }
    }

    @Mixin(ParticleEngine.class)
    public static abstract class ParticleFilterMixin {

        @Inject(method = "add(Lnet/minecraft/client/particle/Particle;)V", at = @At("HEAD"), cancellable = true)
        private void vampy$heartsOnly(Particle particle, CallbackInfo ci) {
            if (particle == null) {
                return;
            }
            if (particle instanceof HeartParticle || particle instanceof SpellParticle) {
                return;
            }
            if (VampyConfig.isParticlesOnlyHearts()) {
                ci.cancel();
                return;
            }
            if (com.vampy.render.SlayerProfitTracker.isInStillgoreChateau()) {
                if (particle instanceof net.minecraft.client.particle.TerrainParticle
                        || particle instanceof net.minecraft.client.particle.HugeExplosionParticle
                        || particle instanceof net.minecraft.client.particle.HugeExplosionSeedParticle
                        || particle instanceof net.minecraft.client.particle.LargeSmokeParticle
                        || particle instanceof net.minecraft.client.particle.SmokeParticle
                        || particle instanceof net.minecraft.client.particle.DustParticle
                        || particle instanceof net.minecraft.client.particle.CampfireSmokeParticle) {
                    ci.cancel();
                }
            }
        }
    }

    @Mixin(ScreenEffectRenderer.class)
    public static abstract class ScreenEffectsMixin {

        @Inject(method = "renderFire", at = @At("HEAD"), cancellable = true)
        private static void vampy$clearFire(PoseStack poseStack, MultiBufferSource bufferSource, TextureAtlasSprite sprite, CallbackInfo ci) {
            if (VampyConfig.isClearOverlays()) {
                ci.cancel();
            }
        }

        @Inject(method = "renderWater", at = @At("HEAD"), cancellable = true)
        private static void vampy$clearUnderwater(Minecraft minecraft, PoseStack poseStack, MultiBufferSource bufferSource, CallbackInfo ci) {
            if (VampyConfig.isClearOverlays()) {
                ci.cancel();
            }
        }
    }

    @Mixin(SoundEngine.class)
    public static abstract class SoundFilterMixin {

        @Unique
        private static final Set<String> BLOCKED_SOUNDS = Set.of(
                "minecraft:entity.wither.spawn"
        );

        @Inject(
                method = "play(Lnet/minecraft/client/resources/sounds/SoundInstance;)Lnet/minecraft/client/sounds/SoundEngine$PlayResult;",
                at = @At("HEAD"),
                cancellable = true
        )
        private void vampy$filterSound(SoundInstance instance, CallbackInfoReturnable<SoundEngine.PlayResult> cir) {
            String soundName = instance.getIdentifier().toString();
            if (BLOCKED_SOUNDS.contains(soundName)) {
                cir.setReturnValue(SoundEngine.PlayResult.NOT_STARTED);
            }
        }
    }
}
