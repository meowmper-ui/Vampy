package com.vampy.mixin.client;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.InputConstants;
import com.mojang.blaze3d.platform.Window;
import com.vampy.config.VampyConfig;
import com.vampy.price.TradeValueOverlay;
import com.vampy.render.CustomCrosshairRenderer;
import com.vampy.render.HotbarCooldownOverlay;
import com.vampy.tooltip.TooltipScrollTracker;
import net.minecraft.client.AttackIndicatorStatus;
import net.minecraft.client.Minecraft;
import net.minecraft.client.MouseHandler;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.gui.screens.inventory.tooltip.ClientTextTooltip;
import net.minecraft.client.gui.screens.inventory.tooltip.ClientTooltipComponent;
import net.minecraft.client.gui.screens.inventory.tooltip.ClientTooltipPositioner;
import net.minecraft.resources.Identifier;
import net.minecraft.util.FormattedCharSequence;
import org.joml.Matrix3x2fStack;
import org.lwjgl.glfw.GLFW;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.List;

/**
 * Unified HudScreenMixin grouping all HUD, container screen, crosshair, and tooltip scrolling mixins:
 * - Gui (custom crosshair, third-person crosshair, ClearView HUD overlays)
 * - AbstractContainerScreen (inventory/container slot cooldowns & trade value overlay)
 * - GuiGraphicsExtractor (scrollable tooltips matrix offset)
 * - MouseHandler (scrollable tooltips wheel handler)
 * - ClientTextTooltip (text accessor for tooltip identity hashing)
 */
public final class HudScreenMixin {

    private HudScreenMixin() {}

    @Mixin(Gui.class)
    public static abstract class GuiHudMixin {

        @Inject(method = "extractConfusionOverlay", at = @At("HEAD"), cancellable = true)
        private void vampy$clearNausea(GuiGraphicsExtractor graphics, float alpha, CallbackInfo ci) {
            if (VampyConfig.isClearOverlays()) {
                ci.cancel();
            }
        }

        @Inject(method = "extractPortalOverlay", at = @At("HEAD"), cancellable = true)
        private void vampy$clearPortal(GuiGraphicsExtractor graphics, float alpha, CallbackInfo ci) {
            if (VampyConfig.isClearOverlays()) {
                ci.cancel();
            }
        }

        @Inject(method = "extractTextureOverlay", at = @At("HEAD"), cancellable = true)
        private void vampy$clearPumpkin(GuiGraphicsExtractor graphics, Identifier texture, float alpha, CallbackInfo ci) {
            if (VampyConfig.isClearOverlays() && texture.getPath().contains("pumpkin")) {
                ci.cancel();
            }
        }

        @ModifyExpressionValue(method = "extractCrosshair",
                at = @At(value = "INVOKE", target = "Lnet/minecraft/client/CameraType;isFirstPerson()Z"))
        private boolean vampy$allowThirdPersonCrosshair(boolean original) {
            return original || VampyConfig.isThirdPersonCrosshair();
        }

        @ModifyExpressionValue(method = "extractCrosshair",
                at = @At(value = "INVOKE", target = "Lnet/minecraft/client/OptionInstance;get()Ljava/lang/Object;"))
        private Object vampy$suppressCrosshairAttackIndicator(Object original) {
            if (VampyConfig.isCustomCrosshair() && original == AttackIndicatorStatus.CROSSHAIR) {
                return AttackIndicatorStatus.OFF;
            }
            return original;
        }

        @Redirect(method = "extractCrosshair",
                at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/GuiGraphicsExtractor;blitSprite(Lcom/mojang/blaze3d/pipeline/RenderPipeline;Lnet/minecraft/resources/Identifier;IIII)V"))
        private void vampy$centeredCrosshair(GuiGraphicsExtractor graphics, RenderPipeline pipeline, Identifier sprite, int x, int y, int width, int height) {
            boolean mainSprite = "hud/crosshair".equals(sprite.getPath());
            if (mainSprite && VampyConfig.isCustomCrosshair()) {
                CustomCrosshairRenderer.render(graphics);
                return;
            }

            float fx = (graphics.guiWidth() - width) / 2f;
            float fy = (graphics.guiHeight() - height) / 2f;
            int ix = (int) Math.floor(fx);
            int iy = (int) Math.floor(fy);
            graphics.pose().pushMatrix();
            graphics.pose().translate(fx - ix, fy - iy);
            graphics.blitSprite(pipeline, sprite, ix, iy, width, height);
            graphics.pose().popMatrix();
        }
    }

    @Mixin(AbstractContainerScreen.class)
    public static abstract class ContainerScreenMixin {

        @Shadow
        protected int leftPos;
        @Shadow
        protected int topPos;
        @Shadow
        protected int imageWidth;

        @Inject(method = "extractContents", at = @At("TAIL"))
        private void vampy$containerSlotCooldowns(
                GuiGraphicsExtractor graphics, int mouseX, int mouseY, float partialTick, CallbackInfo ci) {
            HotbarCooldownOverlay.renderContainerSlots(
                    (AbstractContainerScreen<?>) (Object) this,
                    graphics,
                    this.leftPos,
                    this.topPos);
        }

        @Inject(method = "extractRenderState", at = @At("TAIL"))
        private void vampy$tradeValue(
                GuiGraphicsExtractor graphics, int mouseX, int mouseY, float partialTick, CallbackInfo ci) {
            TradeValueOverlay.render(
                    (AbstractContainerScreen<?>) (Object) this,
                    graphics,
                    this.leftPos,
                    this.topPos,
                    this.imageWidth);
        }
    }

    @Mixin(value = GuiGraphicsExtractor.class, priority = 1100)
    public static abstract class TooltipGraphicsMixin {

        @Shadow
        @Final
        private Matrix3x2fStack pose;

        @Inject(method = "tooltip", at = @At("HEAD"))
        private void vampy$scrollPush(
                Font font,
                List<ClientTooltipComponent> components,
                int x,
                int y,
                ClientTooltipPositioner positioner,
                Identifier texture,
                CallbackInfo ci) {
            if (!VampyConfig.isScrollableTooltips()) return;
            TooltipScrollTracker.onTooltipRender(components);
            this.pose.pushMatrix();
            this.pose.translate(TooltipScrollTracker.xOffset(), TooltipScrollTracker.yOffset());
        }

        @Inject(method = "tooltip", at = @At("RETURN"))
        private void vampy$scrollPop(
                Font font,
                List<ClientTooltipComponent> components,
                int x,
                int y,
                ClientTooltipPositioner positioner,
                Identifier texture,
                CallbackInfo ci) {
            if (!VampyConfig.isScrollableTooltips()) return;
            this.pose.popMatrix();
        }
    }

    @Mixin(MouseHandler.class)
    public static class TooltipMouseMixin {

        @Inject(method = "onScroll", at = @At("HEAD"))
        private void vampy$tooltipScroll(long window, double horizontal, double vertical, CallbackInfo ci) {
            if (!VampyConfig.isScrollableTooltips()) return;
            Window win = Minecraft.getInstance().getWindow();
            boolean shift = InputConstants.isKeyDown(win, GLFW.GLFW_KEY_LEFT_SHIFT)
                    || InputConstants.isKeyDown(win, GLFW.GLFW_KEY_RIGHT_SHIFT);

            if (horizontal != 0) {
                TooltipScrollTracker.scrollHorizontal(horizontal);
            }
            if (vertical != 0) {
                if (shift) TooltipScrollTracker.scrollHorizontal(vertical);
                else TooltipScrollTracker.scrollVertical(vertical);
            }
        }
    }

    @Mixin(ClientTextTooltip.class)
    public interface TextTooltipAccessor {
        @Accessor("text")
        FormattedCharSequence vampy$getText();
    }

    @Mixin(net.minecraft.world.entity.player.Inventory.class)
    public static abstract class InventorySlotLockMixin {

        @Inject(method = "setSelectedSlot", at = @At("HEAD"), cancellable = true)
        private void vampy$holdHolyIceSlot(int slot, CallbackInfo ci) {
            if (HotbarCooldownOverlay.interceptHotbarSlotChange(slot)) {
                ci.cancel();
            }
        }
    }
}
