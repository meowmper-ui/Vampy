package com.vampy.tooltip;

import com.vampy.mixin.client.HudScreenMixin;
import net.minecraft.client.gui.screens.inventory.tooltip.ClientTextTooltip;
import net.minecraft.client.gui.screens.inventory.tooltip.ClientTooltipComponent;
import net.minecraft.util.FormattedCharSequence;
import net.minecraft.util.Mth;

import java.util.List;

/**
 * Tracks mouse-wheel offset for long item tooltips (Tooltip Scroll–style).
 */
public final class TooltipScrollTracker {

    private static final long RELOCK_MS = 120L;
    private static final int SCROLL_STEP = 12;
    private static final double SMOOTH = 0.35;

    private static double currentX;
    private static double currentY;
    private static double targetX;
    private static double targetY;
    private static long unlockAt;
    private static String fingerprint = "";

    private TooltipScrollTracker() {
    }

    public static void onTooltipRender(List<ClientTooltipComponent> components) {
        unlockAt = System.currentTimeMillis();
        String fp = fingerprint(components);
        if (!fp.equals(fingerprint)) {
            fingerprint = fp;
            reset();
        }
        currentX += (targetX - currentX) * SMOOTH;
        currentY += (targetY - currentY) * SMOOTH;
    }

    public static int xOffset() {
        return Mth.floor(currentX);
    }

    public static int yOffset() {
        return Mth.floor(currentY);
    }

    public static void scrollVertical(double wheel) {
        if (locked()) return;
        // wheel up → content moves down (see upper lines)
        if (wheel > 0) targetY += SCROLL_STEP;
        else if (wheel < 0) targetY -= SCROLL_STEP;
    }

    public static void scrollHorizontal(double wheel) {
        if (locked()) return;
        if (wheel > 0) targetX += SCROLL_STEP;
        else if (wheel < 0) targetX -= SCROLL_STEP;
    }

    public static void reset() {
        currentX = currentY = targetX = targetY = 0;
    }

    private static boolean locked() {
        return System.currentTimeMillis() - unlockAt > RELOCK_MS;
    }

    private static String fingerprint(List<ClientTooltipComponent> components) {
        if (components == null || components.isEmpty()) return "";
        StringBuilder sb = new StringBuilder(components.size() * 16);
        for (ClientTooltipComponent c : components) {
            sb.append(c.getClass().getSimpleName()).append(':');
            if (c instanceof ClientTextTooltip text) {
                FormattedCharSequence seq = ((HudScreenMixin.TextTooltipAccessor) text).vampy$getText();
                seq.accept((i, style, cp) -> {
                    sb.appendCodePoint(cp);
                    return true;
                });
            } else {
                sb.append(System.identityHashCode(c));
            }
            sb.append('|');
        }
        return sb.toString();
    }
}

