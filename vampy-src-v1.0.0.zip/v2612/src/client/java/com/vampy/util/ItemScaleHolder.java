package com.vampy.util;

/** Interface implemented onto ItemEntityRenderState via mixin (must NOT live in the mixin package). */
public interface ItemScaleHolder {
    float vampy$getItemScale();
    void vampy$setItemScale(float scale);
}

