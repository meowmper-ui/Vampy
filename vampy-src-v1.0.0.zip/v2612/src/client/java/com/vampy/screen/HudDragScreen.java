package com.vampy.screen;

import com.vampy.config.VampyConfig;
import com.vampy.render.HotbarCooldownOverlay;
import com.vampy.render.PerfHudRenderer;
import com.vampy.render.SlayerProfitTracker;
import java.util.Locale;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import org.joml.Matrix3x2fStack;
import org.lwjgl.glfw.GLFW;

public class HudDragScreen extends Screen {
    private final Screen parent;

    private enum DragTarget {
        NONE, ICHOR, SPRING, MANIA, PERF, PROFIT, HOTBAR_CD
    }

    private DragTarget activeTarget = DragTarget.NONE;
    private DragTarget selectedTarget = DragTarget.PROFIT;
    private int dragOffsetX = 0;
    private int dragOffsetY = 0;
    private boolean snappedX = false;
    private boolean snappedY = false;

    public HudDragScreen(Screen parent) {
        super(Component.literal("Edit HUD Layout"));
        this.parent = parent;
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor context, int mouseX, int mouseY, float delta) {
        context.fill(0, 0, this.width, this.height, 0x7006060A);

        boolean vampStyle = (VampyConfig.getGuiStyle() == VampyConfig.GuiStyle.VAMP);
        int accent = vampStyle ? 0xFFE03050 : 0xFF55FFFF;

        // Draw center & grid alignment guides while dragging or holding Shift
        boolean shiftDown = this.minecraft != null && this.minecraft.hasShiftDown();
        if (activeTarget != DragTarget.NONE || shiftDown) {
            int cx = this.width / 2;
            int cy = this.height / 2;
            int guideXColor = snappedX ? (accent | 0xFF000000) : 0x44FFFFFF;
            int guideYColor = snappedY ? (accent | 0xFF000000) : 0x44FFFFFF;
            context.fill(cx, 0, cx + 1, this.height, guideXColor);
            context.fill(0, cy, this.width, cy + 1, guideYColor);
            if (shiftDown) {
                for (int gx = this.width / 4; gx < this.width; gx += this.width / 4) {
                    if (gx != cx) context.fill(gx, 0, gx + 1, this.height, 0x22FFFFFF);
                }
                for (int gy = this.height / 4; gy < this.height; gy += this.height / 4) {
                    if (gy != cy) context.fill(0, gy, this.width, gy + 1, 0x22FFFFFF);
                }
            }
        }

        String title = "Перетаскивание HUD | Колёсико: Масштаб | Shift: Примагничивание | R / ПКМ: Сброс элемента | ESC: Выход";
        context.text(this.font, title, (this.width - this.font.width(title)) / 2, 10, 0xFFFFFFFF, true);

        // 1. Blood Ichor HUD
        int ichorX = getIchorPx();
        int ichorY = getIchorPy();
        float ichorScale = (float) VampyConfig.getIchorHudScale();
        String ichorSample = "Blood Ichor: 18.4s";
        int ichorW = Math.round((this.font.width(ichorSample) + 12) * ichorScale);
        int ichorH = Math.round(20 * ichorScale);
        drawHudBox(context, ichorX, ichorY, ichorW, ichorH, selectedTarget == DragTarget.ICHOR, accent,
                String.format(Locale.ROOT, "Ichor (%d%%)", Math.round(ichorScale * 100f)));
        drawScaledSampleText(context, ichorSample, ichorX + Math.round(6 * ichorScale), ichorY + Math.round(6 * ichorScale), ichorScale, 0xFFFF5555);

        // 2. Killer Spring HUD
        int springX = getSpringPx();
        int springY = getSpringPy();
        float springScale = (float) VampyConfig.getKillerSpringHudScale();
        String springSample = "Killer Spring: 12.0s";
        int springW = Math.round((this.font.width(springSample) + 12) * springScale);
        int springH = Math.round(20 * springScale);
        drawHudBox(context, springX, springY, springW, springH, selectedTarget == DragTarget.SPRING, accent,
                String.format(Locale.ROOT, "Spring (%d%%)", Math.round(springScale * 100f)));
        drawScaledSampleText(context, springSample, springX + Math.round(6 * springScale), springY + Math.round(6 * springScale), springScale, 0xFF55FFFF);

        // 2b. Mania Status HUD
        if (VampyConfig.isManiaHelper() && VampyConfig.isManiaHudEnabled()) {
            int maniaX = getManiaPx();
            int maniaY = getManiaPy();
            float maniaScale = (float) VampyConfig.getManiaHudScale();
            String maniaSample = "SAFE | coal 1.2s";
            int maniaW = Math.round((this.font.width(maniaSample) + 12) * maniaScale);
            int maniaH = Math.round(20 * maniaScale);
            drawHudBox(context, maniaX, maniaY, maniaW, maniaH, selectedTarget == DragTarget.MANIA, accent,
                    String.format(Locale.ROOT, "Mania Status (%d%%)", Math.round(maniaScale * 100f)));
            drawScaledSampleText(context, maniaSample, maniaX + Math.round(6 * maniaScale), maniaY + Math.round(6 * maniaScale), maniaScale, 0xFF55FF55);
        }

        // 3. Perf HUD
        if (VampyConfig.isPerfHudEnabled()) {
            int perfX = getPerfPx();
            int perfY = getPerfPy();
            float perfScale = (float) VampyConfig.getPerfHudScale();
            int perfW = PerfHudRenderer.panelWidth(this.font);
            int perfH = PerfHudRenderer.panelHeight(this.font);
            PerfHudRenderer.renderSample(context, this.font, perfX, perfY);
            drawHudBox(context, perfX, perfY, perfW, perfH, selectedTarget == DragTarget.PERF, accent,
                    String.format(Locale.ROOT, "Perf HUD (%d%%)", Math.round(perfScale * 100f)));
        }

        // 4. Slayer Profit Tracker HUD
        if (VampyConfig.isSlayerProfitTrackerEnabled()) {
            int profX = getProfitPx();
            int profY = getProfitPy();
            float profScale = (float) VampyConfig.getSlayerProfitScale();
            int profW = SlayerProfitTracker.panelWidth(this.font);
            int profH = SlayerProfitTracker.panelHeight(this.font);
            SlayerProfitTracker.renderSample(context, this.font, profX, profY);
            drawHudBox(context, profX, profY, profW, profH, selectedTarget == DragTarget.PROFIT, accent,
                    String.format(Locale.ROOT, "Profit Tracker (%d%%)", Math.round(profScale * 100f)));
        }

        // 5. Hotbar Cooldowns HUD
        if (VampyConfig.isItemCooldownOverlay()) {
            int cdX = getHotbarCdPx();
            int cdY = getHotbarCdPy();
            float cdScale = (float) VampyConfig.getHotbarCdScale();
            int cdW = HotbarCooldownOverlay.panelWidth(this.font);
            int cdH = HotbarCooldownOverlay.panelHeight(this.font);
            HotbarCooldownOverlay.renderSample(context, this.font, cdX, cdY);
            String modeTag = VampyConfig.getHotbarCdX() < 0 ? "На слотах хотбара" : String.format(Locale.ROOT, "HUD %d%% (ПКМ - сброс)", Math.round(cdScale * 100f));
            drawHudBox(context, cdX, cdY, cdW, cdH, selectedTarget == DragTarget.HOTBAR_CD, accent, "Cooldowns: " + modeTag);
        }

        super.extractRenderState(context, mouseX, mouseY, delta);
    }

    private void drawScaledSampleText(GuiGraphicsExtractor context, String text, int x, int y, float scale, int color) {
        Matrix3x2fStack pose = context.pose();
        pose.pushMatrix();
        pose.translate(x, y);
        pose.scale(scale, scale);
        context.text(this.font, text, 0, 0, color, true);
        pose.popMatrix();
    }

    private void drawHudBox(GuiGraphicsExtractor context, int x, int y, int w, int h, boolean selected, int accent, String label) {
        int border = selected ? accent : 0x80FFFFFF;
        if (selected) {
            context.fill(x - 1, y - 1, x + w + 1, y + h + 1, 0x22FFFFFF);
        }
        context.fill(x - 1, y - 1, x + w + 1, y, border);
        context.fill(x - 1, y + h, x + w + 1, y + h + 1, border);
        context.fill(x - 1, y, x, y + h, border);
        context.fill(x + w, y, x + w + 1, y + h, border);
        context.text(this.font, label, x, Math.max(2, y - 10), selected ? accent : 0xFFCCCCCC, true);
    }

    private DragTarget findTargetAt(double mx, double my) {
        if (VampyConfig.isItemCooldownOverlay()) {
            int cdX = getHotbarCdPx();
            int cdY = getHotbarCdPy();
            int cdW = HotbarCooldownOverlay.panelWidth(this.font);
            int cdH = HotbarCooldownOverlay.panelHeight(this.font);
            if (mx >= cdX && mx <= cdX + cdW && my >= cdY && my <= cdY + cdH) {
                return DragTarget.HOTBAR_CD;
            }
        }
        if (VampyConfig.isSlayerProfitTrackerEnabled()) {
            int profX = getProfitPx();
            int profY = getProfitPy();
            int profW = SlayerProfitTracker.panelWidth(this.font);
            int profH = SlayerProfitTracker.panelHeight(this.font);
            if (mx >= profX && mx <= profX + profW && my >= profY && my <= profY + profH) {
                return DragTarget.PROFIT;
            }
        }
        if (VampyConfig.isPerfHudEnabled()) {
            int perfX = getPerfPx();
            int perfY = getPerfPy();
            int perfW = PerfHudRenderer.panelWidth(this.font);
            int perfH = PerfHudRenderer.panelHeight(this.font);
            if (mx >= perfX && mx <= perfX + perfW && my >= perfY && my <= perfY + perfH) {
                return DragTarget.PERF;
            }
        }
        if (VampyConfig.isManiaHelper() && VampyConfig.isManiaHudEnabled()) {
            float maniaScale = (float) VampyConfig.getManiaHudScale();
            int maniaX = getManiaPx();
            int maniaY = getManiaPy();
            int maniaW = Math.round((this.font.width("SAFE | coal 1.2s") + 12) * maniaScale);
            int maniaH = Math.round(20 * maniaScale);
            if (mx >= maniaX && mx <= maniaX + maniaW && my >= maniaY && my <= maniaY + maniaH) {
                return DragTarget.MANIA;
            }
        }
        float springScale = (float) VampyConfig.getKillerSpringHudScale();
        int springX = getSpringPx();
        int springY = getSpringPy();
        int springW = Math.round((this.font.width("Killer Spring: 12.0s") + 12) * springScale);
        int springH = Math.round(20 * springScale);
        if (mx >= springX && mx <= springX + springW && my >= springY && my <= springY + springH) {
            return DragTarget.SPRING;
        }
        float ichorScale = (float) VampyConfig.getIchorHudScale();
        int ichorX = getIchorPx();
        int ichorY = getIchorPy();
        int ichorW = Math.round((this.font.width("Blood Ichor: 18.4s") + 12) * ichorScale);
        int ichorH = Math.round(20 * ichorScale);
        if (mx >= ichorX && mx <= ichorX + ichorW && my >= ichorY && my <= ichorY + ichorH) {
            return DragTarget.ICHOR;
        }
        return DragTarget.NONE;
    }

    private void resetTargetPositionAndScale(DragTarget target) {
        switch (target) {
            case ICHOR -> {
                VampyConfig.setIchorHudPos(0.5, 0.18);
                VampyConfig.setIchorHudScale(1.0);
            }
            case SPRING -> {
                VampyConfig.setKillerSpringHudPos(0.5, 0.30);
                VampyConfig.setKillerSpringHudScale(1.0);
            }
            case MANIA -> {
                VampyConfig.setManiaHudPos(0.5, 0.36);
                VampyConfig.setManiaHudScale(1.0);
            }
            case PERF -> {
                VampyConfig.setPerfHudPos(0.02, 0.02);
                VampyConfig.setPerfHudScale(1.0);
            }
            case PROFIT -> {
                VampyConfig.setSlayerProfitHudPos(0.015, 0.28);
                VampyConfig.setSlayerProfitScale(1.0);
            }
            case HOTBAR_CD -> {
                VampyConfig.resetHotbarCdPos();
                VampyConfig.setHotbarCdScale(1.0);
            }
            default -> {}
        }
        VampyConfig.save();
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        double mx = event.x();
        double my = event.y();
        int btn = event.button();

        DragTarget hit = findTargetAt(mx, my);
        if (hit != DragTarget.NONE) {
            selectedTarget = hit;
            if (btn == 1 || doubleClick) {
                resetTargetPositionAndScale(hit);
                return true;
            }
            activeTarget = hit;
            int px = getTargetPx(hit);
            int py = getTargetPy(hit);
            dragOffsetX = (int) mx - px;
            dragOffsetY = (int) my - py;
            return true;
        }

        return super.mouseClicked(event, doubleClick);
    }

    private int getTargetPx(DragTarget t) {
        return switch (t) {
            case ICHOR -> getIchorPx();
            case SPRING -> getSpringPx();
            case MANIA -> getManiaPx();
            case PERF -> getPerfPx();
            case PROFIT -> getProfitPx();
            case HOTBAR_CD -> getHotbarCdPx();
            default -> 0;
        };
    }

    private int getTargetPy(DragTarget t) {
        return switch (t) {
            case ICHOR -> getIchorPy();
            case SPRING -> getSpringPy();
            case MANIA -> getManiaPy();
            case PERF -> getPerfPy();
            case PROFIT -> getProfitPy();
            case HOTBAR_CD -> getHotbarCdPy();
            default -> 0;
        };
    }

    private int getTargetWidth(DragTarget t) {
        return switch (t) {
            case ICHOR -> Math.round((this.font.width("Blood Ichor: 18.4s") + 12) * (float) VampyConfig.getIchorHudScale());
            case SPRING -> Math.round((this.font.width("Killer Spring: 12.0s") + 12) * (float) VampyConfig.getKillerSpringHudScale());
            case MANIA -> Math.round((this.font.width("SAFE | coal 1.2s") + 12) * (float) VampyConfig.getManiaHudScale());
            case PERF -> PerfHudRenderer.panelWidth(this.font);
            case PROFIT -> SlayerProfitTracker.panelWidth(this.font);
            case HOTBAR_CD -> HotbarCooldownOverlay.panelWidth(this.font);
            default -> 40;
        };
    }

    private int getTargetHeight(DragTarget t) {
        return switch (t) {
            case ICHOR -> Math.round(20 * (float) VampyConfig.getIchorHudScale());
            case SPRING -> Math.round(20 * (float) VampyConfig.getKillerSpringHudScale());
            case MANIA -> Math.round(20 * (float) VampyConfig.getManiaHudScale());
            case PERF -> PerfHudRenderer.panelHeight(this.font);
            case PROFIT -> SlayerProfitTracker.panelHeight(this.font);
            case HOTBAR_CD -> HotbarCooldownOverlay.panelHeight(this.font);
            default -> 20;
        };
    }

    @Override
    public boolean mouseDragged(MouseButtonEvent event, double deltaX, double deltaY) {
        if (activeTarget == DragTarget.NONE) {
            return super.mouseDragged(event, deltaX, deltaY);
        }
        int newX = (int) event.x() - dragOffsetX;
        int newY = (int) event.y() - dragOffsetY;

        int targetW = getTargetWidth(activeTarget);
        int targetH = getTargetHeight(activeTarget);
        int cx = this.width / 2;
        int cy = this.height / 2;
        boolean shiftDown = this.minecraft != null && this.minecraft.hasShiftDown();
        int snapDist = shiftDown ? 12 : 5;

        snappedX = false;
        snappedY = false;

        // Snap element center or left edge to screen center
        if (Math.abs((newX + targetW / 2) - cx) <= snapDist) {
            newX = cx - targetW / 2;
            snappedX = true;
        } else if (Math.abs(newX - cx) <= snapDist) {
            newX = cx;
            snappedX = true;
        } else if (shiftDown) {
            int gridX = Math.max(8, this.width / 40);
            newX = Math.round((float) newX / gridX) * gridX;
        }

        if (Math.abs((newY + targetH / 2) - cy) <= snapDist) {
            newY = cy - targetH / 2;
            snappedY = true;
        } else if (Math.abs(newY - cy) <= snapDist) {
            newY = cy;
            snappedY = true;
        } else if (shiftDown) {
            int gridY = Math.max(8, this.height / 40);
            newY = Math.round((float) newY / gridY) * gridY;
        }

        double normX = Math.clamp((double) newX / Math.max(1, this.width), 0.0, 0.95);
        double normY = Math.clamp((double) newY / Math.max(1, this.height), 0.0, 0.95);

        switch (activeTarget) {
            case ICHOR -> VampyConfig.setIchorHudPos(normX, normY);
            case SPRING -> VampyConfig.setKillerSpringHudPos(normX, normY);
            case MANIA -> VampyConfig.setManiaHudPos(normX, normY);
            case PERF -> VampyConfig.setPerfHudPos(normX, normY);
            case PROFIT -> VampyConfig.setSlayerProfitHudPos(normX, normY);
            case HOTBAR_CD -> VampyConfig.setHotbarCdPos(normX, normY);
            default -> {}
        }
        return true;
    }

    @Override
    public boolean mouseReleased(MouseButtonEvent event) {
        if (activeTarget != DragTarget.NONE) {
            VampyConfig.save();
            activeTarget = DragTarget.NONE;
            snappedX = false;
            snappedY = false;
            return true;
        }
        return super.mouseReleased(event);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        DragTarget hovered = findTargetAt(mouseX, mouseY);
        if (hovered != DragTarget.NONE) {
            selectedTarget = hovered;
        }
        double step = verticalAmount > 0 ? 0.05 : -0.05;
        switch (selectedTarget) {
            case ICHOR -> VampyConfig.setIchorHudScale(VampyConfig.getIchorHudScale() + step);
            case SPRING -> VampyConfig.setKillerSpringHudScale(VampyConfig.getKillerSpringHudScale() + step);
            case MANIA -> VampyConfig.setManiaHudScale(VampyConfig.getManiaHudScale() + step);
            case PERF -> VampyConfig.setPerfHudScale(VampyConfig.getPerfHudScale() + step);
            case PROFIT -> VampyConfig.setSlayerProfitScale(VampyConfig.getSlayerProfitScale() + step);
            case HOTBAR_CD -> VampyConfig.setHotbarCdScale(VampyConfig.getHotbarCdScale() + step);
            default -> {}
        }
        VampyConfig.save();
        return true;
    }

    @Override
    public boolean keyPressed(KeyEvent event) {
        if (event.key() == GLFW.GLFW_KEY_ESCAPE) {
            if (this.minecraft != null) {
                this.minecraft.setScreen(this.parent);
            }
            return true;
        }
        if (event.key() == GLFW.GLFW_KEY_R && selectedTarget != DragTarget.NONE) {
            resetTargetPositionAndScale(selectedTarget);
            return true;
        }
        return super.keyPressed(event);
    }

    private int getIchorPx() {
        double x = VampyConfig.getIchorHudX();
        return x < 0 ? this.width / 2 - 50 : (int) Math.round(x * this.width);
    }

    private int getIchorPy() {
        double y = VampyConfig.getIchorHudY();
        return y < 0 ? this.height / 2 + 20 : (int) Math.round(y * this.height);
    }

    private int getSpringPx() {
        double x = VampyConfig.getKillerSpringHudX();
        return x < 0 ? this.width / 2 - 50 : (int) Math.round(yOrX(x, this.width));
    }

    private int getSpringPy() {
        double y = VampyConfig.getKillerSpringHudY();
        return y < 0 ? this.height / 2 + 42 : (int) Math.round(y * this.height);
    }

    private int getManiaPx() {
        double x = VampyConfig.getManiaHudX();
        return x < 0 ? this.width / 2 - 50 : (int) Math.round(x * this.width);
    }

    private int getManiaPy() {
        double y = VampyConfig.getManiaHudY();
        return y < 0 ? this.height / 2 + 64 : (int) Math.round(y * this.height);
    }

    private static double yOrX(double v, int dim) {
        return v * dim;
    }

    private int getPerfPx() {
        double x = VampyConfig.getPerfHudX();
        return x < 0 ? 8 : (int) Math.round(x * this.width);
    }

    private int getPerfPy() {
        double y = VampyConfig.getPerfHudY();
        return y < 0 ? 8 : (int) Math.round(y * this.height);
    }

    private int getProfitPx() {
        double x = VampyConfig.getSlayerProfitHudX();
        return x < 0 ? 12 : (int) Math.round(x * this.width);
    }

    private int getProfitPy() {
        double y = VampyConfig.getSlayerProfitHudY();
        return y < 0 ? 90 : (int) Math.round(y * this.height);
    }

    private int getHotbarCdPx() {
        double x = VampyConfig.getHotbarCdX();
        return x < 0 ? this.width / 2 - 60 : (int) Math.round(x * this.width);
    }

    private int getHotbarCdPy() {
        double y = VampyConfig.getHotbarCdY();
        return y < 0 ? this.height - 68 : (int) Math.round(y * this.height);
    }
}
