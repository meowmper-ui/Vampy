package com.vampy.screen;

import com.vampy.config.CommandHotkeyEntry;
import com.vampy.config.VampyConfig;
import com.vampy.input.CommandHotkeys;
import com.vampy.screen.crimson.CrimsonTheme;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;

/**
 * SkyOcean-like command hotkey manager, painted with {@link CrimsonTheme}.
 */
public final class CommandHotkeysScreen extends Screen {

    private static final int WIN_PAD = 16;
    private static final int INNER = 8;
    private static final int TITLE_H = 28;
    private static final int FOOTER_H = 30;
    private static final int ROW_H = 36;
    private static final int ROW_GAP = 4;

    private final Screen parent;
    private final List<CommandHotkeyEntry> entries = new ArrayList<>();

    private int winX, winY, winW, winH;
    private int listX, listY, listW, listH;
    private int doneX, doneY, doneW, doneH;
    private int createX, createY, createW, createH;
    private double scroll;

    public CommandHotkeysScreen(Screen parent) {
        super(Component.translatable("screen.vampy.command_hotkeys.title"));
        this.parent = parent;
        reloadFromConfig();
    }

    private void reloadFromConfig() {
        entries.clear();
        for (CommandHotkeyEntry e : VampyConfig.getCommandHotkeys()) {
            entries.add(e.copy());
        }
    }

    private void persist() {
        List<CommandHotkeyEntry> copy = new ArrayList<>();
        for (CommandHotkeyEntry e : entries) copy.add(e.copy());
        VampyConfig.setCommandHotkeys(copy);
    }

    @Override
    protected void init() {
        CrimsonTheme.sync();
        layout();
    }

    private void layout() {
        winW = Math.min(420, this.width - WIN_PAD * 2);
        winH = Math.min(280, this.height - WIN_PAD * 2);
        if (this.width >= 500) winW = Math.min(460, this.width - WIN_PAD * 2);
        if (this.height >= 340) winH = Math.min(320, this.height - WIN_PAD * 2);
        winX = (this.width - winW) / 2;
        winY = (this.height - winH) / 2;

        listX = winX + INNER;
        listY = winY + TITLE_H + 4;
        listW = winW - INNER * 2;
        listH = winH - TITLE_H - FOOTER_H - 10;

        createW = 110;
        createH = 20;
        createX = winX + (winW - createW) / 2;
        createY = winY + winH - FOOTER_H + 4;

        doneW = 64;
        doneH = 20;
        doneX = winX + winW - INNER - doneW;
        doneY = winY + 5;
    }

    @Override
    public void onClose() {
        persist();
        this.minecraft.setScreenAndShow(parent);
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float partialTick) {
        CrimsonTheme.sync();
        CrimsonTheme.paintScreenBackground(graphics, this.width, this.height);
        CrimsonTheme.paintOrnateWindow(graphics, winX, winY, winW, winH);

        graphics.centeredText(this.font,
                Component.translatable("screen.vampy.command_hotkeys.title"),
                winX + winW / 2, winY + 10, CrimsonTheme.TEXT_ACCENT);
        CrimsonTheme.paintTitleFlourish(graphics, winX + winW / 2, winY + 22, 48);

        boolean doneHover = hit(mouseX, mouseY, doneX, doneY, doneW, doneH);
        CrimsonTheme.paintButton(graphics, doneX, doneY, doneW, doneH, doneHover);
        graphics.centeredText(this.font, Component.translatable("gui.done"),
                doneX + doneW / 2, doneY + 6, CrimsonTheme.TEXT);

        CrimsonTheme.paintPanel(graphics, listX, listY, listW, listH);

        int contentH = entries.size() * (ROW_H + ROW_GAP) + 4;
        int maxScroll = Math.max(0, contentH - listH);
        if (scroll > maxScroll) scroll = maxScroll;
        if (scroll < 0) scroll = 0;

        graphics.enableScissor(listX + 1, listY + 1, listX + listW - 1, listY + listH - 1);
        int y = listY + 4 - (int) scroll;
        for (int i = 0; i < entries.size(); i++) {
            drawRow(graphics, i, listX + 4, y, listW - 8, mouseX, mouseY);
            y += ROW_H + ROW_GAP;
        }
        if (entries.isEmpty()) {
            graphics.centeredText(this.font,
                    Component.translatable("screen.vampy.command_hotkeys.empty"),
                    listX + listW / 2, listY + listH / 2 - 4, CrimsonTheme.TEXT_DIM);
        }
        graphics.disableScissor();

        boolean createHover = hit(mouseX, mouseY, createX, createY, createW, createH);
        CrimsonTheme.paintPrimaryButton(graphics, createX, createY, createW, createH, createHover);
        graphics.centeredText(this.font,
                Component.translatable("screen.vampy.command_hotkeys.create"),
                createX + createW / 2, createY + 6, CrimsonTheme.TEXT);
    }

    private void drawRow(GuiGraphicsExtractor graphics, int index, int x, int y, int w, int mx, int my) {
        CommandHotkeyEntry e = entries.get(index);
        boolean hover = mx >= x && mx < x + w && my >= y && my < y + ROW_H
                && my >= listY && my < listY + listH;
        CrimsonTheme.paintRow(graphics, x, y, w, ROW_H, hover, false);

        String title = e.displayName();
        if (title.length() > 22) title = title.substring(0, 22) + "…";
        graphics.text(this.font, Component.literal(title), x + 6, y + 5, CrimsonTheme.TEXT, false);

        // Enabled badge — accent when on, dim when off (follows Vamp / Simplified palette)
        Component badge = Component.translatable(e.enabled
                ? "screen.vampy.command_hotkeys.enabled"
                : "screen.vampy.command_hotkeys.disabled");
        int badgeW = Math.max(44, this.font.width(badge) + 8);
        int badgeX = x + w - badgeW - 6;
        int badgeY = y + 3;
        int badgeFill = e.enabled ? CrimsonTheme.TOGGLE_ON : CrimsonTheme.TOGGLE_OFF;
        int badgeBorder = e.enabled ? CrimsonTheme.ACCENT : CrimsonTheme.ROW_BORDER;
        int badgeText = e.enabled ? CrimsonTheme.TEXT : CrimsonTheme.TEXT_DIM;
        graphics.fill(badgeX, badgeY, badgeX + badgeW, badgeY + 12, badgeFill);
        graphics.outline(badgeX, badgeY, badgeW, 12, badgeBorder);
        graphics.centeredText(this.font, badge, badgeX + badgeW / 2, badgeY + 2, badgeText);

        Component keyLabel = CommandHotkeys.keyLabel(e);
        String keyText = keyLabel.getString();
        if (keyText.length() > 18) keyText = keyText.substring(0, 18) + "…";
        int keyW = Math.max(28, this.font.width(keyText) + 8);
        int keyX = x + 6;
        int keyY = y + 18;
        graphics.fill(keyX, keyY, keyX + keyW, keyY + 12, CrimsonTheme.BUTTON);
        graphics.outline(keyX, keyY, keyW, 12, CrimsonTheme.ROW_BORDER);
        graphics.centeredText(this.font, Component.literal(keyText), keyX + keyW / 2, keyY + 2, CrimsonTheme.TEXT_DIM);

        int editW = 36;
        int delW = 42;
        int btnH = 12;
        int delX = x + w - delW - 6;
        int editX = delX - 4 - editW;
        int btnY = y + 18;
        boolean editHover = hit(mx, my, editX, btnY, editW, btnH);
        boolean delHover = hit(mx, my, delX, btnY, delW, btnH);
        CrimsonTheme.paintButton(graphics, editX, btnY, editW, btnH, editHover);
        graphics.centeredText(this.font,
                Component.translatable("screen.vampy.command_hotkeys.edit"),
                editX + editW / 2, btnY + 2, CrimsonTheme.TEXT);
        CrimsonTheme.paintButton(graphics, delX, btnY, delW, btnH, delHover);
        graphics.centeredText(this.font,
                Component.translatable("screen.vampy.command_hotkeys.delete"),
                delX + delW / 2, btnY + 2, 0xFFE08080);
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean repeat) {
        double mx = event.x();
        double my = event.y();
        if (hit(mx, my, doneX, doneY, doneW, doneH)) {
            onClose();
            return true;
        }
        if (hit(mx, my, createX, createY, createW, createH)) {
            openEdit(-1, new CommandHotkeyEntry("New", "", true, ""));
            return true;
        }
        if (mx >= listX && mx < listX + listW && my >= listY && my < listY + listH) {
            int y = listY + 4 - (int) scroll;
            for (int i = 0; i < entries.size(); i++) {
                int x = listX + 4;
                int w = listW - 8;
                if (my >= y && my < y + ROW_H) {
                    int editW = 36;
                    int delW = 42;
                    int btnH = 12;
                    int delX = x + w - delW - 6;
                    int editX = delX - 4 - editW;
                    int btnY = y + 18;
                    if (hit(mx, my, delX, btnY, delW, btnH)) {
                        entries.remove(i);
                        persist();
                        return true;
                    }
                    if (hit(mx, my, editX, btnY, editW, btnH) || hit(mx, my, x, y, w, ROW_H)) {
                        openEdit(i, entries.get(i).copy());
                        return true;
                    }
                }
                y += ROW_H + ROW_GAP;
            }
        }
        return super.mouseClicked(event, repeat);
    }

    private void openEdit(int index, CommandHotkeyEntry draft) {
        this.minecraft.setScreenAndShow(new CommandHotkeyEditScreen(this, draft, saved -> {
            if (index >= 0 && index < entries.size()) {
                entries.set(index, saved);
            } else {
                entries.add(saved);
            }
            persist();
            reloadFromConfig();
        }));
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double scrollX, double scrollY) {
        if (mouseX >= listX && mouseX < listX + listW && mouseY >= listY && mouseY < listY + listH) {
            scroll -= scrollY * 14;
            return true;
        }
        return super.mouseScrolled(mouseX, mouseY, scrollX, scrollY);
    }

    private static boolean hit(double mx, double my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }
}

