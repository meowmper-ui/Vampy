package com.vampy.screen;

import net.minecraft.client.gui.ActiveTextCollector;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.TextAlignment;
import net.minecraft.network.chat.Component;
import net.minecraft.util.FormattedCharSequence;
import org.joml.Matrix3x2f;
import org.joml.Vector2f;

/**
 * ActiveTextCollector that finds the chat text line under the cursor. Used by
 * the Ctrl+click chat copy feature; the matched line is then resolved back to
 * its full original message via ChatComponentAccessor.
 */
public final class ChatCopyFinder implements ActiveTextCollector {

    private final Font font;
    private final int testX;
    private final int testY;
    private ActiveTextCollector.Parameters defaultParameters = new ActiveTextCollector.Parameters(new Matrix3x2f());
    private FormattedCharSequence matchedLine;

    public ChatCopyFinder(Font font, int testX, int testY) {
        this.font = font;
        this.testX = testX;
        this.testY = testY;
    }

    @Override
    public ActiveTextCollector.Parameters defaultParameters() {
        return defaultParameters;
    }

    @Override
    public void defaultParameters(ActiveTextCollector.Parameters parameters) {
        this.defaultParameters = parameters;
    }

    @Override
    public void accept(TextAlignment alignment, int x, int y, ActiveTextCollector.Parameters parameters, FormattedCharSequence line) {
        if (matchedLine != null) {
            return;
        }
        int width = font.width(line);
        int left;
        if (alignment == TextAlignment.CENTER) {
            left = x - width / 2;
        } else if (alignment == TextAlignment.RIGHT) {
            left = x - width;
        } else {
            left = x;
        }
        Vector2f topLeft = parameters.pose().transformPosition(left, y, new Vector2f());
        Vector2f bottomRight = parameters.pose().transformPosition(left + width, y + font.lineHeight, new Vector2f());
        if (testX >= topLeft.x && testX <= bottomRight.x && testY >= topLeft.y && testY <= bottomRight.y) {
            matchedLine = line;
        }
    }

    @Override
    public void acceptScrolling(Component component, int x, int y, int width, int height, int color, ActiveTextCollector.Parameters parameters) {
        // collapsed/scrolling banner lines are not copy targets
    }

    public FormattedCharSequence matchedLine() {
        return matchedLine;
    }
}

