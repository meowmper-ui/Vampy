package com.vampy.screen.crimson;

import net.minecraft.client.gui.GuiGraphicsExtractor;

/**
 * Procedural / pixel icons for the crimson config GUI (no atlas).
 * Sidebar / footer icons are {@link #SIZE}×{@link #SIZE}.
 */
public final class CrimsonIcons {

    public static final int SIZE = 16;

    public enum Id {
        BLEEDING_EYE,
        GEAR,
        EYE,
        HEART,
        COMPASS,
        SPEAKER,
        DROPLET,
        CROSSHAIR,
        CHAT,
        CLOCK,
        EFFIGY,
        ESP,
        BOX,
        RESET,
        SAVE,
        VISION
    }

    public static final int BLEEDING_EYE_W = 15;
    public static final int BLEEDING_EYE_H = 18;

    public static final int LARGE_EYE_SCALE = 3;
    public static final int LARGE_EYE_W = BLEEDING_EYE_W * LARGE_EYE_SCALE;
    public static final int LARGE_EYE_H = BLEEDING_EYE_H * LARGE_EYE_SCALE;

    public static final int CORNER_EYE_W = 11;
    public static final int CORNER_EYE_H = 16;

    private CrimsonIcons() {
    }

    public static void draw(GuiGraphicsExtractor g, Id id, int x, int y, int color) {
        switch (id) {
            case BLEEDING_EYE -> bleedingEye(g, x, y, 1);
            case GEAR -> gear16(g, x, y, color);
            case HEART -> heart16(g, x, y, color);
            case SPEAKER -> speaker16(g, x, y, color);
            case RESET -> reset(g, x, y, color);
            default -> {
                g.pose().pushMatrix();
                g.pose().translate(x, y);
                g.pose().scale(2f, 2f);
                draw8(g, id, 0, 0, color);
                g.pose().popMatrix();
            }
        }
    }

    private static void draw8(GuiGraphicsExtractor g, Id id, int x, int y, int color) {
        switch (id) {
            case EYE -> eye(g, x, y, color);
            case COMPASS -> compass(g, x, y, color);
            case DROPLET -> droplet(g, x, y, color);
            case CROSSHAIR -> crosshair(g, x, y, color);
            case CHAT -> chat(g, x, y, color);
            case CLOCK -> clock(g, x, y, color);
            case EFFIGY -> effigy(g, x, y, color);
            case ESP -> esp(g, x, y, color);
            case BOX -> box(g, x, y, color);
            case SAVE -> save(g, x, y, color);
            case VISION -> vision(g, x, y, color);
            default -> {
            }
        }
    }

    public static void drawLargeBleedingEye(GuiGraphicsExtractor g, int x, int y) {
        bleedingEye(g, x, y, LARGE_EYE_SCALE);
    }

    public static void drawCornerDripEye(GuiGraphicsExtractor g, int x, int y) {
        int blood = CrimsonTheme.BLOOD_DROP;
        int shade = CrimsonTheme.BLOOD_DROP_SHADE;
        int hi = CrimsonTheme.BLOOD_DROP_HIGHLIGHT;
        int mid = 0xFFA01018;
        px(g, x + 4, y + 0, 3, 1, blood);
        px(g, x + 2, y + 1, 7, 1, blood);
        px(g, x + 1, y + 2, 9, 1, mid);
        px(g, x + 0, y + 3, 11, 2, blood);
        px(g, x + 1, y + 5, 9, 1, mid);
        px(g, x + 2, y + 6, 7, 1, blood);
        px(g, x + 4, y + 7, 3, 1, blood);
        px(g, x + 4, y + 3, 3, 2, 0xFF0A0404);
        px(g, x + 5, y + 3, 1, 1, hi);
        px(g, x + 2, y + 7, 1, 2, blood);
        px(g, x + 2, y + 9, 1, 2, shade);
        px(g, x + 5, y + 8, 1, 3, blood);
        px(g, x + 5, y + 11, 1, 2, shade);
        px(g, x + 5, y + 13, 1, 1, blood);
        px(g, x + 8, y + 7, 1, 2, blood);
        px(g, x + 8, y + 9, 1, 3, shade);
        px(g, x + 4, y + 14, 3, 1, blood);
        px(g, x + 5, y + 15, 1, 1, shade);
    }

    private static void bleedingEye(GuiGraphicsExtractor g, int x, int y, int scale) {
        int s = Math.max(1, scale);
        int blood = CrimsonTheme.BLOOD_DROP;
        int shade = CrimsonTheme.BLOOD_DROP_SHADE;
        int hi = CrimsonTheme.BLOOD_DROP_HIGHLIGHT;
        int mid = 0xFFA01018;
        int voidC = 0xFF0A0606;

        px(g, x + 5 * s, y + 0 * s, 5 * s, 1 * s, blood);
        px(g, x + 3 * s, y + 1 * s, 2 * s, 1 * s, blood);
        px(g, x + 10 * s, y + 1 * s, 2 * s, 1 * s, blood);
        px(g, x + 2 * s, y + 2 * s, 1 * s, 1 * s, blood);
        px(g, x + 12 * s, y + 2 * s, 1 * s, 1 * s, blood);
        px(g, x + 1 * s, y + 3 * s, 1 * s, 2 * s, blood);
        px(g, x + 13 * s, y + 3 * s, 1 * s, 2 * s, blood);
        px(g, x + 0 * s, y + 5 * s, 1 * s, 1 * s, blood);
        px(g, x + 14 * s, y + 5 * s, 1 * s, 1 * s, blood);
        px(g, x + 1 * s, y + 6 * s, 1 * s, 1 * s, blood);
        px(g, x + 13 * s, y + 6 * s, 1 * s, 1 * s, blood);
        px(g, x + 2 * s, y + 7 * s, 2 * s, 1 * s, blood);
        px(g, x + 11 * s, y + 7 * s, 2 * s, 1 * s, blood);
        px(g, x + 4 * s, y + 8 * s, 7 * s, 1 * s, blood);

        px(g, x + 5 * s, y + 2 * s, 5 * s, 1 * s, mid);
        px(g, x + 4 * s, y + 3 * s, 1 * s, 3 * s, mid);
        px(g, x + 10 * s, y + 3 * s, 1 * s, 3 * s, mid);
        px(g, x + 5 * s, y + 6 * s, 5 * s, 1 * s, mid);
        px(g, x + 5 * s, y + 3 * s, 5 * s, 1 * s, blood);
        px(g, x + 5 * s, y + 5 * s, 5 * s, 1 * s, blood);
        px(g, x + 5 * s, y + 4 * s, 1 * s, 1 * s, blood);
        px(g, x + 9 * s, y + 4 * s, 1 * s, 1 * s, blood);
        px(g, x + 6 * s, y + 4 * s, 3 * s, 1 * s, voidC);
        px(g, x + 5 * s, y + 3 * s, 2 * s, 1 * s, hi);

        px(g, x + 5 * s, y + 7 * s, 1 * s, 1 * s, mid);
        px(g, x + 5 * s, y + 8 * s, 1 * s, 2 * s, blood);
        px(g, x + 5 * s, y + 8 * s, 1 * s, 1 * s, hi);
        px(g, x + 4 * s, y + 10 * s, 3 * s, 1 * s, blood);
        px(g, x + 5 * s, y + 11 * s, 1 * s, 1 * s, shade);

        px(g, x + 3 * s, y + 8 * s, 1 * s, 1 * s, blood);
        px(g, x + 3 * s, y + 9 * s, 1 * s, 2 * s, shade);
        px(g, x + 3 * s, y + 11 * s, 1 * s, 1 * s, blood);
        px(g, x + 7 * s, y + 9 * s, 1 * s, 1 * s, mid);
        px(g, x + 7 * s, y + 10 * s, 1 * s, 3 * s, blood);
        px(g, x + 7 * s, y + 12 * s, 1 * s, 1 * s, hi);
        px(g, x + 6 * s, y + 13 * s, 3 * s, 1 * s, blood);
        px(g, x + 7 * s, y + 14 * s, 1 * s, 2 * s, blood);
        px(g, x + 7 * s, y + 16 * s, 1 * s, 1 * s, shade);
        px(g, x + 11 * s, y + 8 * s, 1 * s, 1 * s, blood);
        px(g, x + 11 * s, y + 9 * s, 1 * s, 3 * s, blood);
        px(g, x + 10 * s, y + 12 * s, 3 * s, 1 * s, blood);
        px(g, x + 11 * s, y + 13 * s, 1 * s, 1 * s, shade);
        px(g, x + 11 * s, y + 10 * s, 1 * s, 1 * s, hi);
    }

    private static void eye(GuiGraphicsExtractor g, int x, int y, int c) {
        px(g, x + 1, y + 3, 6, 2, c);
        px(g, x + 2, y + 2, 4, 1, c);
        px(g, x + 2, y + 5, 4, 1, c);
        px(g, x + 3, y + 3, 2, 2, 0xFF1A1010);
        px(g, x + 4, y + 3, 1, 1, c);
    }

    private static void gear16(GuiGraphicsExtractor g, int x, int y, int c) {
        blitMask16(g, x, y, ICON_GEAR, c);
    }

    private static void heart16(GuiGraphicsExtractor g, int x, int y, int c) {
        blitMask16(g, x, y, ICON_QOL, c);
    }

    private static final int[] ICON_GEAR = {
            0b0000001111000000,
            0b0000001111000000,
            0b0011001111001100,
            0b0011111111111100,
            0b0001111111111000,
            0b0001111111111000,
            0b1111110000111111,
            0b1111110000111111,
            0b1111110000111111,
            0b1111110000111111,
            0b0001111111111000,
            0b0001111111111000,
            0b0011111111111100,
            0b0011001111001100,
            0b0000001111000000,
            0b0000001111000000,
    };

    private static final int[] ICON_QOL = {
            0b0000000000000000,
            0b0000000000000000,
            0b0001110000111000,
            0b0011111001111100,
            0b0111111111111110,
            0b0111111111111110,
            0b0111111111111110,
            0b0111111111111110,
            0b0011111111111100,
            0b0001111111111000,
            0b0000111111110000,
            0b0000011111100000,
            0b0000001111000000,
            0b0000000110000000,
            0b0000000000000000,
            0b0000000000000000,
    };

    private static final int[] ICON_PARTY = {
            0b0000000000000000,
            0b0000000000000000,
            0b0000000010000000,
            0b0000000110000000,
            0b0000001110001100,
            0b0000011110100100,
            0b0111111110010100,
            0b0111111110010010,
            0b0111111110010010,
            0b0111111110010100,
            0b0001011110100100,
            0b0001001110001100,
            0b0001100110000000,
            0b0001100010000000,
            0b0000000000000000,
            0b0000000000000000,
    };

    private static final int[] ICON_RESET = {
            0b0000000000000000,
            0b0000000000000000,
            0b0001111110000000,
            0b0001111111000000,
            0b0000000111010000,
            0b0000000011110000,
            0b0000000001110000,
            0b0011110011110000,
            0b0001110000000000,
            0b0011110000000100,
            0b0111010000001100,
            0b0110000001001100,
            0b0111111011111100,
            0b0111111011111100,
            0b0000000001000000,
            0b0000000000000000,
    };

    private static void compass(GuiGraphicsExtractor g, int x, int y, int c) {
        px(g, x + 2, y + 1, 4, 1, c);
        px(g, x + 1, y + 2, 1, 4, c);
        px(g, x + 6, y + 2, 1, 4, c);
        px(g, x + 2, y + 6, 4, 1, c);
        px(g, x + 3, y + 2, 1, 3, c);
        px(g, x + 4, y + 4, 1, 2, c);
        px(g, x + 4, y + 3, 1, 1, c);
    }

    private static void speaker16(GuiGraphicsExtractor g, int x, int y, int c) {
        blitMask16(g, x, y, ICON_PARTY, c);
    }

    private static void droplet(GuiGraphicsExtractor g, int x, int y, int c) {
        px(g, x + 3, y + 0, 2, 1, c);
        px(g, x + 2, y + 1, 4, 1, c);
        px(g, x + 1, y + 2, 6, 3, c);
        px(g, x + 2, y + 5, 4, 1, c);
        px(g, x + 3, y + 6, 2, 1, c);
        px(g, x + 3, y + 3, 1, 1, 0xFF1A1010);
    }

    public static void drawBloodDrop(GuiGraphicsExtractor g, int x, int y) {
        int body = CrimsonTheme.BLOOD_DROP;
        int shade = CrimsonTheme.BLOOD_DROP_SHADE;
        int hi = CrimsonTheme.BLOOD_DROP_HIGHLIGHT;
        px(g, x + 2, y + 0, 2, 1, body);
        px(g, x + 1, y + 1, 4, 1, body);
        px(g, x + 0, y + 2, 6, 3, body);
        px(g, x + 1, y + 5, 4, 1, body);
        px(g, x + 2, y + 6, 2, 1, body);
        px(g, x + 4, y + 3, 1, 2, shade);
        px(g, x + 1, y + 2, 1, 1, hi);
    }

    private static void crosshair(GuiGraphicsExtractor g, int x, int y, int c) {
        px(g, x + 3, y + 0, 2, 3, c);
        px(g, x + 3, y + 5, 2, 3, c);
        px(g, x + 0, y + 3, 3, 2, c);
        px(g, x + 5, y + 3, 3, 2, c);
        px(g, x + 3, y + 3, 2, 2, 0xFF1A1010);
    }

    private static void chat(GuiGraphicsExtractor g, int x, int y, int c) {
        px(g, x + 1, y + 1, 6, 4, c);
        px(g, x + 2, y + 5, 2, 1, c);
        px(g, x + 2, y + 6, 1, 1, c);
        px(g, x + 2, y + 2, 1, 1, 0xFF1A1010);
        px(g, x + 4, y + 2, 1, 1, 0xFF1A1010);
        px(g, x + 6, y + 2, 1, 1, 0xFF1A1010);
    }

    private static void clock(GuiGraphicsExtractor g, int x, int y, int c) {
        px(g, x + 2, y + 0, 4, 1, c);
        px(g, x + 1, y + 1, 1, 6, c);
        px(g, x + 6, y + 1, 1, 6, c);
        px(g, x + 2, y + 7, 4, 1, c);
        px(g, x + 2, y + 1, 4, 1, c);
        px(g, x + 2, y + 6, 4, 1, c);
        px(g, x + 4, y + 2, 1, 3, c);
        px(g, x + 4, y + 4, 2, 1, c);
    }

    private static void effigy(GuiGraphicsExtractor g, int x, int y, int c) {
        px(g, x + 3, y + 0, 2, 8, c);
        px(g, x + 1, y + 2, 6, 2, c);
        px(g, x + 2, y + 1, 1, 1, c);
        px(g, x + 5, y + 1, 1, 1, c);
    }

    private static void esp(GuiGraphicsExtractor g, int x, int y, int c) {
        px(g, x + 1, y + 1, 6, 1, c);
        px(g, x + 1, y + 6, 6, 1, c);
        px(g, x + 1, y + 2, 1, 4, c);
        px(g, x + 6, y + 2, 1, 4, c);
        px(g, x + 3, y + 3, 2, 2, c);
    }

    private static void box(GuiGraphicsExtractor g, int x, int y, int c) {
        px(g, x + 1, y + 2, 6, 5, c);
        px(g, x + 2, y + 1, 4, 1, c);
        px(g, x + 2, y + 3, 4, 1, 0xFF1A1010);
    }

    private static void reset(GuiGraphicsExtractor g, int x, int y, int c) {
        blitMask16(g, x, y, ICON_RESET, c);
    }

    private static void save(GuiGraphicsExtractor g, int x, int y, int c) {
        droplet(g, x, y, c);
    }

    private static void vision(GuiGraphicsExtractor g, int x, int y, int c) {
        eye(g, x, y, c);
        px(g, x + 0, y + 0, 1, 1, c);
        px(g, x + 7, y + 0, 1, 1, c);
        px(g, x + 0, y + 7, 1, 1, c);
        px(g, x + 7, y + 7, 1, 1, c);
    }

    private static void px(GuiGraphicsExtractor g, int x, int y, int w, int h, int color) {
        g.fill(x, y, x + w, y + h, color);
    }

    private static void blitMask16(GuiGraphicsExtractor g, int x, int y, int[] rows, int color) {
        for (int row = 0; row < rows.length; row++) {
            int bits = rows[row];
            for (int col = 0; col < 16; col++) {
                if (((bits >> (15 - col)) & 1) != 0) {
                    px(g, x + col, y + row, 1, 1, color);
                }
            }
        }
    }
}
