package com.vampy.screen;

import com.mojang.blaze3d.platform.InputConstants;
import com.vampy.config.CommandHotkeyEntry;
import com.vampy.input.CommandHotkeys;
import com.vampy.screen.crimson.CrimsonTheme;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

import java.util.function.Consumer;

/**
 * Edit one command hotkey: name, key capture (with Ctrl/Shift/Alt), enabled, command.
 */
public final class CommandHotkeyEditScreen extends Screen {

    private static final int WIN_PAD = 20;
    private static final int INNER = 10;

    private final Screen parent;
    private final CommandHotkeyEntry draft;
    private final Consumer<CommandHotkeyEntry> onConfirm;

    private EditBox nameBox;
    private EditBox commandBox;
    private boolean listeningKey;

    private int winX, winY, winW, winH;
    private int keyX, keyY, keyW, keyH;
    private int enabledX, enabledY, enabledW, enabledH;
    private int cancelX, confirmX, btnY, btnW, btnH;

    public CommandHotkeyEditScreen(Screen parent, CommandHotkeyEntry draft, Consumer<CommandHotkeyEntry> onConfirm) {
        super(Component.translatable("screen.vampy.command_hotkeys.edit_title"));
        this.parent = parent;
        this.draft = draft == null ? new CommandHotkeyEntry() : draft.copy();
        this.onConfirm = onConfirm;
    }

    @Override
    protected void init() {
        CrimsonTheme.sync();
        layout();

        nameBox = new EditBox(this.font, winX + INNER, winY + 48, winW - INNER * 2, 16,
                Component.translatable("screen.vampy.command_hotkeys.name"));
        nameBox.setMaxLength(48);
        nameBox.setValue(draft.name == null ? "" : draft.name);
        addRenderableWidget(nameBox);

        commandBox = new EditBox(this.font, winX + INNER, winY + 148, winW - INNER * 2, 16,
                Component.translatable("screen.vampy.command_hotkeys.command"));
        commandBox.setMaxLength(256);
        commandBox.setValue(draft.command == null ? "" : draft.command);
        addRenderableWidget(commandBox);

        setInitialFocus(nameBox);
    }

    private void layout() {
        winW = Math.min(300, this.width - WIN_PAD * 2);
        winH = Math.min(220, this.height - WIN_PAD * 2);
        winX = (this.width - winW) / 2;
        winY = (this.height - winH) / 2;

        keyW = winW - INNER * 2;
        keyH = 16;
        keyX = winX + INNER;
        keyY = winY + 84;

        enabledW = 56;
        enabledH = 14;
        enabledX = winX + INNER;
        enabledY = winY + 114;

        btnW = 80;
        btnH = 20;
        btnY = winY + winH - 28;
        cancelX = winX + INNER;
        confirmX = winX + winW - INNER - btnW;
    }

    @Override
    public void onClose() {
        this.minecraft.setScreenAndShow(parent);
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float partialTick) {
        CrimsonTheme.sync();
        CrimsonTheme.paintScreenBackground(graphics, this.width, this.height);
        CrimsonTheme.paintOrnateWindow(graphics, winX, winY, winW, winH);

        graphics.centeredText(this.font,
                Component.translatable("screen.vampy.command_hotkeys.edit_title"),
                winX + winW / 2, winY + 10, CrimsonTheme.TEXT_ACCENT);
        CrimsonTheme.paintTitleFlourish(graphics, winX + winW / 2, winY + 22, 40);

        graphics.text(this.font,
                Component.translatable("screen.vampy.command_hotkeys.name"),
                winX + INNER, winY + 36, CrimsonTheme.TEXT_DIM, false);

        graphics.text(this.font,
                Component.translatable("screen.vampy.command_hotkeys.keys"),
                winX + INNER, winY + 72, CrimsonTheme.TEXT_DIM, false);

        boolean keyHover = hit(mouseX, mouseY, keyX, keyY, keyW, keyH);
        int keyFill = listeningKey ? CrimsonTheme.ROW_SELECTED : (keyHover ? CrimsonTheme.ROW_HOVER : CrimsonTheme.ROW);
        graphics.fill(keyX, keyY, keyX + keyW, keyY + keyH, keyFill);
        graphics.outline(keyX, keyY, keyW, keyH, listeningKey ? CrimsonTheme.ACCENT : CrimsonTheme.ROW_BORDER);
        Component keyText = listeningKey
                ? Component.translatable("screen.vampy.command_hotkeys.press_key")
                : CommandHotkeys.keyLabel(draft);
        graphics.text(this.font, keyText, keyX + 4, keyY + 4,
                listeningKey ? CrimsonTheme.ACCENT_BRIGHT : CrimsonTheme.TEXT, false);

        graphics.text(this.font,
                Component.translatable("screen.vampy.command_hotkeys.enabled"),
                winX + INNER + enabledW + 6, enabledY + 3, CrimsonTheme.TEXT, false);
        boolean enHover = hit(mouseX, mouseY, enabledX, enabledY, enabledW, enabledH);
        int enFill = draft.enabled ? CrimsonTheme.TOGGLE_ON : CrimsonTheme.TOGGLE_OFF;
        if (enHover) enFill = draft.enabled ? CrimsonTheme.ACCENT_BRIGHT : CrimsonTheme.BUTTON_HOVER;
        graphics.fill(enabledX, enabledY, enabledX + enabledW, enabledY + enabledH, enFill);
        graphics.outline(enabledX, enabledY, enabledW, enabledH, CrimsonTheme.ROW_BORDER_HOVER);
        graphics.centeredText(this.font,
                Component.literal(draft.enabled ? "On" : "Off"),
                enabledX + enabledW / 2, enabledY + 3, CrimsonTheme.TEXT);

        graphics.text(this.font,
                Component.translatable("screen.vampy.command_hotkeys.command"),
                winX + INNER, winY + 136, CrimsonTheme.TEXT_DIM, false);
        graphics.text(this.font,
                Component.translatable("screen.vampy.command_hotkeys.command_hint"),
                winX + INNER, winY + 168, CrimsonTheme.TEXT_DIM, false);

        boolean cancelHover = hit(mouseX, mouseY, cancelX, btnY, btnW, btnH);
        boolean confirmHover = hit(mouseX, mouseY, confirmX, btnY, btnW, btnH);
        CrimsonTheme.paintButton(graphics, cancelX, btnY, btnW, btnH, cancelHover);
        graphics.centeredText(this.font, Component.translatable("gui.cancel"),
                cancelX + btnW / 2, btnY + 6, CrimsonTheme.TEXT_DIM);

        CrimsonTheme.paintSaveButton(graphics, confirmX, btnY, btnW, btnH, confirmHover);
        graphics.centeredText(this.font, Component.translatable("gui.done"),
                confirmX + btnW / 2, btnY + 6, CrimsonTheme.SAVE_TEXT);

        super.extractRenderState(graphics, mouseX, mouseY, partialTick);
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean repeat) {
        double mx = event.x();
        double my = event.y();

        if (listeningKey) {
            int button = event.button();
            if (button >= 0) {
                InputConstants.Key key = InputConstants.Type.MOUSE.getOrCreate(button);
                draft.key = CommandHotkeys.keyNameOf(key);
                draft.ctrl = event.hasControlDown();
                draft.shift = event.hasShiftDown();
                draft.alt = event.hasAltDown();
                listeningKey = false;
                return true;
            }
        }

        if (hit(mx, my, keyX, keyY, keyW, keyH)) {
            listeningKey = true;
            nameBox.setFocused(false);
            commandBox.setFocused(false);
            return true;
        }
        if (hit(mx, my, enabledX, enabledY, enabledW, enabledH)) {
            draft.enabled = !draft.enabled;
            return true;
        }
        if (hit(mx, my, cancelX, btnY, btnW, btnH)) {
            onClose();
            return true;
        }
        if (hit(mx, my, confirmX, btnY, btnW, btnH)) {
            confirm();
            return true;
        }

        listeningKey = false;
        return super.mouseClicked(event, repeat);
    }

    @Override
    public boolean keyPressed(KeyEvent event) {
        if (listeningKey) {
            int code = event.key();
            if (code == GLFW.GLFW_KEY_ESCAPE) {
                listeningKey = false;
                return true;
            }
            if (code == GLFW.GLFW_KEY_UNKNOWN) return true;
            // Keep listening while only modifiers are held — wait for the real key
            if (CommandHotkeys.isModifierKeyCode(code)) return true;

            InputConstants.Key key = InputConstants.getKey(event);
            draft.key = CommandHotkeys.keyNameOf(key);
            draft.ctrl = event.hasControlDown();
            draft.shift = event.hasShiftDown();
            draft.alt = event.hasAltDown();
            listeningKey = false;
            return true;
        }
        if (event.key() == GLFW.GLFW_KEY_ESCAPE) {
            onClose();
            return true;
        }
        if (event.key() == GLFW.GLFW_KEY_ENTER || event.key() == GLFW.GLFW_KEY_KP_ENTER) {
            if (commandBox.isFocused() || nameBox.isFocused()) {
                confirm();
                return true;
            }
        }
        return super.keyPressed(event);
    }

    private void confirm() {
        draft.name = nameBox.getValue() == null ? "" : nameBox.getValue().trim();
        draft.command = commandBox.getValue() == null ? "" : commandBox.getValue().trim();
        if (draft.command.startsWith("/")) {
            draft.command = draft.command.substring(1).trim();
        }
        if (draft.key == null) draft.key = "";
        if (draft.name.isEmpty() && !draft.command.isEmpty()) {
            draft.name = draft.command;
        }
        if (onConfirm != null) onConfirm.accept(draft.copy());
        this.minecraft.setScreenAndShow(parent);
    }

    private static boolean hit(double mx, double my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }
}

