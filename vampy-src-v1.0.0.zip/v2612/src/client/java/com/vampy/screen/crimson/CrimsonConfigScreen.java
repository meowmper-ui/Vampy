package com.vampy.screen.crimson;

import com.vampy.VampyMod;
import com.vampy.config.VampyConfig;
import com.vampy.render.CustomCrosshairRenderer;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * Independent crimson-rift config GUI (no YACL) — ornate frame, icon sidebar, HSV color picker.
 * Supports three looks: Vamp (v1), Vamp v2 (gothic mockup), Simplified (gray, no icons).
 */
public final class CrimsonConfigScreen extends Screen {

    private static final int WIN_PAD = 16;
    /** Tall enough for the bleeding-eye mark + title (Vamp); Simplified still uses text-only. */
    private static final int TITLE_H = 34;
    /** Vamp v2: no top chrome (brand lives in the left column); groups are sidebar items. */
    private static final int TITLE_H_V2 = 4;
    private static final int FOOTER_H = 34;
    private static final int SECTION_H = 18;
    private static final int SIDEBAR_W = 128;
    private static final int SIDEBAR_W_V2 = 142;
    private static final int SIDEBAR_ROW = 28;
    private static final int SIDEBAR_ROW_V2 = 26;
    /** Brand + large eye block at top of Vamp v2 sidebar (3× bleeding eye). */
    private static final int SIDEBAR_HERO_V2 = 98;
    /** No footer château in sidebar — scene lives in the full-window background. */
    private static final int CASTLE_RESERVE_V2 = 4;
    private static final int ROW_H = 22;
    private static final int GAP = 3;
    private static final int INNER = 8;

    private final Screen parent;
    private final byte[] undoSnapshot;
    private boolean discardOnClose;

    private List<ConfigCatalog.Tab> tabs = List.of();
    /** Selected group (ESP / Utility / QoL) — formerly a top tab. */
    private int tabIndex;
    private int selectedRow = -1;
    private double scroll;

    private EditBox searchBox;
    private String searchQuery = "";
    private EditBox editBox;
    private EditBox hexBox;
    private boolean editingListItem;
    private int listEditIndex = -1;

    private boolean colorPickerOpen;
    private float pickerH, pickerS, pickerV;
    private int pickerOrigArgb;
    private boolean draggingSv;
    private boolean draggingHue;
    private boolean draggingSlider;

    private int winX, winY, winW, winH;
    private int sidebarX, sidebarY, sidebarH;
    private int contentX, contentY, contentW, contentH;
    private int listX, listY, listW, listH;
    private final List<LayoutRow> layout = new ArrayList<>();
    /** Category section ids that are collapsed (▸). Everything else starts open. */
    private final Set<String> collapsedCategories = new HashSet<>(Set.of("party_fun"));
    /** Subgroup row ids that are currently expanded via their Click! button. */
    private final Set<String> expandedSubgroups = new HashSet<>();

    // Footer button rects (set during render / layout)
    private int resetX, cancelX, saveX, footerY, footerBtnW, footerBtnH;

    // Bottom-left screen style toggle (outside the main window)
    private int styleBtnX, styleBtnY, styleBtnW, styleBtnH;

    // Color picker layout (recomputed when open)
    private int cpX, cpY, cpW, cpH;
    private int svX, svY, svSize;
    private int hueX, hueY, hueW, hueH;
    private int previewX, previewY;
    private int presetX, presetY;
    private int okX, cancelPickX, pickBtnY;

    public CrimsonConfigScreen(Screen parent) {
        super(Component.literal(VampyMod.MOD_NAME));
        this.parent = parent;
        this.undoSnapshot = VampyConfig.createUndoSnapshot();
    }

    public static Screen create(Screen parent) {
        return new CrimsonConfigScreen(parent);
    }

    public void reloadTabsPreserveSelection() {
        String tabId = tabIndex >= 0 && tabIndex < tabs.size() ? tabs.get(tabIndex).id() : "utility";
        String selectedId = selectedEntryId();
        rebuildTabs();
        tabIndex = 0;
        for (int i = 0; i < tabs.size(); i++) {
            if (tabs.get(i).id().equals(tabId)) {
                tabIndex = i;
                break;
            }
        }
        if (tabIndex >= tabs.size()) {
            tabIndex = Math.max(0, tabs.size() - 1);
        }
        rebuildLayout();
        selectedRow = findRowById(selectedId);
        clearEditState();
    }

    @Override
    protected void init() {
        CrimsonTheme.sync();
        rebuildTabs();
        layoutPanels();
        initSearchBox();
        rebuildLayout();
        clearEditState();
    }

    private void initSearchBox() {
        if (searchBox != null) {
            removeWidget(searchBox);
        }
        int sbW = Math.min(130, Math.max(70, contentW - 36));
        int sbX = contentX + 6;
        int sbY = contentY + 3;
        searchBox = new EditBox(this.font, sbX, sbY, sbW, 13, Component.literal("Search..."));
        searchBox.setMaxLength(48);
        searchBox.setValue(searchQuery);
        searchBox.setHint(Component.literal("§8Search settings..."));
        searchBox.setBordered(true);
        searchBox.setTextColor(CrimsonTheme.TEXT);
        searchBox.setResponder(q -> {
            searchQuery = q == null ? "" : q;
            scroll = 0;
            rebuildLayout();
        });
        addRenderableWidget(searchBox);
    }

    private void rebuildTabs() {
        this.tabs = ConfigCatalog.buildTabs(this);
        if (tabIndex >= tabs.size()) {
            tabIndex = Math.max(0, tabs.size() - 1);
        }
    }

    private void layoutPanels() {
        boolean v2 = CrimsonTheme.isVampV2();
        if (v2) {
            winW = Math.min(500, this.width - WIN_PAD * 2);
            winH = Math.min(320, this.height - WIN_PAD * 2);
            if (this.width >= 540) winW = Math.min(520, this.width - WIN_PAD * 2);
            if (this.height >= 360) winH = Math.min(340, this.height - WIN_PAD * 2);
        } else {
            winW = Math.min(420, this.width - WIN_PAD * 2);
            winH = Math.min(280, this.height - WIN_PAD * 2);
            if (this.width >= 480) winW = Math.min(460, this.width - WIN_PAD * 2);
            if (this.height >= 320) winH = Math.min(300, this.height - WIN_PAD * 2);
        }
        winX = (this.width - winW) / 2;
        winY = (this.height - winH) / 2;

        int titleH = v2 ? TITLE_H_V2 : TITLE_H;
        // Groups live in the sidebar — no horizontal tab strip
        int bodyTop = winY + titleH + 2;
        int bodyBottom = winY + winH - FOOTER_H - 4;
        int bodyH = Math.max(40, bodyBottom - bodyTop);

        int sideW = v2 ? SIDEBAR_W_V2 : SIDEBAR_W;
        sidebarX = winX + INNER;
        sidebarY = bodyTop;
        sidebarH = bodyH;

        contentX = sidebarX + sideW + 6;
        contentY = bodyTop;
        contentW = winX + winW - INNER - contentX;
        contentH = bodyH;

        int headerH = 20;
        listX = contentX + 4;
        listY = contentY + headerH;
        listW = contentW - 8;
        listH = Math.max(20, contentH - headerH - 4);
        if (searchBox != null) {
            int sbW = Math.min(140, Math.max(70, contentW - (v2 ? 36 : 14)));
            searchBox.setX(contentX + 6);
            searchBox.setY(contentY + 4);
            searchBox.setWidth(sbW);
        }

        footerBtnH = 22;
        footerBtnW = 92;
        footerY = winY + winH - FOOTER_H + 5;
        int gap = 6;
        saveX = winX + winW - INNER - footerBtnW;
        cancelX = saveX - gap - 64;
        resetX = winX + INNER;

        // Compact style switch just under the window's bottom-left (avoids overlap with the panel)
        styleBtnH = 12;
        styleBtnW = 78;
        styleBtnX = Math.max(4, winX);
        styleBtnY = winY + winH + 3;
        if (styleBtnY + styleBtnH > this.height - 2) {
            styleBtnY = this.height - styleBtnH - 2;
            styleBtnX = 4;
        }
    }

    private int sidebarNavTop() {
        return CrimsonTheme.isVampV2() ? sidebarY + SIDEBAR_HERO_V2 : sidebarY + 4;
    }

    private int sidebarRowH() {
        return CrimsonTheme.isVampV2() ? SIDEBAR_ROW_V2 : SIDEBAR_ROW;
    }

    private int sidebarNavBottom() {
        if (!CrimsonTheme.isVampV2()) return sidebarY + sidebarH;
        return sidebarY + sidebarH - CASTLE_RESERVE_V2;
    }

    private static String modVersionLabel() {
        try {
            return net.fabricmc.loader.api.FabricLoader.getInstance()
                    .getModContainer(VampyMod.MOD_ID)
                    .map(c -> "v" + c.getMetadata().getVersion().getFriendlyString())
                    .orElse("");
        } catch (Throwable t) {
            return "";
        }
    }

    private ConfigCatalog.Tab currentTab() {
        if (tabs.isEmpty() || tabIndex < 0 || tabIndex >= tabs.size()) return null;
        return tabs.get(tabIndex);
    }

    /** Flatten every category in the selected group (or across all groups when searching) into one scrollable list. */
    private void rebuildLayout() {
        layout.clear();
        String q = searchQuery == null ? "" : searchQuery.trim().toLowerCase(Locale.ROOT);
        if (!q.isEmpty()) {
            for (ConfigCatalog.Tab t : tabs) {
                for (ConfigCatalog.Category cat : t.categories()) {
                    List<ConfigEntry> matched = new ArrayList<>();
                    for (ConfigEntry entry : cat.entries()) {
                        if (entry.kind == ConfigEntry.Kind.SECTION) continue;
                        String eName = entry.name != null ? entry.name.getString().toLowerCase(Locale.ROOT) : "";
                        boolean selfMatch = eName.contains(q) || (entry.id != null && entry.id.toLowerCase(Locale.ROOT).contains(q));
                        boolean childMatch = false;
                        if (entry.kind == ConfigEntry.Kind.SUBGROUP && entry.childEntries != null) {
                            for (ConfigEntry child : entry.childEntries) {
                                String cName = child.name != null ? child.name.getString().toLowerCase(Locale.ROOT) : "";
                                if (cName.contains(q) || (child.id != null && child.id.toLowerCase(Locale.ROOT).contains(q))) {
                                    childMatch = true;
                                    break;
                                }
                            }
                        }
                        if (selfMatch || childMatch) {
                            matched.add(entry);
                        }
                    }
                    if (!matched.isEmpty()) {
                        Component secName = Component.literal("▾ " + t.name().getString() + " — " + cat.name().getString());
                        layout.add(new LayoutRow(ConfigEntry.section("sec_" + cat.id(), secName), SECTION_H, false));
                        for (ConfigEntry entry : matched) {
                            int h = entry.kind == ConfigEntry.Kind.STRING_LIST ? listRowHeight(entry) : ROW_H;
                            layout.add(new LayoutRow(entry, h, false));
                            if (entry.kind == ConfigEntry.Kind.SUBGROUP && entry.childEntries != null) {
                                for (ConfigEntry child : entry.childEntries) {
                                    int ch = child.kind == ConfigEntry.Kind.STRING_LIST ? listRowHeight(child) : ROW_H;
                                    layout.add(new LayoutRow(child, ch, true));
                                }
                            }
                        }
                    }
                }
            }
            clampScroll();
            return;
        }

        ConfigCatalog.Tab tab = currentTab();
        if (tab == null) return;
        List<ConfigCatalog.Category> cats = tab.categories();
        for (ConfigCatalog.Category cat : cats) {
            boolean expanded = !collapsedCategories.contains(cat.id());
            Component secName = Component.literal((expanded ? "▾ " : "▸ ") + cat.name().getString());
            // Section titles (e.g. ESP / Warnings / Player) — same chrome as Utility's "Warnings"
            layout.add(new LayoutRow(ConfigEntry.section("sec_" + cat.id(), secName), SECTION_H, false));
            if (!expanded) continue;
            for (ConfigEntry entry : cat.entries()) {
                if (entry.kind == ConfigEntry.Kind.SECTION) {
                    layout.add(new LayoutRow(entry, SECTION_H, false));
                    continue;
                }
                int h = entry.kind == ConfigEntry.Kind.STRING_LIST ? listRowHeight(entry) : ROW_H;
                layout.add(new LayoutRow(entry, h, false));
                if (entry.kind == ConfigEntry.Kind.SUBGROUP && expandedSubgroups.contains(entry.id) && entry.childEntries != null) {
                    for (ConfigEntry child : entry.childEntries) {
                        int ch = child.kind == ConfigEntry.Kind.STRING_LIST ? listRowHeight(child) : ROW_H;
                        layout.add(new LayoutRow(child, ch, true));
                    }
                }
            }
        }
        clampScroll();
    }

    private static CrimsonIcons.Id iconForGroup(String tabId) {
        return switch (tabId) {
            case "esp" -> CrimsonIcons.Id.EYE;
            case "qol" -> CrimsonIcons.Id.HEART;
            case "party" -> CrimsonIcons.Id.SPEAKER;
            default -> CrimsonIcons.Id.GEAR; // utility
        };
    }

    private int listRowHeight(ConfigEntry entry) {
        int n = entry.listGet != null ? entry.listGet.get().size() : 0;
        return ROW_H + Math.max(1, n) * 14 + 18;
    }

    private void clampScroll() {
        int total = 0;
        for (LayoutRow row : layout) total += row.height + GAP;
        double max = Math.max(0, total - listH);
        if (scroll < 0) scroll = 0;
        if (scroll > max) scroll = max;
    }

    private String selectedEntryId() {
        if (selectedRow >= 0 && selectedRow < layout.size()) {
            return layout.get(selectedRow).entry.id;
        }
        return "";
    }

    private int findRowById(String id) {
        if (id == null || id.isEmpty()) return -1;
        for (int i = 0; i < layout.size(); i++) {
            if (layout.get(i).entry.id.equals(id)) return i;
        }
        return -1;
    }

    private void clearEditState() {
        draggingSlider = false;
        draggingSv = false;
        draggingHue = false;
        colorPickerOpen = false;
        editingListItem = false;
        listEditIndex = -1;
        if (editBox != null) {
            removeWidget(editBox);
            editBox = null;
        }
        if (hexBox != null) {
            removeWidget(hexBox);
            hexBox = null;
        }
    }

    private void layoutColorPicker() {
        cpW = 220;
        cpH = 168;
        cpX = this.width / 2 - cpW / 2;
        cpY = this.height / 2 - cpH / 2;
        svSize = 96;
        svX = cpX + 10;
        svY = cpY + 28;
        hueX = svX + svSize + 8;
        hueY = svY;
        hueW = 12;
        hueH = svSize;
        previewX = hueX + hueW + 10;
        previewY = svY;
        presetX = previewX;
        presetY = svY + 40;
        pickBtnY = cpY + cpH - 24;
        cancelPickX = cpX + cpW - 100;
        okX = cpX + cpW - 50;
    }

    @Override
    public void extractBackground(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float a) {
        CrimsonTheme.sync();
        if (this.minecraft != null && this.minecraft.level != null) {
            this.extractBlurredBackground(graphics);
        }
        CrimsonTheme.paintScreenBackground(graphics, this.width, this.height);
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float partialTick) {
        CrimsonTheme.sync();
        layoutPanels();
        CrimsonTheme.paintOrnateWindow(graphics, winX, winY, winW, winH);

        // Vamp v1 / Simplified: centered title; Vamp v2: brand lives in the left column
        if (!CrimsonTheme.isVampV2()) {
            int titleCx = winX + winW / 2;
            if (CrimsonTheme.showIcons()) {
                CrimsonIcons.draw(graphics, CrimsonIcons.Id.BLEEDING_EYE,
                        titleCx - CrimsonIcons.BLEEDING_EYE_W / 2, winY + 2, CrimsonTheme.ACCENT_BRIGHT);
                graphics.centeredText(this.font, Component.literal(VampyMod.MOD_NAME).withStyle(CrimsonTheme.accentStyle()),
                        titleCx, winY + 2 + CrimsonIcons.BLEEDING_EYE_H + 1, CrimsonTheme.TEXT_ACCENT);
            } else {
                graphics.centeredText(this.font, Component.literal(VampyMod.MOD_NAME).withStyle(CrimsonTheme.accentStyle()),
                        titleCx, winY + 12, CrimsonTheme.TEXT_ACCENT);
            }
        }

        drawSidebar(graphics, mouseX, mouseY);
        drawContentPanel(graphics, mouseX, mouseY);
        drawFooter(graphics, mouseX, mouseY);
        drawStyleToggle(graphics, mouseX, mouseY);
        drawCrosshairPreview(graphics, mouseX, mouseY);

        if (colorPickerOpen) {
            layoutColorPicker();
            drawColorPicker(graphics, mouseX, mouseY);
        }

        super.extractRenderState(graphics, mouseX, mouseY, partialTick);
    }

    private void drawSidebar(GuiGraphicsExtractor graphics, int mouseX, int mouseY) {
        int sideW = CrimsonTheme.isVampV2() ? SIDEBAR_W_V2 : SIDEBAR_W;
        graphics.fill(sidebarX, sidebarY, sidebarX + sideW, sidebarY + sidebarH, CrimsonTheme.SIDEBAR);
        graphics.outline(sidebarX, sidebarY, sideW, sidebarH, CrimsonTheme.PANEL_BORDER);

        if (CrimsonTheme.isVampV2()) {
            drawSidebarHeroV2(graphics, sideW);
        }

        // Groups (ESP / Utility / QoL) — click shows that group's full settings on the right
        int rowH = sidebarRowH();
        int y = sidebarNavTop();
        int navBottom = sidebarNavBottom();
        for (int i = 0; i < tabs.size(); i++) {
            ConfigCatalog.Tab group = tabs.get(i);
            int ry = y;
            y += rowH + (CrimsonTheme.isVampV2() ? 2 : 3);
            if (ry + rowH > navBottom) break;
            boolean selected = i == tabIndex;
            boolean hover = mouseX >= sidebarX + 2 && mouseX < sidebarX + sideW - 2
                    && mouseY >= ry && mouseY < ry + rowH;
            CrimsonTheme.paintSidebarButton(graphics, sidebarX + 2, ry, sideW - 4, rowH, hover, selected);
            boolean icons = CrimsonTheme.showIcons();
            int icon = CrimsonIcons.SIZE;
            if (icons) {
                CrimsonIcons.draw(graphics, iconForGroup(group.id()), sidebarX + 6, ry + (rowH - icon) / 2,
                        selected ? CrimsonTheme.ACCENT_BRIGHT : CrimsonTheme.TEXT_DIM);
            }
            int textX = icons ? sidebarX + 8 + icon : sidebarX + 8;
            int maxLabelW = sideW - (icons ? 14 + icon : 16);
            String label = group.name().getString();
            if (this.font.width(label) > maxLabelW) {
                while (label.length() > 3 && this.font.width(label + "…") > maxLabelW) {
                    label = label.substring(0, label.length() - 1);
                }
                label = label + "…";
            }
            graphics.text(this.font, Component.literal(label),
                    textX, ry + (rowH - 8) / 2,
                    selected ? CrimsonTheme.TEXT : CrimsonTheme.TEXT_DIM, false);
        }
    }

    /** Brand + large bleeding eye at the top of the Vamp v2 left column. */
    private void drawSidebarHeroV2(GuiGraphicsExtractor graphics, int sideW) {
        // Vamp v2 brand marks use ✝ (not +); Vamp v1 / Simple keep plain MOD_NAME elsewhere.
        // Brand + hero eye stay vivid crimson (user requested); rest of Vamp v2 chrome is stone/purple.
        String brand = "\u271D" + VampyMod.MOD_NAME.toUpperCase(Locale.ROOT) + "\u271D";
        int brandRed = CrimsonTheme.BLOOD_DROP_HIGHLIGHT;
        graphics.centeredText(this.font, Component.literal(brand),
                sidebarX + sideW / 2, sidebarY + 4, brandRed);
        graphics.centeredText(this.font, Component.literal("CONFIGURATION"),
                sidebarX + sideW / 2, sidebarY + 14, CrimsonTheme.TEXT_DIM);
        String ver = modVersionLabel();
        if (!ver.isEmpty()) {
            graphics.centeredText(this.font, Component.literal(ver),
                    sidebarX + sideW / 2, sidebarY + 23, CrimsonTheme.TEXT_DIM);
        }
        // Inset from sidebar edges so the larger eye never kisses the outline / tab strip / nav.
        int eyeX = sidebarX + (sideW - CrimsonIcons.LARGE_EYE_W) / 2;
        int eyeY = sidebarY + 33;
        CrimsonIcons.drawLargeBleedingEye(graphics, eyeX, eyeY); // stays BLOOD_DROP red
        // Soft separator under the hero before nav rows
        int sepY = sidebarY + SIDEBAR_HERO_V2 - 4;
        graphics.fill(sidebarX + 10, sepY, sidebarX + sideW - 10, sepY + 1, CrimsonTheme.FRAME_DIM);
        graphics.fill(sidebarX + sideW / 2 - 3, sepY - 1, sidebarX + sideW / 2 + 3, sepY + 2, CrimsonTheme.FRAME);
    }

    private void drawContentPanel(GuiGraphicsExtractor graphics, int mouseX, int mouseY) {
        CrimsonTheme.paintPanel(graphics, contentX, contentY, contentW, contentH);
        ConfigCatalog.Tab group = currentTab();
        if (group == null) {
            graphics.text(this.font, Component.literal("No options"), contentX + 8, contentY + 12,
                    CrimsonTheme.TEXT_DIM, false);
            return;
        }

        if (CrimsonTheme.isVampV2()) {
            CrimsonIcons.drawCornerDripEye(graphics,
                    contentX + contentW - CrimsonIcons.CORNER_EYE_W - 4, contentY + 3);
        }

        graphics.enableScissor(listX, listY, listX + listW, listY + listH);
        drawOptionList(graphics, mouseX, mouseY);
        graphics.disableScissor();
    }

    private void drawOptionList(GuiGraphicsExtractor graphics, int mouseX, int mouseY) {
        int y = listY - (int) scroll;
        for (int i = 0; i < layout.size(); i++) {
            LayoutRow row = layout.get(i);
            int ry = y;
            y += row.height + GAP;
            if (ry + row.height < listY || ry > listY + listH) continue;

            if (row.entry.kind == ConfigEntry.Kind.SECTION) {
                graphics.text(this.font, row.entry.name.copy().withStyle(CrimsonTheme.accentStyle()),
                        listX + 4, ry + 5, CrimsonTheme.TEXT_ACCENT, false);
                int lineY = ry + row.height - 2;
                graphics.fill(listX + 4, lineY, listX + listW - 4, lineY + 1, CrimsonTheme.ACCENT_DIM);
                if (CrimsonTheme.isVampV2()) {
                    graphics.fill(listX + 4, lineY, listX + 16, lineY + 1, CrimsonTheme.FLOURISH);
                }
                continue;
            }

            int rowX = row.indented ? listX + 10 : listX;
            int rowW = row.indented ? listW - 10 : listW;

            boolean hovered = !colorPickerOpen
                    && mouseX >= rowX && mouseX < rowX + rowW
                    && mouseY >= Math.max(listY, ry) && mouseY < Math.min(listY + listH, ry + row.height);
            boolean selected = i == selectedRow;

            if (row.indented) {
                graphics.fill(listX + 4, ry, listX + 6, ry + row.height, CrimsonTheme.ACCENT_DIM);
            }
            CrimsonTheme.paintRow(graphics, rowX, ry, rowW, row.height, hovered, selected);
            graphics.text(this.font, row.entry.name, rowX + 6, ry + 6, CrimsonTheme.TEXT, false);
            drawControl(graphics, row.entry, rowX, ry, rowW, row.height, hovered);
        }
    }

    private void drawControl(GuiGraphicsExtractor graphics, ConfigEntry entry,
                             int x, int y, int w, int h, boolean hovered) {
        switch (entry.kind) {
            case TOGGLE -> {
                boolean on = entry.boolGet.getAsBoolean();
                int tw = 28, th = 12;
                int tx = x + w - tw - 8;
                int ty = y + (ROW_H - th) / 2;
                graphics.fill(tx, ty, tx + tw, ty + th, on ? CrimsonTheme.TOGGLE_ON : CrimsonTheme.TOGGLE_OFF);
                graphics.outline(tx, ty, tw, th, CrimsonTheme.ROW_BORDER);
                int knob = on ? tx + tw - 10 : tx + 2;
                // Dark knob on light (Simplified ON) track for contrast
                int knobColor = on && CrimsonTheme.isSimplified() ? 0xFF1A1A1A : CrimsonTheme.TEXT;
                graphics.fill(knob, ty + 2, knob + 8, ty + th - 2, knobColor);
            }
            case SLIDER -> {
                double v = entry.doubleGet.getAsDouble();
                double t = (v - entry.min) / (entry.max - entry.min);
                int sw = 70;
                int sx = x + w - sw - 8;
                int sy = y + ROW_H / 2;
                graphics.fill(sx, sy - 1, sx + sw, sy + 1, CrimsonTheme.ROW_BORDER);
                int kx = sx + (int) (t * (sw - 6));
                graphics.fill(kx, sy - 4, kx + 6, sy + 4, CrimsonTheme.ACCENT);
                Component label = entry.format != null ? entry.format.apply(v)
                        : Component.literal(String.format(Locale.ROOT, "%.2f", v));
                graphics.text(this.font, label, sx - 4 - this.font.width(label), y + 6, CrimsonTheme.TEXT_DIM, false);
            }
            case CYCLE -> {
                int idx = entry.cycleIndexGet.get();
                Component label = entry.cycleLabels[Math.max(0, Math.min(idx, entry.cycleLabels.length - 1))];
                int lw = this.font.width(label);
                graphics.text(this.font, label, x + w - lw - 10, y + 6, CrimsonTheme.TEXT_ACCENT, false);
            }
            case COLOR -> {
                int c = entry.colorGet.getAsInt() | 0xFF000000;
                int sx = x + w - 48;
                int sy = y + 4;
                graphics.fill(sx, sy, sx + 14, sy + 14, c);
                graphics.outline(sx, sy, 14, 14, CrimsonTheme.ROW_BORDER_HOVER);
                String hex = CrimsonTheme.toHex(c);
                graphics.text(this.font, Component.literal(hex), sx - 4 - this.font.width(hex), y + 6,
                        CrimsonTheme.TEXT_DIM, false);
            }
            case STRING -> {
                String val = entry.stringGet.get();
                if (val == null) val = "";
                String shown = val.length() > 18 ? val.substring(0, 18) + "…" : val;
                int lw = this.font.width(shown);
                graphics.text(this.font, Component.literal(shown), x + w - lw - 10, y + 6, CrimsonTheme.TEXT_DIM, false);
            }
            case WARNING_LINE -> {
                String text = entry.warningTextGet.get();
                if (text == null) text = "";
                String shown = text.length() > 12 ? text.substring(0, 12) + "…" : text;
                int c = entry.warningColorGet.getAsInt() | 0xFF000000;
                int sx = x + w - 22;
                graphics.fill(sx, y + 4, sx + 14, y + 18, c);
                graphics.outline(sx, y + 4, 14, 14, CrimsonTheme.ROW_BORDER_HOVER);
                String hex = CrimsonTheme.toHex(c);
                int lw = this.font.width(shown);
                graphics.text(this.font, Component.literal(shown), sx - 6 - lw, y + 6, CrimsonTheme.TEXT_DIM, false);
                graphics.text(this.font, Component.literal(hex),
                        sx - 8 - lw - this.font.width(hex) - 4, y + 6, CrimsonTheme.TEXT_DIM, false);
            }
            case ACTION -> {
                Component label = entry.actionLabel != null ? entry.actionLabel : Component.literal("Open");
                int bw = Math.min(90, this.font.width(label) + 12);
                int bx = x + w - bw - 6;
                int by = y + 3;
                CrimsonTheme.paintButton(graphics, bx, by, bw, 16, hovered);
                graphics.centeredText(this.font, label, bx + bw / 2, by + 4, CrimsonTheme.TEXT);
            }
            case SUBGROUP -> {
                boolean open = expandedSubgroups.contains(entry.id);
                Component label = Component.literal(open ? "Hide" : "Click!");
                int bw = Math.min(90, Math.max(40, this.font.width(label) + 12));
                int bx = x + w - bw - 6;
                int by = y + 3;
                CrimsonTheme.paintButton(graphics, bx, by, bw, 16, hovered);
                graphics.centeredText(this.font, label, bx + bw / 2, by + 4,
                        open ? CrimsonTheme.TEXT_ACCENT : CrimsonTheme.TEXT);
            }
            case STRING_LIST -> drawStringListControl(graphics, entry, x, y, w);
            default -> {
            }
        }
    }

    private void drawStringListControl(GuiGraphicsExtractor graphics, ConfigEntry entry, int x, int y, int w) {
        List<String> items = entry.listGet.get();
        int iy = y + ROW_H;
        graphics.text(this.font, Component.literal("(" + items.size() + ")"),
                x + w - 30, y + 6, CrimsonTheme.TEXT_DIM, false);
        for (int i = 0; i < items.size(); i++) {
            String s = items.get(i);
            String shown = s.length() > 28 ? s.substring(0, 28) + "…" : s;
            graphics.text(this.font, Component.literal("• " + shown), x + 10, iy, CrimsonTheme.TEXT_DIM, false);
            graphics.text(this.font, Component.literal("✕"), x + w - 16, iy, CrimsonTheme.ACCENT, false);
            iy += 14;
        }
        graphics.text(this.font, Component.literal("+ Add pattern"), x + 10, iy + 2, CrimsonTheme.TEXT_ACCENT, false);
    }

    private void drawFooter(GuiGraphicsExtractor graphics, int mouseX, int mouseY) {
        boolean icons = CrimsonTheme.showIcons();

        // Reset to Defaults
        int resetW = 124;
        boolean resetHover = mouseX >= resetX && mouseX < resetX + resetW && mouseY >= footerY && mouseY < footerY + footerBtnH;
        CrimsonTheme.paintButton(graphics, resetX, footerY, resetW, footerBtnH, resetHover);
        if (icons) {
            int icon = CrimsonIcons.SIZE;
            int iconY = footerY + (footerBtnH - icon) / 2;
            int textY = footerY + (footerBtnH - 8) / 2;
            CrimsonIcons.draw(graphics, CrimsonIcons.Id.RESET, resetX + 5, iconY, CrimsonTheme.TEXT_DIM);
            graphics.text(this.font, Component.literal("Reset Defaults"),
                    resetX + 8 + icon, textY, CrimsonTheme.TEXT, false);
        } else {
            graphics.centeredText(this.font, Component.literal("Reset Defaults"),
                    resetX + resetW / 2, footerY + (footerBtnH - 8) / 2, CrimsonTheme.TEXT);
        }

        // Cancel
        int cancelW = 64;
        boolean cancelHover = mouseX >= cancelX && mouseX < cancelX + cancelW && mouseY >= footerY && mouseY < footerY + footerBtnH;
        CrimsonTheme.paintButton(graphics, cancelX, footerY, cancelW, footerBtnH, cancelHover);
        graphics.centeredText(this.font, Component.literal("Cancel"), cancelX + cancelW / 2, footerY + 5, CrimsonTheme.TEXT);

        // Save Changes — Vamp: maroon + blood drop; Simplified: gray, text only
        boolean saveHover = mouseX >= saveX && mouseX < saveX + footerBtnW && mouseY >= footerY && mouseY < footerY + footerBtnH;
        CrimsonTheme.paintSaveButton(graphics, saveX, footerY, footerBtnW, footerBtnH, saveHover);
        String saveLabel = "Save Changes";
        if (icons) {
            int iconW = 7;
            int iconGap = 4;
            int clusterW = iconW + iconGap + this.font.width(saveLabel);
            int clusterX = saveX + (footerBtnW - clusterW) / 2;
            int clusterY = footerY + (footerBtnH - 8) / 2;
            CrimsonIcons.drawBloodDrop(graphics, clusterX, clusterY);
            graphics.text(this.font, Component.literal(saveLabel),
                    clusterX + iconW + iconGap, clusterY, CrimsonTheme.SAVE_TEXT, false);
        } else {
            graphics.centeredText(this.font, Component.literal(saveLabel),
                    saveX + footerBtnW / 2, footerY + 5, CrimsonTheme.SAVE_TEXT);
        }
    }

    /** Bottom-left screen toggle: Vamp → Vamp v2 → Simple. */
    private void drawStyleToggle(GuiGraphicsExtractor graphics, int mouseX, int mouseY) {
        if (VampyConfig.isSimpleOnlyBuild()) return;
        boolean hover = mouseX >= styleBtnX && mouseX < styleBtnX + styleBtnW
                && mouseY >= styleBtnY && mouseY < styleBtnY + styleBtnH;
        CrimsonTheme.paintButton(graphics, styleBtnX, styleBtnY, styleBtnW, styleBtnH, hover);
        String label = switch (VampyConfig.getGuiStyle()) {
            case SIMPLIFIED -> "Style: Simple";
            case VAMP -> "Style: Vamp";
        };
        graphics.centeredText(this.font, Component.literal(label),
                styleBtnX + styleBtnW / 2, styleBtnY + 2,
                hover ? CrimsonTheme.TEXT : CrimsonTheme.TEXT_DIM);
    }

    /** True for Crosshair Style / Size / Color / Chroma (and related) option rows. */
    private static boolean isCrosshairOptionRow(String id) {
        if (id == null) return false;
        return id.startsWith("crosshair_")
                || "custom_crosshair".equals(id)
                || "tp_crosshair".equals(id);
    }

    /**
     * Live crosshair overlay — only while hovering a Crosshair option row,
     * or while dragging Crosshair Size.
     */
    private void drawCrosshairPreview(GuiGraphicsExtractor graphics, int mouseX, int mouseY) {
        if (colorPickerOpen) return;
        ConfigCatalog.Tab group = currentTab();
        if (group == null || !"qol".equals(group.id())) return;

        boolean sizeFocus = draggingSlider && selectedEntry() != null
                && "crosshair_scale".equals(selectedEntry().id);
        boolean hoverCrosshair = sizeFocus;
        if (!hoverCrosshair) {
            int y = listY - (int) scroll;
            for (LayoutRow row : layout) {
                int ry = y;
                y += row.height + GAP;
                if (!isCrosshairOptionRow(row.entry.id)) continue;
                if (mouseX >= listX && mouseX < listX + listW
                        && mouseY >= Math.max(listY, ry)
                        && mouseY < Math.min(listY + listH, ry + row.height)) {
                    hoverCrosshair = true;
                    if ("crosshair_scale".equals(row.entry.id)) sizeFocus = true;
                    break;
                }
            }
        }
        if (!hoverCrosshair) return;

        int cx = this.width / 2;
        int cy = Math.max(24, winY - 18);
        if (cy < 16) cy = 16;

        int pad = (int) Math.ceil(14 * VampyConfig.getCrosshairScale()) + 6;
        graphics.fill(cx - pad, cy - pad, cx + pad, cy + pad, 0x66000000);
        graphics.outline(cx - pad, cy - pad, pad * 2, pad * 2, CrimsonTheme.ACCENT_DIM);

        CustomCrosshairRenderer.renderAt(graphics, cx, cy);

        String label = sizeFocus
                ? String.format(Locale.ROOT, "Preview  %.2fx", VampyConfig.getCrosshairScale())
                : "Preview";
        graphics.centeredText(this.font, Component.literal(label), cx, cy + pad + 4, CrimsonTheme.TEXT_DIM);
    }

    private void drawColorPicker(GuiGraphicsExtractor graphics, int mouseX, int mouseY) {
        graphics.fill(0, 0, this.width, this.height, 0x99000000);
        CrimsonTheme.paintOrnateWindow(graphics, cpX, cpY, cpW, cpH);
        graphics.text(this.font, Component.literal("Color").withStyle(CrimsonTheme.accentStyle()),
                cpX + 10, cpY + 8, CrimsonTheme.TEXT_ACCENT, false);

        // SV square
        int hueRgb = CrimsonColorMath.hueToRgb(pickerH);
        int hr = (hueRgb >> 16) & 0xFF, hg = (hueRgb >> 8) & 0xFF, hb = hueRgb & 0xFF;
        for (int py = 0; py < svSize; py++) {
            float v = 1f - py / (float) (svSize - 1);
            for (int px = 0; px < svSize; px += 2) {
                float s = px / (float) (svSize - 1);
                // blend: white -> hue by S, then * V
                int r = Math.round((hr + (255 - hr) * (1f - s)) * v);
                int g = Math.round((hg + (255 - hg) * (1f - s)) * v);
                int b = Math.round((hb + (255 - hb) * (1f - s)) * v);
                int argb = 0xFF000000 | (r << 16) | (g << 8) | b;
                int w = Math.min(2, svSize - px);
                graphics.fill(svX + px, svY + py, svX + px + w, svY + py + 1, argb);
            }
        }
        graphics.outline(svX - 1, svY - 1, svSize + 2, svSize + 2, CrimsonTheme.ROW_BORDER_HOVER);
        int cx = svX + Math.round(pickerS * (svSize - 1));
        int cy = svY + Math.round((1f - pickerV) * (svSize - 1));
        graphics.outline(cx - 2, cy - 2, 5, 5, 0xFFFFFFFF);
        graphics.outline(cx - 1, cy - 1, 3, 3, 0xFF000000);

        // Hue strip
        for (int i = 0; i < hueH; i++) {
            float h = (i / (float) (hueH - 1)) * 360f;
            graphics.fill(hueX, hueY + i, hueX + hueW, hueY + i + 1, CrimsonColorMath.hueToRgb(h));
        }
        graphics.outline(hueX - 1, hueY - 1, hueW + 2, hueH + 2, CrimsonTheme.ROW_BORDER_HOVER);
        int hy = hueY + Math.round((pickerH / 360f) * (hueH - 1));
        graphics.fill(hueX - 2, hy - 1, hueX + hueW + 2, hy + 2, 0xFFFFFFFF);

        // Preview
        int live = currentPickerArgb();
        graphics.fill(previewX, previewY, previewX + 36, previewY + 28, live);
        graphics.outline(previewX, previewY, 36, 28, CrimsonTheme.ROW_BORDER_HOVER);
        graphics.fill(previewX, previewY + 30, previewX + 18, previewY + 42, pickerOrigArgb | 0xFF000000);
        graphics.fill(previewX + 18, previewY + 30, previewX + 36, previewY + 42, live);
        graphics.outline(previewX, previewY + 30, 36, 12, CrimsonTheme.ROW_BORDER);

        // RGB readouts
        int r = (live >> 16) & 0xFF, g = (live >> 8) & 0xFF, b = live & 0xFF;
        int rx = previewX;
        int ry = previewY + 48;
        graphics.text(this.font, Component.literal("R " + r), rx, ry, 0xFFFF8888, false);
        graphics.text(this.font, Component.literal("G " + g), rx, ry + 10, 0xFF88FF88, false);
        graphics.text(this.font, Component.literal("B " + b), rx, ry + 20, 0xFF8888FF, false);

        // Presets
        graphics.text(this.font, Component.literal("Presets"), presetX, presetY + 40, CrimsonTheme.TEXT_DIM, false);
        for (int i = 0; i < CrimsonColorMath.PRESETS.length; i++) {
            int px = presetX + (i % 4) * 12;
            int py = presetY + 52 + (i / 4) * 12;
            graphics.fill(px, py, px + 10, py + 10, CrimsonColorMath.PRESETS[i]);
            graphics.outline(px, py, 10, 10, CrimsonTheme.ROW_BORDER);
        }

        // Hex label (EditBox drawn by widget system)
        graphics.text(this.font, Component.literal("Hex"), svX, svY + svSize + 8, CrimsonTheme.TEXT_DIM, false);

        boolean okHover = mouseX >= okX && mouseX < okX + 42 && mouseY >= pickBtnY && mouseY < pickBtnY + 16;
        boolean cancelHover = mouseX >= cancelPickX && mouseX < cancelPickX + 42 && mouseY >= pickBtnY && mouseY < pickBtnY + 16;
        CrimsonTheme.paintButton(graphics, cancelPickX, pickBtnY, 42, 16, cancelHover);
        graphics.centeredText(this.font, Component.literal("Cancel"), cancelPickX + 21, pickBtnY + 4, CrimsonTheme.TEXT);
        CrimsonTheme.paintPrimaryButton(graphics, okX, pickBtnY, 42, 16, okHover);
        graphics.centeredText(this.font, Component.literal("OK"), okX + 21, pickBtnY + 4, CrimsonTheme.TEXT);
    }

    private int currentPickerArgb() {
        return CrimsonColorMath.hsvToRgb(pickerH, pickerS, pickerV);
    }

    private ConfigEntry selectedEntry() {
        if (selectedRow < 0 || selectedRow >= layout.size()) return null;
        return layout.get(selectedRow).entry;
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean repeat) {
        double mx = event.x();
        double my = event.y();

        if (colorPickerOpen) {
            return handleColorPickerClick(event, repeat);
        }

        // Bottom-left style toggle (outside main window)
        if (!VampyConfig.isSimpleOnlyBuild()
                && mx >= styleBtnX && mx < styleBtnX + styleBtnW
                && my >= styleBtnY && my < styleBtnY + styleBtnH) {
            VampyConfig.cycleGuiStyle();
            CrimsonTheme.sync();
            layoutPanels();
            rebuildLayout();
            return true;
        }

        // Sidebar groups (ESP / Utility / QoL)
        int sideW = CrimsonTheme.isVampV2() ? SIDEBAR_W_V2 : SIDEBAR_W;
        int rowH = sidebarRowH();
        int navBottom = sidebarNavBottom();
        if (mx >= sidebarX && mx < sidebarX + sideW
                && my >= sidebarNavTop() && my < navBottom) {
            int sy = sidebarNavTop();
            for (int i = 0; i < tabs.size(); i++) {
                if (my >= sy && my < sy + rowH) {
                    if (i != tabIndex) {
                        tabIndex = i;
                        selectedRow = -1;
                        scroll = 0;
                        clearEditState();
                        rebuildLayout();
                    }
                    return true;
                }
                sy += rowH + (CrimsonTheme.isVampV2() ? 2 : 3);
            }
        }

        // Footer
        if (my >= footerY && my < footerY + footerBtnH) {
            int resetW = 124;
            if (mx >= resetX && mx < resetX + resetW) {
                resetCurrentGroup();
                return true;
            }
            int cancelW = 64;
            if (mx >= cancelX && mx < cancelX + cancelW) {
                discardOnClose = true;
                VampyConfig.restoreUndoSnapshot(undoSnapshot);
                this.minecraft.setScreenAndShow(parent);
                return true;
            }
            if (mx >= saveX && mx < saveX + footerBtnW) {
                discardOnClose = false;
                onClose();
                return true;
            }
        }

        // List
        if (mx >= listX && mx < listX + listW && my >= listY && my < listY + listH) {
            return handleListClick(mx, my, event.button());
        }

        if (editBox != null && editBox.mouseClicked(event, repeat)) {
            return true;
        }
        return super.mouseClicked(event, repeat);
    }

    private boolean handleColorPickerClick(MouseButtonEvent event, boolean repeat) {
        double mx = event.x();
        double my = event.y();
        // OK
        if (mx >= okX && mx < okX + 42 && my >= pickBtnY && my < pickBtnY + 16) {
            applyColorPicker();
            closeColorPicker(false);
            return true;
        }
        // Cancel
        if (mx >= cancelPickX && mx < cancelPickX + 42 && my >= pickBtnY && my < pickBtnY + 16) {
            closeColorPicker(true);
            return true;
        }
        // SV
        if (mx >= svX && mx < svX + svSize && my >= svY && my < svY + svSize) {
            draggingSv = true;
            updateSvFromMouse(mx, my);
            return true;
        }
        // Hue
        if (mx >= hueX && mx < hueX + hueW && my >= hueY && my < hueY + hueH) {
            draggingHue = true;
            updateHueFromMouse(my);
            return true;
        }
        // Presets
        for (int i = 0; i < CrimsonColorMath.PRESETS.length; i++) {
            int px = presetX + (i % 4) * 12;
            int py = presetY + 52 + (i / 4) * 12;
            if (mx >= px && mx < px + 10 && my >= py && my < py + 10) {
                setPickerFromArgb(CrimsonColorMath.PRESETS[i]);
                syncHexBox();
                return true;
            }
        }
        if (hexBox != null && hexBox.mouseClicked(event, repeat)) {
            return true;
        }
        // Click outside → cancel
        if (mx < cpX || mx > cpX + cpW || my < cpY || my > cpY + cpH) {
            closeColorPicker(true);
            return true;
        }
        return true;
    }

    private void updateSvFromMouse(double mx, double my) {
        pickerS = (float) clamp01((mx - svX) / (double) (svSize - 1));
        pickerV = (float) clamp01(1.0 - (my - svY) / (double) (svSize - 1));
        syncHexBox();
    }

    private void updateHueFromMouse(double my) {
        pickerH = (float) clamp01((my - hueY) / (double) (hueH - 1)) * 360f;
        syncHexBox();
    }

    private void setPickerFromArgb(int argb) {
        int r = (argb >> 16) & 0xFF;
        int g = (argb >> 8) & 0xFF;
        int b = argb & 0xFF;
        float[] hsv = CrimsonColorMath.rgbToHsv(r, g, b);
        pickerH = hsv[0];
        pickerS = hsv[1];
        pickerV = hsv[2];
    }

    private void syncHexBox() {
        if (hexBox != null) {
            hexBox.setValue(CrimsonTheme.toHex(currentPickerArgb()));
        }
    }

    private void applyColorPicker() {
        ConfigEntry entry = selectedEntry();
        if (entry == null) return;
        int argb = currentPickerArgb();
        if (entry.kind == ConfigEntry.Kind.COLOR && entry.colorSet != null) {
            entry.colorSet.accept(argb);
        } else if (entry.kind == ConfigEntry.Kind.WARNING_LINE && entry.warningColorSet != null) {
            entry.warningColorSet.accept(argb);
        }
    }

    private void closeColorPicker(boolean cancel) {
        if (hexBox != null) {
            removeWidget(hexBox);
            hexBox = null;
        }
        colorPickerOpen = false;
        draggingSv = false;
        draggingHue = false;
        if (!cancel) {
            // already applied on OK
        }
    }

    private boolean handleListClick(double mx, double my, int button) {
        int y = listY - (int) scroll;
        for (int i = 0; i < layout.size(); i++) {
            LayoutRow row = layout.get(i);
            int ry = y;
            y += row.height + GAP;
            if (my < ry || my >= ry + row.height) continue;
            if (my < listY || my >= listY + listH) continue;

            ConfigEntry entry = row.entry;
            if (entry.kind == ConfigEntry.Kind.SECTION) {
                if (entry.id != null && entry.id.startsWith("sec_")) {
                    String catId = entry.id.substring("sec_".length());
                    if (!collapsedCategories.add(catId)) {
                        collapsedCategories.remove(catId);
                    }
                    String keepId = selectedEntryId();
                    rebuildLayout();
                    selectedRow = findRowById(keepId);
                    return true;
                }
                return true;
            }
            selectedRow = i;

            switch (entry.kind) {
                case TOGGLE -> entry.boolSet.accept(!entry.boolGet.getAsBoolean());
                case SLIDER -> {
                    draggingSlider = true;
                    updateSliderFromMouse(entry, mx);
                }
                case CYCLE -> {
                    int idx = entry.cycleIndexGet.get();
                    int next = button == 1 ? idx - 1 : idx + 1;
                    if (next < 0) next = entry.cycleLabels.length - 1;
                    if (next >= entry.cycleLabels.length) next = 0;
                    entry.cycleIndexSet.accept(next);
                }
                case COLOR -> openColorPicker(entry.colorGet.getAsInt());
                case STRING -> beginStringEdit(entry);
                case WARNING_LINE -> {
                    if (mx >= listX + listW - 26) {
                        openColorPicker(entry.warningColorGet.getAsInt());
                    } else {
                        beginWarningTextEdit(entry);
                    }
                }
                case ACTION -> {
                    if (entry.action != null) entry.action.run();
                }
                case SUBGROUP -> {
                    if (!expandedSubgroups.add(entry.id)) {
                        expandedSubgroups.remove(entry.id);
                    }
                    String keepId = entry.id;
                    clearEditState();
                    rebuildLayout();
                    selectedRow = findRowById(keepId);
                }
                case STRING_LIST -> handleStringListClick(entry, mx, my, ry);
                default -> {
                }
            }
            return true;
        }
        return true;
    }

    private void handleStringListClick(ConfigEntry entry, double mx, double my, int rowTop) {
        List<String> items = new ArrayList<>(entry.listGet.get());
        int iy = rowTop + ROW_H;
        for (int i = 0; i < items.size(); i++) {
            if (my >= iy && my < iy + 14) {
                if (mx >= listX + listW - 20) {
                    items.remove(i);
                    entry.listSet.accept(items);
                    rebuildLayout();
                } else {
                    beginListItemEdit(entry, i);
                }
                return;
            }
            iy += 14;
        }
        if (my >= iy && my < iy + 16) {
            items.add("");
            entry.listSet.accept(items);
            rebuildLayout();
            beginListItemEdit(entry, items.size() - 1);
        }
    }

    private void openColorPicker(int argb) {
        clearEditWidgetsOnly();
        colorPickerOpen = true;
        pickerOrigArgb = argb | 0xFF000000;
        setPickerFromArgb(argb);
        layoutColorPicker();
        hexBox = new EditBox(this.font, svX + 24, svY + svSize + 4, 72, 16, Component.literal("Hex"));
        hexBox.setMaxLength(7);
        hexBox.setValue(CrimsonTheme.toHex(argb));
        hexBox.setBordered(true);
        hexBox.setTextColor(CrimsonTheme.TEXT);
        hexBox.setResponder(s -> {
            Integer parsed = CrimsonColorMath.parseHex(s);
            if (parsed != null) {
                setPickerFromArgb(parsed);
            }
        });
        addRenderableWidget(hexBox);
        setInitialFocus(hexBox);
    }

    private void beginStringEdit(ConfigEntry entry) {
        clearEditWidgetsOnly();
        editingListItem = false;
        editBox = new EditBox(this.font, listX + 6, listY + listH - 22, listW - 12, 18, Component.literal(""));
        editBox.setMaxLength(256);
        editBox.setValue(entry.stringGet.get());
        editBox.setBordered(true);
        editBox.setTextColor(CrimsonTheme.TEXT);
        editBox.setResponder(s -> entry.stringSet.accept(s));
        addRenderableWidget(editBox);
        setInitialFocus(editBox);
    }

    private void beginWarningTextEdit(ConfigEntry entry) {
        clearEditWidgetsOnly();
        editingListItem = false;
        editBox = new EditBox(this.font, listX + 6, listY + listH - 22, listW - 12, 18, Component.literal(""));
        editBox.setMaxLength(128);
        editBox.setValue(entry.warningTextGet.get());
        editBox.setBordered(true);
        editBox.setTextColor(CrimsonTheme.TEXT);
        editBox.setResponder(s -> entry.warningTextSet.accept(s));
        addRenderableWidget(editBox);
        setInitialFocus(editBox);
    }

    private void beginListItemEdit(ConfigEntry entry, int index) {
        clearEditWidgetsOnly();
        editingListItem = true;
        listEditIndex = index;
        List<String> items = entry.listGet.get();
        String cur = index >= 0 && index < items.size() ? items.get(index) : "";
        editBox = new EditBox(this.font, listX + 6, listY + listH - 22, listW - 12, 18, Component.literal(""));
        editBox.setMaxLength(256);
        editBox.setValue(cur);
        editBox.setBordered(true);
        editBox.setTextColor(CrimsonTheme.TEXT);
        editBox.setResponder(s -> {
            List<String> copy = new ArrayList<>(entry.listGet.get());
            if (listEditIndex >= 0 && listEditIndex < copy.size()) {
                copy.set(listEditIndex, s);
                entry.listSet.accept(copy);
            }
        });
        addRenderableWidget(editBox);
        setInitialFocus(editBox);
    }

    private void clearEditWidgetsOnly() {
        if (editBox != null) {
            removeWidget(editBox);
            editBox = null;
        }
        if (hexBox != null) {
            removeWidget(hexBox);
            hexBox = null;
        }
    }

    private void updateSliderFromMouse(ConfigEntry entry, double mx) {
        int sw = 70;
        int sx = listX + listW - sw - 8;
        double t = (mx - sx) / (double) sw;
        t = clamp01(t);
        double raw = entry.min + t * (entry.max - entry.min);
        double stepped = Math.round(raw / entry.step) * entry.step;
        stepped = Math.max(entry.min, Math.min(entry.max, stepped));
        entry.doubleSet.accept(stepped);
    }

    @Override
    public boolean mouseDragged(MouseButtonEvent event, double dragX, double dragY) {
        if (colorPickerOpen) {
            if (draggingSv) {
                updateSvFromMouse(event.x(), event.y());
                return true;
            }
            if (draggingHue) {
                updateHueFromMouse(event.y());
                return true;
            }
        }
        if (draggingSlider) {
            ConfigEntry entry = selectedEntry();
            if (entry != null && entry.kind == ConfigEntry.Kind.SLIDER) {
                updateSliderFromMouse(entry, event.x());
                return true;
            }
        }
        return super.mouseDragged(event, dragX, dragY);
    }

    @Override
    public boolean mouseReleased(MouseButtonEvent event) {
        draggingSlider = false;
        draggingSv = false;
        draggingHue = false;
        return super.mouseReleased(event);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double scrollX, double scrollY) {
        if (!colorPickerOpen && mouseX >= listX && mouseX < listX + listW
                && mouseY >= listY && mouseY < listY + listH) {
            scroll -= scrollY * 14;
            clampScroll();
            return true;
        }
        return super.mouseScrolled(mouseX, mouseY, scrollX, scrollY);
    }

    @Override
    public boolean keyPressed(KeyEvent event) {
        if (colorPickerOpen && event.key() == GLFW.GLFW_KEY_ESCAPE) {
            closeColorPicker(true);
            return true;
        }
        if (hexBox != null && hexBox.isFocused()) {
            if (event.key() == GLFW.GLFW_KEY_ENTER || event.key() == GLFW.GLFW_KEY_KP_ENTER) {
                applyColorPicker();
                closeColorPicker(false);
                return true;
            }
            if (hexBox.keyPressed(event)) return true;
        }
        if (editBox != null && editBox.isFocused()) {
            if (event.key() == GLFW.GLFW_KEY_ENTER || event.key() == GLFW.GLFW_KEY_KP_ENTER) {
                clearEditState();
                rebuildLayout();
                return true;
            }
            if (editBox.keyPressed(event)) {
                return true;
            }
        }
        return super.keyPressed(event);
    }

    /** Reset every option in the selected sidebar group (ESP / Utility / QoL). */
    private void resetCurrentGroup() {
        ConfigCatalog.Tab group = currentTab();
        if (group == null) return;
        for (ConfigEntry entry : group.allEntries()) {
            if (entry.kind != ConfigEntry.Kind.SECTION && entry.kind != ConfigEntry.Kind.ACTION) {
                entry.resetToDefault();
            }
        }
        rebuildTabs();
        rebuildLayout();
        clearEditState();
        VampyConfig.save();
    }

    @Override
    public void removed() {
        if (!discardOnClose) {
            VampyConfig.save();
        }
    }

    @Override
    public void onClose() {
        if (!discardOnClose) {
            VampyConfig.save();
        }
        this.minecraft.setScreenAndShow(parent);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    private static double clamp01(double v) {
        return v < 0 ? 0 : (v > 1 ? 1 : v);
    }

    private record LayoutRow(ConfigEntry entry, int height, boolean indented) {
    }
}

