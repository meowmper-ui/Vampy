package com.vampy.price;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.vampy.VampyMod;
import com.vampy.config.VampyConfig;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Lowest-BIN prices keyed by SkyBlock item id.
 * <p>
 * Fetches Vemp (Hypixel AH mirror) and Elite in parallel, then keeps the
 * <strong>fresher</strong> feed as primary and fills missing ids from the older one.
 */
public final class AhLowestBinCache {

    private static final String VEMP_URL =
            "https://raw.githubusercontent.com/meowmper-ui/Vemp/main/data/lbins.json";
    private static final String ELITE_URL =
            "https://api.eliteskyblock.com/resources/auctions/neu";

    private static final long REFRESH_MS = 60L * 1000L;
    private static final long RETRY_FAIL_MS = 20L * 1000L;

    private static final HttpClient HTTP = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(8))
            .followRedirects(HttpClient.Redirect.NORMAL)
            .build();

    private static volatile Map<String, Long> prices = Collections.emptyMap();
    private static volatile long lastSuccessMs = 0;
    private static volatile long lastAttemptMs = 0;
    private static volatile boolean lastFailed = false;
    private static final AtomicBoolean refreshing = new AtomicBoolean(false);

    private AhLowestBinCache() {
    }

    public static void tick() {
        if (!VampyConfig.isAhLowestBin() && !VampyConfig.isTradeValueOverlay()) return;
        long now = System.currentTimeMillis();
        long interval = lastFailed ? RETRY_FAIL_MS : REFRESH_MS;
        if (prices.isEmpty() || now - lastSuccessMs >= interval) {
            if (now - lastAttemptMs < 5_000L) return;
            requestRefresh();
        }
    }

    public static void requestRefresh() {
        if (!VampyConfig.isAhLowestBin() && !VampyConfig.isTradeValueOverlay()) return;
        forceRefreshForTrade();
    }

    public static void forceRefreshForTrade() {
        if (!refreshing.compareAndSet(false, true)) return;
        lastAttemptMs = System.currentTimeMillis();
        Thread t = new Thread(AhLowestBinCache::fetchSafe, "vampy-ah-lbin");
        t.setDaemon(true);
        t.start();
    }

    public static boolean isReady() {
        return !prices.isEmpty();
    }

    public static boolean isRefreshing() {
        return refreshing.get();
    }

    public static Long getLowestBin(String skyblockId) {
        if (skyblockId == null || skyblockId.isEmpty()) return null;
        return prices.get(skyblockId);
    }

    public static String formatCoins(long coins) {
        return String.format(Locale.US, "%,d", coins);
    }

    private static void fetchSafe() {
        try {
            CompletableFuture<Feed> vempF = CompletableFuture.supplyAsync(() -> tryDownload("vemp", VEMP_URL));
            CompletableFuture<Feed> eliteF = CompletableFuture.supplyAsync(() -> tryDownload("elite", ELITE_URL));
            Feed vemp = vempF.join();
            Feed elite = eliteF.join();

            Feed chosen = pickFresher(vemp, elite);
            if (chosen == null || chosen.prices.isEmpty()) {
                throw new IllegalStateException("both LBIN feeds failed or empty");
            }
            Feed other = (chosen == vemp) ? elite : vemp;
            Map<String, Long> merged = mergePreferFresher(chosen, other);

            prices = merged;
            lastSuccessMs = System.currentTimeMillis();
            lastFailed = false;
            VampyMod.LOGGER.info(
                    "[Vampy] AH LBIN cache refreshed ({} items, primary={}, age={}s{})",
                    merged.size(),
                    chosen.name,
                    Math.max(0L, (System.currentTimeMillis() - chosen.updatedMs) / 1000L),
                    other != null && !other.prices.isEmpty()
                            ? ", filled gaps from " + other.name
                            : "");
        } catch (Exception e) {
            lastFailed = true;
            VampyMod.LOGGER.warn("[Vampy] AH LBIN refresh failed: {}", e.toString());
        } finally {
            refreshing.set(false);
        }
    }

    private static Feed tryDownload(String name, String url) {
        try {
            return download(name, url);
        } catch (Exception e) {
            VampyMod.LOGGER.warn("[Vampy] {} LBIN feed failed: {}", name, e.toString());
            return null;
        }
    }

    private static Feed pickFresher(Feed a, Feed b) {
        if (a == null || a.prices.isEmpty()) return (b != null && !b.prices.isEmpty()) ? b : null;
        if (b == null || b.prices.isEmpty()) return a;
        return a.updatedMs >= b.updatedMs ? a : b;
    }

    /** Prefer prices from {@code fresh}; add ids only present in {@code older}. */
    private static Map<String, Long> mergePreferFresher(Feed fresh, Feed older) {
        Map<String, Long> out = new HashMap<>(fresh.prices);
        if (older != null && !older.prices.isEmpty()) {
            for (Map.Entry<String, Long> e : older.prices.entrySet()) {
                out.putIfAbsent(e.getKey(), e.getValue());
            }
        }
        return Map.copyOf(out);
    }

    private static Feed download(String name, String url) throws Exception {
        String bust = url.contains("?") ? "&" : "?";
        String full = url + bust + "t=" + (System.currentTimeMillis() / 30_000L);
        HttpRequest req = HttpRequest.newBuilder(URI.create(full))
                .timeout(Duration.ofSeconds(20))
                .header("User-Agent", "Vampy/" + VampyMod.MOD_ID)
                .header("Accept", "application/json")
                .GET()
                .build();
        HttpResponse<String> resp = HTTP.send(req, HttpResponse.BodyHandlers.ofString());
        if (resp.statusCode() < 200 || resp.statusCode() >= 300) {
            throw new IllegalStateException("HTTP " + resp.statusCode());
        }

        Parsed parsed = parseLbins(resp.body());
        long updated = parsed.updatedMs;
        if (updated <= 0) {
            updated = headerTimeMs(resp).orElse(System.currentTimeMillis());
        }
        if (parsed.prices.isEmpty()) {
            throw new IllegalStateException("empty payload");
        }
        return new Feed(name, updated, parsed.prices);
    }

    private static Optional<Long> headerTimeMs(HttpResponse<?> resp) {
        Optional<String> lastMod = resp.headers().firstValue("Last-Modified");
        if (lastMod.isPresent()) {
            try {
                return Optional.of(ZonedDateTime.parse(lastMod.get(), DateTimeFormatter.RFC_1123_DATE_TIME)
                        .toInstant().toEpochMilli());
            } catch (Exception ignored) {
            }
        }
        Optional<String> date = resp.headers().firstValue("Date");
        if (date.isPresent()) {
            try {
                return Optional.of(ZonedDateTime.parse(date.get(), DateTimeFormatter.RFC_1123_DATE_TIME)
                        .toInstant().toEpochMilli());
            } catch (Exception ignored) {
            }
        }
        return Optional.empty();
    }

    private static Parsed parseLbins(String body) {
        JsonElement root = JsonParser.parseString(body);
        if (!root.isJsonObject()) return new Parsed(0L, Collections.emptyMap());
        JsonObject obj = root.getAsJsonObject();

        long updated = 0L;
        if (obj.has("updated") && obj.get("updated").isJsonPrimitive()) {
            try {
                updated = obj.get("updated").getAsLong();
            } catch (Exception ignored) {
            }
        }

        JsonObject priceObj = obj;
        if (obj.has("prices") && obj.get("prices").isJsonObject()) {
            priceObj = obj.getAsJsonObject("prices");
        } else {
            // Flat Elite map: strip non-price metadata keys if any appear later
            Set<String> skip = new HashSet<>();
            skip.add("updated");
            skip.add("source");
            skip.add("count");
            skip.add("pages");
            Map<String, Long> flat = new HashMap<>(Math.max(16, priceObj.size()));
            for (Map.Entry<String, JsonElement> e : priceObj.entrySet()) {
                if (skip.contains(e.getKey())) continue;
                JsonElement v = e.getValue();
                if (v == null || !v.isJsonPrimitive() || !v.getAsJsonPrimitive().isNumber()) continue;
                long price = v.getAsLong();
                if (price <= 0) continue;
                flat.put(e.getKey(), price);
            }
            return new Parsed(updated, Map.copyOf(flat));
        }

        Map<String, Long> map = new HashMap<>(Math.max(16, priceObj.size()));
        for (Map.Entry<String, JsonElement> e : priceObj.entrySet()) {
            JsonElement v = e.getValue();
            if (v == null || !v.isJsonPrimitive() || !v.getAsJsonPrimitive().isNumber()) continue;
            long price = v.getAsLong();
            if (price <= 0) continue;
            map.put(e.getKey(), price);
        }
        return new Parsed(updated, Map.copyOf(map));
    }

    private record Feed(String name, long updatedMs, Map<String, Long> prices) {
    }

    private record Parsed(long updatedMs, Map<String, Long> prices) {
    }
}

