package com.vampy;

import com.mojang.brigadier.Command;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import com.vampy.chat.ChatHistoryStore;
import com.vampy.chat.ChatStackSession;
import com.vampy.chat.ClientModChat;
import com.vampy.chat.LatencyTracker;
import com.vampy.chat.PartyChatCommands;
import com.vampy.chat.TpsTracker;
import com.vampy.input.CommandHotkeys;
import com.vampy.input.KeyBindings;
import com.vampy.price.AhLowestBinCache;
import com.vampy.price.AhLowestBinTooltip;
import com.vampy.render.HotbarCooldownOverlay;
import com.vampy.render.PerfHudRenderer;
import com.vampy.render.SkyblockCombatFeatures;
import com.vampy.render.SlayerProfitTracker;
import com.vampy.render.SlayerTimerTracker;
import com.vampy.render.VampyRenderer;
import com.vampy.render.WarningHudRenderer;
import com.vampy.screen.HudDragScreen;
import com.vampy.screen.crimson.CrimsonConfigScreen;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.command.v2.ClientCommands;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionResult;
import org.lwjgl.glfw.GLFW;

public class VampyClient implements ClientModInitializer {
    private static boolean guiKeyWasDown = false;
    private static boolean prevLeftMouse = false;
    private static boolean prevRightMouse = false;
    private static boolean prevMiddleMouse = false;

    @Override
    public void onInitializeClient() {
        try {
            KeyBindings.register();
            VampyRenderer.register();
            WarningHudRenderer.register();
            SlayerProfitTracker.register();
            SkyblockCombatFeatures.register();
            UseItemCallback.EVENT.register((player, world, hand) -> {
                if (world.isClientSide()) {
                    SkyblockCombatFeatures.onItemUsed(Minecraft.getInstance(), hand);
                    HotbarCooldownOverlay.onItemUsed(Minecraft.getInstance(), hand);
                }
                return InteractionResult.PASS;
            });
            PerfHudRenderer.register();
            com.vampy.render.ChatCopyNotificationOverlay.register();
            AhLowestBinTooltip.register();
            registerConfigCommands();
            ChatHistoryStore.startLoadAsync();
            com.vampy.chat.VampWebSocketManager.getOrComputeAuthHash();

            AttackEntityCallback.EVENT.register((player, world, hand, entity, hitResult) -> {
                if (world.isClientSide()) {
                    WarningHudRenderer.onPlayerAttack(entity);
                    SlayerProfitTracker.onPlayerHitMob(entity);
                    SkyblockCombatFeatures.onPlayerAttackEntity(entity);
                    SkyblockCombatFeatures.onLeftClickSwing(Minecraft.getInstance());
                }
                return InteractionResult.PASS;
            });

            ClientLifecycleEvents.CLIENT_STOPPING.register(client -> {
                try {
                    ChatHistoryStore.captureLiveIfPresent();
                    ChatHistoryStore.flushAndAwait(3000L);
                } catch (Exception ignored) {
                }
            });

            ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> {
                try {
                    ChatStackSession.beginNewSession();
                    ChatHistoryStore.ensureAppliedToLiveChat();
                    LatencyTracker.reset();
                    TpsTracker.reset();
                    SlayerProfitTracker.onWorldChange();
                    com.vampy.render.LootshareBossTracker.clearChatBlockWaypoints();
                    com.vampy.chat.VampWebSocketManager.onServerJoin();
                    com.vampy.render.ManiaHelper.reset();
                } catch (Exception ignored) {
                }
            });
            ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> {
                ChatStackSession.beginNewSession();
                LatencyTracker.reset();
                TpsTracker.hardReset();
                SlayerProfitTracker.onWorldChange();
                com.vampy.render.LootshareBossTracker.clearChatBlockWaypoints();
                com.vampy.render.LootshareBossTracker.clearPartyMembers();
                com.vampy.chat.VampWebSocketManager.clearRemotePositions();
                com.vampy.render.ManiaHelper.reset();
            });

            ClientTickEvents.START_CLIENT_TICK.register(HotbarCooldownOverlay::onClientTick);
            ClientTickEvents.END_CLIENT_TICK.register(client -> {
                try {
                    handleGuiKey(client);
                    pollTrackerMouseClicks(client);
                    // CommandHotkeys removed for Hypixel rules compliance
                    PartyChatCommands.onClientTick(client);
                    com.vampy.chat.VampWebSocketManager.onClientTick(client);
                    SlayerProfitTracker.tick(client);
                    SlayerTimerTracker.tick(client);
                    SkyblockCombatFeatures.tick(client);
                    WarningHudRenderer.onClientTick(client);
                    com.vampy.render.ManiaHelper.onClientTick(client);
                    AhLowestBinCache.tick();
                    ChatHistoryStore.tick();

                    if (client.level == null || client.player == null) {
                        WarningHudRenderer.clearHelpingState();
                        SlayerProfitTracker.onWorldChange();
                        SlayerTimerTracker.reset();
                        com.vampy.render.ManiaHelper.reset();
                    }

                    if (WarningHudRenderer.screenOpen && client.screen == null) {
                        WarningHudRenderer.screenOpen = false;
                    }
                } catch (Exception ignored) {
                }
            });

            VampyMod.LOGGER.info("{} client initialized", VampyMod.MOD_NAME);
        } catch (Exception e) {
            VampyMod.LOGGER.error("{} client failed to initialize", VampyMod.MOD_NAME, e);
        }
    }

    private static void pollTrackerMouseClicks(Minecraft client) {
        if (client == null || client.getWindow() == null || !SlayerProfitTracker.isInteractiveScreenOpen(client)) {
            prevLeftMouse = false;
            prevRightMouse = false;
            prevMiddleMouse = false;
            return;
        }
        long win = client.getWindow().handle();
        boolean left = GLFW.glfwGetMouseButton(win, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
        boolean right = GLFW.glfwGetMouseButton(win, GLFW.GLFW_MOUSE_BUTTON_RIGHT) == GLFW.GLFW_PRESS;
        boolean middle = GLFW.glfwGetMouseButton(win, GLFW.GLFW_MOUSE_BUTTON_MIDDLE) == GLFW.GLFW_PRESS;

        double mx = client.mouseHandler.xpos() * (double) client.getWindow().getGuiScaledWidth() / (double) client.getWindow().getScreenWidth();
        double my = client.mouseHandler.ypos() * (double) client.getWindow().getGuiScaledHeight() / (double) client.getWindow().getScreenHeight();

        if (left && !prevLeftMouse) {
            SlayerProfitTracker.handleMouseClick(mx, my, 0);
        }
        if (right && !prevRightMouse) {
            SlayerProfitTracker.handleMouseClick(mx, my, 1);
        }
        if (middle && !prevMiddleMouse) {
            SlayerProfitTracker.handleMouseClick(mx, my, 2);
        }

        prevLeftMouse = left;
        prevRightMouse = right;
        prevMiddleMouse = middle;
    }

    private static void handleGuiKey(Minecraft client) {
        boolean isDown = KeyBindings.OPEN_GUI.isDown();
        if (isDown && !guiKeyWasDown) {
            if (client.player != null && client.screen == null) {
                openConfigScreen(client);
            }
        }
        guiKeyWasDown = isDown;
    }

    private static final SuggestionProvider<FabricClientCommandSource> TRACKER_TARGET_SUGGESTIONS = (context, builder) -> {
        String remaining = builder.getRemaining().toLowerCase(java.util.Locale.ROOT);
        String[] extraTargets = new String[]{"kills", "wins", "fails", "losses"};
        for (String t : extraTargets) {
            if (t.startsWith(remaining)) {
                builder.suggest(t);
            }
        }
        for (SlayerProfitTracker.DropType dt : SlayerProfitTracker.DropType.values()) {
            String key = dt.key.toLowerCase(java.util.Locale.ROOT);
            if (key.startsWith(remaining) || key.contains(remaining)) {
                builder.suggest(key);
            }
        }
        return builder.buildFuture();
    };

    private static final SuggestionProvider<FabricClientCommandSource> TRACKER_FORCE_TARGET_SUGGESTIONS = (context, builder) -> {
        String remaining = builder.getRemaining().toLowerCase(java.util.Locale.ROOT);
        String[] extraTargets = new String[]{"kills", "wins", "fails", "losses", "time"};
        for (String t : extraTargets) {
            if (t.startsWith(remaining)) {
                builder.suggest(t);
            }
        }
        for (SlayerProfitTracker.DropType dt : SlayerProfitTracker.DropType.values()) {
            String key = dt.key.toLowerCase(java.util.Locale.ROOT);
            if (key.startsWith(remaining) || key.contains(remaining)) {
                builder.suggest(key);
            }
        }
        return builder.buildFuture();
    };

    private static long parseDurationInputMs(String raw) {
        if (raw == null || raw.isBlank()) return -1L;
        String s = raw.trim().toLowerCase(java.util.Locale.ROOT);
        if (s.matches("^\\d+$")) {
            return Long.parseLong(s) * 60_000L;
        }
        java.util.regex.Matcher m = java.util.regex.Pattern.compile(
                "(\\d+)\\s*(d|day|days|д|дн|h|hr|hrs|hour|hours|ч|час|m|min|mins|minute|minutes|м|мин|s|sec|secs|second|seconds|с|сек)?"
        ).matcher(s);
        long totalMs = 0L;
        boolean found = false;
        int matchedChars = 0;
        while (m.find()) {
            String numStr = m.group(1);
            String unit = m.group(2);
            if (numStr == null) continue;
            long val = Long.parseLong(numStr);
            found = true;
            matchedChars += m.group(0).trim().length();
            if (unit == null || unit.isEmpty() || unit.startsWith("m") || unit.startsWith("м")) {
                totalMs += val * 60_000L;
            } else if (unit.startsWith("d") || unit.startsWith("д")) {
                totalMs += val * 86_400_000L;
            } else if (unit.startsWith("h") || unit.startsWith("ч")) {
                totalMs += val * 3_600_000L;
            } else if (unit.startsWith("s") || unit.startsWith("с")) {
                totalMs += val * 1_000L;
            }
        }
        String compact = s.replaceAll("\\s+", "");
        if (!found || matchedChars == 0 || compact.replaceAll("[0-9a-zа-я]", "").length() > 0) {
            return -1L;
        }
        return totalMs;
    }

    private static int applyTimeChange(String timeExpr, int sign, boolean isSet) {
        long ms = parseDurationInputMs(timeExpr);
        if (ms < 0L) {
            ClientModChat.info("§cInvalid time format: '" + timeExpr + "'. Examples: 45 (mins), 1d 20hr 1min, 2h 30m");
            return 0;
        }
        if (isSet) {
            SlayerProfitTracker.forceSetTimeMs(ms);
            ClientModChat.info("[Force] Set Lifetime Chateau Time to " + SlayerProfitTracker.formatDuration(ms));
        } else {
            long delta = ms * sign;
            SlayerProfitTracker.forceModifyTimeMs(delta);
            ClientModChat.info("[Force] " + (sign >= 0 ? "Added " : "Removed ") + SlayerProfitTracker.formatDuration(ms)
                    + " (Lifetime Chateau Time: " + SlayerProfitTracker.formatDuration(SlayerProfitTracker.getTotalPlaytimeMs()) + ")");
        }
        return 1;
    }

    private static int applyTrackerChange(String targetStr, int amount, boolean isSet, boolean force) {
        String q = targetStr == null ? "" : targetStr.trim().toLowerCase(java.util.Locale.ROOT);
        if (force && (q.equals("time") || q.equals("playtime") || q.equals("minutes") || q.equals("mins") || q.equals("min"))) {
            long ms = Math.abs((long) amount) * 60_000L;
            if (isSet) {
                SlayerProfitTracker.forceSetTimeMs(ms);
                ClientModChat.info("[Force] Set Lifetime Chateau Time to " + SlayerProfitTracker.formatDuration(ms));
            } else {
                long delta = (long) amount * 60_000L;
                SlayerProfitTracker.forceModifyTimeMs(delta);
                ClientModChat.info("[Force] " + (amount >= 0 ? "Added " : "Removed ") + SlayerProfitTracker.formatDuration(ms)
                        + " (Lifetime Chateau Time: " + SlayerProfitTracker.formatDuration(SlayerProfitTracker.getTotalPlaytimeMs()) + ")");
            }
            return 1;
        }
        if (q.equals("kills") || q.equals("kill") || q.equals("wins") || q.equals("win") || q.equals("w") || q.equals("bosses") || q.equals("boss")) {
            if (force) {
                if (isSet) {
                    SlayerProfitTracker.forceSetKills(amount);
                    ClientModChat.info("[Force] Set Lifetime Boss Kills (counted in /hr) to " + amount);
                } else {
                    SlayerProfitTracker.forceModifyKills(amount);
                    ClientModChat.info("[Force] " + (amount >= 0 ? "Added +" : "Removed ") + amount + " Lifetime Boss Kills (counted in /hr)");
                }
            } else {
                if (isSet) {
                    SlayerProfitTracker.setKillsActive(amount);
                    ClientModChat.info("Set Boss Kills (Wins, excluded from /hr) to " + amount);
                } else {
                    SlayerProfitTracker.modifyKillsBoth(amount);
                    ClientModChat.info((amount >= 0 ? "Added +" : "Removed ") + amount + " Boss Kills (Wins, excluded from /hr)");
                }
            }
            return 1;
        }
        if (q.equals("fails") || q.equals("fail") || q.equals("losses") || q.equals("loss") || q.equals("l")) {
            if (force) {
                if (isSet) {
                    SlayerProfitTracker.forceSetFails(amount);
                    ClientModChat.info("[Force] Set Lifetime Boss Fails to " + amount);
                } else {
                    SlayerProfitTracker.forceModifyFails(amount);
                    ClientModChat.info("[Force] " + (amount >= 0 ? "Added +" : "Removed ") + amount + " Lifetime Boss Fails");
                }
            } else {
                if (isSet) {
                    SlayerProfitTracker.setFailsActive(amount);
                    ClientModChat.info("Set Boss Fails (Losses) to " + amount);
                } else {
                    SlayerProfitTracker.modifyFailsBoth(amount);
                    ClientModChat.info((amount >= 0 ? "Added +" : "Removed ") + amount + " Boss Fails (Losses)");
                }
            }
            return 1;
        }

        SlayerProfitTracker.DropType dt = SlayerProfitTracker.findDropType(targetStr);
        if (dt == null) {
            ClientModChat.info("§cUnknown target: '" + targetStr + "'. Use kills, fails" + (force ? ", time," : "") + " or drop key (e.g. unfanged_vampire_part, the_one_iv, coven_seal).");
            return 0;
        }
        if (force) {
            if (isSet) {
                SlayerProfitTracker.forceSetDrop(dt, amount);
                ClientModChat.info("[Force] Set Lifetime " + dt.displayName + " to " + amount);
            } else {
                SlayerProfitTracker.forceModifyDrop(dt, amount);
                ClientModChat.info("[Force] " + (amount >= 0 ? "Added +" : "Removed ") + amount + " Lifetime " + dt.displayName);
            }
        } else {
            if (isSet) {
                SlayerProfitTracker.setDropActive(dt, amount);
                ClientModChat.info("Set " + dt.displayName + " (" + SlayerProfitTracker.viewMode().label + ") to " + amount);
            } else {
                SlayerProfitTracker.modifyDropBoth(dt, amount);
                ClientModChat.info((amount >= 0 ? "Added +" : "Removed ") + amount + " " + dt.displayName);
            }
        }
        return 1;
    }

    private static LiteralArgumentBuilder<FabricClientCommandSource> buildTimeSubcommand() {
        return ClientCommands.literal("time")
                .then(ClientCommands.literal("set")
                        .then(ClientCommands.argument("duration", StringArgumentType.greedyString())
                                .executes(ctx -> applyTimeChange(StringArgumentType.getString(ctx, "duration"), 1, true))))
                .then(ClientCommands.literal("add")
                        .then(ClientCommands.argument("duration", StringArgumentType.greedyString())
                                .executes(ctx -> applyTimeChange(StringArgumentType.getString(ctx, "duration"), 1, false))))
                .then(ClientCommands.literal("remove")
                        .then(ClientCommands.argument("duration", StringArgumentType.greedyString())
                                .executes(ctx -> applyTimeChange(StringArgumentType.getString(ctx, "duration"), -1, false))));
    }

    private static void registerConfigCommands() {
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) -> {
            Command<FabricClientCommandSource> openGui = ctx -> {
                Minecraft client = Minecraft.getInstance();
                client.execute(() -> openConfigScreen(client));
                return 1;
            };
            Command<FabricClientCommandSource> openHud = ctx -> {
                Minecraft client = Minecraft.getInstance();
                client.execute(() -> openHudDragScreen(client));
                return 1;
            };
            Command<FabricClientCommandSource> ping = ctx -> {
                ClientModChat.info(formatPing());
                return 1;
            };
            Command<FabricClientCommandSource> tps = ctx -> {
                ClientModChat.info(TpsTracker.formatTps());
                return 1;
            };

            for (String root : new String[]{"va", "vampy"}) {
                LiteralArgumentBuilder<FabricClientCommandSource> forceCmd = ClientCommands.literal("force")
                        .then(buildTimeSubcommand())
                        .then(ClientCommands.literal("add")
                                .then(ClientCommands.literal("time")
                                        .then(ClientCommands.argument("duration", StringArgumentType.greedyString())
                                                .executes(ctx -> applyTimeChange(StringArgumentType.getString(ctx, "duration"), 1, false))))
                                .then(ClientCommands.argument("target", StringArgumentType.word())
                                        .suggests(TRACKER_FORCE_TARGET_SUGGESTIONS)
                                        .executes(ctx -> applyTrackerChange(StringArgumentType.getString(ctx, "target"), 1, false, true))
                                        .then(ClientCommands.argument("amount", IntegerArgumentType.integer(1, 1000000))
                                                .executes(ctx -> applyTrackerChange(
                                                        StringArgumentType.getString(ctx, "target"),
                                                        IntegerArgumentType.getInteger(ctx, "amount"),
                                                        false, true)))))
                        .then(ClientCommands.literal("remove")
                                .then(ClientCommands.literal("time")
                                        .then(ClientCommands.argument("duration", StringArgumentType.greedyString())
                                                .executes(ctx -> applyTimeChange(StringArgumentType.getString(ctx, "duration"), -1, false))))
                                .then(ClientCommands.argument("target", StringArgumentType.word())
                                        .suggests(TRACKER_FORCE_TARGET_SUGGESTIONS)
                                        .executes(ctx -> applyTrackerChange(StringArgumentType.getString(ctx, "target"), -1, false, true))
                                        .then(ClientCommands.argument("amount", IntegerArgumentType.integer(1, 1000000))
                                                .executes(ctx -> applyTrackerChange(
                                                        StringArgumentType.getString(ctx, "target"),
                                                        -IntegerArgumentType.getInteger(ctx, "amount"),
                                                        false, true)))))
                        .then(ClientCommands.literal("set")
                                .then(ClientCommands.literal("time")
                                        .then(ClientCommands.argument("duration", StringArgumentType.greedyString())
                                                .executes(ctx -> applyTimeChange(StringArgumentType.getString(ctx, "duration"), 1, true))))
                                .then(ClientCommands.argument("target", StringArgumentType.word())
                                        .suggests(TRACKER_FORCE_TARGET_SUGGESTIONS)
                                        .then(ClientCommands.argument("amount", IntegerArgumentType.integer(0, 10000000))
                                                .executes(ctx -> applyTrackerChange(
                                                        StringArgumentType.getString(ctx, "target"),
                                                        IntegerArgumentType.getInteger(ctx, "amount"),
                                                        true, true)))));

                LiteralArgumentBuilder<FabricClientCommandSource> trackerCmd = ClientCommands.literal("tracker")
                        .executes(ctx -> {
                            SlayerProfitTracker.toggleViewMode();
                            ClientModChat.info("Tracker mode: " + SlayerProfitTracker.viewMode().label);
                            return 1;
                        })
                        .then(ClientCommands.literal("mode").executes(ctx -> {
                            SlayerProfitTracker.toggleViewMode();
                            ClientModChat.info("Tracker mode switched to: " + SlayerProfitTracker.viewMode().label);
                            return 1;
                        }))
                        .then(ClientCommands.literal("reset").executes(ctx -> {
                            SlayerProfitTracker.resetSession();
                            ClientModChat.info("Session profit tracker reset.");
                            return 1;
                        }))
                        .then(ClientCommands.literal("resetall").executes(ctx -> {
                            SlayerProfitTracker.resetTotal();
                            ClientModChat.info("Lifetime & Session profit tracker reset.");
                            return 1;
                        }))
                        .then(forceCmd)
                        .then(ClientCommands.literal("add")
                                .then(ClientCommands.argument("target", StringArgumentType.word())
                                        .suggests(TRACKER_TARGET_SUGGESTIONS)
                                        .executes(ctx -> applyTrackerChange(StringArgumentType.getString(ctx, "target"), 1, false, false))
                                        .then(ClientCommands.argument("amount", IntegerArgumentType.integer(1, 100000))
                                                .executes(ctx -> applyTrackerChange(
                                                        StringArgumentType.getString(ctx, "target"),
                                                        IntegerArgumentType.getInteger(ctx, "amount"),
                                                        false, false)))))
                        .then(ClientCommands.literal("remove")
                                .then(ClientCommands.argument("target", StringArgumentType.word())
                                        .suggests(TRACKER_TARGET_SUGGESTIONS)
                                        .executes(ctx -> applyTrackerChange(StringArgumentType.getString(ctx, "target"), -1, false, false))
                                        .then(ClientCommands.argument("amount", IntegerArgumentType.integer(1, 100000))
                                                .executes(ctx -> applyTrackerChange(
                                                        StringArgumentType.getString(ctx, "target"),
                                                        -IntegerArgumentType.getInteger(ctx, "amount"),
                                                        false, false)))))
                        .then(ClientCommands.literal("set")
                                .then(ClientCommands.argument("target", StringArgumentType.word())
                                        .suggests(TRACKER_TARGET_SUGGESTIONS)
                                        .then(ClientCommands.argument("amount", IntegerArgumentType.integer(0, 1000000))
                                                .executes(ctx -> applyTrackerChange(
                                                        StringArgumentType.getString(ctx, "target"),
                                                        IntegerArgumentType.getInteger(ctx, "amount"),
                                                        true, false)))));

                LiteralArgumentBuilder<FabricClientCommandSource> chatCmd = ClientCommands.literal("chat")
                        .executes(ctx -> {
                            boolean next = !com.vampy.chat.VampWebSocketManager.isVaChatChannelActive();
                            com.vampy.chat.VampWebSocketManager.setVaChatChannelActive(next, false);
                            return 1;
                        })
                        .then(ClientCommands.argument("message", StringArgumentType.greedyString())
                                .executes(ctx -> {
                                    com.vampy.chat.VampWebSocketManager.sendChatMessage(
                                            StringArgumentType.getString(ctx, "message"), false);
                                    return 1;
                                }));

                SuggestionProvider<FabricClientCommandSource> onlineModUsersSuggestions = (context, builder) -> {
                    String rem = builder.getRemaining().toLowerCase(java.util.Locale.ROOT);
                    for (String user : com.vampy.chat.VampWebSocketManager.getOnlineModUsers()) {
                        if (user.toLowerCase(java.util.Locale.ROOT).startsWith(rem)) {
                            builder.suggest(user);
                        }
                    }
                    for (String pm : com.vampy.render.LootshareBossTracker.getPartyMemberIgns()) {
                        if (pm.toLowerCase(java.util.Locale.ROOT).startsWith(rem)) {
                            builder.suggest(pm);
                        }
                    }
                    return builder.buildFuture();
                };

                LiteralArgumentBuilder<FabricClientCommandSource> msgCmd = ClientCommands.literal("msg")
                        .then(ClientCommands.argument("ign", StringArgumentType.word())
                                .suggests(onlineModUsersSuggestions)
                                .then(ClientCommands.argument("message", StringArgumentType.greedyString())
                                        .executes(ctx -> {
                                            com.vampy.chat.VampWebSocketManager.sendDirectMessage(
                                                    StringArgumentType.getString(ctx, "ign"),
                                                    StringArgumentType.getString(ctx, "message"));
                                            return 1;
                                        })));

                LiteralArgumentBuilder<FabricClientCommandSource> mCmd = ClientCommands.literal("m")
                        .then(ClientCommands.argument("ign", StringArgumentType.word())
                                .suggests(onlineModUsersSuggestions)
                                .then(ClientCommands.argument("message", StringArgumentType.greedyString())
                                        .executes(ctx -> {
                                            com.vampy.chat.VampWebSocketManager.sendDirectMessage(
                                                    StringArgumentType.getString(ctx, "ign"),
                                                    StringArgumentType.getString(ctx, "message"));
                                            return 1;
                                        })));

                LiteralArgumentBuilder<FabricClientCommandSource> rCmd = ClientCommands.literal("r")
                        .then(ClientCommands.argument("message", StringArgumentType.greedyString())
                                .executes(ctx -> {
                                    com.vampy.chat.VampWebSocketManager.replyDirectMessage(
                                            StringArgumentType.getString(ctx, "message"));
                                    return 1;
                                }));

                LiteralArgumentBuilder<FabricClientCommandSource> replyCmd = ClientCommands.literal("reply")
                        .then(ClientCommands.argument("message", StringArgumentType.greedyString())
                                .executes(ctx -> {
                                    com.vampy.chat.VampWebSocketManager.replyDirectMessage(
                                            StringArgumentType.getString(ctx, "message"));
                                    return 1;
                                }));

                LiteralArgumentBuilder<FabricClientCommandSource> cmd = ClientCommands.literal(root)
                        .executes(openGui)
                        .then(ClientCommands.literal("gui").executes(openGui))
                        .then(ClientCommands.literal("hud").executes(openHud))
                        .then(ClientCommands.literal("ping").executes(ping))
                        .then(ClientCommands.literal("tps").executes(tps))
                        .then(chatCmd)
                        .then(msgCmd)
                        .then(mCmd)
                        .then(rCmd)
                        .then(replyCmd)
                        .then(trackerCmd);
                dispatcher.register(cmd);
            }

            // Single-message WebSocket chat commands: /vac <msg> (global VA chat) and /vap <msg> (party VA chat)
            dispatcher.register(ClientCommands.literal("vac")
                    .executes(ctx -> {
                        boolean next = !com.vampy.chat.VampWebSocketManager.isVaChatChannelActive();
                        com.vampy.chat.VampWebSocketManager.setVaChatChannelActive(next, false);
                        return 1;
                    })
                    .then(ClientCommands.argument("message", StringArgumentType.greedyString())
                            .executes(ctx -> {
                                com.vampy.chat.VampWebSocketManager.sendChatMessage(
                                        StringArgumentType.getString(ctx, "message"), false);
                                return 1;
                            })));

            dispatcher.register(ClientCommands.literal("vap")
                    .executes(ctx -> {
                        boolean next = !com.vampy.chat.VampWebSocketManager.isVaChatChannelActive();
                        com.vampy.chat.VampWebSocketManager.setVaChatChannelActive(next, true);
                        return 1;
                    })
                    .then(ClientCommands.argument("message", StringArgumentType.greedyString())
                            .executes(ctx -> {
                                com.vampy.chat.VampWebSocketManager.sendChatMessage(
                                        StringArgumentType.getString(ctx, "message"), true);
                                return 1;
                            })));
        });
    }

    private static String formatPing() {
        int ms = LatencyTracker.getPingMs();
        return ms < 0 ? "ping unavailable" : ms + "ms";
    }

    private static void openHudDragScreen(Minecraft client) {
        if (client == null) return;
        try {
            client.setScreenAndShow(new HudDragScreen(null));
        } catch (Exception e) {
            VampyMod.LOGGER.error("Failed to open HUD editor screen", e);
        }
    }

    private static void openConfigScreen(Minecraft client) {
        if (client == null) return;
        try {
            client.setScreenAndShow(new CrimsonConfigScreen(null));
            WarningHudRenderer.screenOpen = true;
        } catch (Exception e) {
            VampyMod.LOGGER.error("Failed to open config screen", e);
            if (client.player != null) {
                client.player.sendSystemMessage(
                        Component.literal("§cFailed to open " + VampyMod.MOD_NAME + " config."));
            }
        } catch (Error e) {
            VampyMod.LOGGER.error("Error opening config screen", e);
        }
    }
}
