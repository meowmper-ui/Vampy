package com.vampy.render;

import com.vampy.chat.ClientModChat;
import com.vampy.config.VampyConfig;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.scores.DisplaySlot;
import net.minecraft.world.scores.Objective;
import net.minecraft.world.scores.PlayerScoreEntry;
import net.minecraft.world.scores.PlayerTeam;
import net.minecraft.world.scores.Scoreboard;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class SlayerTimerTracker {

    private static final long SCAN_INTERVAL_MS = 100L;
    private static final Pattern BOSS_TIER_PATTERN = Pattern.compile(
        "(Revenant Horror|Atoned Horror|Tarantula Broodfather|Sven Packmaster|Voidgloom Seraph|Inferno Demonlord|Riftstalker Bloodfiend|Bacte)\\s+(V|IV|III|II|I|5|4|3|2|1)(?:[^I]|$)",
        Pattern.CASE_INSENSITIVE
    );

    private static String currentBossWithTier = null;
    private static long questStartMs = -1L;
    private static long bossSpawnMs = -1L;
    private static boolean questStartKnown;
    private static boolean reported;
    private static boolean sawSlayBoss;
    private static boolean sawBossSlain;
    private static boolean ignoreSidebarUntilClear;
    private static long lastScanMs;

    private static final Map<String, Long> BOSS_KILL_PB_MS = new ConcurrentHashMap<>();
    private static final Map<String, Long> BOSS_QUEST_PB_MS = new ConcurrentHashMap<>();
    private static final File PB_FILE = new File(FabricLoader.getInstance().getConfigDir().toFile(), "vampy_slayer_pb.properties");
    private static final File LEGACY_PB_FILE = new File(FabricLoader.getInstance().getConfigDir().toFile(), "vampaddons_slayer_pb.properties");

    static {
        loadPersonalBests();
    }

    private SlayerTimerTracker() {
    }

    public static String getCurrentBossWithTier() {
        return currentBossWithTier;
    }

    public static void onChatMessage(String raw) {
        if (raw == null || raw.isEmpty()) return;
        String text = ChatFormatting.stripFormatting(raw).trim();
        if (text.isEmpty()) return;

        if (containsIgnoreCase(text, "SLAYER QUEST STARTED!")) {
            resetRun(true);
            ignoreSidebarUntilClear = true;
            return;
        }
        if (containsIgnoreCase(text, "SLAYER QUEST FAILED!")) {
            Minecraft mc = Minecraft.getInstance();
            updateActiveBossFromWorldAndSidebar(mc);
            SlayerProfitTracker.recordBossFail(currentBossWithTier);
        }
        if (containsIgnoreCase(text, "SLAYER QUEST FAILED!")
                || containsIgnoreCase(text, "Your Slayer Quest has been cancelled!")) {
            resetRun(false);
            ignoreSidebarUntilClear = true;
            return;
        }
        if (containsIgnoreCase(text, "NICE! SLAYER BOSS SLAIN!")
                || containsIgnoreCase(text, "SLAYER QUEST COMPLETE!")) {
            Minecraft mc = Minecraft.getInstance();
            updateActiveBossFromWorldAndSidebar(mc);
            SlayerProfitTracker.recordBossKill(currentBossWithTier);
            if (VampyConfig.isSlayerTimersEnabled()) {
                tryFinish(System.currentTimeMillis());
            }
        }
    }

    public static void tick(Minecraft client) {
        if (client == null || client.level == null) return;

        long now = System.currentTimeMillis();
        if (now - lastScanMs < SCAN_INTERVAL_MS) return;
        lastScanMs = now;

        boolean slayBoss = false;
        boolean bossSlain = false;
        try {
            Scoreboard sb = client.level.getScoreboard();
            Objective obj = sb.getDisplayObjective(DisplaySlot.SIDEBAR);
            if (obj != null) {
                List<PlayerScoreEntry> entries = new ArrayList<>(sb.listPlayerScores(obj));
                entries.sort(Comparator.comparingInt(PlayerScoreEntry::value).reversed());
                for (PlayerScoreEntry entry : entries) {
                    String plain = plainLine(sb, entry);
                    String parsed = parseCanonicalBossAndTier(plain);
                    if (parsed != null) {
                        currentBossWithTier = parsed;
                        SlayerProfitTracker.notifyDetectedBossWithTier(parsed);
                    }
                    String lower = plain.toLowerCase(Locale.ROOT);
                    if (lower.contains("slay the boss")) slayBoss = true;
                    if (lower.contains("boss slain")) bossSlain = true;
                }
            }
        } catch (Exception ignored) {
        }

        if (slayBoss || currentBossWithTier == null) {
            String worldBoss = scanWorldBossNametag(client);
            if (worldBoss != null) {
                if (currentBossWithTier == null || !sameBossFamily(currentBossWithTier, worldBoss)) {
                    currentBossWithTier = worldBoss;
                }
                SlayerProfitTracker.notifyDetectedBossWithTier(currentBossWithTier);
            }
        }

        if (ignoreSidebarUntilClear) {
            if (!slayBoss && !bossSlain) {
                ignoreSidebarUntilClear = false;
            }
            sawSlayBoss = slayBoss;
            sawBossSlain = bossSlain;
            return;
        }

        if (slayBoss && !sawSlayBoss) {
            if (bossSpawnMs < 0L) {
                bossSpawnMs = now;
                updateActiveBossFromWorldAndSidebar(client);
                if (SlayerProfitTracker.getCurrentLocationCategory() != null) {
                    SlayerProfitTracker.recordBossSpawned(currentBossWithTier);
                }
            }
        }
        sawSlayBoss = slayBoss;

        if (bossSlain && !sawBossSlain) {
            updateActiveBossFromWorldAndSidebar(client);
            if (VampyConfig.isSlayerTimersEnabled()) {
                tryFinish(now);
            }
        }
        sawBossSlain = bossSlain;
    }

    private static void updateActiveBossFromWorldAndSidebar(Minecraft client) {
        if (client == null || client.level == null) return;
        try {
            Scoreboard sb = client.level.getScoreboard();
            Objective obj = sb.getDisplayObjective(DisplaySlot.SIDEBAR);
            if (obj != null) {
                for (PlayerScoreEntry entry : sb.listPlayerScores(obj)) {
                    String plain = plainLine(sb, entry);
                    String parsed = parseCanonicalBossAndTier(plain);
                    if (parsed != null) {
                        currentBossWithTier = parsed;
                        SlayerProfitTracker.notifyDetectedBossWithTier(parsed);
                        return;
                    }
                }
            }
        } catch (Exception ignored) {}

        String worldBoss = scanWorldBossNametag(client);
        if (worldBoss != null) {
            currentBossWithTier = worldBoss;
            SlayerProfitTracker.notifyDetectedBossWithTier(worldBoss);
        }
    }

    private static String scanWorldBossNametag(Minecraft client) {
        if (client == null || client.level == null || client.player == null) return null;
        String bestLabel = null;
        double bestDistSq = 18.0 * 18.0;
        for (Entity e : NearbyEntityCache.getEntities(client)) {
            if (e instanceof ArmorStand && e.hasCustomName() && e.getCustomName() != null) {
                double dSq = e.distanceToSqr(client.player);
                if (dSq > bestDistSq) continue;
                String clean = ChatFormatting.stripFormatting(e.getCustomName().getString());
                if (clean == null || clean.isEmpty()) continue;
                String parsed = parseCanonicalBossAndTier(clean);
                if (parsed != null) {
                    bestDistSq = dSq;
                    bestLabel = parsed;
                    continue;
                }
                String lower = clean.toLowerCase(Locale.ROOT);
                if (lower.contains("atoned horror")) {
                    bestDistSq = dSq;
                    bestLabel = "Revenant Horror V";
                } else if (lower.contains("revenant horror")) {
                    bestDistSq = dSq;
                    bestLabel = currentBossWithTier != null && currentBossWithTier.startsWith("Revenant Horror ")
                            ? currentBossWithTier : "Revenant Horror IV";
                } else if (lower.contains("tarantula broodfather")) {
                    bestDistSq = dSq;
                    bestLabel = currentBossWithTier != null && currentBossWithTier.startsWith("Tarantula Broodfather ")
                            ? currentBossWithTier : "Tarantula Broodfather IV";
                } else if (lower.contains("sven packmaster")) {
                    bestDistSq = dSq;
                    bestLabel = currentBossWithTier != null && currentBossWithTier.startsWith("Sven Packmaster ")
                            ? currentBossWithTier : "Sven Packmaster IV";
                } else if (lower.contains("voidgloom seraph")) {
                    bestDistSq = dSq;
                    bestLabel = currentBossWithTier != null && currentBossWithTier.startsWith("Voidgloom Seraph ")
                            ? currentBossWithTier : "Voidgloom Seraph IV";
                } else if (lower.contains("inferno demonlord")) {
                    bestDistSq = dSq;
                    bestLabel = currentBossWithTier != null && currentBossWithTier.startsWith("Inferno Demonlord ")
                            ? currentBossWithTier : "Inferno Demonlord IV";
                } else if (lower.contains("bloodfiend")) {
                    bestDistSq = dSq;
                    bestLabel = currentBossWithTier != null && currentBossWithTier.startsWith("Riftstalker Bloodfiend ")
                            ? currentBossWithTier : "Riftstalker Bloodfiend V";
                }
            }
        }
        return bestLabel;
    }

    private static boolean sameBossFamily(String a, String b) {
        if (a == null || b == null) return false;
        int ia = a.lastIndexOf(' ');
        int ib = b.lastIndexOf(' ');
        String fa = ia > 0 ? a.substring(0, ia) : a;
        String fb = ib > 0 ? b.substring(0, ib) : b;
        return fa.equalsIgnoreCase(fb);
    }

    public static String parseCanonicalBossAndTier(String text) {
        if (text == null || text.isEmpty()) return null;
        Matcher m = BOSS_TIER_PATTERN.matcher(text);
        if (!m.find()) return null;
        String rawBoss = m.group(1).trim();
        String rawTier = m.group(2).trim().toUpperCase(Locale.ROOT);
        String tierRoman = switch (rawTier) {
            case "1", "I" -> "I";
            case "2", "II" -> "II";
            case "3", "III" -> "III";
            case "4", "IV" -> "IV";
            case "5", "V" -> "V";
            default -> "IV";
        };
        String lowerBoss = rawBoss.toLowerCase(Locale.ROOT);
        String canonicalBoss;
        if (lowerBoss.contains("revenant") || lowerBoss.contains("atoned")) {
            canonicalBoss = "Revenant Horror";
            if (lowerBoss.contains("atoned")) tierRoman = "V";
        } else if (lowerBoss.contains("tarantula")) {
            canonicalBoss = "Tarantula Broodfather";
        } else if (lowerBoss.contains("sven")) {
            canonicalBoss = "Sven Packmaster";
        } else if (lowerBoss.contains("voidgloom")) {
            canonicalBoss = "Voidgloom Seraph";
        } else if (lowerBoss.contains("inferno")) {
            canonicalBoss = "Inferno Demonlord";
        } else if (lowerBoss.contains("bloodfiend") || lowerBoss.contains("riftstalker")) {
            canonicalBoss = "Riftstalker Bloodfiend";
        } else {
            return null;
        }
        return canonicalBoss + " " + tierRoman;
    }

    private static void tryFinish(long endMs) {
        if (reported) return;
        if (bossSpawnMs < 0L) return;
        reported = true;

        Minecraft mc = Minecraft.getInstance();
        updateActiveBossFromWorldAndSidebar(mc);

        String bossLabel = (currentBossWithTier != null && !currentBossWithTier.isBlank())
                ? currentBossWithTier
                : (SlayerProfitTracker.isInStillgoreChateau() ? "Riftstalker Bloodfiend V" : "Slayer Boss");

        long killMs = Math.max(0L, endMs - bossSpawnMs);
        Long prevKillPb = BOSS_KILL_PB_MS.get(bossLabel);
        boolean killPb = (prevKillPb == null || killMs < prevKillPb);
        if (killPb && killMs > 0L) {
            BOSS_KILL_PB_MS.put(bossLabel, killMs);
            savePersonalBests();
        }
        String prevKillText = (killPb && prevKillPb != null && prevKillPb > 0L) ? formatDuration(prevKillPb) : null;
        ClientModChat.info(bossLabel + " took " + formatDuration(killMs), killPb, prevKillText);

        if (!questStartKnown || questStartMs < 0L || questStartMs >= bossSpawnMs) {
            return;
        }
        long questMs = Math.max(0L, endMs - questStartMs);
        Long prevQuestPb = BOSS_QUEST_PB_MS.get(bossLabel);
        boolean questPb = (prevQuestPb == null || questMs < prevQuestPb);
        if (questPb && questMs > 0L) {
            BOSS_QUEST_PB_MS.put(bossLabel, questMs);
            savePersonalBests();
        }
        String prevQuestText = (questPb && prevQuestPb != null && prevQuestPb > 0L) ? formatDuration(prevQuestPb) : null;
        ClientModChat.info(bossLabel + " quest took: " + formatDuration(questMs), questPb, prevQuestText);
    }

    private static void resetRun(boolean started) {
        questStartMs = started ? System.currentTimeMillis() : -1L;
        questStartKnown = started;
        bossSpawnMs = -1L;
        currentBossWithTier = null;
        reported = false;
        sawSlayBoss = false;
        sawBossSlain = false;
        ignoreSidebarUntilClear = false;
    }

    public static void reset() {
        resetRun(false);
        ignoreSidebarUntilClear = false;
    }

    static String formatDuration(long ms) {
        if (ms < 0L) return "?";
        return String.format(Locale.ROOT, "%.2fs", ms / 1000.0);
    }

    private static boolean containsIgnoreCase(String hay, String needle) {
        return hay.toLowerCase(Locale.ROOT).contains(needle.toLowerCase(Locale.ROOT));
    }

    public static String plainLine(Scoreboard sb, PlayerScoreEntry entry) {
        if (entry == null) return "";
        if (entry.display() != null) {
            String disp = ChatFormatting.stripFormatting(entry.display().getString());
            if (disp != null && !disp.isBlank()) {
                return disp.replace('\u00A0', ' ').trim();
            }
        }
        PlayerTeam team = sb.getPlayersTeam(entry.owner());
        if (team != null) {
            StringBuilder out = new StringBuilder();
            if (team.getPlayerPrefix() != null) {
                out.append(team.getPlayerPrefix().getString());
            }
            if (team.getPlayerSuffix() != null) {
                out.append(team.getPlayerSuffix().getString());
            }
            String teamStr = ChatFormatting.stripFormatting(out.toString());
            if (teamStr != null && !teamStr.isBlank()) {
                return teamStr.replace('\u00A0', ' ').trim();
            }
        }
        String raw = PlayerTeam.formatNameForTeam(team, entry.ownerName()).getString();
        String stripped = ChatFormatting.stripFormatting(raw);
        return stripped == null ? "" : stripped.replace('\u00A0', ' ').trim();
    }

    private static void loadPersonalBests() {
        File target = PB_FILE.exists() ? PB_FILE : (LEGACY_PB_FILE.exists() ? LEGACY_PB_FILE : null);
        if (target == null) return;
        try (FileInputStream fis = new FileInputStream(target)) {
            Properties props = new Properties();
            props.load(fis);
            for (String k : props.stringPropertyNames()) {
                long val = Long.parseLong(props.getProperty(k, "0"));
                if (val > 0) {
                    if (k.startsWith("kill.")) BOSS_KILL_PB_MS.put(k.substring(5), val);
                    else if (k.startsWith("quest.")) BOSS_QUEST_PB_MS.put(k.substring(6), val);
                }
            }
        } catch (Throwable ignored) {}
    }

    private static void savePersonalBests() {
        try (FileOutputStream fos = new FileOutputStream(PB_FILE)) {
            Properties props = new Properties();
            for (var e : BOSS_KILL_PB_MS.entrySet()) props.setProperty("kill." + e.getKey(), String.valueOf(e.getValue()));
            for (var e : BOSS_QUEST_PB_MS.entrySet()) props.setProperty("quest." + e.getKey(), String.valueOf(e.getValue()));
            props.store(fos, "Vampy Slayer Personal Bests per Boss & Tier");
        } catch (Throwable ignored) {}
    }
}
