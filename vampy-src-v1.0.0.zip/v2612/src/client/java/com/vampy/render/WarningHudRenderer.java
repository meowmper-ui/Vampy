package com.vampy.render;

import com.vampy.VampyMod;
import com.vampy.config.VampyConfig;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.Map.Entry;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.scores.DisplaySlot;
import net.minecraft.world.scores.Objective;
import net.minecraft.world.scores.PlayerScoreEntry;
import net.minecraft.world.scores.PlayerTeam;
import net.minecraft.world.scores.Scoreboard;

public final class WarningHudRenderer {
    private static long activeSteakNowUntilMs = 0L;
    private static int activeSteakNowColor = 0xFFFF2222;
    public static final String STEAK_NOW_TEXT = "STEAK NOW!";
    private static final Pattern TIMER_PATTERN = Pattern.compile("(\\d+\\.?\\d*)s");
    public static boolean screenOpen = false;
    public static boolean hudDragOpen = false;
    private static final Map<String, WarningHudRenderer.WarningEntry> activeWarnings = new LinkedHashMap<>();
    private static final Set<String> funnyDropKeys = new HashSet<>();
    private static final int HELP_HITS_REQUIRED = 3;
    private static final long HELP_HIT_DEBOUNCE_MS = 50L;
    private static UUID myBossAnchorId = null;
    private static boolean myBossConfirmedByHit = false;
    private static long myBossLastSeenMs = 0L;
    private static long lastBossSpawnChatMs = 0L;
    private static final Map<UUID, Integer> otherBossHitCountsByUuid = new HashMap<>();
    private static UUID helpingBossAnchorId = null;
    private static String helpingOwnerIgn = null;
    private static long lastHelpHitMs = 0L;
    private static long helpingBossLastSeenMs = 0L;
    private static final Map<UUID, Long> ichorFirstSeen = new LinkedHashMap<>();
    private static long lastIchorScan = 0L;
    private static final List<WarningHudRenderer.IchorTimer> ichorTimers = new ArrayList<>();
    private static long lastSpringScan = 0L;
    private static final List<WarningHudRenderer.IchorTimer> springTimers = new ArrayList<>();

    private static final List<Entity> cachedAllBossAnchors = new ArrayList<>(4);
    private static final List<Entity> cachedAllowedBossAnchors = new ArrayList<>(4);
    private static long lastBossAnchorsScanMs = 0L;

   private WarningHudRenderer() {
   }

   private static boolean cachedSteakReady = false;
   private static boolean cachedSlayTheBossSidebar = false;
   private static long lastSidebarCheckMs = 0L;

   public static boolean isAllowedBossSteakReady(Minecraft client) {
      return cachedSteakReady;
   }

   private static boolean computeAllowedBossSteakReady(Minecraft client, List<Entity> entities, List<Entity> allowedAnchors) {
      if (client == null || client.level == null || client.player == null) return false;
      if (!com.vampy.render.SlayerProfitTracker.isInStillgoreChateau()) return false;
      for (int i = 0, n = entities.size(); i < n; i++) {
         Entity e = entities.get(i);
         if (e != null && e.hasCustomName() && e.getCustomName() != null) {
            String raw = e.getCustomName().getString();
            String clean = stripFormatting(raw);
            if (isSteakReadyNametag(clean)) {
               if (isAllowedBossAnchor(e) || isNearAnyAnchorFast(client, allowedAnchors, e.position())) {
                  return true;
               }
            }
         }
      }
      return false;
   }

   private static boolean isSteakReadyNametag(String clean) {
      if (clean == null || clean.isEmpty()) return false;
      return clean.contains("🥩") || clean.contains("\uD83E\uDD69");
   }

   private static boolean isNearAnyAnchorFast(Minecraft client, List<Entity> allowedAnchors, Vec3 pos) {
      for (int i = 0, n = allowedAnchors.size(); i < n; i++) {
         Entity allowed = allowedAnchors.get(i);
         if (allowed != null) {
            double dx = allowed.getX() - pos.x;
            double dz = allowed.getZ() - pos.z;
            double dy = Math.abs(allowed.getY() - pos.y);
            // Ability nametags (TWINCLAW / MANIA / STONEWRAITH) are stacked directly on the same boss column
            // (within ~2.5 blocks horizontally and ~3.5 blocks vertically of the boss anchor).
            if (dx * dx + dz * dz <= 6.25 && dy <= 3.5) {
               return true;
            }
         }
      }
      return false;
   }

   public static boolean isNearAllowedOrLootsharedBoss(Minecraft client, List<Entity> entities, Vec3 pos) {
      List<Entity> allowedAnchors = findAllowedBossAnchors(entities);
      return isNearAnyAnchorFast(client, allowedAnchors, pos);
   }

    public static void triggerExternalWarning(String text, int rgbColor, long lingerMs) {
        if (!com.vampy.render.SlayerProfitTracker.isInStillgoreChateau()) return;
        if (text == null || text.isEmpty()) return;
        if (STEAK_NOW_TEXT.equals(text) && !cachedSteakReady) {
            return;
        }
        long now = System.currentTimeMillis();
        activeSteakNowColor = rgbColor & 0xFFFFFF;
        activeSteakNowUntilMs = now + Math.max(lingerMs, 600L);
        activeWarnings.put(text, new WarningEntry(0xFFFF2222, System.currentTimeMillis() + 250L));
    }

    public static void register() {
      Identifier id = Identifier.fromNamespaceAndPath("vampy", "warning_hud");
      HudElementRegistry.addLast(id, WarningHudRenderer::renderHud);
      Identifier cdId = Identifier.fromNamespaceAndPath("vampy", "hotbar_cooldown_hud");
      HudElementRegistry.addLast(cdId, (graphics, deltaTracker) -> HotbarCooldownOverlay.render(graphics));
   }

   public static String stripFormatting(String s) {
      if (s == null || s.isEmpty()) return "";
      int len = s.length();
      if (s.indexOf('\u00A7') < 0 && s.indexOf('\u00A0') < 0) {
         return s.trim();
      }
      StringBuilder sb = new StringBuilder(len);
      for (int i = 0; i < len; i++) {
         char c = s.charAt(i);
         if (c == '\u00A7' && i + 1 < len) {
            i++;
            continue;
         }
         sb.append(c == '\u00A0' ? ' ' : c);
      }
      return sb.toString().trim();
   }

   public static void onBossSpawnedChat() {
        if (!com.vampy.render.SlayerProfitTracker.isInStillgoreChateau()) return;
      lastBossSpawnChatMs = System.currentTimeMillis();
      myBossAnchorId = null;
      myBossConfirmedByHit = false;
   }

   public static void showFunnyDrop(String funnyMessage, String itemName, int msgColor, int itemColor) {
        if (!com.vampy.render.SlayerProfitTracker.isInStillgoreChateau()) return;
      if (funnyMessage != null && !funnyMessage.isEmpty()) {
         if (itemName != null && !itemName.isEmpty()) {
            long now = System.currentTimeMillis();
            long expiry = now + 2500L;
            if (!funnyDropKeys.isEmpty()) {
               activeWarnings.keySet().removeIf(funnyDropKeys::contains);
               funnyDropKeys.clear();
            }

            String itemLine = "(" + itemName + ")";
            funnyDropKeys.add(funnyMessage);
            funnyDropKeys.add(itemLine);
            activeWarnings.put(funnyMessage, new WarningHudRenderer.WarningEntry(msgColor & 16777215, expiry, 400L));
            activeWarnings.put(itemLine, new WarningHudRenderer.WarningEntry(itemColor & 16777215, expiry, 400L));
         }
      }
   }

   private static boolean isFunnyDropKey(String key) {
      return key != null && funnyDropKeys.contains(key);
   }

   private static void pruneExpiredFunnyDropKeys(long now) {
        if (!com.vampy.render.SlayerProfitTracker.isInStillgoreChateau()) return;
      if (!funnyDropKeys.isEmpty()) {
         funnyDropKeys.removeIf(k -> {
            WarningHudRenderer.WarningEntry e = activeWarnings.get(k);
            return e == null || now > e.expiry + e.fadeMs;
         });
      }
   }

   /**
    * Runs once per client tick (20 Hz) from VampyClient so all warning/ichor/spring/steak/sidebar scans
    * happen immediately on every tick (zero delay!) and NEVER run on the render thread!
    */
   public static void onClientTick(Minecraft client) {
      if (client == null || client.level == null || client.player == null || !com.vampy.render.SlayerProfitTracker.isInStillgoreChateau()) {
         cachedSteakReady = false;
         cachedSlayTheBossSidebar = false;
         return;
      }
      long now = System.currentTimeMillis();
      if (now - lastSidebarCheckMs >= 100L) {
         lastSidebarCheckMs = now;
         boolean prevSlay = cachedSlayTheBossSidebar;
         cachedSlayTheBossSidebar = pollSlayTheBossOnSidebar(client);
         if (cachedSlayTheBossSidebar && !prevSlay) {
            lastBossSpawnChatMs = now;
         }
      }
      List<Entity> entities = NearbyEntityCache.getEntities(client);
      tickHelpingState(client, entities);
      updateBossAnchorsCache(entities, now);
      List<Entity> allowedAnchors = cachedAllowedBossAnchors;
      cachedSteakReady = VampyConfig.isBossSteakAlert() && computeAllowedBossSteakReady(client, entities, allowedAnchors);
      if (cachedSteakReady) {
         activeWarnings.put("STEAK NOW!", new WarningHudRenderer.WarningEntry(0xFFFF2222, now + 350L));
      }
      tickRiftTimeReminder(client);
      if (VampyConfig.isIchorTimer() && now - lastIchorScan >= 50L) {
         lastIchorScan = now;
         scanIchors(client, now);
      }
      if (VampyConfig.isKillerSpringTimer() && now - lastSpringScan >= 50L) {
         lastSpringScan = now;
         scanKillerSprings(client, now);
      }
      // Scan warnings EVERY single tick (50ms) so Twinclaw / Stonewraith / Boss Spawn Soon never lag behind!
      scanForWarningsFast(client, entities, allowedAnchors, now);
   }

   private static void renderHud(GuiGraphicsExtractor graphics, DeltaTracker deltaTracker) {
        if (!com.vampy.render.SlayerProfitTracker.isInStillgoreChateau()) return;
      try {
         Minecraft client = Minecraft.getInstance();
         if (client.level == null || client.player == null) {
            return;
         }

         long now = System.currentTimeMillis();
         renderIchorHud(client, graphics, now);
         renderKillerSpringHud(client, graphics, now);

         boolean enabled = VampyConfig.isWarningsEnabled();
         String preview = VampyConfig.getWarningPreview();
         boolean showPreview = preview != null && !preview.isEmpty() && screenOpen;
         boolean hasForcedPopup = activeWarnings.containsKey("STEAK NOW!") || activeWarnings.containsKey("ONLY 4 MINS LEFT") || activeWarnings.containsKey("Boss spawn soon!") || !funnyDropKeys.isEmpty();
         if (!enabled && !showPreview && !hasForcedPopup) {
            return;
         }

         activeWarnings.entrySet().removeIf(e -> now > e.getValue().expiry + e.getValue().fadeMs);
         pruneExpiredFunnyDropKeys(now);
         Font font = client.font;
         float size = (float)VampyConfig.getWarningSize();
         if (size < 0.5F) {
            size = 0.5F;
         }

         int screenWidth = graphics.guiWidth();
         int screenHeight = graphics.guiHeight();
         float centerX = (float)screenWidth / 2.0F;
         float centerY = (float)screenHeight / 2.0F;
         List<WarningHudRenderer.RenderLine> lines = new ArrayList<>();
         if (enabled || hasForcedPopup) {
            for (Entry<String, WarningHudRenderer.WarningEntry> e : activeWarnings.entrySet()) {
               if (enabled || e.getKey().equals("STEAK NOW!") || e.getKey().equals("ONLY 4 MINS LEFT") || e.getKey().equals("Boss spawn soon!") || isFunnyDropKey(e.getKey())) {
                  int alpha = 255;
                  if (now > e.getValue().expiry) {
                     long fadeMs = Math.max(1L, e.getValue().fadeMs);
                     long fadeElapsed = now - e.getValue().expiry;
                     alpha = (int)(255.0 * (1.0 - (double)fadeElapsed / (double)fadeMs));
                     if (alpha <= 0) {
                        continue;
                     }
                  }

                  lines.add(new WarningHudRenderer.RenderLine(e.getKey(), e.getValue().color, alpha));
               }
            }
         }

         if (showPreview) {
            lines.add(new WarningHudRenderer.RenderLine(preview, VampyConfig.getWarningColor(preview), 255));
         }

         if (lines.isEmpty()) {
            return;
         }

         lines.sort(Comparator.<WarningHudRenderer.RenderLine>comparingInt(l -> linePriority(l.text)).thenComparing(l -> l.text));
         int lineHeight = (int)(14.0F * size);
         int totalHeight = lines.size() * lineHeight;
         int startY = (int)(centerY - (float)totalHeight / 2.0F);

         for (int i = 0; i < lines.size(); i++) {
            WarningHudRenderer.RenderLine line = lines.get(i);
            int y = startY + i * lineHeight;
            int r = line.color >> 16 & 0xFF;
            int g = line.color >> 8 & 0xFF;
            int b = line.color & 0xFF;
            int textColor = line.alpha << 24 | r << 16 | g << 8 | b;
            int shadowAlpha = (int)((double)line.alpha * 0.6);
            int shadowColor = shadowAlpha << 24 | 1052688;
            graphics.pose().pushMatrix();
            graphics.pose().translate(centerX, (float)(y + 1));
            graphics.pose().scale(size, size);
            graphics.pose().translate(-centerX, (float)(-(y + 1)));
            graphics.centeredText(font, Component.literal(line.text), (int)centerX + 1, y + 2, shadowColor);
            graphics.centeredText(font, Component.literal(line.text), (int)centerX, y + 1, textColor);
            graphics.pose().popMatrix();
         }
      } catch (Exception var28) {
      }
   }

   private static int linePriority(String text) {
      if (text == null) {
         return 2;
      } else if (isFunnyDropKey(text)) {
         return text.startsWith("(") ? -1 : -2;
      } else {
         String twin = VampyConfig.resolveWarningDisplay("TWINCLAW");
         String twinCrit = VampyConfig.resolveWarningDisplay("TWINCLAW <0.8s");
         String mania = VampyConfig.resolveWarningDisplay("Mania Over");
         if (!text.startsWith(twin)
            && !text.startsWith(twinCrit)
            && !text.startsWith(mania)
            && !text.startsWith("TWINCLAW")
            && !text.startsWith("SPLASH YO FACE")
            && !text.startsWith("WASH YO FACE")
            && !text.startsWith("MANIA OVER")) {
            for (String key : VampyConfig.warningRuleKeysView()) {
               if (!VampyConfig.isBuiltInBossWarning(key)) {
                  String display = VampyConfig.resolveWarningDisplay(key);
                  if (!display.isEmpty() && text.startsWith(display)) {
                     return 1;
                  }
               }
            }

            for (String replacement : VampyConfig.getTextReplacements().values()) {
               if (!replacement.isEmpty() && text.startsWith(replacement)) {
                  return 1;
               }
            }

            return 2;
         } else {
            return 0;
         }
      }
   }

   private static void renderIchorHud(Minecraft client, GuiGraphicsExtractor graphics, long now) {
        if (!com.vampy.render.SlayerProfitTracker.isInStillgoreChateau()) return;
      if (VampyConfig.isIchorTimer() && !hudDragOpen && !ichorTimers.isEmpty()) {
         Font font = client.font;
         int screenWidth = graphics.guiWidth();
         int screenHeight = graphics.guiHeight();
         float x = (float)(VampyConfig.getIchorHudX() * (double)screenWidth);
         float y = (float)(VampyConfig.getIchorHudY() * (double)screenHeight);
         int lineHeight = 12;
         float scale = (float)VampyConfig.getIchorHudScale();
         graphics.pose().pushMatrix();
         graphics.pose().translate(x, y);
         graphics.pose().scale(scale, scale);
         int curY = 0;

         for (WarningHudRenderer.IchorTimer t : ichorTimers) {
            graphics.centeredText(font, Component.literal(t.text), 0, curY, t.color);
            curY += lineHeight;
         }

         graphics.pose().popMatrix();
      }
   }

   private static void renderKillerSpringHud(Minecraft client, GuiGraphicsExtractor graphics, long now) {
        if (!com.vampy.render.SlayerProfitTracker.isInStillgoreChateau()) return;
      if (VampyConfig.isKillerSpringTimer() && !hudDragOpen && !springTimers.isEmpty()) {
         Font font = client.font;
         int screenWidth = graphics.guiWidth();
         int screenHeight = graphics.guiHeight();
         float x = (float)(VampyConfig.getKillerSpringHudX() * (double)screenWidth);
         float y = (float)(VampyConfig.getKillerSpringHudY() * (double)screenHeight);
         int lineHeight = 12;
         float scale = (float)VampyConfig.getKillerSpringHudScale();
         graphics.pose().pushMatrix();
         graphics.pose().translate(x, y);
         graphics.pose().scale(scale, scale);
         int curY = 0;

         for (WarningHudRenderer.IchorTimer t : springTimers) {
            graphics.centeredText(font, Component.literal(t.text), 0, curY, t.color);
            curY += lineHeight;
         }

         graphics.pose().popMatrix();
      }
   }

   private static void scanKillerSprings(Minecraft client, long now) {
        if (!com.vampy.render.SlayerProfitTracker.isInStillgoreChateau()) return;
      springTimers.clear();
      if (!VampyConfig.isKillerSpringEsp() && !VampyConfig.isKillerSpringTracer()) {
         List<Entity> entities = NearbyEntityCache.getEntities(client);
         KillerSpringTracker.update(client, entities);
      }

      for (KillerSpringTracker.TimerInfo timer : KillerSpringTracker.getActiveTimers()) {
         String text = "SPRING " + String.format("%.1f", timer.seconds) + "s";
         int color = timer.seconds <= 3.0 ? -43691 : -16711936;
         springTimers.add(new WarningHudRenderer.IchorTimer(text, color));
      }
   }

   private static void scanIchors(Minecraft client, long now) {
        if (!com.vampy.render.SlayerProfitTracker.isInStillgoreChateau()) return;
      ichorTimers.clear();
      Set<UUID> seen = new HashSet<>();
      List<Entity> entities = NearbyEntityCache.getEntities(client);
      if (!VampyConfig.isIchorEsp() && !VampyConfig.isIchorTracer()) {
         IchorTracker.update(client, entities);
      }

      for (Entity e : entities) {
         if (e != client.player && IchorTracker.isIchorMarker(e)) {
            seen.add(e.getUUID());
            Long first = ichorFirstSeen.get(e.getUUID());
            if (first == null) {
               first = now;
               ichorFirstSeen.put(e.getUUID(), first);
            }

            double remaining = -1.0;
            if (e.hasCustomName() && e.getCustomName() != null) {
               String nameText = stripFormatting(e.getCustomName().getString());
               int ichorIdx = nameText.toLowerCase(Locale.ROOT).indexOf("ichor");
               Matcher m = TIMER_PATTERN.matcher(nameText);

               while (m.find()) {
                  if (ichorIdx < 0 || m.start() >= ichorIdx) {
                     try {
                        remaining = Double.parseDouble(m.group(1));
                     } catch (Exception var14) {
                     }
                     break;
                  }
               }
            }

            if (remaining < 0.0) {
               remaining = (double)(25000L - (now - first)) / 1000.0;
            }

            if (remaining < 0.0) {
               remaining = 0.0;
            }

            String text = "ICHOR " + String.format("%.1f", remaining) + "s";
            int color = remaining <= 5.0 ? -43691 : -5636096;
            ichorTimers.add(new WarningHudRenderer.IchorTimer(text, color));
         }
      }

      ichorFirstSeen.keySet().retainAll(seen);
   }

   private static boolean isPrimaryBossMarker(Entity e) {
      if (e != null && e.hasCustomName() && e.getCustomName() != null) {
         String clean = stripFormatting(e.getCustomName().getString()).toLowerCase(Locale.ROOT);
         if (clean.isEmpty()) {
            return false;
         } else {
            return clean.contains("spawned by:") ? true : clean.equals("slayer boss") || clean.startsWith("slayer boss ");
         }
      } else {
         return false;
      }
   }

   private static boolean isBloodfiendHealthTag(Entity e) {
      if (e != null && e.hasCustomName() && e.getCustomName() != null) {
         String clean = stripFormatting(e.getCustomName().getString()).toLowerCase(Locale.ROOT);
         return clean.contains("bloodfiend") && (clean.contains("❤") || clean.contains("/"));
      } else {
         return false;
      }
   }

    public static void updateBossAnchorsCache(List<Entity> entities, long now) {
       lastBossAnchorsScanMs = now;
       cachedAllBossAnchors.clear();
       cachedAllowedBossAnchors.clear();

       List<Entity> primary = new ArrayList<>(4);
       for (int i = 0, n = entities.size(); i < n; i++) {
          Entity e = entities.get(i);
          if (isPrimaryBossMarker(e)) {
             primary.add(e);
          }
       }
       cachedAllBossAnchors.addAll(primary);

       for (int i = 0, n = entities.size(); i < n; i++) {
          Entity ex = entities.get(i);
          if (isBloodfiendHealthTag(ex)) {
             boolean covered = false;
             for (int j = 0, m = primary.size(); j < m; j++) {
                if (primary.get(j).position().distanceTo(ex.position()) <= 2.5) {
                   covered = true;
                   break;
                }
             }
             if (!covered) {
                cachedAllBossAnchors.add(ex);
             }
          }
       }

       for (int i = 0, n = cachedAllBossAnchors.size(); i < n; i++) {
          Entity anchor = cachedAllBossAnchors.get(i);
          if (isAllowedBossAnchor(anchor)) {
             cachedAllowedBossAnchors.add(anchor);
          }
       }
    }

    public static List<Entity> findAllBossAnchors(List<Entity> entities) {
       long now = System.currentTimeMillis();
       if (now - lastBossAnchorsScanMs < 60L && !cachedAllBossAnchors.isEmpty()) {
          return cachedAllBossAnchors;
       }
       updateBossAnchorsCache(entities, now);
       return cachedAllBossAnchors;
    }

    public static List<Entity> findAllowedBossAnchors(List<Entity> entities) {
       long now = System.currentTimeMillis();
       if (now - lastBossAnchorsScanMs < 60L && !cachedAllowedBossAnchors.isEmpty()) {
          return cachedAllowedBossAnchors;
       }
       Minecraft client = Minecraft.getInstance();
       tickHelpingState(client, entities);
       updateBossAnchorsCache(entities, now);
       return cachedAllowedBossAnchors;
    }

   public static boolean isMyOwnBossAnchor(Entity anchor) {
      if (anchor == null) return false;
      if (anchor.getUUID().equals(myBossAnchorId)) return true;
      if (anchor.hasCustomName() && anchor.getCustomName() != null) {
         Minecraft client = Minecraft.getInstance();
         String myName = client != null && client.player != null ? client.player.getName().getString().trim() : "";
         String legacyOwner = extractSpawnedByOwner(stripFormatting(anchor.getCustomName().getString()).toLowerCase(Locale.ROOT));
         if (legacyOwner != null && !myName.isEmpty() && legacyOwner.equalsIgnoreCase(myName)) {
            return true;
         }
      }
      return false;
   }

   public static boolean isHelpedBossAnchor(Entity anchor) {
      if (anchor == null) return false;
      return anchor.getUUID().equals(helpingBossAnchorId);
   }

   public static Entity findBossAnchorInColumn(List<Entity> entities, Vec3 at, double maxHorizRange) {
      List<Entity> anchors = findAllBossAnchors(entities);
      Entity best = null;
      double bestHorizSq = maxHorizRange * maxHorizRange;
      for (int i = 0, n = anchors.size(); i < n; i++) {
         Entity e = anchors.get(i);
         double dx = e.getX() - at.x;
         double dz = e.getZ() - at.z;
         double dy = Math.abs(e.getY() - at.y);
         double hSq = dx * dx + dz * dz;
         if (hSq <= bestHorizSq && dy <= 4.0) {
            bestHorizSq = hSq;
            best = e;
         }
      }
      return best;
   }

   public static boolean isNearMyOwnBoss(Minecraft client, List<Entity> entities, Vec3 pos) {
      for (Entity anchor : findAllBossAnchors(entities)) {
         if (isMyOwnBossAnchor(anchor)) {
            double dx = anchor.getX() - pos.x;
            double dz = anchor.getZ() - pos.z;
            if (dx * dx + dz * dz <= 6.25 && Math.abs(anchor.getY() - pos.y) <= 3.5) {
               return true;
            }
         }
      }
      return false;
   }

   public static boolean isNearHelpedBoss(List<Entity> entities, Vec3 pos) {
      for (Entity anchor : findAllBossAnchors(entities)) {
         if (isHelpedBossAnchor(anchor)) {
            double dx = anchor.getX() - pos.x;
            double dz = anchor.getZ() - pos.z;
            if (dx * dx + dz * dz <= 6.25 && Math.abs(anchor.getY() - pos.y) <= 3.5) {
               return true;
            }
         }
      }
      return false;
   }

   public static boolean isAllowedBossAnchor(Entity anchor) {
      if (anchor == null) {
         return false;
      }
      return isMyOwnBossAnchor(anchor) || isHelpedBossAnchor(anchor);
   }

   public static String getBossAnchorOwnerKey(Entity anchor) {
      if (anchor == null) {
         return null;
      } else {
         if (anchor.hasCustomName() && anchor.getCustomName() != null) {
            String legacyOwner = extractSpawnedByOwner(stripFormatting(anchor.getCustomName().getString()).toLowerCase(Locale.ROOT));
            if (legacyOwner != null) {
               return legacyOwner;
            }
         }

         UUID id = anchor.getUUID();
         Minecraft client = Minecraft.getInstance();
         String myName = client != null && client.player != null ? client.player.getName().getString().trim() : "self";
         if (id.equals(myBossAnchorId)) {
            return myName.isEmpty() ? "self" : myName;
         } else if (id.equals(helpingBossAnchorId)) {
            return helpingOwnerIgn != null ? helpingOwnerIgn : "helped_" + id.toString().substring(0, 8);
         } else {
            return null;
         }
      }
   }

   public static boolean hasSlayTheBossOnSidebar(Minecraft client) {
      return cachedSlayTheBossSidebar;
   }

   private static boolean pollSlayTheBossOnSidebar(Minecraft client) {
      if (client != null && client.level != null) {
         try {
            Scoreboard sb = client.level.getScoreboard();
            Objective obj = sb.getDisplayObjective(DisplaySlot.SIDEBAR);
            if (obj == null) {
               return false;
            }

            for (PlayerScoreEntry entry : sb.listPlayerScores(obj)) {
               String plain = plainSidebarLine(sb, entry).toLowerCase(Locale.ROOT);
               if (plain.contains("slay the boss")) {
                  return true;
               }
            }
         } catch (Exception var6) {
         }

         return false;
      } else {
         return false;
      }
   }

   private static String plainSidebarLine(Scoreboard sb, PlayerScoreEntry entry) {
      if (entry.display() != null) {
         return stripFormatting(entry.display().getString());
      }
      StringBuilder out = new StringBuilder();
      PlayerTeam team = sb.getPlayersTeam(entry.owner());
      if (team != null && team.getPlayerPrefix() != null) {
         out.append(team.getPlayerPrefix().getString());
      }

      if (entry.ownerName() != null) {
         out.append(entry.ownerName().getString());
      } else if (entry.owner() != null) {
         out.append(entry.owner());
      }

      if (team != null && team.getPlayerSuffix() != null) {
         out.append(team.getPlayerSuffix().getString());
      }

      return stripFormatting(out.toString());
   }

   public static void onPlayerAttack(Entity attacked) {
        if (!com.vampy.render.SlayerProfitTracker.isInStillgoreChateau()) return;
      try {
         if (attacked == null) {
            return;
         }

         Minecraft client = Minecraft.getInstance();
         if (client.level == null || client.player == null) {
            return;
         }

         if (!isCountableBossHit(attacked)) {
            return;
         }

         Vec3 at = attacked.position();
         AABB area = new AABB(at.x - 4.5, at.y - 4.5, at.z - 4.5, at.x + 4.5, at.y + 4.5, at.z + 4.5);
         List<Entity> nearby = client.level.getEntities((Entity)null, area, e -> true);
         if (!isActualBloodfiendEntity(attacked, nearby)) {
            return;
         }
         Entity anchor = findBossAnchorInColumn(nearby, at, 1.15);
         if (anchor == null) {
            anchor = findBossAnchorInColumn(NearbyEntityCache.getEntities(client), at, 1.15);
         }
         if (anchor == null) {
            return;
         }
         double dx = anchor.getX() - at.x;
         double dz = anchor.getZ() - at.z;
         double dy = anchor.getY() - at.y;
         if (dx * dx + dz * dz > 1.35 || dy < -0.5 || dy > 3.5) {
            return;
         }

         UUID anchorId = anchor.getUUID();
         UUID bodyId = attacked.getUUID();
         // Also find any Bloodfiend health tag in the same column so both SLAYER BOSS and Bloodfiend UUIDs are tracked!
         UUID healthTagId = null;
         for (Entity ne : nearby) {
            if (isBloodfiendHealthTag(ne)) {
               double hdx = ne.getX() - anchor.getX();
               double hdz = ne.getZ() - anchor.getZ();
               if (hdx * hdx + hdz * hdz <= 1.5 && Math.abs(ne.getY() - anchor.getY()) <= 2.5) {
                  healthTagId = ne.getUUID();
                  break;
               }
            }
         }
         long now = System.currentTimeMillis();
         if (anchorId.equals(myBossAnchorId) || (healthTagId != null && healthTagId.equals(myBossAnchorId))) {
            myBossAnchorId = anchorId;
            myBossConfirmedByHit = true;
            myBossLastSeenMs = now;
            return;
         }

         if (anchorId.equals(helpingBossAnchorId) || bodyId.equals(helpingBossAnchorId) || (healthTagId != null && healthTagId.equals(helpingBossAnchorId))) {
            helpingBossAnchorId = anchorId;
            helpingBossLastSeenMs = now;
            return;
         }

         boolean ownBossActive = hasSlayTheBossOnSidebar(client) || now - lastBossSpawnChatMs < 5000L;
         int prevHits = Math.max(
            otherBossHitCountsByUuid.getOrDefault(anchorId, 0),
            Math.max(
               otherBossHitCountsByUuid.getOrDefault(bodyId, 0),
               healthTagId != null ? otherBossHitCountsByUuid.getOrDefault(healthTagId, 0) : 0
            )
         );

         // 1-hit fallback for own boss ONLY when myBossAnchorId is not yet locked and Slay the boss! is active.
         // If myBossAnchorId is already locked onto our own boss, any other boss is a foreign boss and strictly requires 3 hits!
         if (ownBossActive && myBossAnchorId == null && prevHits == 0) {
            myBossAnchorId = anchorId;
            myBossConfirmedByHit = true;
            myBossLastSeenMs = now;
            return;
         }

         if (now - lastHelpHitMs < HELP_HIT_DEBOUNCE_MS) {
            return;
         }

         lastHelpHitMs = now;
         int hits = prevHits + 1;
         otherBossHitCountsByUuid.put(anchorId, hits);
         otherBossHitCountsByUuid.put(bodyId, hits);
         if (healthTagId != null) {
            otherBossHitCountsByUuid.put(healthTagId, hits);
         }
         if (hits >= HELP_HITS_REQUIRED) {
            helpingBossAnchorId = anchorId;
            helpingOwnerIgn = "helped_" + anchorId.toString().substring(0, 8);
            helpingBossLastSeenMs = now;
            VampyMod.LOGGER.info("[Vampy] Helping boss (UUID {}, hits={}) — Lootshare Helper active", anchorId, hits);
         }
      } catch (Exception var11) {
      }
   }

   private static boolean isActualBloodfiendEntity(Entity attacked, List<Entity> nearby) {
      Vec3 at = attacked.position();
      Entity matchedBossTag = null;
      double bestBossTagHorizSq = Double.MAX_VALUE;

      for (Entity e : nearby) {
         if (e == null || e == attacked || !e.hasCustomName() || e.getCustomName() == null) continue;
         String clean = stripFormatting(e.getCustomName().getString());
         String lower = clean.toLowerCase(Locale.ROOT);
         double dx = e.getX() - at.x;
         double dz = e.getZ() - at.z;
         double hSq = dx * dx + dz * dz;
         double dy = e.getY() - at.y;

         // 1) If the attacked entity has a regular Rift vampire mob nametag directly above its head, it is NOT a boss!
         if (hSq <= 0.81 && dy >= 0.2 && dy <= 2.6) {
            if (lower.contains("fledgling") || lower.contains("thrall") || lower.contains("packouden") || lower.contains("vampire")) {
               return false;
            }
         }

         // 2) Boss nametag must be in a tight vertical column directly above the attacked entity (<= 1.12m horizontally)
         if (hSq <= 1.25 && dy >= 0.0 && dy <= 3.2) {
            if (lower.contains("bloodfiend") || lower.contains("slayer boss") || lower.contains("spawned by")) {
               if (hSq < bestBossTagHorizSq) {
                  bestBossTagHorizSq = hSq;
                  matchedBossTag = e;
               }
            }
         }
      }

      if (matchedBossTag == null) {
         return false;
      }

      // 3) Verify no other countable LivingEntity (the real boss body) is horizontally closer to matchedBossTag than attacked is
      double attackedToTagSq = bestBossTagHorizSq;
      for (Entity other : nearby) {
         if (other == null || other == attacked || !isCountableBossHit(other)) continue;
         double odx = other.getX() - matchedBossTag.getX();
         double odz = other.getZ() - matchedBossTag.getZ();
         double ody = matchedBossTag.getY() - other.getY();
         double ohSq = odx * odx + odz * odz;
         if (ody >= 0.0 && ody <= 3.2 && ohSq + 0.08 < attackedToTagSq) {
            return false;
         }
      }

      return true;
   }

   private static boolean isCountableBossHit(Entity attacked) {
      if (attacked instanceof LivingEntity living && living.isAlive()) {
         String typeId = VampyConfig.getEntityTypeId(attacked);
         if ("minecraft:armor_stand".equals(typeId)) {
            return false;
         }

         if (VampyConfig.isRealPlayer(attacked)) {
            return false;
         }

         if (attacked.hasCustomName() && attacked.getCustomName() != null) {
            String lower = stripFormatting(attacked.getCustomName().getString()).toLowerCase(Locale.ROOT);
            if (lower.contains("spawned by")
               || lower.contains("slayer boss")
               || lower.contains("twinclaw")
               || lower.contains("mania")
               || lower.contains("ichor")
               || lower.contains("killer spring")
               || lower.contains("fledgling")
               || lower.contains("thrall")
               || lower.contains("packouden")) {
               return false;
            }
         }

         return true;
      }

      return false;
   }

   public static void clearHelpingState() {
      helpingOwnerIgn = null;
      helpingBossAnchorId = null;
      helpingBossLastSeenMs = 0L;
      otherBossHitCountsByUuid.clear();
   }

   public static boolean isHelpingOtherBoss() {
      return helpingBossAnchorId != null || helpingOwnerIgn != null;
   }

   public static boolean isAnyBossEngagedByPlayer() {
      return myBossAnchorId != null || myBossConfirmedByHit || isHelpingOtherBoss();
   }

   public static String getHelpingOwnerIgn() {
      return helpingOwnerIgn;
   }

   public static boolean isAllowedBossOwner(String owner) {
      Minecraft client = Minecraft.getInstance();
      String playerName = client.player != null ? client.player.getName().getString() : "";
      return isAllowedWarningOwner(owner, playerName);
   }

   public static String parseSpawnedByOwner(String nameText) {
      if (nameText != null && !nameText.isEmpty()) {
         String clean = stripFormatting(nameText).toLowerCase(Locale.ROOT);
         String legacy = extractSpawnedByOwner(clean);
         if (legacy != null) {
            return legacy;
         } else {
            if (clean.equals("slayer boss") || clean.startsWith("slayer boss ")) {
               Minecraft client = Minecraft.getInstance();
               if (myBossAnchorId != null || hasSlayTheBossOnSidebar(client)) {
                  return client != null && client.player != null ? client.player.getName().getString().trim() : "self";
               }

               if (helpingOwnerIgn != null) {
                  return helpingOwnerIgn;
               }
            }

            return null;
         }
      } else {
         return null;
      }
   }

   public static Entity findNearestSpawnedByMarker(List<Entity> entities, Vec3 at, double range) {
      List<Entity> anchors = findAllBossAnchors(entities);
      Entity best = null;
      double bestDist = Double.MAX_VALUE;

      for (Entity e : anchors) {
         double d = e.position().distanceTo(at);
         if (d <= range && d < bestDist) {
            bestDist = d;
            best = e;
         }
      }

      return best;
   }

   public static String findNearestBossOwner(List<Entity> entities, Vec3 at, double range) {
      Entity marker = findNearestSpawnedByMarker(entities, at, range);
      return getBossAnchorOwnerKey(marker);
   }

   public static boolean isOwnedByAllowedAnchor(List<Entity> entities, Vec3 at, double range) {
      Entity marker = findNearestSpawnedByMarker(entities, at, range);
      return isAllowedBossAnchor(marker);
   }

   private static boolean isAllowedWarningOwner(String owner, String playerName) {
      if (owner == null || owner.isEmpty()) {
         return false;
      } else if ("self".equalsIgnoreCase(owner)) {
         return true;
      } else {
         return playerName != null && owner.equalsIgnoreCase(playerName.trim()) ? true : helpingOwnerIgn != null && owner.equalsIgnoreCase(helpingOwnerIgn);
      }
   }

   private static UUID migrateClusterAnchorId(UUID trackedId, List<Entity> anchors, List<Entity> allEntities) {
      if (trackedId == null) {
         return null;
      } else {
         for (Entity a : anchors) {
            if (a.getUUID().equals(trackedId)) {
               return trackedId;
            }
         }

         Entity oldEntity = null;

         for (Entity e : allEntities) {
            if (e != null && trackedId.equals(e.getUUID())) {
               oldEntity = e;
               break;
            }
         }

         if (oldEntity != null) {
            for (Entity ax : anchors) {
               if (ax.position().distanceTo(oldEntity.position()) <= 2.5) {
                  return ax.getUUID();
               }
            }
         }

         return trackedId;
      }
   }

   private static void tickHelpingState(Minecraft client, List<Entity> entities) {
        if (!com.vampy.render.SlayerProfitTracker.isInStillgoreChateau()) return;
      if (client != null && client.level != null && client.player != null) {
         long now = System.currentTimeMillis();
         List<Entity> anchors = findAllBossAnchors(entities);
         myBossAnchorId = migrateClusterAnchorId(myBossAnchorId, anchors, entities);
         helpingBossAnchorId = migrateClusterAnchorId(helpingBossAnchorId, anchors, entities);
         Set<UUID> presentAnchorIds = new HashSet<>();

         for (Entity a : anchors) {
            presentAnchorIds.add(a.getUUID());
         }

         boolean ownBossQuestActive = hasSlayTheBossOnSidebar(client) || now - lastBossSpawnChatMs < 5000L;
         if (!ownBossQuestActive) {
            myBossAnchorId = null;
            myBossConfirmedByHit = false;
            myBossLastSeenMs = 0L;
         } else {
            if (myBossAnchorId != null && presentAnchorIds.contains(myBossAnchorId)) {
               myBossLastSeenMs = now;
            } else if (myBossAnchorId != null && now - myBossLastSeenMs > 2500L) {
               myBossAnchorId = null;
               myBossConfirmedByHit = false;
            }

            if (myBossAnchorId == null && !anchors.isEmpty() && now - lastBossSpawnChatMs <= 2200L) {
               Vec3 playerPos = client.player.position();
               Entity best = null;
               double bestScore = Double.MAX_VALUE;

               for (Entity a : anchors) {
                  if (!a.getUUID().equals(helpingBossAnchorId)) {
                     double dx = a.getX() - playerPos.x;
                     double dz = a.getZ() - playerPos.z;
                     double horizDist = Math.sqrt(dx * dx + dz * dz);
                     double footY = a.getY() - 1.8;
                     double vertDist = Math.abs(footY - playerPos.y);
                     if (horizDist <= 4.5
                           && vertDist <= 3.5
                           && isFreshSpawnBossColumn(entities, a)
                           && !isCloserToAnyOtherRealPlayerHoriz(client, entities, a.position(), horizDist)) {
                        double score = isPrimaryBossMarker(a) ? horizDist : horizDist + 5.0;
                        if (score < bestScore) {
                           bestScore = score;
                           best = a;
                        }
                     }
                  }
               }

               if (best != null) {
                  myBossAnchorId = best.getUUID();
                  myBossLastSeenMs = now;
               }
            }
         }

         if (helpingBossAnchorId == null && !otherBossHitCountsByUuid.isEmpty()) {
            // Keep hit counts for up to 15 seconds while fighting
            if (now - lastHelpHitMs > 15000L) {
               otherBossHitCountsByUuid.clear();
            }
         }

         if (helpingBossAnchorId != null) {
            if (presentAnchorIds.contains(helpingBossAnchorId)) {
               helpingBossLastSeenMs = now;
            } else if (helpingBossLastSeenMs == 0L) {
               helpingBossLastSeenMs = now;
            } else if (now - helpingBossLastSeenMs >= 8000L) {
               VampyMod.LOGGER.info("[Vampy] Helping cleared — helped boss gone");
               clearHelpingState();
            }
         }
      } else {
         myBossAnchorId = null;
         myBossConfirmedByHit = false;
         if (helpingOwnerIgn != null || helpingBossAnchorId != null) {
            clearHelpingState();
         }
      }
   }

   private static final Pattern BOSS_HP_PARSE_PATTERN = Pattern.compile("([0-9][0-9,.]*[kKmMbB]?)(?:\\s*/\\s*([0-9][0-9,.]*[kKmMbB]?))?\\s*[❤♥]");

   private static boolean isFreshSpawnBossColumn(List<Entity> entities, Entity anchor) {
      if (anchor == null) return false;
      Minecraft client = Minecraft.getInstance();
      String myName = client != null && client.player != null ? client.player.getName().getString().trim() : "";

      if (anchor.hasCustomName() && anchor.getCustomName() != null) {
         String legacyOwner = extractSpawnedByOwner(stripFormatting(anchor.getCustomName().getString()).toLowerCase(Locale.ROOT));
         if (legacyOwner != null && !myName.isEmpty()) {
            return legacyOwner.equalsIgnoreCase(myName);
         }
      }

      for (int i = 0, n = entities.size(); i < n; i++) {
         Entity e = entities.get(i);
         if (e == null || !e.hasCustomName() || e.getCustomName() == null) continue;
         double dx = e.getX() - anchor.getX();
         double dz = e.getZ() - anchor.getZ();
         if (dx * dx + dz * dz > 2.25 || Math.abs(e.getY() - anchor.getY()) > 3.0) continue;

         String clean = stripFormatting(e.getCustomName().getString());
         String lower = clean.toLowerCase(Locale.ROOT);
         String legacyOwner = extractSpawnedByOwner(lower);
         if (legacyOwner != null && !myName.isEmpty()) {
            return legacyOwner.equalsIgnoreCase(myName);
         }

         // If this boss column already has a mid-fight ability nametag (MANIA / TWINCLAW / ICHOR / SPRING), it is NOT a fresh spawn!
         if (lower.contains("mania") || lower.contains("twinclaw") || lower.contains("killer spring") || lower.contains("ichor")) {
            return false;
         }

         if (lower.contains("bloodfiend") && (clean.indexOf('❤') >= 0 || clean.indexOf('♥') >= 0)) {
            if (clean.contains("🛡") || clean.contains("🥩") || clean.contains("\uD83E\uDD69")) {
               return false;
            }
            Matcher m = BOSS_HP_PARSE_PATTERN.matcher(clean);
            if (m.find()) {
               double cur = parseBossHpValue(m.group(1));
               double max = m.group(2) != null ? parseBossHpValue(m.group(2)) : -1.0;
               if (cur > 0.0 && max > 0.0) {
                  if (cur / max < 0.92) {
                     return false;
                  }
               } else if (cur > 0.0) {
                  // Rift Bloodfiend displays current HP only (e.g. "☠ Bloodfiend 2,400❤" or "1,800❤").
                  // Tier I=600, II=1100, III=1500, IV=1800, V=2400 (or 3000 with modifiers).
                  // Any mid-fight damaged boss (like 854❤ in the screenshot) is not near a fresh tier max HP!
                  boolean nearFreshTierHp = (cur >= 550 && cur <= 600)
                        || (cur >= 1020 && cur <= 1100)
                        || (cur >= 1380 && cur <= 1500)
                        || (cur >= 1660 && cur <= 1800)
                        || (cur >= 2200 && cur <= 3000);
                  if (!nearFreshTierHp) {
                     return false;
                  }
               }
            }
         }
      }
      return true;
   }

   private static double parseBossHpValue(String s) {
      if (s == null || s.isEmpty()) return -1.0;
      s = s.replace(",", "").trim().toUpperCase(Locale.ROOT);
      double mult = 1.0;
      if (s.endsWith("K")) { mult = 1_000.0; s = s.substring(0, s.length() - 1); }
      else if (s.endsWith("M")) { mult = 1_000_000.0; s = s.substring(0, s.length() - 1); }
      try {
         return Double.parseDouble(s) * mult;
      } catch (NumberFormatException ex) {
         return -1.0;
      }
   }

   private static boolean isCloserToAnyOtherRealPlayerHoriz(Minecraft client, List<Entity> entities, Vec3 bossPos, double myHorizDist) {
      if (client == null || client.player == null) return false;
      for (int i = 0, n = entities.size(); i < n; i++) {
         Entity e = entities.get(i);
         if (e instanceof net.minecraft.world.entity.player.Player p
                 && p != client.player
                 && p.isAlive()
                 && p.getUUID().version() == 4) {
            double dx = p.getX() - bossPos.x;
            double dz = p.getZ() - bossPos.z;
            double otherHoriz = Math.sqrt(dx * dx + dz * dz);
            if (otherHoriz + 0.35 < myHorizDist && Math.abs(p.getY() - (bossPos.y - 1.8)) <= 4.0) {
               return true;
            }
         }
      }
      return false;
   }

   private static String extractSpawnedByOwner(String lowerName) {
      String marker = "spawned by: ";
      int idx = lowerName.indexOf(marker);
      if (idx < 0) {
         return null;
      } else {
         String rest = lowerName.substring(idx + marker.length()).trim();
         if (rest.isEmpty()) {
            return null;
         } else {
            int end;
            for (end = 0; end < rest.length(); end++) {
               char c = rest.charAt(end);
               if (!Character.isLetterOrDigit(c) && c != '_' && c != '-') {
                  break;
               }
            }

            return end == 0 ? null : rest.substring(0, end);
         }
      }
   }

   public static boolean isLikelyBossPrompt(String lower) {
      return lower.length() <= 40 || TIMER_PATTERN.matcher(lower).find();
   }

   public static void triggerMessage(String messageText) {
        if (!com.vampy.render.SlayerProfitTracker.isInStillgoreChateau()) return;
      if (VampyConfig.isWarningsEnabled()) {
         if (messageText != null && !messageText.isEmpty()) {
            String clean = stripFormatting(messageText);
            String lower = clean.toLowerCase(Locale.ROOT);
            String timer = "";
            Matcher timerMatcher = TIMER_PATTERN.matcher(clean);
            if (timerMatcher.find()) {
               timer = timerMatcher.group(1) + "s";
            }

            for (Entry<String, String> rule : VampyConfig.getWarningRules().entrySet()) {
               String trigger = rule.getKey();
               if (!VampyConfig.isBuiltInBossWarning(trigger)
                  && lower.contains(trigger.toLowerCase(Locale.ROOT))
                  && (isLikelyBossPrompt(lower) || trigger.length() >= 3)) {
                  String base = VampyConfig.resolveWarningDisplay(trigger);
                  String popupText = timer.isEmpty() ? base : base + " " + timer;
                  int color = VampyConfig.getWarningColor(trigger);
                  long expiry = System.currentTimeMillis() + 200L;
                  activeWarnings.keySet().removeIf(k -> k.startsWith(base));
                  activeWarnings.put(popupText, new WarningHudRenderer.WarningEntry(color, expiry));
                  return;
               }
            }

            if (isLikelyBossPrompt(lower)) {
               for (Entry<String, String> entry : VampyConfig.getTextReplacements().entrySet()) {
                  if (lower.contains(entry.getKey().toLowerCase(Locale.ROOT))) {
                     String replacementBase = entry.getValue().isEmpty() ? entry.getKey() : entry.getValue();
                     String popupText = timer.isEmpty() ? replacementBase : replacementBase + " " + timer;
                     int color = VampyConfig.getWarningColor(entry.getKey());
                     if (color == -43691) {
                        color = VampyConfig.getWarningColor(replacementBase);
                     }

                     long expiry = System.currentTimeMillis() + 200L;
                     activeWarnings.keySet().removeIf(k -> k.startsWith(replacementBase));
                     activeWarnings.put(popupText, new WarningHudRenderer.WarningEntry(color, expiry));
                     return;
                  }
               }
            }
         }
      }
   }

   private static List<VampyConfig.Warning> scanBuiltInTwinclaws(Minecraft client, List<Entity> allowedEntities) {
      List<VampyConfig.Warning> result = new ArrayList<>();
      Set<String> seen = new HashSet<>();
      if (client.player == null) return result;
      Vec3 playerPos = client.player.position();
      // When fighting our own boss (Slay the boss! on sidebar) or a confirmed helped boss, alert up to 15m horizontally
      // (since during Mania outer ring 4 the player can be 13-14m from the boss when Twinclaw starts!).
      // Only restrict to 5.5m when no boss is engaged and Slay the boss! is NOT active.
      boolean activeFight = hasSlayTheBossOnSidebar(client) || isAnyBossEngagedByPlayer();
      double maxHorizSq = activeFight ? (15.5 * 15.5) : (5.5 * 5.5);

      for (int i = 0, n = allowedEntities.size(); i < n; i++) {
         Entity e = allowedEntities.get(i);
         if (e.hasCustomName() && e.getCustomName() != null) {
            String nameText = stripFormatting(e.getCustomName().getString());
            String lower = nameText.toLowerCase(Locale.ROOT);
            int idx = lower.indexOf("twinclaw");
             
            if (idx >= 0) {
               double dx = e.getX() - playerPos.x;
               double dz = e.getZ() - playerPos.z;
               double dy = Math.abs((e.getY() - 1.8) - playerPos.y);
               if (dx * dx + dz * dz > maxHorizSq || dy > 6.0) {
                  continue;
               }

               double timerSeconds = -1.0;
               String timerStr = "";
               Matcher matcher = TIMER_PATTERN.matcher(nameText);

               while (matcher.find()) {
                  if (matcher.start() >= idx) {
                     timerStr = matcher.group(1) + "s";

                     try {
                        timerSeconds = Double.parseDouble(matcher.group(1));
                     } catch (Exception var16) {
                     }
                     break;
                  }
               }

               String ruleKey;
               String popupText;
               if (timerSeconds >= 0.0 && timerSeconds < 0.8) {
                  ruleKey = "TWINCLAW <0.8s";
                  popupText = VampyConfig.resolveWarningDisplay(ruleKey);
               } else {
                  ruleKey = "TWINCLAW";
                  popupText = VampyConfig.resolveWarningDisplay(ruleKey);
                  if (timerSeconds > 0.0) {
                     popupText = popupText + " " + timerStr;
                  }
               }

               if (seen.add(popupText)) {
                  result.add(new VampyConfig.Warning(popupText, VampyConfig.getWarningColor(ruleKey)));
               }
            }
         }
      }

      return result;
   }

   private static List<VampyConfig.Warning> scanBuiltInMania(Minecraft client, List<Entity> allowedEntities) {
      List<VampyConfig.Warning> result = new ArrayList<>();
      if (client.player == null) return result;
      Vec3 playerPos = client.player.position();
      boolean activeFight = hasSlayTheBossOnSidebar(client) || isAnyBossEngagedByPlayer();
      double maxHorizSq = activeFight ? (16.5 * 16.5) : (7.0 * 7.0);

      for (int i = 0, n = allowedEntities.size(); i < n; i++) {
         Entity e = allowedEntities.get(i);
         if (e.hasCustomName() && e.getCustomName() != null) {
            String nameText = stripFormatting(e.getCustomName().getString());
            int idx = nameText.toLowerCase(Locale.ROOT).indexOf("mania");
            if (idx >= 0) {
               double dx = e.getX() - playerPos.x;
               double dz = e.getZ() - playerPos.z;
               double dy = Math.abs((e.getY() - 1.8) - playerPos.y);
               if (dx * dx + dz * dz > maxHorizSq || dy > 6.5) {
                  continue;
               }

               double timerSeconds = -1.0;
               Matcher matcher = TIMER_PATTERN.matcher(nameText);

               while (matcher.find()) {
                  if (matcher.start() >= idx) {
                     try {
                        timerSeconds = Double.parseDouble(matcher.group(1));
                     } catch (Exception var12) {
                     }
                     break;
                  }
               }

               if (timerSeconds >= 0.0 && timerSeconds <= 2.1) {
                  String ruleKey = "Mania Over";
                  result.add(new VampyConfig.Warning(VampyConfig.resolveWarningDisplay(ruleKey), VampyConfig.getWarningColor(ruleKey)));
               }
            }
         }
      }

      return result;
   }

   private static void tickRiftTimeReminder(Minecraft client) {
        if (!com.vampy.render.SlayerProfitTracker.isInStillgoreChateau()) return;
      RiftTimeReminderTracker.update(client);
      if (RiftTimeReminderTracker.consumeTrigger()) {
         long now = System.currentTimeMillis();
         activeWarnings.put("ONLY 4 MINS LEFT", new WarningHudRenderer.WarningEntry(-43691, now + 2000L, 400L));
      }
   }

   private static void scanForWarningsFast(Minecraft client, List<Entity> entities, List<Entity> allowedAnchors, long now) {
      if (client.level != null && client.player != null) {
         try {
            SlayerSidebarTracker.update(client);
            if (SlayerSidebarTracker.consumeBossSoonTrigger()) {
               activeWarnings.put("Boss spawn soon!", new WarningHudRenderer.WarningEntry(-43691, now + 1500L, 300L));
            }
            if (!VampyConfig.isWarningsEnabled()) {
               return;
            }

            Vec3 playerPos = client.player.position();
            boolean activeFight = hasSlayTheBossOnSidebar(client) || isAnyBossEngagedByPlayer();
            double maxAbilityRangeSq = activeFight ? (16.5 * 16.5) : (6.0 * 6.0);
            List<Entity> allowedEntities = new ArrayList<>(16);
            for (int i = 0, n = entities.size(); i < n; i++) {
               Entity e = entities.get(i);
               if (e != null && e.hasCustomName()) {
                  // Match each ability stand to the boss anchor directly in its own vertical column (<= 2.5m horizontal)
                  // so a foreign boss 5m away cannot hijack or suppress our boss's Twinclaw/Mania stand!
                  Entity columnAnchor = findBossAnchorInColumn(entities, e.position(), 2.5);
                  boolean allowed;
                  if (columnAnchor != null) {
                     allowed = isAllowedBossAnchor(columnAnchor);
                  } else {
                     allowed = isAllowedBossAnchor(e) || isNearAnyAnchorFast(client, allowedAnchors, e.position());
                  }
                  if (allowed) {
                     double dx = e.getX() - playerPos.x;
                     double dz = e.getZ() - playerPos.z;
                     if (dx * dx + dz * dz <= maxAbilityRangeSq && Math.abs((e.getY() - 1.8) - playerPos.y) <= 6.5) {
                        allowedEntities.add(e);
                     }
                  }
               }
            }
            List<VampyConfig.Warning> warnings = new ArrayList<>(VampyConfig.checkWarnings(allowedEntities));
            warnings.addAll(scanBuiltInTwinclaws(client, allowedEntities));
            warnings.addAll(scanBuiltInMania(client, allowedEntities));

            long newExpiry = now + 500L;
            Set<String> newWarningTexts = new HashSet<>();

            for (VampyConfig.Warning warning : warnings) {
               newWarningTexts.add(warning.text);
            }

            activeWarnings.keySet().removeIf(k -> {
               for (Entry<String, String> rule : VampyConfig.getWarningRules().entrySet()) {
                  if (!VampyConfig.isBuiltInBossWarning(rule.getKey())) {
                     String display = VampyConfig.resolveWarningDisplay(rule.getKey());
                     if (k.startsWith(display)) {
                        return false;
                     }
                  }
               }

               for (String replacement : VampyConfig.getTextReplacements().values()) {
                  if (!replacement.isEmpty() && k.startsWith(replacement)) {
                     return false;
                  }
               }

               if (k.equals("Boss spawn soon!")) {
                  return false;
               } else if (k.equals("STEAK NOW!")) {
                  return !cachedSteakReady;
               } else if (k.equals("ONLY 4 MINS LEFT")) {
                  return false;
               } else if (isFunnyDropKey(k)) {
                  return false;
               } else {
                  return k.equals(VampyConfig.getWarningPreview()) ? false : !newWarningTexts.contains(k);
               }
            });

            for (VampyConfig.Warning warning : warnings) {
               activeWarnings.put(warning.text, new WarningHudRenderer.WarningEntry(warning.color, newExpiry));
            }
         } catch (Exception var11) {
            VampyMod.LOGGER.error("[RiftThraller] Scanner error", var11);
         }
      } else {
         if (helpingOwnerIgn != null || helpingBossAnchorId != null) {
            clearHelpingState();
         }
      }
   }

   private static final class IchorTimer {
      final String text;
      final int color;

      IchorTimer(String text, int color) {
         this.text = text;
         this.color = color;
      }
   }

   private static final class RenderLine {
      final String text;
      final int color;
      final int alpha;

      RenderLine(String text, int color, int alpha) {
         this.text = text;
         this.color = color;
         this.alpha = alpha;
      }
   }

   private static final class WarningEntry {
      int color;
      long expiry;
      long fadeMs;

      WarningEntry(int color, long expiry) {
         this(color, expiry, 100L);
      }

      WarningEntry(int color, long expiry, long fadeMs) {
         this.color = color;
         this.expiry = expiry;
         this.fadeMs = fadeMs;
      }
   }
}
