package com.vampy.render;

import com.vampy.VampyMod;
import com.vampy.config.VampyConfig;
import net.fabricmc.fabric.api.client.rendering.v1.level.LevelRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.level.LevelRenderEvents;
import net.minecraft.client.CameraType;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.state.level.CameraRenderState;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;

import java.util.List;

public final class VampyRenderer {
    private static long lastTrackerUpdateTick = -1L;
    private static long lastEffigyUpdateTick = -1L;

    private VampyRenderer() {
    }

    public static void register() {
        LevelRenderEvents.AFTER_SOLID_FEATURES.register(VampyRenderer::renderAfterOpaqueTerrain);
        LevelRenderEvents.BEFORE_GIZMOS.register(VampyRenderer::render);
        net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry.addLast(
                net.minecraft.resources.Identifier.fromNamespaceAndPath(VampyMod.MOD_ID, "render_queue_hud"),
                VampRenderQueue::dispatchHudLayer);
    }

    private static void renderAfterOpaqueTerrain(LevelRenderContext context) {
        try {
            Minecraft client = Minecraft.getInstance();
            if (client.level == null || client.player == null) return;
            if (!SlayerProfitTracker.isInStillgoreChateau()) return;
            CameraRenderState cameraState = context.levelState().cameraRenderState;
            Vec3 cameraPos = cameraState != null && cameraState.pos != null
                    ? cameraState.pos
                    : client.gameRenderer.getMainCamera().position();
            ManiaHelper.renderWorldBlocks(client, context.poseStack(), context.bufferSource(), cameraPos);
        } catch (Exception e) {
            VampyMod.LOGGER.error("Vampy Mania terrain render error", e);
        }
    }

    private static void render(LevelRenderContext context) {
        try {
            Minecraft client = Minecraft.getInstance();
            if (client.level == null || client.player == null) return;

            long gameTick = client.level.getGameTime();
            boolean isNewTick = (gameTick != lastTrackerUpdateTick);
            if (isNewTick) {
                lastTrackerUpdateTick = gameTick;
            }

            CameraRenderState cameraState = context.levelState().cameraRenderState;
            Vec3 cameraPos = cameraState != null && cameraState.pos != null
                    ? cameraState.pos
                    : client.gameRenderer.getMainCamera().position();

            float partialTick = 1.0f;
            try {
                partialTick = client.getDeltaTracker().getGameTimeDeltaPartialTick(false);
            } catch (Throwable ignored) {}

            boolean inChateau = SlayerProfitTracker.isInStillgoreChateau();
            boolean inSlayer = SlayerProfitTracker.isInSlayerLocation();

            if (inChateau && VampyConfig.isEffigyEnabled() && gameTick != lastEffigyUpdateTick) {
                lastEffigyUpdateTick = gameTick;
                EffigyTracker.updateSidebar(client);
                EffigyTracker.updateWorld(client);
            }

            if (isNewTick && inSlayer) {
                OutlineEspManager.updateItems(client);
            }

            if (inChateau) {
                boolean ichorEsp = VampyConfig.isIchorEsp();
                boolean thirdPersonBehind = client.options.getCameraType() == CameraType.THIRD_PERSON_BACK;
                boolean ichorTracer = VampyConfig.isIchorTracer() && thirdPersonBehind;
                boolean springEsp = VampyConfig.isKillerSpringEsp();
                boolean springTracer = VampyConfig.isKillerSpringTracer() && thirdPersonBehind;

                boolean needEntityScan = ichorEsp || ichorTracer || springEsp || springTracer
                        || VampyConfig.isKillerSpringTimer()
                        || VampyConfig.isIchorTimer()
                        || VampyConfig.isLootshareBossCallout();

                if (needEntityScan) {
                    List<Entity> entities = NearbyEntityCache.getEntities(client);

                    if (isNewTick) {
                        if (springEsp || springTracer || VampyConfig.isKillerSpringTimer()) {
                            KillerSpringTracker.update(client, entities);
                        }
                        if (ichorEsp || ichorTracer || VampyConfig.isIchorTimer()) {
                            IchorTracker.update(client, entities);
                        }
                        if (VampyConfig.isLootshareBossCallout()) {
                            LootshareBossTracker.tick(client, entities);
                        }
                    }
                }
            }

            VampRenderQueue.dispatchWorldGizmos(client, cameraState, cameraPos, partialTick);
        } catch (Exception e) {
            VampyMod.LOGGER.error("Vampy render error", e);
        }
    }
}
