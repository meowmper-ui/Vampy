package com.vampy.render;

import com.vampy.config.VampyConfig;
import net.minecraft.client.Camera;
import net.minecraft.client.CameraType;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.state.level.CameraRenderState;
import net.minecraft.gizmos.GizmoStyle;
import net.minecraft.gizmos.Gizmos;
import net.minecraft.gizmos.TextGizmo;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.joml.Vector3f;

import java.util.List;
import java.util.Locale;

/**
 * Pure 3D GPU Gizmos (alwaysOnTop).
 * Emits all boxes, beacons, tracers, and labels directly into Minecraft 26.1.2's native
 * LateDebugPass (Gizmos.cuboid / Gizmos.line / Gizmos.billboardText with .setAlwaysOnTop()),
 * which uses the exact same GPU projection UBO, viewRotationMatrix, and CameraRenderState.pos
 * as the 3D world — completely eliminating 2D/3D HUD projection desync and jitter.
 */
public final class ScreenSpaceEspRenderer {
    private static double camX, camY, camZ;
    private static final java.util.Set<String> RENDERED_LOCAL_IGNS = new java.util.HashSet<>(16);

    private ScreenSpaceEspRenderer() {}

    public static void emitWorldGizmos(
            Minecraft client,
            CameraRenderState cameraState,
            Vec3 cameraPos,
            float partialTick
    ) {
        if (client == null || client.level == null || client.player == null) return;
        if (cameraPos == null) return;

        camX = cameraPos.x;
        camY = cameraPos.y;
        camZ = cameraPos.z;

        // 1. Party Members Nametag Overlay EVERYWHERE (not just Stillgore Chateau!)
        // Iterates client.level.players() O(P) for nearby party members + falls back to VampWebSocketManager
        // for far-away party members (>64m outside Minecraft's entity render distance)!
        if (VampyConfig.isPartyMemberGlow() && !LootshareBossTracker.getPartyMemberIgns().isEmpty()) {
            RENDERED_LOCAL_IGNS.clear();
            for (Player p : client.level.players()) {
                if (SkyblockCombatFeatures.isPartyMemberHumanEntity(client, p, null)) {
                    String pName = p.getGameProfile() != null && p.getGameProfile().name() != null
                            ? p.getGameProfile().name().trim()
                            : SkyblockCombatFeatures.fastStripFormatting(p.getName().getString()).trim();
                    RENDERED_LOCAL_IGNS.add(pName.toLowerCase(Locale.ROOT));
                    double px = Mth.lerp(partialTick, p.xo, p.getX());
                    double py = Mth.lerp(partialTick, p.yo, p.getY()) + p.getBbHeight() + 0.52;
                    double pz = Mth.lerp(partialTick, p.zo, p.getZ());
                    double dist = Math.sqrt(distSqToCam(px, py - 1.0, pz));
                    float distScale = Mth.clamp((float) (dist * 0.045), 0.45f, 2.6f);

                    int memberColor = LootshareBossTracker.resolvePartyMemberColor(client, pName) | 0xFF000000;
                    LootshareBossTracker.DungeonClass dc = LootshareBossTracker.getPartyMemberDungeonClass(client, pName);
                    String classPrefix = (dc != null && VampyConfig.isDungeonClassColors())
                            ? "[" + dc.getShortTag() + "] "
                            : "";
                    String txt = String.format(Locale.ROOT, "%s%s §7(%.0fm)", classPrefix, pName, dist);
                    Gizmos.billboardText(
                            txt,
                            new Vec3(px, py, pz),
                            TextGizmo.Style.forColorAndCentered(memberColor).withScale(distScale)
                    ).setAlwaysOnTop();
                }
            }

            // Render far-away party members via WebSocket live coordinates if they aren't loaded in client.level.players()
            var remoteMap = com.vampy.chat.VampWebSocketManager.getRemotePartyPositions();
            if (!remoteMap.isEmpty()) {
                String myServer = com.vampy.chat.VampWebSocketManager.getCurrentServerId();
                long now = System.currentTimeMillis();
                for (com.vampy.chat.VampWebSocketManager.RemotePartyMemberPos rem : remoteMap.values()) {
                    if (now - rem.lastUpdateMs > 6_000L) continue;
                    String lowerIgn = rem.ign.toLowerCase(Locale.ROOT);
                    if (RENDERED_LOCAL_IGNS.contains(lowerIgn)) continue;
                    if (!LootshareBossTracker.isPartyMember(rem.ign)) continue;
                    // Only render in 3D world if on the same Hypixel server/lobby (or if server ID hasn't been parsed yet)
                    if (!myServer.isEmpty() && !rem.serverId.isEmpty() && !myServer.equalsIgnoreCase(rem.serverId)) {
                        continue;
                    }
                    double rx = Mth.lerp(partialTick, rem.prevX, rem.x);
                    double ry = Mth.lerp(partialTick, rem.prevY, rem.y);
                    double rz = Mth.lerp(partialTick, rem.prevZ, rem.z);

                    int memberColor = LootshareBossTracker.resolvePartyMemberColor(client, rem.ign) | 0xFF000000;
                    LootshareBossTracker.DungeonClass dc = LootshareBossTracker.getPartyMemberDungeonClass(client, rem.ign);
                    String classPrefix = (dc != null && VampyConfig.isDungeonClassColors())
                            ? "[" + dc.getShortTag() + "] "
                            : "";

                    // Draw a player-sized 3D outline box where the far party member stands
                    AABB remoteBox = new AABB(rx - 0.35, ry, rz - 0.35, rx + 0.35, ry + 1.85, rz + 0.35);
                    emitStylizedBox3D(remoteBox, memberColor & 0xFFFFFF, 2.2f);

                    double labelY = ry + 2.35;
                    double dist = Math.sqrt(distSqToCam(rx, ry + 1.0, rz));
                    float distScale = Mth.clamp((float) (dist * 0.045), 0.55f, 3.0f);
                    String txt = String.format(Locale.ROOT, "%s%s §7(%.0fm)", classPrefix, rem.ign, dist);
                    Gizmos.billboardText(
                            txt,
                            new Vec3(rx, labelY, rz),
                            TextGizmo.Style.forColorAndCentered(memberColor).withScale(distScale)
                    ).setAlwaysOnTop();
                }
            }
        }

        // 1b. Chat Coordinate Block Waypoints EVERYWHERE (Block outline + label, no beacon beam!)
        List<LootshareBossTracker.ChatBlockWaypoint> chatWaypoints = LootshareBossTracker.getChatBlockWaypoints();
        if (!chatWaypoints.isEmpty()) {
            for (LootshareBossTracker.ChatBlockWaypoint cwp : chatWaypoints) {
                double bx = cwp.x;
                double by = cwp.y;
                double bz = cwp.z;
                AABB blockBox = new AABB(bx, by, bz, bx + 1.0, by + 1.0, bz + 1.0);
                emitStylizedBox3D(blockBox, 0x55FFFF, 2.8f);

                double cx = bx + 0.5;
                double cy = by + 1.35;
                double cz = bz + 0.5;
                double dist = Math.sqrt(distSqToCam(cx, by + 0.5, cz));
                float scale = Mth.clamp((float) (dist * 0.045), 0.50f, 2.8f);
                String txt = String.format(Locale.ROOT, "§b%s §7(%.0fm)", cwp.label, dist);
                Gizmos.billboardText(
                        txt,
                        new Vec3(cx, cy, cz),
                        TextGizmo.Style.forColorAndCentered(0xFF55FFFF).withScale(scale)
                ).setAlwaysOnTop();
            }
        }

        if (!SlayerProfitTracker.isInStillgoreChateau()) return;

        // Mania Safe Spot Ground Highlight
        ManiaHelper.emitWorldGizmos(client);

        boolean thirdPersonBehind = client.options.getCameraType() == CameraType.THIRD_PERSON_BACK;
        boolean ichorEsp = VampyConfig.isIchorEsp();
        boolean ichorTracer = VampyConfig.isIchorTracer() && thirdPersonBehind;
        boolean springEsp = VampyConfig.isKillerSpringEsp();
        boolean springTracer = VampyConfig.isKillerSpringTracer() && thirdPersonBehind;

        double maxDist = VampyConfig.getRenderDistance();
        double maxDistSq = maxDist * maxDist;

        Vec3 tracerOrigin = computeCrosshairTracerOrigin(cameraState, cameraPos);

        // 2. Effigy Beacon Beams + Grey "Effigy #N" Labels (Beam only, no base block box!)
        if (VampyConfig.isEffigyEnabled() && EffigyTracker.hasRenderSignal()) {
            for (EffigyTracker.Effigy eff : EffigyTracker.all()) {
                if (!EffigyTracker.isSpotNeedsBreak(eff.index)) continue;
                Vec3 c = eff.center;
                emitBeaconColumn3D(c.x, c.y, c.z, 0xFFFF3333);
                double dist = Math.sqrt(distSqToCam(c.x, c.y + 1.5, c.z));
                float scale = Mth.clamp((float) (dist * 0.045), 0.50f, 2.8f);
                Gizmos.billboardText(
                        "Effigy #" + eff.index,
                        new Vec3(c.x, c.y + 2.35, c.z),
                        TextGizmo.Style.forColorAndCentered(0xFFAAAAAA).withScale(scale)
                ).setAlwaysOnTop();
            }
        }

        // 3. Blood Ichor (World-Locked Positions; turns bright pink 0xFF55FF when Player-Boss-Ichor are aligned for Twinclaw!)
        if (ichorEsp || ichorTracer) {
            int baseRgb = VampyConfig.getIchorEspColor() & 0xFFFFFF;
            for (Vec3 p : IchorTracker.getActiveIchorPositions()) {
                if (distSqToCam(p.x, p.y, p.z) > maxDistSq) continue;
                boolean aligned = IchorTracker.isIchorAligned(p, client);
                int rgb = aligned ? IchorTracker.ALIGNED_PINK_RGB : baseRgb;
                if (ichorEsp) {
                    AABB box = new AABB(p.x - 0.45, p.y - 1.65, p.z - 0.45, p.x + 0.45, p.y - 0.65, p.z + 0.45);
                    emitStylizedBox3D(box, rgb, aligned ? 2.8f : 2.5f);
                }
                if (ichorTracer) {
                    emitTracer3D(tracerOrigin, new Vec3(p.x, p.y - 1.15, p.z), rgb, aligned ? 2.6f : 2.2f);
                }
            }
        }

        // 4. Killer Spring (World-Locked X/Y/Z Column)
        if (springEsp || springTracer) {
            int rgb = VampyConfig.getKillerSpringEspColor() & 0xFFFFFF;
            for (KillerSpringTracker.EspAnchor a : KillerSpringTracker.getEspAnchors()) {
                if (distSqToCam(a.x, a.y, a.z) > maxDistSq) continue;
                if (springEsp) {
                    double half = 0.45;
                    AABB box = new AABB(a.x - half, a.y, a.z - half, a.x + half, a.y + a.height, a.z + half);
                    emitStylizedBox3D(box, rgb, 2.5f);
                }
                if (springTracer) {
                    emitTracer3D(tracerOrigin, a.mid(), rgb, 2.2f);
                }
            }
        }

        // 5. Lootsharable Boss Waypoints (Beacon Beam + Text only, no box and no tracer!)
        if (VampyConfig.isLootshareBossCallout()) {
            for (LootshareBossTracker.BossWaypoint wp : LootshareBossTracker.getActiveWaypoints()) {
                Vec3 livePos = LootshareBossTracker.getInterpolatedPos(client, wp, partialTick);
                double wx = livePos.x;
                double wy = livePos.y;
                double wz = livePos.z;
                double dist = Math.sqrt(distSqToCam(wx, wy, wz));

                emitBeaconColumn3D(wx, wy, wz, 0xFFFFAA00);

                float scale = Mth.clamp((float) (dist * 0.045), 0.50f, 2.8f);
                String txt = String.format(Locale.ROOT, "§6§l%s BOSS §e(%.0fm)", wp.tierLabel, dist);
                Gizmos.billboardText(
                        txt,
                        new Vec3(wx, wy + 2.45, wz),
                        TextGizmo.Style.forColorAndCentered(0xFFFFAA00).withScale(scale)
                ).setAlwaysOnTop();
            }
        }
    }

    private static Vec3 computeCrosshairTracerOrigin(CameraRenderState cameraState, Vec3 cameraPos) {
        if (cameraState != null && cameraState.orientation != null) {
            Vector3f forward = new Vector3f(0.0f, 0.0f, -1.0f).rotate(cameraState.orientation);
            return new Vec3(
                    cameraPos.x + forward.x * 2.0,
                    cameraPos.y + forward.y * 2.0,
                    cameraPos.z + forward.z * 2.0
            );
        }
        Minecraft client = Minecraft.getInstance();
        if (client != null && client.gameRenderer != null && client.gameRenderer.getMainCamera() != null) {
            Camera cam = client.gameRenderer.getMainCamera();
            Vector3f forward = new Vector3f(0.0f, 0.0f, -1.0f).rotate(cam.rotation());
            return new Vec3(
                    cameraPos.x + forward.x * 2.0,
                    cameraPos.y + forward.y * 2.0,
                    cameraPos.z + forward.z * 2.0
            );
        }
        return cameraPos;
    }

    private static void emitStylizedBox3D(AABB box, int rgb, float strokeWidth) {
        int strokeColor = 0xB8000000 | (rgb & 0xFFFFFF);
        int fillColor = 0x58000000 | (rgb & 0xFFFFFF);
        Gizmos.cuboid(box, GizmoStyle.strokeAndFill(strokeColor, Math.min(strokeWidth, 2.2f), fillColor)).setAlwaysOnTop();
    }

    private static void emitBeaconColumn3D(double wx, double wy, double wz, int argbColor) {
        int rgb = argbColor & 0xFFFFFF;
        int fillOuter = 0x62000000 | rgb;
        int strokeOuter = 0x78000000 | rgb;

        AABB pillar = new AABB(wx - 0.22, wy, wz - 0.22, wx + 0.22, wy + 180.0, wz + 0.22);
        Gizmos.cuboid(pillar, GizmoStyle.strokeAndFill(strokeOuter, 1.5f, fillOuter)).setAlwaysOnTop();
    }

    private static void emitTracer3D(Vec3 start, Vec3 end, int rgb, float width) {
        int color = 0xE6000000 | (rgb & 0xFFFFFF);
        Gizmos.line(start, end, color, width).setAlwaysOnTop();
    }

    private static double distSqToCam(double x, double y, double z) {
        double dx = x - camX;
        double dy = y - camY;
        double dz = z - camZ;
        return dx * dx + dy * dy + dz * dz;
    }
}
