package com.vampy.render;

import com.vampy.config.VampyConfig;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.core.component.DataComponents;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.CustomData;
import net.minecraft.world.item.component.ItemLore;
import org.joml.Matrix3x2fStack;
import org.lwjgl.glfw.GLFW;

public final class HotbarCooldownOverlay {

    private static final Pattern LORE_COOLDOWN_PATTERN =
            Pattern.compile("(?i)cooldown:\\s*(\\d+(?:\\.\\d+)?)\\s*s");
    private static final Pattern LORE_EFFECT_DURATION_PATTERN =
            Pattern.compile("(?i)(?:for|lasts|duration:?)\\s+(\\d+(?:\\.\\d+)?)\\s*(?:s|sec|seconds)\\b");
    private static final Pattern CHAT_COOLDOWN_PATTERN =
            Pattern.compile("(?i)on cooldown for (\\d+(?:\\.\\d+)?)s");

    private static final class LoreTimings {
        final long displayDurationMs; // Math.max(effectMs, cooldownMs)
        final long reuseCooldownMs;   // реальный Cooldown: Xs до следующего использования
        final boolean hasRightClickAbility;
        final boolean hasLeftClickAbility;

        LoreTimings(long displayDurationMs, long reuseCooldownMs, boolean hasRightClickAbility, boolean hasLeftClickAbility) {
            this.displayDurationMs = displayDurationMs;
            this.reuseCooldownMs = reuseCooldownMs;
            this.hasRightClickAbility = hasRightClickAbility;
            this.hasLeftClickAbility = hasLeftClickAbility;
        }
    }

    private static final class CooldownState {
        String displayName;
        long durationMs;
        long readyAtMs;         // когда закончится отображаемый таймер (эффект или КД)
        long cooldownReadyAtMs; // когда откатится реальный Cooldown предмета и его можно нажать снова
        long lastTriggerMs;
    }

    private static final Map<String, CooldownState> COOLDOWNS = new HashMap<>();
    private static final Map<String, LoreTimings> LORE_TIMINGS_CACHE = new HashMap<>();

    private static boolean wasRightClickDown = false;
    private static boolean wasLeftClickDown = false;
    private static int lastSelectedSlot = -1;
    private static String lastTriggeredKey = null;

    // Randomized 90-130ms slot retention after pressing Holy Ice + queued slot auto-switch
    private static volatile long holyIceLockUntilMs = 0L;
    private static volatile int holyIceLockedSlot = -1;
    private static volatile int queuedHotbarSlotAfterLock = -1;
    private static volatile boolean applyingQueuedSlot = false;

    private HotbarCooldownOverlay() {}

    /**
     * Called from HudScreenMixin$InventorySlotLockMixin on Inventory.setSelectedSlot(slot).
     * Returns true if the slot change should be intercepted and queued until the 90-130ms Holy Ice window ends.
     */
    public static boolean interceptHotbarSlotChange(int newSlot) {
        if (applyingQueuedSlot) return false;
        long lockUntil = holyIceLockUntilMs;
        if (lockUntil <= 0L) return false;
        long now = System.currentTimeMillis();
        if (now < lockUntil && holyIceLockedSlot >= 0 && newSlot >= 0 && newSlot < 9) {
            if (newSlot != holyIceLockedSlot) {
                queuedHotbarSlotAfterLock = newSlot;
                return true;
            }
            // Player pressed the Holy Ice slot again: cancel any queued switch back
            queuedHotbarSlotAfterLock = -1;
            return false;
        }
        return false;
    }

    private static void flushQueuedHotbarSlotIfReady(Minecraft client, long now) {
        if (holyIceLockUntilMs <= 0L) return;
        if (now < holyIceLockUntilMs) return;

        int targetSlot = queuedHotbarSlotAfterLock;
        holyIceLockUntilMs = 0L;
        holyIceLockedSlot = -1;
        queuedHotbarSlotAfterLock = -1;

        if (targetSlot >= 0 && targetSlot < 9 && client != null && client.player != null) {
            try {
                applyingQueuedSlot = true;
                client.player.getInventory().setSelectedSlot(targetSlot);
                if (client.getConnection() != null) {
                    client.getConnection().send(new net.minecraft.network.protocol.game.ServerboundSetCarriedItemPacket(targetSlot));
                }
            } catch (Throwable ignored) {
            } finally {
                applyingQueuedSlot = false;
            }
        }
    }

    private static int getSelectedSlot(Player player) {
        if (player == null) return 0;
        try {
            return player.getInventory().getSelectedSlot();
        } catch (Throwable t) {
            return 0;
        }
    }

    private static boolean isIgnoredCombatWeapon(String key) {
        if (key == null || key.isEmpty()) return true;
        String u = key.toUpperCase(Locale.ROOT);
        return u.contains("DAGGER") || u.contains("KARAMBIT") || u.contains("HEARTMAW") || u.contains("STEAK");
    }

    public static void onChatMessage(String cleanMsg) {
        if (cleanMsg == null || cleanMsg.isEmpty()) return;
        String lower = stripFormatting(cleanMsg).toLowerCase(Locale.ROOT);
        long now = System.currentTimeMillis();

        if ((lower.contains("not enough mana")
                || lower.contains("not enough soulflow")
                || lower.contains("don't have enough mana")
                || lower.contains("not enough health")
                || lower.contains("cannot use this"))
                && lastTriggeredKey != null) {
            CooldownState st = COOLDOWNS.get(lastTriggeredKey);
            if (st != null && now - st.lastTriggerMs < 750L) {
                st.readyAtMs = 0L;
                st.cooldownReadyAtMs = 0L;
            }
            return;
        }

        if (lower.contains("on cooldown for ") && lastTriggeredKey != null) {
            Matcher m = CHAT_COOLDOWN_PATTERN.matcher(lower);
            if (m.find()) {
                CooldownState st = COOLDOWNS.get(lastTriggeredKey);
                if (st != null && now - st.lastTriggerMs < 750L) {
                    float sec = Float.parseFloat(m.group(1));
                    long remMs = Math.round(sec * 1000.0f);
                    st.cooldownReadyAtMs = now + remMs;
                    if (now >= st.readyAtMs) {
                        st.durationMs = Math.max(st.durationMs, remMs);
                        st.readyAtMs = now + remMs;
                    }
                }
            }
        }
    }

    private static void triggerItem(ItemStack stack, long now) {
        triggerItem(stack, now, false);
    }

    private static void triggerItem(ItemStack stack, long now, boolean isLeftClick) {
        if (stack == null || stack.isEmpty()) return;

        String key = getItemKey(stack);
        if (key.isEmpty() || isIgnoredCombatWeapon(key)) return;

        LoreTimings timings = getLoreTimings(stack);
        if (isLeftClick && !timings.hasLeftClickAbility) return;
        if (!isLeftClick && timings.hasLeftClickAbility && !timings.hasRightClickAbility) return;
        if (timings.displayDurationMs <= 0L) return;

        CooldownState st = COOLDOWNS.computeIfAbsent(key, k -> new CooldownState());
        // Минимальный анти-дубль в рамках одного и того же предмета (10мс вместо 40мс),
        // при этом разные предметы в разных слотах имеют разные ключи и срабатывают за 0мс!
        if (now - st.lastTriggerMs < 10L) return;

        if (now < st.cooldownReadyAtMs) {
            lastTriggeredKey = key;
            return;
        }

        st.displayName = stripFormatting(stack.getHoverName().getString());
        st.durationMs = timings.displayDurationMs;
        st.lastTriggerMs = now;
        st.readyAtMs = now + timings.displayDurationMs;
        st.cooldownReadyAtMs = now + timings.reuseCooldownMs;
        lastTriggeredKey = key;

        // If Holy Ice was just activated, engage randomized 90-130ms slot lock so the server registers the right-click!
        String upperKey = key.toUpperCase(Locale.ROOT);
        if (!isLeftClick && (upperKey.contains("HOLY_ICE") || upperKey.contains("HOLY ICE"))) {
            Minecraft mc = Minecraft.getInstance();
            if (mc != null && mc.player != null) {
                int slot = getSelectedSlot(mc.player);
                if (slot >= 0 && slot < 9) {
                    long jitterDelayMs = java.util.concurrent.ThreadLocalRandom.current().nextLong(90L, 131L);
                    holyIceLockedSlot = slot;
                    holyIceLockUntilMs = now + jitterDelayMs;
                    queuedHotbarSlotAfterLock = -1;
                }
            }
        }
    }

    public static void onItemUsed(Minecraft client, InteractionHand hand) {
        if (client == null || client.player == null) return;
        long now = System.currentTimeMillis();
        ItemStack held = client.player.getItemInHand(hand);
        triggerItem(held, now, false);
    }

    private static boolean isRightClickCurrentlyPressed(Minecraft client) {
        if (client == null) return false;
        boolean keyUseDown = client.options != null && client.options.keyUse != null && client.options.keyUse.isDown();
        if (keyUseDown) return true;
        try {
            if (client.getWindow() != null) {
                long win = client.getWindow().handle();
                if (GLFW.glfwGetMouseButton(win, GLFW.GLFW_MOUSE_BUTTON_RIGHT) == GLFW.GLFW_PRESS) {
                    return true;
                }
            }
        } catch (Throwable ignored) {
        }
        return false;
    }

    private static boolean isLeftClickCurrentlyPressed(Minecraft client) {
        if (client == null) return false;
        boolean keyAttackDown = client.options != null && client.options.keyAttack != null && client.options.keyAttack.isDown();
        if (keyAttackDown) return true;
        try {
            if (client.getWindow() != null) {
                long win = client.getWindow().handle();
                if (GLFW.glfwGetMouseButton(win, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS) {
                    return true;
                }
            }
        } catch (Throwable ignored) {
        }
        return false;
    }

    public static void pollFastUse(Minecraft client) {
        if (client == null || client.player == null || client.level == null) {
            wasRightClickDown = false;
            wasLeftClickDown = false;
            lastSelectedSlot = -1;
            holyIceLockUntilMs = 0L;
            holyIceLockedSlot = -1;
            queuedHotbarSlotAfterLock = -1;
            return;
        }
        long now = System.currentTimeMillis();
        flushQueuedHotbarSlotIfReady(client, now);

        if (client.screen != null) {
            wasRightClickDown = false;
            wasLeftClickDown = false;
            lastSelectedSlot = getSelectedSlot(client.player);
            return;
        }

        int currentSlot = getSelectedSlot(client.player);
        boolean rmbDown = isRightClickCurrentlyPressed(client);
        boolean lmbDown = isLeftClickCurrentlyPressed(client);

        if (rmbDown && (!wasRightClickDown || currentSlot != lastSelectedSlot)) {
            ItemStack held = client.player.getMainHandItem();
            triggerItem(held, now, false);
        }
        if (lmbDown && !wasLeftClickDown) {
            ItemStack held = client.player.getMainHandItem();
            triggerItem(held, now, true);
        }

        wasRightClickDown = rmbDown;
        wasLeftClickDown = lmbDown;
        lastSelectedSlot = currentSlot;
    }

    public static void onClientTick(Minecraft client) {
        pollFastUse(client);
    }

    public static void render(GuiGraphicsExtractor context) {
        Minecraft client = Minecraft.getInstance();
        // Опрашиваем прямо в рендере (каждый кадр 200+ FPS), чтобы ловить 1-тиковые и суб-тиковые свапы!
        pollFastUse(client);

        if (!VampyConfig.isItemCooldownOverlay()) return;
        if (client.player == null || client.options.hideGui) return;

        Player player = client.player;
        Font font = client.font;
        long now = System.currentTimeMillis();
        boolean vampStyle = (VampyConfig.getGuiStyle() == VampyConfig.GuiStyle.VAMP);

        double customX = VampyConfig.getHotbarCdX();
        double customY = VampyConfig.getHotbarCdY();

        if (customX >= 0.0 && customY >= 0.0) {
            int sw = context.guiWidth();
            int sh = context.guiHeight();
            int px = (int) Math.round(customX * sw);
            int py = (int) Math.round(customY * sh);
            float scale = (float) VampyConfig.getHotbarCdScale();
            renderFloatingHud(context, font, player, now, px, py, scale, vampStyle, false);
            return;
        }

        int sw = context.guiWidth();
        int sh = context.guiHeight();
        int baseX = sw / 2 - 88;
        int baseY = sh - 19;

        for (int slot = 0; slot < 9; slot++) {
            ItemStack stack = player.getInventory().getItem(slot);
            if (stack.isEmpty()) continue;

            String key = getItemKey(stack);
            if (key.isEmpty() || isIgnoredCombatWeapon(key)) continue;

            CooldownState st = COOLDOWNS.get(key);
            if (st != null && now < st.readyAtMs && st.durationMs > 0L) {
                long rem = st.readyAtMs - now;
                float remainingSec = rem / 1000.0f;
                if (remainingSec > 0.04f) {
                    float progress = Math.clamp((float) rem / (float) st.durationMs, 0.0f, 1.0f);
                    int barColor = key.contains("ICE") ? 0xFF00E5FF : (vampStyle ? 0xFFE03050 : 0xFF00E5FF);
                    int slotX = baseX + slot * 20;
                    int slotY = baseY;
                    drawSlotCooldownOverlay(context, font, slotX, slotY, remainingSec, progress, barColor, vampStyle);
                }
            }
        }
    }

    public static void renderContainerSlots(
            net.minecraft.client.gui.screens.inventory.AbstractContainerScreen<?> screen,
            GuiGraphicsExtractor context,
            int leftPos,
            int topPos
    ) {
        if (!VampyConfig.isItemCooldownOverlay()) return;
        if (screen == null || screen.getMenu() == null) return;

        Minecraft client = Minecraft.getInstance();
        if (client == null || client.font == null) return;

        Font font = client.font;
        long now = System.currentTimeMillis();
        boolean vampStyle = (VampyConfig.getGuiStyle() == VampyConfig.GuiStyle.VAMP);

        for (net.minecraft.world.inventory.Slot slot : screen.getMenu().slots) {
            if (slot == null || !slot.isActive()) continue;
            ItemStack stack = slot.getItem();
            if (stack == null || stack.isEmpty()) continue;

            String key = getItemKey(stack);
            if (key.isEmpty() || isIgnoredCombatWeapon(key)) continue;

            CooldownState st = COOLDOWNS.get(key);
            if (st != null && now < st.readyAtMs && st.durationMs > 0L) {
                long rem = st.readyAtMs - now;
                float remainingSec = rem / 1000.0f;
                if (remainingSec > 0.04f) {
                    float progress = Math.clamp((float) rem / (float) st.durationMs, 0.0f, 1.0f);
                    int barColor = key.contains("ICE") ? 0xFF00E5FF : (vampStyle ? 0xFFE03050 : 0xFF00E5FF);
                    int slotX = leftPos + slot.x;
                    int slotY = topPos + slot.y;
                    drawSlotCooldownOverlay(context, font, slotX, slotY, remainingSec, progress, barColor, vampStyle);
                }
            }
        }
    }

    public static void renderSample(GuiGraphicsExtractor context, Font font, int x, int y) {
        Minecraft client = Minecraft.getInstance();
        boolean vampStyle = (VampyConfig.getGuiStyle() == VampyConfig.GuiStyle.VAMP);
        float scale = (float) VampyConfig.getHotbarCdScale();
        renderFloatingHud(context, font, client.player, System.currentTimeMillis(), x, y, scale, vampStyle, true);
    }

    public static int panelWidth(Font font) {
        float scale = (float) VampyConfig.getHotbarCdScale();
        return Math.round(118 * scale);
    }

    public static int panelHeight(Font font) {
        float scale = (float) VampyConfig.getHotbarCdScale();
        return Math.round(38 * scale);
    }

    private static void renderFloatingHud(
            GuiGraphicsExtractor context,
            Font font,
            Player player,
            long now,
            int x,
            int y,
            float scale,
            boolean vampStyle,
            boolean sampleMode
    ) {
        List<String> lines = new ArrayList<>();
        List<Integer> colors = new ArrayList<>();

        if (sampleMode) {
            lines.add("Holy Ice: 2.4s");
            colors.add(0xFF55FFFF);
            lines.add("Weirder Tuba: 28.5s");
            colors.add(0xFFFF5577);
        } else if (player != null) {
            java.util.Set<String> shownKeys = new java.util.HashSet<>();
            for (int slot = 0; slot < 36; slot++) {
                ItemStack stack = player.getInventory().getItem(slot);
                if (stack.isEmpty()) continue;
                String key = getItemKey(stack);
                if (key.isEmpty() || isIgnoredCombatWeapon(key) || !shownKeys.add(key)) continue;
                CooldownState st = COOLDOWNS.get(key);
                if (st != null && now < st.readyAtMs) {
                    float sec = (st.readyAtMs - now) / 1000.0f;
                    String name = (st.displayName != null && !st.displayName.isEmpty())
                            ? st.displayName
                            : stripFormatting(stack.getHoverName().getString());
                    lines.add(String.format(Locale.ROOT, "%s: %.1fs", name, sec));
                    colors.add(key.contains("ICE") ? 0xFF55FFFF : (vampStyle ? 0xFFFF5577 : 0xFFFFAA00));
                }
            }
        }

        if (lines.isEmpty()) return;

        int padX = 6;
        int padY = 5;
        int lineStep = 11;
        int maxW = 96;
        String header = "Cooldowns";
        maxW = Math.max(maxW, font.width(header));
        for (String s : lines) {
            maxW = Math.max(maxW, font.width(s));
        }

        int boxW = maxW + padX * 2;
        int boxH = (lines.size() + 1) * lineStep + padY * 2;

        Matrix3x2fStack matrices = context.pose();
        matrices.pushMatrix();
        matrices.translate(x, y);
        matrices.scale(scale, scale);

        if (vampStyle) {
            context.fill(0, 0, boxW, boxH, 0xC80D070E);
            context.fill(0, 0, boxW, 1, 0xFFE03050);
            context.fill(0, boxH - 1, boxW, boxH, 0xFFE03050);
            context.fill(0, 1, 1, boxH - 1, 0xFFE03050);
            context.fill(boxW - 1, 1, boxW, boxH - 1, 0xFFE03050);
            context.text(font, "§c§lCooldowns", padX, padY, 0xFFFFFFFF, true);
        } else {
            context.fill(0, 0, boxW, boxH, 0x90000000);
            context.fill(0, 0, boxW, 1, 0x60FFFFFF);
            context.fill(0, boxH - 1, boxW, boxH, 0x40FFFFFF);
            context.text(font, "§fCooldowns", padX, padY, 0xFFFFFFFF, true);
        }

        int ty = padY + lineStep;
        for (int i = 0; i < lines.size(); i++) {
            context.text(font, lines.get(i), padX, ty, colors.get(i), true);
            ty += lineStep;
        }

        matrices.popMatrix();
    }

    private static void drawSlotCooldownOverlay(
            GuiGraphicsExtractor context,
            Font font,
            int slotX,
            int slotY,
            float remainingSec,
            float progress,
            int barColor,
            boolean vampStyle
    ) {
        int curtainH = Math.clamp(Math.round(16.0f * progress), 1, 16);
        int bgTint = vampStyle ? 0x8814080E : 0x78000000;
        context.fill(slotX, slotY + (16 - curtainH), slotX + 16, slotY + 16, bgTint);

        context.fill(slotX + 1, slotY + 14, slotX + 15, slotY + 16, 0xAA08080C);
        int fillW = Math.clamp(Math.round(14.0f * (1.0f - progress)), 1, 14);
        context.fill(slotX + 1, slotY + 14, slotX + 1 + fillW, slotY + 15, barColor);

        String label = remainingSec >= 10.0f
                ? String.format(Locale.ROOT, "%ds", Math.round(remainingSec))
                : String.format(Locale.ROOT, "%.1f", remainingSec);

        int textColor;
        if (remainingSec <= 1.0f) {
            textColor = 0xFF55FF55;
        } else if (remainingSec <= 2.5f) {
            textColor = 0xFFFFFF55;
        } else {
            textColor = vampStyle ? 0xFFFF5577 : 0xFFFFAA00;
        }

        float scale = 0.75f;
        int textW = font.width(label);
        float drawX = slotX + (16.0f - textW * scale) / 2.0f + 0.5f;
        float drawY = slotY + 4.0f;

        Matrix3x2fStack matrices = context.pose();
        matrices.pushMatrix();
        matrices.translate(drawX, drawY);
        matrices.scale(scale, scale);
        context.text(font, label, 0, 0, textColor, true);
        matrices.popMatrix();
    }

    private static LoreTimings getLoreTimings(ItemStack stack) {
        if (stack == null || stack.isEmpty()) return new LoreTimings(0L, 0L, false, false);
        String key = getItemKey(stack);
        if (!key.isEmpty() && LORE_TIMINGS_CACHE.containsKey(key)) {
            return LORE_TIMINGS_CACHE.get(key);
        }

        double maxCooldownSec = 0.0;
        double maxEffectSec = 0.0;
        boolean inRightClickAbility = false;
        boolean inLeftClickAbility = false;

        try {
            ItemLore lore = stack.get(DataComponents.LORE);
            if (lore != null) {
                for (Component line : lore.lines()) {
                    String clean = stripFormatting(line.getString());
                    String upper = clean.toUpperCase(Locale.ROOT);

                    if (upper.contains("ABILITY:")) {
                        if (upper.contains("RIGHT CLICK") || upper.contains("USE")) {
                            inRightClickAbility = true;
                        }
                        if (upper.contains("LEFT CLICK")) {
                            inLeftClickAbility = true;
                        }
                    }

                    Matcher cdMatcher = LORE_COOLDOWN_PATTERN.matcher(clean);
                    if (cdMatcher.find()) {
                        double sec = Double.parseDouble(cdMatcher.group(1));
                        if (sec > 0.0 && sec <= 600.0) {
                            maxCooldownSec = Math.max(maxCooldownSec, sec);
                        }
                    }

                    if (inRightClickAbility || inLeftClickAbility || maxCooldownSec > 0.0) {
                        Matcher effMatcher = LORE_EFFECT_DURATION_PATTERN.matcher(clean);
                        while (effMatcher.find()) {
                            double sec = Double.parseDouble(effMatcher.group(1));
                            if (sec > 0.0 && sec <= 600.0) {
                                maxEffectSec = Math.max(maxEffectSec, sec);
                            }
                        }
                    }
                }
            }
        } catch (Exception ignored) {}

        // Хардкод-фоллбеки для ключевых предметов на случай кастомного лора
        String uKey = key.toUpperCase(Locale.ROOT);
        if (uKey.contains("HOLY_ICE") || uKey.contains("HOLY ICE")) {
            inRightClickAbility = true;
            if (maxCooldownSec <= 0.0) maxCooldownSec = 4.0;
            if (maxEffectSec <= 0.0) maxEffectSec = 1.5;
        } else if (uKey.contains("WEIRDER_TUBA") || uKey.contains("WEIRDER TUBA")) {
            inRightClickAbility = true;
            if (maxCooldownSec <= 0.0) maxCooldownSec = 20.0;
            if (maxEffectSec <= 0.0) maxEffectSec = 30.0;
        } else if (uKey.contains("WEIRD_TUBA") || uKey.contains("WEIRD TUBA")) {
            inRightClickAbility = true;
            if (maxCooldownSec <= 0.0) maxCooldownSec = 20.0;
            if (maxEffectSec <= 0.0) maxEffectSec = 20.0;
        } else if (uKey.contains("GYROKINETIC_WAND") || uKey.contains("GYROKINETIC WAND")) {
            inLeftClickAbility = true;
            if (maxCooldownSec <= 0.0) maxCooldownSec = 10.0;
            if (maxEffectSec <= 0.0) maxEffectSec = 6.0;
        } else if (uKey.contains("WAND_OF_ATONEMENT") || uKey.contains("WAND_OF_RESTORATION")
                || uKey.contains("WAND_OF_MENDING") || uKey.contains("WAND_OF_HEALING")) {
            inRightClickAbility = true;
            if (maxCooldownSec <= 0.0) maxCooldownSec = 1.0;
            if (maxEffectSec <= 0.0) maxEffectSec = 7.0;
        }

        double bestSec = Math.max(maxCooldownSec, maxEffectSec);
        if (maxCooldownSec <= 0.0 && !inRightClickAbility && !inLeftClickAbility) {
            bestSec = 0.0;
        }
        if (bestSec > 0.0 && !inRightClickAbility && !inLeftClickAbility) {
            inRightClickAbility = true;
        }

        long displayMs = bestSec > 0.0 ? Math.round(bestSec * 1000.0) + 50L : 0L;
        long reuseCdMs = maxCooldownSec > 0.0 ? Math.round(maxCooldownSec * 1000.0) : displayMs;
        LoreTimings result = new LoreTimings(displayMs, reuseCdMs, inRightClickAbility, inLeftClickAbility);
        if (!key.isEmpty()) {
            LORE_TIMINGS_CACHE.put(key, result);
        }
        return result;
    }

    private static String getItemKey(ItemStack stack) {
        if (stack == null || stack.isEmpty()) return "";
        String sbId = getSkyblockId(stack);
        if (!sbId.isEmpty()) return sbId;
        return stripFormatting(stack.getHoverName().getString()).toUpperCase(Locale.ROOT);
    }

    private static String getSkyblockId(ItemStack stack) {
        try {
            CustomData customData = stack.get(DataComponents.CUSTOM_DATA);
            if (customData != null) {
                CompoundTag tag = customData.copyTag();
                if (tag.contains("id")) {
                    return tag.getString("id").orElse("");
                }
                if (tag.contains("ExtraAttributes")) {
                    CompoundTag extra = tag.getCompound("ExtraAttributes").orElse(null);
                    if (extra != null && extra.contains("id")) {
                        return extra.getString("id").orElse("");
                    }
                }
            }
        } catch (Exception ignored) {}
        return "";
    }

    private static String stripFormatting(String s) {
        if (s == null) return "";
        return s.replaceAll("(?i)§[0-9A-FK-ORX]", "").trim();
    }
}
