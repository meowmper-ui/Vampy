package com.vampy.render;

import com.vampy.VampyMod;
import com.vampy.chat.ClientModChat;
import com.vampy.config.VampyConfig;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientPacketListener;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.minecraft.client.multiplayer.PlayerInfo;
import net.minecraft.world.scores.DisplaySlot;
import net.minecraft.world.scores.Objective;
import net.minecraft.world.scores.PlayerScoreEntry;
import net.minecraft.world.scores.PlayerTeam;
import net.minecraft.world.scores.Scoreboard;

/**
 * Detects low-HP Tier IV (<=1080 HP) and Tier V (<=1200 HP) Riftstalker Bloodfiends
 * in render distance, sends "Lootsharable <tier> boss at <x> <y> <z>" to party chat (/pc),
 * maintains 3D beacon waypoints for the party, and manages clickable / auto chat block waypoints.
 */
public final class LootshareBossTracker {

    private static final long WAYPOINT_DURATION_MS = 45_000L;
    private static final long CHAT_WAYPOINT_DURATION_MS = 60_000L;
    private static final long CHAT_COOLDOWN_MS = 2_500L;

    // Matches "980/2,400❤", "1,150❤", "1.1k/2.4k❤", etc. Group 1+2 = current HP before optional "/max"
    private static final Pattern SLASH_HP_PATTERN = Pattern.compile("([0-9][0-9,.]*)\\s*([kKmM])?\\s*/\\s*([0-9][0-9,.]*)\\s*([kKmM])?\\s*[❤♥]");
    private static final Pattern DIRECT_HP_PATTERN = Pattern.compile("([0-9][0-9,.]*)\\s*([kKmM])?\\s*[❤♥]");
    private static final Pattern PARTY_CALLOUT_PATTERN = Pattern.compile(
            "(?i)(?:lootsharable\\s+)?(t5|t4|t3|tier\\s*5|tier\\s*4|tier\\s*3|v|iv|iii)\\s+boss(?:\\s*\\([^)]*\\))?\\s+at\\s+(-?\\d+)[,\\s]+(-?\\d+)[,\\s]+(-?\\d+)");

    // Matches labeled coords like "x: -120, y: 72, z: 45" or "X=-120 Y=72 Z=45"
    private static final Pattern LABELED_COORDS_PATTERN = Pattern.compile(
            "(?i)\\bx\\s*[:=]\\s*(-?\\d{1,5})\\s*[,;/\\s]+\\s*y\\s*[:=]\\s*(-?\\d{1,4})\\s*[,;/\\s]+\\s*z\\s*[:=]\\s*(-?\\d{1,5})\\b");
    // Matches plain 3-coordinate triples like "-120 72 45" or "249, 83, 115"
    private static final Pattern PLAIN_COORDS_PATTERN = Pattern.compile(
            "(?<![0-9A-Za-z_/.:-])(-?\\d{1,4})(?:\\s*,\\s*|\\s+)(?:([0-9]{1,3})(?:\\s*,\\s*|\\s+))(-?\\d{1,4})(?![0-9A-Za-z_/.:-])");

    private static final Map<UUID, Long> announcedBossAnchors = new LinkedHashMap<>();
    private static final List<AnnouncedSpot> announcedBossSpots = new ArrayList<>();
    private static final Map<String, BossWaypoint> activeWaypoints = new LinkedHashMap<>();
    private static final Map<String, ChatBlockWaypoint> chatBlockWaypoints = new LinkedHashMap<>();
    private static long lastChatSentMs = 0L;

    private static final class AnnouncedSpot {
        final int tier;
        double x, y, z;
        long timeMs;

        AnnouncedSpot(int tier, double x, double y, double z, long timeMs) {
            this.tier = tier;
            this.x = x;
            this.y = y;
            this.z = z;
            this.timeMs = timeMs;
        }
    }

    public static final class BossWaypoint {
        public final String key;
        public final String tierLabel;
        public final String sender;
        public double x, y, z;
        public UUID trackedEntityId;
        public UUID trackedAnchorId;
        public Entity trackedEntity;
        public boolean wasSeenInWorld;
        public int missingTicks;
        public final long createdAtMs;
        public long expiresAtMs;

        public BossWaypoint(String key, String tierLabel, String sender, double x, double y, double z, UUID trackedEntityId, UUID trackedAnchorId, Entity trackedEntity, long now) {
            this.key = key;
            this.tierLabel = tierLabel;
            this.sender = sender;
            this.x = x;
            this.y = y;
            this.z = z;
            this.trackedEntityId = trackedEntityId;
            this.trackedAnchorId = trackedAnchorId;
            this.trackedEntity = trackedEntity;
            this.wasSeenInWorld = (trackedEntity != null || trackedEntityId != null || trackedAnchorId != null);
            this.missingTicks = 0;
            this.createdAtMs = now;
            this.expiresAtMs = now + WAYPOINT_DURATION_MS;
        }
    }

    public static final class ChatBlockWaypoint {
        public final String key;
        public final String label;
        public final int x, y, z;
        public final long createdAtMs;
        public long expiresAtMs;

        public ChatBlockWaypoint(String key, String label, int x, int y, int z, long now) {
            this.key = key;
            this.label = label;
            this.x = x;
            this.y = y;
            this.z = z;
            this.createdAtMs = now;
            this.expiresAtMs = now + CHAT_WAYPOINT_DURATION_MS;
        }
    }

    private LootshareBossTracker() {}

    public static Vec3 getInterpolatedPos(Minecraft client, BossWaypoint wp, float partialTick) {
        if (wp == null) return Vec3.ZERO;
        return new Vec3(wp.x, wp.y, wp.z);
    }

    public static List<ChatBlockWaypoint> getChatBlockWaypoints() {
        if (chatBlockWaypoints.isEmpty()) {
            return java.util.Collections.emptyList();
        }
        long now = System.currentTimeMillis();
        Minecraft mc = Minecraft.getInstance();
        Iterator<Map.Entry<String, ChatBlockWaypoint>> it = chatBlockWaypoints.entrySet().iterator();
        while (it.hasNext()) {
            ChatBlockWaypoint cwp = it.next().getValue();
            if (now > cwp.expiresAtMs) {
                it.remove();
                continue;
            }
            if (mc != null && mc.player != null) {
                double dx = mc.player.getX() - (cwp.x + 0.5);
                double dy = mc.player.getY() - cwp.y;
                double dz = mc.player.getZ() - (cwp.z + 0.5);
                if (dx * dx + dy * dy + dz * dz <= 9.0 && now - cwp.createdAtMs > 2500L) {
                    it.remove();
                }
            }
        }
        if (chatBlockWaypoints.isEmpty()) {
            return java.util.Collections.emptyList();
        }
        return new ArrayList<>(chatBlockWaypoints.values());
    }

    public static void clearChatBlockWaypoints() {
        chatBlockWaypoints.clear();
    }

    public static boolean handleClickedChatLineForWaypoint(String rawLine) {
        if (rawLine == null || rawLine.isEmpty()) return false;
        String clean = ChatFormatting.stripFormatting(rawLine).trim();
        if (clean.isEmpty()) return false;

        int[] coords = extractCoordinatesFromText(clean);
        if (coords == null) return false;

        int x = coords[0];
        int y = coords[1];
        int z = coords[2];
        String sender = extractSenderLabel(clean);
        String posKey = x + "," + y + "," + z;

        if (chatBlockWaypoints.containsKey(posKey)) {
            chatBlockWaypoints.remove(posKey);
            ClientModChat.info(String.format(Locale.ROOT, "§7Removed waypoint at §b%d %d %d", x, y, z));
            return true;
        }

        String label = (sender != null && !sender.isEmpty()) ? sender : String.format(Locale.ROOT, "%d %d %d", x, y, z);
        long now = System.currentTimeMillis();
        chatBlockWaypoints.put(posKey, new ChatBlockWaypoint(posKey, label, x, y, z, now));
        ClientModChat.info(String.format(Locale.ROOT, "§aAdded waypoint §b%s §7at §e%d %d %d §8(click again to remove)", label, x, y, z));
        return true;
    }

    private static void maybeAutoAddChatWaypoint(String clean) {
        if (!VampyConfig.isAutoChatWaypoints()) return;
        if (clean == null || clean.isEmpty()) return;
        if (clean.startsWith("[Vampy]") || clean.contains("[Vampy]")) return;
        // Skip boss callout lines since they already have their own boss beacon waypoint
        if (PARTY_CALLOUT_PATTERN.matcher(clean).find()) return;

        int[] coords = extractCoordinatesFromText(clean);
        if (coords == null) return;

        int x = coords[0];
        int y = coords[1];
        int z = coords[2];
        String sender = extractSenderLabel(clean);

        // Ignore our own chat coordinate messages if we don't need them, or keep them with sender label
        String label = (sender != null && !sender.isEmpty()) ? sender : String.format(Locale.ROOT, "%d %d %d", x, y, z);
        String posKey = x + "," + y + "," + z;
        long now = System.currentTimeMillis();
        chatBlockWaypoints.put(posKey, new ChatBlockWaypoint(posKey, label, x, y, z, now));
    }

    public static int[] extractCoordinatesFromText(String clean) {
        if (clean == null || clean.isEmpty()) return null;

        Matcher lm = LABELED_COORDS_PATTERN.matcher(clean);
        if (lm.find()) {
            try {
                int x = Integer.parseInt(lm.group(1));
                int y = Integer.parseInt(lm.group(2));
                int z = Integer.parseInt(lm.group(3));
                if (y >= -64 && y <= 320 && Math.abs(x) <= 30000 && Math.abs(z) <= 30000) {
                    return new int[]{x, y, z};
                }
            } catch (NumberFormatException ignored) {}
        }

        Matcher pm = PLAIN_COORDS_PATTERN.matcher(clean);
        while (pm.find()) {
            try {
                int x = Integer.parseInt(pm.group(1));
                int y = Integer.parseInt(pm.group(2));
                int z = Integer.parseInt(pm.group(3));
                // Valid Minecraft Y range and avoid matching "10/09/26" date strings
                if (y >= 10 && y <= 320 && (Math.abs(x) >= 15 || Math.abs(z) >= 15)) {
                    return new int[]{x, y, z};
                }
            } catch (NumberFormatException ignored) {}
        }
        return null;
    }

    private static String extractSenderLabel(String clean) {
        if (clean.startsWith("Party > ")) {
            int colon = clean.indexOf(':');
            if (colon > 8) {
                String prefix = clean.substring(8, colon).trim();
                int lastSpace = prefix.lastIndexOf(' ');
                return lastSpace >= 0 ? prefix.substring(lastSpace + 1).trim() : prefix;
            }
        }
        if (clean.startsWith("From ")) {
            int colon = clean.indexOf(':');
            if (colon > 5) {
                String prefix = clean.substring(5, colon).trim();
                int lastSpace = prefix.lastIndexOf(' ');
                return lastSpace >= 0 ? prefix.substring(lastSpace + 1).trim() : prefix;
            }
        }
        int colon = clean.indexOf(':');
        if (colon > 0 && colon < 42) {
            String prefix = clean.substring(0, colon).trim();
            int lastSpace = prefix.lastIndexOf(' ');
            String candidate = lastSpace >= 0 ? prefix.substring(lastSpace + 1).trim() : prefix;
            if (candidate.matches("^[A-Za-z0-9_]{2,16}$")) {
                return candidate;
            }
        }
        return "Waypoint";
    }

    public static void tick(Minecraft client, List<Entity> entities) {
        if (!VampyConfig.isLootshareBossCallout()) {
            activeWaypoints.clear();
            return;
        }
        if (client == null || client.level == null || client.player == null) {
            activeWaypoints.clear();
            announcedBossAnchors.clear();
            announcedBossSpots.clear();
            return;
        }
        if (!SlayerProfitTracker.isInStillgoreChateau()) {
            activeWaypoints.clear();
            announcedBossAnchors.clear();
            announcedBossSpots.clear();
            return;
        }

        long now = System.currentTimeMillis();
        announcedBossAnchors.entrySet().removeIf(entry -> now - entry.getValue() > 60_000L);
        announcedBossSpots.removeIf(spot -> now - spot.timeMs > 45_000L);

        if (entities == null) {
            activeWaypoints.entrySet().removeIf(e -> now > e.getValue().expiresAtMs);
            return;
        }

        Iterator<Map.Entry<String, BossWaypoint>> it = activeWaypoints.entrySet().iterator();
        while (it.hasNext()) {
            BossWaypoint wp = it.next().getValue();
            if (now > wp.expiresAtMs) {
                it.remove();
            }
        }

        if (entities.isEmpty()) return;

        for (Entity e : entities) {
            if (e == null || !e.hasCustomName() || e.getCustomName() == null) continue;
            String raw = e.getCustomName().getString();
            String clean = WarningHudRenderer.stripFormatting(raw);
            String lower = clean.toLowerCase(Locale.ROOT);
            if (!lower.contains("bloodfiend")) continue;
            if (!clean.contains("❤") && !clean.contains("♥")) continue;

            UUID tagId = e.getUUID();

            int tier = parseTierFromText(clean);
            if (tier < 3) {
                // Strictly only T3, T4, and T5 directly from the Bloodfiend nametag
                continue;
            }

            double hp = parseCurrentHealth(clean);
            if (hp <= 0.0) continue;

            Entity anchor = WarningHudRenderer.findNearestSpawnedByMarker(entities, e.position(), 4.5);
            UUID bossKeyId = anchor != null ? anchor.getUUID() : tagId;

            int threshold = (tier == 3) ? 750 : ((tier == 4) ? 1080 : 1200);
            if (hp <= threshold) {
                boolean alreadyAnnounced = announcedBossAnchors.containsKey(bossKeyId) || announcedBossAnchors.containsKey(tagId);
                if (!alreadyAnnounced) {
                    for (AnnouncedSpot spot : announcedBossSpots) {
                        if (spot.tier == tier) {
                            double dx = spot.x - e.getX();
                            double dy = spot.y - e.getY();
                            double dz = spot.z - e.getZ();
                            if (dx * dx + dz * dz <= 22.0 * 22.0 && Math.abs(dy) <= 10.0) {
                                alreadyAnnounced = true;
                                spot.x = e.getX();
                                spot.y = e.getY();
                                spot.z = e.getZ();
                                break;
                            }
                        }
                    }
                }
                if (!alreadyAnnounced) {
                    for (BossWaypoint wp : activeWaypoints.values()) {
                        double dx = wp.x - e.getX();
                        double dy = wp.y - (e.getY() - 1.8);
                        double dz = wp.z - e.getZ();
                        if (dx * dx + dz * dz <= 22.0 * 22.0 && Math.abs(dy) <= 10.0) {
                            alreadyAnnounced = true;
                            if (wp.trackedEntityId == null) {
                                wp.trackedEntityId = tagId;
                                wp.trackedAnchorId = bossKeyId;
                                wp.trackedEntity = e;
                                wp.wasSeenInWorld = true;
                            }
                            break;
                        }
                    }
                }

                announcedBossAnchors.put(bossKeyId, now);
                announcedBossAnchors.put(tagId, now);

                if (!alreadyAnnounced) {
                    announcedBossSpots.add(new AnnouncedSpot(tier, e.getX(), e.getY(), e.getZ(), now));
                    int bx = (int) Math.floor(e.getX());
                    int by = (int) Math.floor(e.getY() - 1.8);
                    int bz = (int) Math.floor(e.getZ());
                    String tierStr = "T" + tier;
                    String ownerLabel = resolveBossOwnerLabel(client, anchor, e, entities);

                    String wpKey = "local_" + bossKeyId;
                    activeWaypoints.put(wpKey, new BossWaypoint(
                            wpKey, tierStr, ownerLabel, bx + 0.5, by, bz + 0.5, tagId, bossKeyId, e, now));

                    ClientModChat.info(String.format(Locale.ROOT, "§6%s boss (%.0f❤) at %d %d %d", tierStr, hp, bx, by, bz));

                    if (now - lastChatSentMs >= CHAT_COOLDOWN_MS) {
                        lastChatSentMs = now;
                        sendPartyCallout(tierStr, hp, bx, by, bz);
                    }
                }
            }
        }
    }

    public enum DungeonClass {
        HEALER("H"),
        MAGE("M"),
        BERSERK("B"),
        ARCHER("A"),
        TANK("T");

        private final String shortTag;

        DungeonClass(String shortTag) {
            this.shortTag = shortTag;
        }

        public String getShortTag() {
            return shortTag;
        }

        public int getConfiguredColor() {
            return switch (this) {
                case HEALER -> VampyConfig.getClassHealerColor();
                case MAGE -> VampyConfig.getClassMageColor();
                case BERSERK -> VampyConfig.getClassBerserkColor();
                case ARCHER -> VampyConfig.getClassArcherColor();
                case TANK -> VampyConfig.getClassTankColor();
            };
        }

        public static DungeonClass fromNameOrLetter(String s) {
            if (s == null || s.isEmpty()) return null;
            String u = s.trim().toUpperCase(Locale.ROOT);
            return switch (u) {
                case "HEALER", "H" -> HEALER;
                case "MAGE", "M" -> MAGE;
                case "BERSERK", "BERSERKER", "B" -> BERSERK;
                case "ARCHER", "A" -> ARCHER;
                case "TANK", "T" -> TANK;
                default -> null;
            };
        }
    }

    private static final Set<String> partyMemberIgns = new HashSet<>();
    private static final Map<String, DungeonClass> partyMemberClasses = new ConcurrentHashMap<>();
    private static long lastDungeonScanMs = 0L;
    private static volatile boolean cachedInDungeons = false;

    private static final Pattern TAB_DUNGEON_CLASS_PATTERN = Pattern.compile(
            "(?:\\[\\d+\\]\\s*)?([A-Za-z0-9_]{2,16})\\s+.*?\\((Healer|Mage|Berserk|Berserker|Archer|Tank)(?:\\s+[IVXLCDM0-9]+)?\\)",
            Pattern.CASE_INSENSITIVE
    );
    private static final Pattern SCOREBOARD_CLASS_LETTER_PATTERN = Pattern.compile(
            "^\\[([HMBAT])\\]\\s+([A-Za-z0-9_]{2,16})\\b"
    );
    private static final Pattern PF_CLASS_JOIN_PATTERN = Pattern.compile(
            "Party Finder > ([A-Za-z0-9_]{2,16}) joined the dungeon group! \\((Healer|Mage|Berserk|Berserker|Archer|Tank)\\b",
            Pattern.CASE_INSENSITIVE
    );
    private static final Pattern CLASS_SELECTED_CHAT_PATTERN = Pattern.compile(
            "^([A-Za-z0-9_]{2,16}) selected the (Healer|Mage|Berserk|Berserker|Archer|Tank) Dungeon Class!",
            Pattern.CASE_INSENSITIVE
    );

    public static Set<String> getPartyMemberIgns() {
        return partyMemberIgns;
    }

    public static void clearPartyMembers() {
        partyMemberIgns.clear();
        partyMemberClasses.clear();
    }

    public static boolean isInDungeons(Minecraft client) {
        if (client == null || client.level == null) return false;
        long now = System.currentTimeMillis();
        if (now - lastDungeonScanMs >= 750L) {
            lastDungeonScanMs = now;
            refreshDungeonStateAndClasses(client);
        }
        return cachedInDungeons;
    }

    public static DungeonClass getPartyMemberDungeonClass(Minecraft client, String ign) {
        if (ign == null || ign.isEmpty()) return null;
        if (!isInDungeons(client)) return null;
        return partyMemberClasses.get(ign.trim().toLowerCase(Locale.ROOT));
    }

    public static int resolvePartyMemberColor(Minecraft client, String ign) {
        if (VampyConfig.isDungeonClassColors() && isInDungeons(client) && ign != null && !ign.isEmpty()) {
            DungeonClass dc = partyMemberClasses.get(ign.trim().toLowerCase(Locale.ROOT));
            if (dc != null) {
                return dc.getConfiguredColor();
            }
        }
        return VampyConfig.getPartyMemberColor();
    }

    private static void refreshDungeonStateAndClasses(Minecraft client) {
        boolean foundCatacombs = false;
        try {
            Scoreboard sb = client.level.getScoreboard();
            Objective obj = sb.getDisplayObjective(DisplaySlot.SIDEBAR);
            if (obj != null) {
                String titleClean = WarningHudRenderer.stripFormatting(obj.getDisplayName().getString()).toLowerCase(Locale.ROOT);
                if (titleClean.contains("dungeon") || titleClean.contains("catacombs")) {
                    foundCatacombs = true;
                }
                for (PlayerScoreEntry entry : sb.listPlayerScores(obj)) {
                    StringBuilder lineBuilder = new StringBuilder();
                    if (entry.display() != null) {
                        lineBuilder.append(entry.display().getString());
                    } else {
                        PlayerTeam team = sb.getPlayersTeam(entry.owner());
                        if (team != null && team.getPlayerPrefix() != null) {
                            lineBuilder.append(team.getPlayerPrefix().getString());
                        }
                        if (entry.ownerName() != null) {
                            lineBuilder.append(entry.ownerName().getString());
                        } else if (entry.owner() != null) {
                            lineBuilder.append(entry.owner());
                        }
                        if (team != null && team.getPlayerSuffix() != null) {
                            lineBuilder.append(team.getPlayerSuffix().getString());
                        }
                    }
                    String cleanLine = WarningHudRenderer.stripFormatting(lineBuilder.toString()).trim();
                    String lowerLine = cleanLine.toLowerCase(Locale.ROOT);
                    if (lowerLine.contains("the catacombs") || lowerLine.contains("catacombs (") || lowerLine.contains("dungeon cleared") || lowerLine.contains("time elapsed:")) {
                        foundCatacombs = true;
                    }
                    Matcher sm = SCOREBOARD_CLASS_LETTER_PATTERN.matcher(cleanLine);
                    if (sm.find()) {
                        foundCatacombs = true;
                        DungeonClass dc = DungeonClass.fromNameOrLetter(sm.group(1));
                        String playerIgn = sm.group(2);
                        if (dc != null && playerIgn != null) {
                            addPartyMemberIgn(playerIgn);
                            partyMemberClasses.put(playerIgn.toLowerCase(Locale.ROOT), dc);
                        }
                    }
                }
            }

            if (client.getConnection() != null) {
                for (PlayerInfo info : client.getConnection().getOnlinePlayers()) {
                    if (info.getTabListDisplayName() == null) continue;
                    String tabClean = WarningHudRenderer.stripFormatting(info.getTabListDisplayName().getString()).trim();
                    if (tabClean.isEmpty()) continue;
                    String tabLower = tabClean.toLowerCase(Locale.ROOT);
                    if (tabLower.contains("dungeon:") || tabLower.contains("the catacombs") || tabLower.contains("crypts:")) {
                        foundCatacombs = true;
                    }
                    Matcher tm = TAB_DUNGEON_CLASS_PATTERN.matcher(tabClean);
                    if (tm.find()) {
                        foundCatacombs = true;
                        String playerIgn = tm.group(1);
                        DungeonClass dc = DungeonClass.fromNameOrLetter(tm.group(2));
                        if (dc != null && playerIgn != null) {
                            addPartyMemberIgn(playerIgn);
                            partyMemberClasses.put(playerIgn.toLowerCase(Locale.ROOT), dc);
                        }
                    }
                }
            }
        } catch (Exception ignored) {
        }
        cachedInDungeons = foundCatacombs;
    }

    public static void trackPartyChatMessage(String raw) {
        if (raw == null || raw.isEmpty()) return;
        String clean = ChatFormatting.stripFormatting(raw).trim();
        if (clean.isEmpty()) return;

        Matcher pfm = PF_CLASS_JOIN_PATTERN.matcher(clean);
        if (pfm.find()) {
            String joinedIgn = pfm.group(1);
            DungeonClass dc = DungeonClass.fromNameOrLetter(pfm.group(2));
            addPartyMemberIgn(joinedIgn);
            if (dc != null) {
                partyMemberClasses.put(joinedIgn.toLowerCase(Locale.ROOT), dc);
            }
            return;
        }

        Matcher csm = CLASS_SELECTED_CHAT_PATTERN.matcher(clean);
        if (csm.find()) {
            String selIgn = csm.group(1);
            DungeonClass dc = DungeonClass.fromNameOrLetter(csm.group(2));
            addPartyMemberIgn(selIgn);
            if (dc != null) {
                partyMemberClasses.put(selIgn.toLowerCase(Locale.ROOT), dc);
            }
            return;
        }

        // Track party members from "Party > [Rank] IGN: ..."
        if (clean.startsWith("Party > ")) {
            int colon = clean.indexOf(':');
            if (colon > 8) {
                String prefix = clean.substring(8, colon).trim();
                int lastSpace = prefix.lastIndexOf(' ');
                String sender = lastSpace >= 0 ? prefix.substring(lastSpace + 1).trim() : prefix;
                addPartyMemberIgn(sender);
            }
            return;
        }

        String lower = clean.toLowerCase(Locale.ROOT);
        if (lower.equals("you have left the party.")
                || lower.startsWith("the party was disbanded")
                || lower.startsWith("you have been kicked from the party")
                || lower.equals("you are not currently in a party.")
                || lower.startsWith("the party was disbanded because")) {
            partyMemberIgns.clear();
            partyMemberClasses.clear();
            com.vampy.chat.VampWebSocketManager.onPartyDisbanded();
            return;
        }
        if (lower.endsWith(" has left the party.") || lower.endsWith(" has been removed from the party.") || lower.endsWith(" was removed from your party because they disconnected.")) {
            int idx = lower.indexOf(" has left the party.");
            if (idx < 0) idx = lower.indexOf(" has been removed from the party.");
            if (idx < 0) idx = lower.indexOf(" was removed from your party");
            if (idx > 0) {
                String part = clean.substring(0, idx).trim();
                int sp = part.lastIndexOf(' ');
                String leftIgn = sp >= 0 ? part.substring(sp + 1).trim() : part;
                partyMemberIgns.remove(leftIgn.toLowerCase(Locale.ROOT));
                partyMemberClasses.remove(leftIgn.toLowerCase(Locale.ROOT));
            }
            return;
        }
        if (lower.endsWith(" joined the party.") || lower.endsWith(" joined the dungeon group!")) {
            String suffix = lower.endsWith(" joined the party.") ? " joined the party." : " joined the dungeon group!";
            String part = clean.substring(0, clean.length() - suffix.length()).trim();
            int sp = part.lastIndexOf(' ');
            addPartyMemberIgn(sp >= 0 ? part.substring(sp + 1).trim() : part);
        } else if (lower.contains(" invited ") && lower.endsWith(" to the party! they have 60 seconds to accept.")) {
            int invIdx = lower.indexOf(" invited ");
            if (invIdx > 0) {
                String inviterPart = clean.substring(0, invIdx).trim();
                int sp1 = inviterPart.lastIndexOf(' ');
                addPartyMemberIgn(sp1 >= 0 ? inviterPart.substring(sp1 + 1).trim() : inviterPart);
            }
        } else if (lower.startsWith("party finder > ")) {
            int jIdx = lower.indexOf(" joined the dungeon group!");
            if (jIdx > "Party Finder > ".length()) {
                String part = clean.substring("Party Finder > ".length(), jIdx).trim();
                int sp = part.lastIndexOf(' ');
                addPartyMemberIgn(sp >= 0 ? part.substring(sp + 1).trim() : part);
            }
        } else if (lower.startsWith("party leader, ") && (lower.contains(", summoned you") || lower.contains(" warped"))) {
            int endIdx = lower.indexOf(", summoned you");
            if (endIdx < 0) endIdx = lower.indexOf(" warped");
            if (endIdx > "Party Leader, ".length()) {
                String part = clean.substring("Party Leader, ".length(), endIdx).trim();
                int sp = part.lastIndexOf(' ');
                addPartyMemberIgn(sp >= 0 ? part.substring(sp + 1).trim() : part);
            }
        } else if (lower.contains(" has promoted ") || lower.contains(" has demoted ")) {
            String sep = lower.contains(" has promoted ") ? " has promoted " : " has demoted ";
            int idx = lower.indexOf(sep);
            if (idx > 0) {
                String p1 = clean.substring(0, idx).trim();
                int sp1 = p1.lastIndexOf(' ');
                addPartyMemberIgn(sp1 >= 0 ? p1.substring(sp1 + 1).trim() : p1);
                String rest = clean.substring(idx + sep.length());
                int toIdx = rest.toLowerCase(Locale.ROOT).indexOf(" to ");
                if (toIdx > 0) {
                    String p2 = rest.substring(0, toIdx).trim();
                    int sp2 = p2.lastIndexOf(' ');
                    addPartyMemberIgn(sp2 >= 0 ? p2.substring(sp2 + 1).trim() : p2);
                }
            }
        } else if (lower.startsWith("the party was transferred to ")) {
            String rest = clean.substring("The party was transferred to ".length());
            for (String chunk : rest.split(" by | because ")) {
                String p = chunk.replace(".", "").trim();
                int sp = p.lastIndexOf(' ');
                addPartyMemberIgn(sp >= 0 ? p.substring(sp + 1).trim() : p);
            }
        } else if (lower.startsWith("you have joined ") && (lower.endsWith("'s party!") || lower.endsWith("s' party!"))) {
            partyMemberIgns.clear();
            int endIdx = lower.lastIndexOf("'");
            if (endIdx > "You have joined ".length()) {
                String part = clean.substring("You have joined ".length(), endIdx).trim();
                int sp = part.lastIndexOf(' ');
                addPartyMemberIgn(sp >= 0 ? part.substring(sp + 1).trim() : part);
            }
        } else if (lower.startsWith("you'll be partying with: ")) {
            String listPart = clean.substring("You'll be partying with: ".length());
            for (String entry : listPart.split(",")) {
                String trimmed = entry.trim();
                int sp = trimmed.lastIndexOf(' ');
                addPartyMemberIgn(sp >= 0 ? trimmed.substring(sp + 1).trim() : trimmed);
            }
        } else if (lower.startsWith("party leader: ")) {
            partyMemberIgns.clear();
            int colon = clean.indexOf(':');
            if (colon > 0) {
                String[] tokens = clean.substring(colon + 1).split("\\s+");
                for (String tok : tokens) {
                    String t = tok.replace("●", "").trim();
                    if (!t.isEmpty() && !t.startsWith("[")) {
                        addPartyMemberIgn(t);
                    }
                }
            }
        } else if (lower.startsWith("party moderators: ") || lower.startsWith("party members: ")) {
            int colon = clean.indexOf(':');
            if (colon > 0) {
                String[] tokens = clean.substring(colon + 1).split("\\s+");
                for (String tok : tokens) {
                    String t = tok.replace("●", "").trim();
                    if (!t.isEmpty() && !t.startsWith("[")) {
                        addPartyMemberIgn(t);
                    }
                }
            }
        }
    }

    private static void addPartyMemberIgn(String ign) {
        if (ign == null || ign.isEmpty()) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc != null && mc.player != null && ign.equalsIgnoreCase(mc.player.getName().getString().trim())) {
            return;
        }
        if (ign.matches("^[A-Za-z0-9_]{1,16}$")) {
            partyMemberIgns.add(ign.toLowerCase(Locale.ROOT));
        }
    }

    public static boolean isPartyMember(String ign) {
        if (ign == null || ign.isEmpty()) return false;
        return partyMemberIgns.contains(ign.trim().toLowerCase(Locale.ROOT));
    }

    public static boolean hasPartyMembers() {
        return !partyMemberIgns.isEmpty();
    }

    /**
     * @return true if this chat message is our own echoed "Party > [Rank] MyIgn: Lootsharable T... boss at X Y Z"
     *         and should be suppressed from chat so only the [Vampy] notification shows.
     */
    public static boolean onChatMessage(String raw) {
        trackPartyChatMessage(raw);
        if (raw == null || raw.isEmpty()) return false;
        String clean = ChatFormatting.stripFormatting(raw).trim();
        if (clean.isEmpty()) return false;

        maybeAutoAddChatWaypoint(clean);

        if (!VampyConfig.isLootshareBossCallout()) return false;

        Matcher m = PARTY_CALLOUT_PATTERN.matcher(clean);
        if (!m.find()) return false;

        String rawTier = m.group(1).toUpperCase(Locale.ROOT).replace("TIER", "").trim();
        String tierLabel;
        if ("3".equals(rawTier) || "III".equals(rawTier) || "T3".equals(rawTier)) {
            tierLabel = "T3";
        } else if ("4".equals(rawTier) || "IV".equals(rawTier) || "T4".equals(rawTier)) {
            tierLabel = "T4";
        } else {
            tierLabel = "T5";
        }

        int x, y, z;
        try {
            x = Integer.parseInt(m.group(2));
            y = Integer.parseInt(m.group(3));
            z = Integer.parseInt(m.group(4));
        } catch (NumberFormatException ex) {
            return false;
        }

        String sender = "Party";
        if (clean.startsWith("Party > ")) {
            int colon = clean.indexOf(':');
            if (colon > 8) {
                String prefix = clean.substring(8, colon).trim();
                int lastSpace = prefix.lastIndexOf(' ');
                sender = lastSpace >= 0 ? prefix.substring(lastSpace + 1).trim() : prefix;
            }
        }

        Minecraft mc = Minecraft.getInstance();
        if (mc != null && mc.player != null) {
            String myIgn = mc.player.getName().getString().trim();
            if (sender.equalsIgnoreCase(myIgn)) {
                return clean.startsWith("Party > ");
            }
        }

        addPartyMemberIgn(sender);

        long now = System.currentTimeMillis();
        for (BossWaypoint existing : activeWaypoints.values()) {
            double dx = existing.x - (x + 0.5);
            double dy = existing.y - y;
            double dz = existing.z - (z + 0.5);
            if (dx * dx + dy * dy + dz * dz <= 100.0) {
                existing.expiresAtMs = now + WAYPOINT_DURATION_MS;
                return false;
            }
        }

        String key = "party_" + sender.toLowerCase(Locale.ROOT);
        activeWaypoints.put(key, new BossWaypoint(
                key, tierLabel, sender, x + 0.5, y, z + 0.5, null, null, null, now));
        return false;
    }

    private static String resolveBossOwnerLabel(Minecraft client, Entity anchor, Entity healthStand, List<Entity> entities) {
        if (anchor != null && WarningHudRenderer.isAllowedBossAnchor(anchor) && !WarningHudRenderer.isHelpingOtherBoss()) {
            return "You";
        }
        return "";
    }

    private static int parseTierFromText(String text) {
        if (text == null || text.isEmpty()) return 0;
        String upper = " " + text.toUpperCase(Locale.ROOT).replaceAll("[^A-Z0-9 ]", " ").replaceAll("\\s+", " ") + " ";
        if (upper.contains(" BLOODFIEND V ") || upper.contains(" TIER V ") || upper.contains(" T5 ")) {
            return 5;
        }
        if (upper.contains(" BLOODFIEND IV ") || upper.contains(" TIER IV ") || upper.contains(" T4 ")) {
            return 4;
        }
        if (upper.contains(" BLOODFIEND III ") || upper.contains(" TIER III ") || upper.contains(" T3 ")) {
            return 3;
        }
        if (upper.contains(" BLOODFIEND II ") || upper.contains(" TIER II ") || upper.contains(" T2 ")) {
            return 2;
        }
        if (upper.contains(" BLOODFIEND I ") || upper.contains(" TIER I ") || upper.contains(" T1 ")) {
            return 1;
        }
        return 0;
    }

    private static double parseCurrentHealth(String clean) {
        Matcher slash = SLASH_HP_PATTERN.matcher(clean);
        if (slash.find()) {
            return parseNumberWithSuffix(slash.group(1), slash.group(2));
        }
        Matcher direct = DIRECT_HP_PATTERN.matcher(clean);
        if (direct.find()) {
            return parseNumberWithSuffix(direct.group(1), direct.group(2));
        }
        return -1.0;
    }

    private static double parseNumberWithSuffix(String numPart, String suffix) {
        if (numPart == null || numPart.isEmpty()) return -1.0;
        try {
            double val = Double.parseDouble(numPart.replace(",", ""));
            if (suffix != null) {
                if ("k".equalsIgnoreCase(suffix)) val *= 1_000.0;
                else if ("m".equalsIgnoreCase(suffix)) val *= 1_000_000.0;
            }
            return val;
        } catch (NumberFormatException e) {
            return -1.0;
        }
    }

    private static void sendPartyCallout(String tierStr, double hp, int x, int y, int z) {
        Minecraft client = Minecraft.getInstance();
        if (client == null) return;
        String cmd = String.format(Locale.ROOT, "pc %s boss (%.0f❤) at %d %d %d", tierStr, hp, x, y, z);
        client.execute(() -> {
            try {
                ClientPacketListener conn = client.getConnection();
                if (conn != null) {
                    conn.sendCommand(cmd);
                }
            } catch (Exception e) {
                VampyMod.LOGGER.warn("Failed to send lootshare boss callout", e);
            }
        });
    }

    public static List<BossWaypoint> getActiveWaypoints() {
        return new ArrayList<>(activeWaypoints.values());
    }
}
