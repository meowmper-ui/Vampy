package com.vampy.render;

import com.mojang.blaze3d.vertex.PoseStack;
import com.vampy.config.VampyConfig;
import it.unimi.dsi.fastutil.ints.IntArrayList;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.gizmos.GizmoStyle;
import net.minecraft.gizmos.Gizmos;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientboundBlockUpdatePacket;
import net.minecraft.network.protocol.game.ClientboundSectionBlocksUpdatePacket;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.shapes.VoxelShape;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.atomic.AtomicLong;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Hypixel Rift Bloodfiend Mania safe-ring reconstructor & ground highlighter.
 * Reconstructs the concentric 4-ring Mania pattern in memory from server block updates
 * (with WorldScan fallback), fits the true pattern centre, learns deviations from the radius formula,
 * and paints the rings onto the ground using Minecraft 26.1.2's native 3D GPU Gizmos.
 */
public final class ManiaHelper {
    public static final int MAX_RENDER_RADIUS = 30;
    private static final double MAX_PLAYER_DISTANCE_SQ = 20.0 * 20.0;

    private static final Pattern MANIA_REGEX = Pattern.compile("(?i)MANIA\\s+(\\d+(?:\\.\\d+)?)s");

    // Netty thread state
    private static final AtomicLong SERVER_TICK = new AtomicLong();
    private static final ConcurrentLinkedQueue<ManiaUpdate> PENDING = new ConcurrentLinkedQueue<>();
    private static volatile boolean capturing = false;
    private static volatile int captureX = 0;
    private static volatile int captureZ = 0;
    private static volatile boolean preCaptureActive = false;
    private static volatile int preCaptureX = 0;
    private static volatile int preCaptureZ = 0;

    // Main thread state
    private static ManiaSession session = null;
    private static Level sessionLevel = null;
    private static boolean wasMania = false;
    private static long lastTick = 0L;
    private static long lastProcessedServerTick = -1L;
    private static WorldScan worldScan = null;
    private static final List<ManiaUpdate> BATCH = new ArrayList<>();
    private static final SurfaceCache SURFACE_CACHE = new SurfaceCache();

    private ManiaHelper() {}

    public enum ManiaBlock {
        NONE("-"),
        GREEN("G"),
        RED("R"),
        REDSTONE("RS"),
        COAL("C");

        public final String symbol;

        ManiaBlock(String symbol) {
            this.symbol = symbol;
        }

        public static ManiaBlock of(BlockState state) {
            if (state == null) return NONE;
            Block b = state.getBlock();
            if (b == Blocks.GREEN_TERRACOTTA) return GREEN;
            if (b == Blocks.RED_TERRACOTTA) return RED;
            if (b == Blocks.REDSTONE_BLOCK) return REDSTONE;
            if (b == Blocks.COAL_BLOCK) return COAL;
            return NONE;
        }
    }

    public static final class ManiaUpdate {
        public final long tick;
        public final int x;
        public final int y;
        public final int z;
        public final ManiaBlock type;

        public ManiaUpdate(long tick, int x, int y, int z, ManiaBlock type) {
            this.tick = tick;
            this.x = x;
            this.y = y;
            this.z = z;
            this.type = type;
        }
    }

    /**
     * Called on the Netty thread from TpsConnectionMixin.channelRead0 for incoming packets.
     */
    public static void onNetworkPacket(Packet<?> packet) {
        if (!VampyConfig.isManiaHelper()) return;

        if (packet instanceof ClientboundBlockUpdatePacket blockPacket) {
            if (!capturing && !preCaptureActive) return;
            BlockPos pos = blockPacket.getPos();
            capture(pos.getX(), pos.getY(), pos.getZ(), blockPacket.getBlockState());
        } else if (packet instanceof ClientboundSectionBlocksUpdatePacket sectionPacket) {
            if (!capturing && !preCaptureActive) return;
            sectionPacket.runUpdates((pos, state) -> capture(pos.getX(), pos.getY(), pos.getZ(), state));
        }
    }

    /**
     * Driven once per client tick (20 Hz) from ClientTickEvents.END_CLIENT_TICK.
     */
    public static void onClientTick(Minecraft mc) {
        if (!VampyConfig.isManiaHelper()) {
            if (session != null || capturing || preCaptureActive) {
                reset();
            }
            return;
        }
        if (mc == null || mc.level == null || mc.player == null) {
            if (session != null || capturing || preCaptureActive) {
                reset();
            }
            return;
        }
        if (!SlayerProfitTracker.isInStillgoreChateau()) {
            if (session != null || capturing || preCaptureActive || !PENDING.isEmpty()) {
                reset();
            }
            return;
        }
        preCaptureX = mc.player.getBlockX();
        preCaptureZ = mc.player.getBlockZ();
        preCaptureActive = true;
        long tick = SERVER_TICK.incrementAndGet();
        onServerTick(mc, tick);
    }

    private static void capture(int x, int y, int z, BlockState state) {
        if (capturing) {
            int dx = x - captureX;
            int dz = z - captureZ;
            if (dx * dx + dz * dz > ManiaGeometry.CAPTURE_RADIUS_SQ) return;
            PENDING.add(new ManiaUpdate(SERVER_TICK.get(), x, y, z, ManiaBlock.of(state)));
        } else if (preCaptureActive) {
            ManiaBlock mb = ManiaBlock.of(state);
            if (mb == ManiaBlock.NONE) return;
            int dx = x - preCaptureX;
            int dz = z - preCaptureZ;
            if (dx * dx + dz * dz > 26 * 26) return;
            PENDING.add(new ManiaUpdate(SERVER_TICK.get(), x, y, z, mb));
            while (PENDING.size() > 1200) {
                PENDING.poll();
            }
        }
    }

    private static void onServerTick(Minecraft mc, long tick) {
        lastProcessedServerTick = tick;
        if (!VampyConfig.isManiaHelper()) {
            reset();
            return;
        }
        lastTick = tick;
        updateLifecycle(mc, tick);
        drainPending(tick);
        ManiaSession s = session;
        if (s == null) return;
        s.tick(tick);
        runWorldScan(mc, s, tick);
        if (sessionLevel != null && mc.player != null) {
            s.reconcileLiveWorldRing(sessionLevel, mc.player.getBlockY(), tick);
        }
    }

    private static void drainPending(long tick) {
        long batchTick = Long.MIN_VALUE;
        while (true) {
            ManiaUpdate update = PENDING.peek();
            if (update == null || update.tick > tick) break;
            PENDING.poll();
            if (session == null) {
                // Keep recent pre-captured Mania packets from the last 4 ticks so when the MANIA nametag spawns,
                // the blocks placed 1-3 ticks earlier are immediately processed!
                if (tick - update.tick <= 4L && update.type != ManiaBlock.NONE) {
                    BATCH.add(update);
                }
                continue;
            }
            if (update.tick != batchTick) {
                flushBatch(batchTick, false);
                batchTick = update.tick;
            }
            BATCH.add(update);
        }
        if (session != null) {
            flushBatch(batchTick, false);
        } else {
            // Re-queue recent pre-captured packets for the next tick
            for (int i = 0, n = BATCH.size(); i < n; i++) {
                PENDING.add(BATCH.get(i));
            }
            BATCH.clear();
        }
    }

    private static void flushBatch(long tick, boolean synthetic) {
        if (BATCH.isEmpty()) return;
        ManiaSession s = session;
        if (s != null) {
            for (int i = 0, n = BATCH.size(); i < n; i++) {
                ManiaUpdate u = BATCH.get(i);
                SURFACE_CACHE.invalidate(s, u.x, u.z);
            }
            if (!s.processBatch(tick, BATCH, synthetic)) {
                endSession();
            }
        }
        BATCH.clear();
    }

    private static final class ManiaTarget {
        final double bossX;
        final double bossY;
        final double bossZ;
        final String timerText;
        final boolean hasForeignOverlap;
        final double foreignX;
        final double foreignZ;

        ManiaTarget(double bossX, double bossY, double bossZ, String timerText, boolean hasForeignOverlap, double foreignX, double foreignZ) {
            this.bossX = bossX;
            this.bossY = bossY;
            this.bossZ = bossZ;
            this.timerText = timerText;
            this.hasForeignOverlap = hasForeignOverlap;
            this.foreignX = foreignX;
            this.foreignZ = foreignZ;
        }
    }

    private static long lastManiaSeenTick = -1000L;
    private static ManiaTarget lastValidManiaTarget = null;

    private static ManiaTarget findActiveManiaTarget(Minecraft mc) {
        if (mc == null || mc.level == null || mc.player == null) return null;
        if (!SlayerProfitTracker.isInStillgoreChateau()) return null;

        List<Entity> entities = NearbyEntityCache.getEntities(mc);

        Entity bestOwnPosRef = null;
        Entity bestOwnStand = null;
        String bestOwnText = null;
        double bestOwnDistSq = Double.MAX_VALUE;

        Entity bestHelpedPosRef = null;
        Entity bestHelpedStand = null;
        String bestHelpedText = null;
        double bestHelpedDistSq = Double.MAX_VALUE;

        List<Vec3> allManiaCentres = new ArrayList<>(2);

        for (int i = 0, n = entities.size(); i < n; i++) {
            Entity e = entities.get(i);
            if (e instanceof ArmorStand && e.hasCustomName() && e.getCustomName() != null) {
                String clean = WarningHudRenderer.stripFormatting(e.getCustomName().getString());
                String upper = clean.toUpperCase(Locale.ROOT);
                if (upper.contains("MANIA")) {
                    // Match the boss anchor directly in the same vertical stack (<= 2.5m horizontally)
                    // so a nearby foreign boss 4-5m away NEVER steals this MANIA nametag!
                    Entity anchor = WarningHudRenderer.findBossAnchorInColumn(entities, e.position(), 2.5);
                    Entity posRef = anchor != null ? anchor : e;
                    allManiaCentres.add(posRef.position());

                    boolean isOwnBoss = WarningHudRenderer.isMyOwnBossAnchor(anchor)
                            || WarningHudRenderer.isMyOwnBossAnchor(e)
                            || WarningHudRenderer.isNearMyOwnBoss(mc, entities, e.position());
                    boolean helped = WarningHudRenderer.isHelpedBossAnchor(anchor)
                            || WarningHudRenderer.isHelpedBossAnchor(e)
                            || WarningHudRenderer.isNearHelpedBoss(entities, e.position());

                    double distSq = mc.player.distanceToSqr(posRef);
                    if (isOwnBoss && distSq < bestOwnDistSq) {
                        bestOwnDistSq = distSq;
                        bestOwnPosRef = posRef;
                        bestOwnStand = e;
                        bestOwnText = clean;
                    }
                    if (helped && distSq < bestHelpedDistSq) {
                        bestHelpedDistSq = distSq;
                        bestHelpedPosRef = posRef;
                        bestHelpedStand = e;
                        bestHelpedText = clean;
                    }
                }
            }
        }

        // Prioritize the player's OWN boss, then a helped (lootshared) boss (exactly as in 6.2.3!)
        Entity chosenPosRef = bestOwnPosRef != null ? bestOwnPosRef : bestHelpedPosRef;
        Entity chosenStand = bestOwnStand != null ? bestOwnStand : bestHelpedStand;
        String chosenText = bestOwnText != null ? bestOwnText : bestHelpedText;
        if (chosenPosRef == null || chosenStand == null) return null;

        double by = chosenStand.getY() - 1.8;
        // Require the player to be within the Mania arena range (<= 16.5m horizontally and <= 12.0m vertically when engaged so knockback into rafters keeps rendering)
        double pdx = mc.player.getX() - chosenPosRef.getX();
        double pdz = mc.player.getZ() - chosenPosRef.getZ();
        double pdy = Math.abs(mc.player.getY() - by);
        boolean engaged = WarningHudRenderer.isAnyBossEngagedByPlayer();
        double maxHorizSq = engaged ? (16.5 * 16.5) : (10.5 * 10.5);
        double maxVert = engaged ? 12.0 : 6.5;
        if (pdx * pdx + pdz * pdz > maxHorizSq || pdy > maxVert) {
            return null;
        }

        boolean hasForeignOverlap = false;
        double foreignX = 0.0;
        double foreignZ = 0.0;
        double minForeignDistSq = Double.MAX_VALUE;
        for (int i = 0, n = allManiaCentres.size(); i < n; i++) {
            Vec3 other = allManiaCentres.get(i);
            double dx = other.x - chosenPosRef.getX();
            double dz = other.z - chosenPosRef.getZ();
            double dSq = dx * dx + dz * dz;
            // Another Mania boss whose 15-block ring overlaps with our 15-block ring (centres between 1.5 and 30 blocks apart)
            if (dSq > 2.25 && dSq < 30.0 * 30.0 && dSq < minForeignDistSq) {
                minForeignDistSq = dSq;
                hasForeignOverlap = true;
                foreignX = other.x;
                foreignZ = other.z;
            }
        }

        return new ManiaTarget(chosenPosRef.getX(), by, chosenPosRef.getZ(), chosenText, hasForeignOverlap, foreignX, foreignZ);
    }

    private static void updateLifecycle(Minecraft mc, long tick) {
        Level level = mc.level;
        ManiaTarget liveTarget = findActiveManiaTarget(mc);
        if (liveTarget != null) {
            lastManiaSeenTick = tick;
            lastValidManiaTarget = liveTarget;
        }
        boolean inMania = (level != null && (liveTarget != null
                || (session != null && (tick - lastManiaSeenTick) <= 18L
                    && (session.maniaRemaining == null || session.maniaRemaining > 0.35))));
        ManiaTarget target = liveTarget != null ? liveTarget : lastValidManiaTarget;

        if (session != null && (!inMania || sessionLevel != level)) {
            endSession();
        }
        if (!inMania || target == null) {
            wasMania = false;
            lastValidManiaTarget = null;
            return;
        }

        if (!wasMania || session == null) {
            wasMania = true;
            ManiaSession newSession = new ManiaSession(
                    tick,
                    Mth.floor(target.bossX),
                    Mth.floor(target.bossZ),
                    target.bossX,
                    target.bossY,
                    target.bossZ
            );
            newSession.setForeignOverlap(target.hasForeignOverlap, Mth.floor(target.foreignX), Mth.floor(target.foreignZ));
            startSession(newSession, level);
            drainPending(tick);
            // Immediately scan the world on the very first tick of Mania so we never miss the initial terracotta placement!
            runWorldScan(mc, newSession, tick);
        } else {
            session.setForeignOverlap(target.hasForeignOverlap, Mth.floor(target.foreignX), Mth.floor(target.foreignZ));
            session.updateGuessBeforeLock(Mth.floor(target.bossX), Mth.floor(target.bossZ), target.bossY);
            captureX = session.locked ? session.centreX : session.guessX;
            captureZ = session.locked ? session.centreZ : session.guessZ;
        }

        if (session != null && !target.timerText.isEmpty()) {
            Matcher m = MANIA_REGEX.matcher(target.timerText);
            if (m.find()) {
                try {
                    session.setManiaRemaining(Double.parseDouble(m.group(1)));
                } catch (NumberFormatException ignored) {
                }
            }
        }
    }

    private static void startSession(ManiaSession s, Level level) {
        // Preserve any pre-captured packets from the last 4 ticks!
        List<ManiaUpdate> preCaptured = new ArrayList<>();
        while (!PENDING.isEmpty()) {
            ManiaUpdate u = PENDING.poll();
            if (u != null && s.startTick - u.tick <= 4L && u.type != ManiaBlock.NONE) {
                preCaptured.add(u);
            }
        }
        endSession();
        session = s;
        sessionLevel = level;
        captureX = s.guessX;
        captureZ = s.guessZ;
        capturing = true;
        PENDING.addAll(preCaptured);
    }

    private static void endSession() {
        capturing = false;
        PENDING.clear();
        BATCH.clear();
        worldScan = null;
        session = null;
        sessionLevel = null;
        SURFACE_CACHE.clear();
    }

    public static void reset() {
        endSession();
        preCaptureActive = false;
        wasMania = false;
        lastValidManiaTarget = null;
        lastManiaSeenTick = -1000L;
    }

    private static long lastWorldScanTick = -100L;

    private static void runWorldScan(Minecraft mc, ManiaSession s, long tick) {
        if (mc.player == null || sessionLevel == null) return;
        long sinceCycleStart = tick - s.cycleStartTick;
        // Run WorldScan when:
        // 1) Not yet locked onto centre, or greenRing == 0 (waiting for wave)
        // 2) Approaching or inside the new-wave transition window (sinceCycleStart >= 52 ticks, or phase == COAL)
        // 3) No network packets were seen recently (tick - s.lastUpdateTick >= 4L)
        boolean inTransitionWindow = s.locked && s.cycleIndex >= 0 && (sinceCycleStart >= 52L || s.phase == ManiaSession.Phase.COAL);
        boolean needScan = !s.locked || s.cycleIndex < 0 || s.greenRing == 0
                || inTransitionWindow
                || (tick - s.lastUpdateTick >= 4L);
        if (!needScan) return;

        boolean urgent = !s.locked || s.cycleIndex < 0 || s.greenRing == 0 || inTransitionWindow;
        if (!urgent && tick - lastWorldScanTick < 3L) return;
        lastWorldScanTick = tick;

        int targetOriginX = s.locked ? s.centreX : s.guessX;
        int targetOriginZ = s.locked ? s.centreZ : s.guessZ;
        if (worldScan == null || worldScan.originX != targetOriginX || worldScan.originZ != targetOriginZ) {
            worldScan = new WorldScan(targetOriginX, targetOriginZ, Mth.floor(s.bossY));
        }
        worldScan.scan(sessionLevel, mc.player.getBlockY(), Mth.floor(s.bossY), s, tick, BATCH);
        flushBatch(tick, true);
    }

    public static void renderWorldBlocks(
            Minecraft mc,
            PoseStack poseStack,
            MultiBufferSource.BufferSource bufferSource,
            Vec3 cameraPos
    ) {
        // Rendered via emitWorldGizmos (just like 6.2.3) so it works with both Shaders (Iris/Clarity) and Vanilla!
    }

    /**
     * Exact 6.2.3 Gizmos rendering path (GizmoStyle.strokeAndFill) which renders reliably both
     * with Shaders (Iris / Clarity) and without Shaders, combined with non-culled 3D surface tint
     * (via RenderMixin's DrawableGizmoPrimitives$Group.renderQuads -> RenderTypes.debugQuads() + top cap rect).
     */
    public static void emitWorldGizmos(Minecraft mc) {
        if (!VampyConfig.isManiaHelper()) return;
        ManiaSession s = session;
        if (s == null || !s.locked || s.cycleIndex < 0) return;
        if (lastTick - lastManiaSeenTick > 18L) return;
        if (mc == null || mc.player == null || mc.level == null) return;
        if (mc.level != sessionLevel) return;

        double px = mc.player.getX();
        double pz = mc.player.getZ();
        double fromCentreX = px - (s.centreX + 0.5);
        double fromCentreZ = pz - (s.centreZ + 0.5);
        if (fromCentreX * fromCentreX + fromCentreZ * fromCentreZ > MAX_PLAYER_DISTANCE_SQ) return;

        int arenaFloorY = Mth.floor(s.bossY);
        SURFACE_CACHE.sync(s, arenaFloorY);
        int cfgRadius = VampyConfig.getManiaRenderRadius();
        double radiusSq = cfgRadius >= 30 ? Double.MAX_VALUE : (double) (cfgRadius * cfgRadius);
        boolean greenOnly = VampyConfig.isManiaSafeOnly();
        boolean skipMatching = VampyConfig.isManiaOnlyDifferent();
        double floorRefY = s.bossY;

        int greenRgb = colourFor(ManiaBlock.GREEN) & 0xFFFFFF;
        // Soft outline + fill merged together so the grid-style block outline is visible with Shaders (Iris/Clarity)
        // AND the smooth surface fill is visible without Shaders!
        GizmoStyle greenMergedStyle = GizmoStyle.strokeAndFill(
                0x58000000 | greenRgb,
                1.35f,
                0x80000000 | greenRgb
        );

        GizmoStyle[] styles = null;
        if (!greenOnly) {
            styles = new GizmoStyle[ManiaBlock.values().length];
            for (ManiaBlock mb : ManiaBlock.values()) {
                int rgb = colourFor(mb) & 0xFFFFFF;
                int strokeAlpha = (mb == ManiaBlock.GREEN) ? 0x58000000 : 0x3C000000;
                int fillAlpha = (mb == ManiaBlock.GREEN) ? 0x80000000 : 0x52000000;
                styles[mb.ordinal()] = GizmoStyle.strokeAndFill(strokeAlpha | rgb, 1.25f, fillAlpha | rgb);
            }
        }

        for (int i = 0; i < ManiaGeometry.OFFSET_COUNT; i++) {
            ManiaBlock expected = s.expectedBlock(s.columnBand[i]);
            if (expected == null) continue;
            if (greenOnly && expected != ManiaBlock.GREEN) continue;

            int x = s.centreX + ManiaGeometry.OFFSET_X[i];
            int z = s.centreZ + ManiaGeometry.OFFSET_Z[i];
            double dx = (x + 0.5) - px;
            double dz = (z + 0.5) - pz;
            if (dx * dx + dz * dz > radiusSq) continue;

            SURFACE_CACHE.ensure(i, mc.level, x, z, floorRefY);
            List<AABB> boxes = SURFACE_CACHE.tints[i];
            if (boxes.isEmpty()) continue;

            if (skipMatching && expected != ManiaBlock.GREEN && SURFACE_CACHE.types[i] == expected) continue;

            GizmoStyle style = greenOnly ? greenMergedStyle : styles[expected.ordinal()];
            for (int b = 0, bn = boxes.size(); b < bn; b++) {
                Gizmos.cuboid(boxes.get(b), style);
            }
        }
    }

    public static void renderHud(Minecraft mc, GuiGraphicsExtractor graphics) {
        // Center-screen Mania text removed as requested since the 3D full-block safe glow already clearly shows the safe zone.
    }

    private static int colourFor(ManiaBlock block) {
        return switch (block) {
            case GREEN -> VampyConfig.getManiaSafeColor();
            case RED -> VampyConfig.getManiaTerracottaColor();
            case REDSTONE -> VampyConfig.getManiaRedstoneColor();
            case COAL, NONE -> VampyConfig.getManiaCoalColor();
        };
    }

    // =========================================================================
    // Static Mania Geometry
    // =========================================================================
    public static final class ManiaGeometry {
        public static final int CORE = 0;
        public static final int BORDER = 5;
        public static final int OUTSIDE = 6;
        public static final int BAND_COUNT = 7;
        public static final int UNKNOWN = -1;

        public static final int PATTERN_RADIUS = 15;
        public static final int PATTERN_RADIUS_SQ = PATTERN_RADIUS * PATTERN_RADIUS;
        public static final int FIT_RANGE = 4;
        public static final int CAPTURE_RADIUS = PATTERN_RADIUS + FIT_RANGE;
        public static final int CAPTURE_RADIUS_SQ = CAPTURE_RADIUS * CAPTURE_RADIUS;
        public static final int ORBIT_COUNT = (PATTERN_RADIUS + 1) * (PATTERN_RADIUS + 1);

        private static final int SIDE = 2 * PATTERN_RADIUS + 1;
        private static final int[] LOOKUP = new int[SIDE * SIDE];

        public static final int[] OFFSET_X;
        public static final int[] OFFSET_Z;
        public static final int[] OFFSET_FORMULA;
        public static final int[] OFFSET_ORBIT;
        public static final int OFFSET_COUNT;

        static {
            Arrays.fill(LOOKUP, -1);
            IntArrayList xs = new IntArrayList();
            IntArrayList zs = new IntArrayList();
            for (int dx = -PATTERN_RADIUS; dx <= PATTERN_RADIUS; dx++) {
                for (int dz = -PATTERN_RADIUS; dz <= PATTERN_RADIUS; dz++) {
                    if (dx * dx + dz * dz > PATTERN_RADIUS_SQ) continue;
                    LOOKUP[(dx + PATTERN_RADIUS) * SIDE + dz + PATTERN_RADIUS] = xs.size();
                    xs.add(dx);
                    zs.add(dz);
                }
            }
            OFFSET_X = xs.toIntArray();
            OFFSET_Z = zs.toIntArray();
            OFFSET_COUNT = OFFSET_X.length;
            OFFSET_FORMULA = new int[OFFSET_COUNT];
            OFFSET_ORBIT = new int[OFFSET_COUNT];
            for (int i = 0; i < OFFSET_COUNT; i++) {
                OFFSET_FORMULA[i] = formulaBand(OFFSET_X[i], OFFSET_Z[i]);
                OFFSET_ORBIT[i] = orbitIndex(OFFSET_X[i], OFFSET_Z[i]);
            }
        }

        public static int offsetIndex(int dx, int dz) {
            if (dx < -PATTERN_RADIUS || dx > PATTERN_RADIUS || dz < -PATTERN_RADIUS || dz > PATTERN_RADIUS) {
                return -1;
            }
            return LOOKUP[(dx + PATTERN_RADIUS) * SIDE + dz + PATTERN_RADIUS];
        }

        public static int orbitIndex(int dx, int dz) {
            int a = Math.abs(dx);
            int b = Math.abs(dz);
            return Math.max(a, b) * (PATTERN_RADIUS + 1) + Math.min(a, b);
        }

        public static int formulaBand(int dx, int dz) {
            int q = 4 * (dx * dx + dz * dz);
            if (q < 16) return CORE;
            if (q < 100) return 1;
            if (q < 225) return 2;
            if (q < 400) return 3;
            if (q < 625) return 4;
            if (q <= 841) return BORDER;
            return OUTSIDE;
        }

        public static boolean isRing(int band) {
            return band >= 1 && band <= 4;
        }
    }

    // =========================================================================
    // ManiaSession
    // =========================================================================
    public static final class ManiaSession {
        public enum Phase { WAITING, TERRACOTTA, REDSTONE, COAL }

        private static final int GRID_RADIUS = ManiaGeometry.CAPTURE_RADIUS;
        private static final int GRID_SIDE = 2 * GRID_RADIUS + 1;
        private static final int GRID_CELLS = GRID_SIDE * GRID_SIDE;

        private static final int REDSTONE_OFFSET = 25;
        private static final int REDSTONE_DURATION = 20;
        private static final int COAL_OFFSET = REDSTONE_OFFSET + REDSTONE_DURATION;
        private static final int CYCLE_TICKS = 66;
        private static final int MAX_CYCLES = 8;
        private static final int PREDICTION_GRACE = 3;
        private static final int MISSED_CYCLE_GRACE = 2;

        private static final int CONTINUATION_TICKS = 3;

        private static final int MIN_FIT_CELLS = 20;
        private static final int MAX_REFITS = 3;
        private static final int MIN_REVERT_CELLS = 30;
        private static final double REVERT_WINDOW_SECONDS = 3.0;

        public final long startTick;
        public int guessX;
        public int guessZ;
        public final double bossX;
        public double bossY;
        public final double bossZ;

        public int centreX;
        public int centreZ;
        public boolean locked = false;
        public int centreVersion = 0;
        public Phase phase = Phase.WAITING;
        public int greenRing = 0;
        public int lastConfirmedGreenRing = 0;
        public int cycleIndex = -1;
        public int packetsSeen = 0;
        public long lastUpdateTick = 0L;
        public boolean hasForeignOverlap = false;
        public int foreignX = 0;
        public int foreignZ = 0;

        private Double maniaRemaining = null;
        private Double startRemaining = null;

        public final int[] columnBand = Arrays.copyOf(ManiaGeometry.OFFSET_FORMULA, ManiaGeometry.OFFSET_COUNT);

        private long cycleStartTick = 0L;
        private long redstoneTick = 0L;
        private long coalTick = 0L;
        private boolean phasePredicted = false;
        private int referenceCount = 0;
        private int lastRedCount = 0;
        private int refitsAfterLock = 0;

        private final int[] greenCounts = new int[GRID_CELLS * 5];
        private final int[] redCounts = new int[GRID_CELLS * 5];
        private final int[] coalCounts = new int[GRID_CELLS];

        private final IntArrayList greens = new IntArrayList();
        private final IntArrayList reds = new IntArrayList();
        private final IntArrayList redstones = new IntArrayList();
        private final IntArrayList coals = new IntArrayList();
        private final int[] greenHist = new int[ManiaGeometry.BAND_COUNT];
        private final int[] redHist = new int[ManiaGeometry.BAND_COUNT];

        private final int[] seenStamp = new int[ManiaGeometry.OFFSET_COUNT];
        private final ManiaBlock[] seenType = new ManiaBlock[ManiaGeometry.OFFSET_COUNT];
        private final int[] conflictStamp = new int[ManiaGeometry.OFFSET_COUNT];
        private final IntArrayList batchOffsets = new IntArrayList();
        private int batchStamp = 0;

        private int pickedRing = 0;
        private int pickedConsistent = 0;

        public ManiaSession(long startTick, int guessX, int guessZ, double bossX, double bossY, double bossZ) {
            this.startTick = startTick;
            this.guessX = guessX;
            this.guessZ = guessZ;
            this.bossX = bossX;
            this.bossY = bossY;
            this.bossZ = bossZ;
            this.centreX = guessX;
            this.centreZ = guessZ;
        }

        public void setForeignOverlap(boolean overlap, int fx, int fz) {
            this.hasForeignOverlap = overlap;
            this.foreignX = fx;
            this.foreignZ = fz;
        }

        public void updateGuessBeforeLock(int gx, int gz, double by) {
            this.bossY = by;
            if (!locked) {
                this.guessX = gx;
                this.guessZ = gz;
                this.centreX = gx;
                this.centreZ = gz;
            }
        }

        public void setManiaRemaining(Double value) {
            if (this.maniaRemaining == null) {
                this.startRemaining = value;
            }
            this.maniaRemaining = value;
        }

        public int effectiveGreenRing() {
            return greenRing != 0 ? greenRing : lastConfirmedGreenRing;
        }

        public int bandAt(int x, int z) {
            int i = ManiaGeometry.offsetIndex(x - centreX, z - centreZ);
            return i < 0 ? ManiaGeometry.OUTSIDE : columnBand[i];
        }

        public ManiaBlock expectedBlock(int band) {
            if (band == ManiaGeometry.CORE || band == ManiaGeometry.BORDER) {
                return ManiaBlock.COAL;
            }
            int activeRing = effectiveGreenRing();
            if (!ManiaGeometry.isRing(band) || activeRing == 0) {
                return null;
            }
            if (band == activeRing) {
                return ManiaBlock.GREEN;
            }
            return switch (phase) {
                case TERRACOTTA -> ManiaBlock.RED;
                case REDSTONE -> ManiaBlock.REDSTONE;
                case COAL -> ManiaBlock.COAL;
                case WAITING -> null;
            };
        }

        public Long ticksUntilCoal(long now) {
            return switch (phase) {
                case TERRACOTTA -> Math.max(0L, cycleStartTick + COAL_OFFSET - now);
                case REDSTONE -> Math.max(0L, redstoneTick + REDSTONE_DURATION - now);
                default -> null;
            };
        }

        public boolean processBatch(long tick, List<ManiaUpdate> batch, boolean synthetic) {
            int g = 0, r = 0, rs = 0, c = 0;
            for (int idx = 0, n = batch.size(); idx < n; idx++) {
                ManiaUpdate u = batch.get(idx);
                switch (u.type) {
                    case GREEN -> g++;
                    case RED -> r++;
                    case REDSTONE -> rs++;
                    case COAL -> c++;
                    case NONE -> {}
                }
            }
            int maniaCells = g + r + rs + c;
            if (maniaCells > 0) {
                lastUpdateTick = tick;
            }
            if (!synthetic) packetsSeen += maniaCells;

            if ((g + r > 0 || (!locked && rs + c >= MIN_FIT_CELLS)) && (!locked || refitsAfterLock < MAX_REFITS)) {
                fitCentre(batch);
            }
            if (!locked) {
                return true;
            }

            int inNone = classify(batch);
            if (maniaCells == 0 && inNone == 0) return true;
            if (isRevert(inNone)) {
                return false;
            }

            boolean terracottaAccepted = false;
            if (greens.size() + reds.size() > 0) {
                terracottaAccepted = handleTerracotta(tick);
            }
            if (!redstones.isEmpty() && !terracottaAccepted) {
                handleStage(Phase.REDSTONE, redstones, tick);
            }
            if (!coals.isEmpty() && !terracottaAccepted) {
                handleStage(Phase.COAL, coals, tick);
            }
            return true;
        }

        public void tick(long now) {
            switch (phase) {
                case TERRACOTTA -> {
                    if (now - cycleStartTick >= REDSTONE_OFFSET + PREDICTION_GRACE) {
                        phase = Phase.REDSTONE;
                        redstoneTick = cycleStartTick + REDSTONE_OFFSET;
                        phasePredicted = true;
                    }
                }
                case REDSTONE -> {
                    if (now - redstoneTick >= REDSTONE_DURATION + PREDICTION_GRACE) {
                        phase = Phase.COAL;
                        coalTick = redstoneTick + REDSTONE_DURATION;
                        phasePredicted = true;
                    }
                }
                case COAL -> {
                    if (cycleIndex < MAX_CYCLES - 1 && now - cycleStartTick >= CYCLE_TICKS + MISSED_CYCLE_GRACE) {
                        cycleIndex++;
                        cycleStartTick += CYCLE_TICKS;
                        phase = Phase.TERRACOTTA;
                        phasePredicted = true;
                    }
                }
                case WAITING -> {}
            }
        }

        private final BlockPos.MutableBlockPos liveScanPos = new BlockPos.MutableBlockPos();
        private final ManiaBlock[] liveGridTypes = new ManiaBlock[GRID_CELLS];

        /**
         * Directly inspects the live loaded world around (guessX, guessZ) on every client tick,
         * jointly solves for the exact pattern centre (cx, cz) and active green ring (1..4),
         * and snaps boundary cells to actual world GREEN/RED blocks so wave transitions never
         * get stuck on an old ring or misclassify into an adjacent ring.
         */
        public void reconcileLiveWorldRing(Level level, int playerBlockY, long tick) {
            int bossBlockY = Mth.floor(bossY);
            int minY = Math.min(bossBlockY, playerBlockY) - 7;
            int maxY = Math.max(bossBlockY, playerBlockY) + 7;

            Arrays.fill(liveGridTypes, ManiaBlock.NONE);
            int totalWorldGreen = 0;
            int totalWorldRed = 0;
            int totalWorldRedstone = 0;
            int totalWorldCoal = 0;

            for (int gx = 0; gx < GRID_SIDE; gx++) {
                int x = guessX + (gx - GRID_RADIUS);
                for (int gz = 0; gz < GRID_SIDE; gz++) {
                    int z = guessZ + (gz - GRID_RADIUS);
                    if (hasForeignOverlap) {
                        int refX = locked ? centreX : guessX;
                        int refZ = locked ? centreZ : guessZ;
                        int dxOwn = x - refX;
                        int dzOwn = z - refZ;
                        int dxFor = x - foreignX;
                        int dzFor = z - foreignZ;
                        if (dxFor * dxFor + dzFor * dzFor + 4 < dxOwn * dxOwn + dzOwn * dzOwn && dxOwn * dxOwn + dzOwn * dzOwn > 6 * 6) {
                            continue;
                        }
                    }
                    ManiaBlock found = ManiaBlock.NONE;
                    ManiaBlock fallbackBuried = ManiaBlock.NONE;
                    // Search across the staircase/arena height; prefer Mania blocks that actually have walkable
                    // headroom above them (or under a walkable stair) over buried blocks inside walls/foundations!
                    for (int y = maxY; y >= minY; y--) {
                        ManiaBlock mb = ManiaBlock.of(level.getBlockState(liveScanPos.set(x, y, z)));
                        if (mb != ManiaBlock.NONE) {
                            if (fallbackBuried == ManiaBlock.NONE) {
                                fallbackBuried = mb;
                            }
                            if (SURFACE_CACHE.hasTwoBlocksHeadroom(level, x, y, z)
                                    || SURFACE_CACHE.hasTwoBlocksHeadroom(level, x, y + 1, z)
                                    || SURFACE_CACHE.hasTwoBlocksHeadroom(level, x, y + 2, z)) {
                                found = mb;
                                break;
                            }
                        }
                    }
                    if (found == ManiaBlock.NONE) {
                        found = fallbackBuried;
                    }
                    if (found != ManiaBlock.NONE) {
                        liveGridTypes[gx * GRID_SIDE + gz] = found;
                        switch (found) {
                            case GREEN -> totalWorldGreen++;
                            case RED -> totalWorldRed++;
                            case REDSTONE -> totalWorldRedstone++;
                            case COAL -> totalWorldCoal++;
                            case NONE -> {}
                        }
                    }
                }
            }

            int totalDanger = totalWorldRed + totalWorldRedstone;
            if (totalWorldGreen == 0 && totalDanger < 8 && (locked || totalDanger + totalWorldCoal < MIN_FIT_CELLS)) {
                return;
            }

            int fitRange = hasForeignOverlap ? 2 : 3;
            int baseCx = locked ? centreX : guessX;
            int baseCz = locked ? centreZ : guessZ;

            int bestCx = baseCx;
            int bestCz = baseCz;
            int bestRing = 0;
            int bestScore = Integer.MIN_VALUE;
            int bestGreenInRing = 0;
            int bestGreenTotal = 0;
            int bestRedInRing = 0;
            int bestRedOutside = 0;
            int bestDistSq = Integer.MAX_VALUE;

            int currentCentreBestRing = 0;
            int currentCentreBestScore = Integer.MIN_VALUE;
            int currentCentreGreenInRing = 0;

            for (int ox = -fitRange; ox <= fitRange; ox++) {
                for (int oz = -fitRange; oz <= fitRange; oz++) {
                    int cx = guessX + ox;
                    int cz = guessZ + oz;
                    Arrays.fill(greenHist, 0);
                    Arrays.fill(redHist, 0);
                    int coalCoreBorder = 0;
                    int coalInRing = 0;

                    for (int i = 0; i < ManiaGeometry.OFFSET_COUNT; i++) {
                        int dx = ManiaGeometry.OFFSET_X[i];
                        int dz = ManiaGeometry.OFFSET_Z[i];
                        int gx = (cx - guessX) + dx + GRID_RADIUS;
                        int gz = (cz - guessZ) + dz + GRID_RADIUS;
                        if (gx < 0 || gx >= GRID_SIDE || gz < 0 || gz >= GRID_SIDE) continue;
                        ManiaBlock mb = liveGridTypes[gx * GRID_SIDE + gz];
                        if (mb == ManiaBlock.NONE) continue;
                        int band = ManiaGeometry.OFFSET_FORMULA[i];
                        if (mb == ManiaBlock.GREEN) {
                            greenHist[band]++;
                        } else if (mb == ManiaBlock.RED || mb == ManiaBlock.REDSTONE) {
                            redHist[band]++;
                        } else if (mb == ManiaBlock.COAL) {
                            if (band == ManiaGeometry.CORE || band == ManiaGeometry.BORDER) {
                                coalCoreBorder++;
                            } else if (ManiaGeometry.isRing(band)) {
                                coalInRing++;
                            }
                        }
                    }

                    int gRingSum = ringSum(greenHist);
                    int rRingSum = ringSum(redHist);
                    int distFromCurrentSq = (cx - baseCx) * (cx - baseCx) + (cz - baseCz) * (cz - baseCz);

                    for (int k = 1; k <= 4; k++) {
                        int gIn = greenHist[k];
                        int gOut = gRingSum - gIn + greenHist[ManiaGeometry.CORE] + greenHist[ManiaGeometry.BORDER];
                        int rIn = redHist[k];
                        int rOut = rRingSum - rIn;
                        // Heavy reward for green inside ring k, heavy penalty for green outside ring k or red inside ring k
                        int score = gIn * 5 - gOut * 3 + rOut * 2 - rIn * 4 + coalCoreBorder;
                        if (cx == baseCx && cz == baseCz && score > currentCentreBestScore) {
                            currentCentreBestScore = score;
                            currentCentreBestRing = k;
                            currentCentreGreenInRing = gIn;
                        }
                        if (score > bestScore || (score == bestScore && distFromCurrentSq < bestDistSq)) {
                            bestScore = score;
                            bestDistSq = distFromCurrentSq;
                            bestCx = cx;
                            bestCz = cz;
                            bestRing = k;
                            bestGreenInRing = gIn;
                            bestGreenTotal = gRingSum;
                            bestRedInRing = rIn;
                            bestRedOutside = rOut;
                        }
                    }
                }
            }

            if (bestRing == 0) return;

            // Validate the winning ring:
            // 1) Standard case: at least 1 green block in the winning ring and more green than red in that ring.
            // 2) Clipped-room / basement case (e.g. outer ring 4 clipped by walls so 0 green blocks spawn,
            //    while inner rings 1..3 are filled with RED/REDSTONE): infer the safe ring from the ring that has
            //    NO red/redstone blocks while other rings have >= 6 red/redstone blocks!
            if (bestGreenInRing >= 1 && bestGreenInRing > bestRedInRing) {
                // Valid green ring directly observed
            } else if (totalDanger >= 6 && bestRedOutside >= 6 && bestRedInRing <= 1) {
                // Safe ring inferred by elimination in narrow room/basement where safe ring is clipped by walls/stairs!
            } else if (locked && totalWorldGreen == 0 && totalDanger == 0 && lastConfirmedGreenRing != 0) {
                // During the COAL transition between waves, all rings turn to COAL; preserve lastConfirmedGreenRing!
                return;
            } else if (!locked && bestRedOutside >= MIN_FIT_CELLS) {
                lockCentre(bestCx, bestCz, false);
                return;
            } else {
                return;
            }

            // Decide whether to update the locked centre:
            // - If not locked yet: lock immediately onto (bestCx, bestCz).
            // - If already locked: shift centre if (bestCx, bestCz) beats the current centre's score by >= 6 points
            //   (e.g., at least 2 more green blocks cleanly inside the ring instead of spilling into an adjacent ring!).
            if (!locked) {
                centreX = bestCx;
                centreZ = bestCz;
                locked = true;
                centreVersion++;
            } else if ((bestCx != centreX || bestCz != centreZ) && !hasForeignOverlap) {
                if (bestScore >= currentCentreBestScore + 6 && bestGreenInRing >= currentCentreGreenInRing) {
                    centreX = bestCx;
                    centreZ = bestCz;
                    centreVersion++;
                    SURFACE_CACHE.clear();
                } else {
                    // Keep existing centre and use its best ring
                    bestRing = currentCentreBestRing;
                }
            }

            // Update active ring & phase immediately if the ring changed or a new wave started
            int currentActive = effectiveGreenRing();
            boolean ringChanged = (bestRing != currentActive);
            boolean newTerracottaWaveOnSameRing = (bestRing == currentActive)
                    && (greenRing == 0 || phase == Phase.REDSTONE || phase == Phase.COAL || phasePredicted)
                    && totalWorldRed >= 4 && totalWorldRed >= totalWorldRedstone;

            if (ringChanged || newTerracottaWaveOnSameRing || cycleIndex < 0) {
                if (cycleIndex < 0) {
                    cycleIndex = 0;
                } else if (ringChanged || newTerracottaWaveOnSameRing) {
                    cycleIndex++;
                }
                greenRing = bestRing;
                lastConfirmedGreenRing = bestRing;
                if (totalWorldRed >= 4 && totalWorldRed >= totalWorldRedstone) {
                    phase = Phase.TERRACOTTA;
                } else if (totalWorldRedstone >= 4) {
                    phase = Phase.REDSTONE;
                    redstoneTick = tick;
                } else {
                    phase = Phase.TERRACOTTA;
                }
                phasePredicted = false;
                cycleStartTick = tick;
                SURFACE_CACHE.clear();
            }

            // Snap columnBand using formula bands + live world verification on ring borders
            // so any actual GREEN block on a 1-block terrain/rounding border is always included in greenRing,
            // and any actual RED/REDSTONE block on a border is never falsely highlighted as green!
            updateColumnBandsFromLiveWorld(bestRing);
        }

        private void updateColumnBandsFromLiveWorld(int activeRing) {
            // Strictly follow the concentric ring radius formula (OFFSET_FORMULA) so buried RED/REDSTONE
            // blocks underneath staircases or walls never erase cells from the safe ring!
            System.arraycopy(ManiaGeometry.OFFSET_FORMULA, 0, columnBand, 0, ManiaGeometry.OFFSET_COUNT);
        }

        private int classify(List<ManiaUpdate> batch) {
            greens.clear();
            reds.clear();
            redstones.clear();
            coals.clear();
            batchOffsets.clear();
            batchStamp++;

            int bossBlockY = Mth.floor(bossY);
            Minecraft mc = Minecraft.getInstance();
            int playerBlockY = (mc != null && mc.player != null) ? mc.player.getBlockY() : bossBlockY;
            int minValidY = Math.min(bossBlockY, playerBlockY) - 7;
            int maxValidY = Math.max(bossBlockY, playerBlockY) + 7;

            for (int j = 0, n = batch.size(); j < n; j++) {
                ManiaUpdate u = batch.get(j);
                if (u.type != ManiaBlock.NONE && (u.y < minValidY || u.y > maxValidY)) {
                    batchOffsets.add(-1);
                    continue;
                }
                if (hasForeignOverlap && u.type != ManiaBlock.NONE) {
                    int dxOwn = u.x - centreX;
                    int dzOwn = u.z - centreZ;
                    int dxFor = u.x - foreignX;
                    int dzFor = u.z - foreignZ;
                    int distOwnSq = dxOwn * dxOwn + dzOwn * dzOwn;
                    int distForSq = dxFor * dxFor + dzFor * dzFor;
                    if (distForSq + 4 < distOwnSq && distOwnSq > 6 * 6) {
                        batchOffsets.add(-1);
                        continue;
                    }
                }
                int i = ManiaGeometry.offsetIndex(u.x - centreX, u.z - centreZ);
                batchOffsets.add(i);
                if (i < 0) continue;
                if (seenStamp[i] != batchStamp) {
                    seenStamp[i] = batchStamp;
                    seenType[i] = u.type;
                } else if (seenType[i] != u.type) {
                    conflictStamp[i] = batchStamp;
                }
            }

            int inNone = 0;
            for (int j = 0, n = batch.size(); j < n; j++) {
                ManiaUpdate u = batch.get(j);
                int i = batchOffsets.getInt(j);
                if (i < 0 || conflictStamp[i] == batchStamp || seenStamp[i] != batchStamp) continue;
                seenStamp[i] = 0;
                switch (u.type) {
                    case GREEN -> greens.add(i);
                    case RED -> reds.add(i);
                    case REDSTONE -> redstones.add(i);
                    case COAL -> coals.add(i);
                    case NONE -> {
                        if (columnBand[i] != ManiaGeometry.OUTSIDE) inNone++;
                    }
                }
            }
            return inNone;
        }

        private boolean isRevert(int inNone) {
            if (cycleIndex < 0 || inNone < Math.max(MIN_REVERT_CELLS, referenceCount / 2)) return false;
            Double remaining = maniaRemaining;
            return remaining == null || remaining <= REVERT_WINDOW_SECONDS || cycleIndex >= MAX_CYCLES - 2;
        }

        private void fitCentre(List<ManiaUpdate> batch) {
            if (locked && hasForeignOverlap) {
                return;
            }
            int bestX = locked ? centreX : guessX;
            int bestZ = locked ? centreZ : guessZ;
            int bestScore = Integer.MIN_VALUE;
            int bestConsistent = 0;
            int bestDist = Integer.MAX_VALUE;
            int total = 0;
            int bossBlockY = Mth.floor(bossY);
            Minecraft mc = Minecraft.getInstance();
            int playerBlockY = (mc != null && mc.player != null) ? mc.player.getBlockY() : bossBlockY;
            int minValidY = Math.min(bossBlockY, playerBlockY) - 7;
            int maxValidY = Math.max(bossBlockY, playerBlockY) + 7;

            int fitRange = hasForeignOverlap ? 2 : ManiaGeometry.FIT_RANGE;
            int currentCentreScore = Integer.MIN_VALUE;

            for (int ox = -fitRange; ox <= fitRange; ox++) {
                for (int oz = -fitRange; oz <= fitRange; oz++) {
                    int cx = guessX + ox;
                    int cz = guessZ + oz;
                    Arrays.fill(greenHist, 0);
                    Arrays.fill(redHist, 0);
                    int coalOk = 0;
                    int cells = 0;

                    for (int j = 0, n = batch.size(); j < n; j++) {
                        ManiaUpdate u = batch.get(j);
                        ManiaBlock type = u.type;
                        if (type == ManiaBlock.NONE) continue;
                        if (u.y < minValidY || u.y > maxValidY) continue;
                        int dx = u.x - cx;
                        int dz = u.z - cz;
                        if (dx * dx + dz * dz > ManiaGeometry.PATTERN_RADIUS_SQ) continue;
                        cells++;
                        int band = ManiaGeometry.formulaBand(dx, dz);
                        if (type == ManiaBlock.GREEN) {
                            greenHist[band]++;
                        } else if (type == ManiaBlock.RED || type == ManiaBlock.REDSTONE) {
                            redHist[band]++;
                        } else if (band == ManiaGeometry.CORE || band == ManiaGeometry.BORDER) {
                            coalOk++;
                        }
                    }

                    int gRing = ringSum(greenHist);
                    int redRing = ringSum(redHist);
                    int dist = ox * ox + oz * oz;
                    for (int k = 1; k <= 4; k++) {
                        int gIn = greenHist[k];
                        int gOut = gRing - gIn;
                        int rIn = redHist[k];
                        int rOut = redRing - rIn;
                        int consistent = gIn + rOut + coalOk;
                        int score = gIn * 4 - gOut * 3 + rOut * 2 - rIn * 3 + coalOk;
                        if (locked && cx == centreX && cz == centreZ && score > currentCentreScore) {
                            currentCentreScore = score;
                        }
                        if (score > bestScore || (score == bestScore && dist < bestDist)) {
                            bestScore = score;
                            bestDist = dist;
                            bestConsistent = consistent;
                            total = cells;
                            bestX = cx;
                            bestZ = cz;
                        }
                    }
                }
            }

            if (total < 6 || bestConsistent < total * 0.45) {
                return;
            }

            if (!locked) {
                lockCentre(bestX, bestZ, false);
                return;
            }

            if ((bestX != centreX || bestZ != centreZ) && bestScore >= currentCentreScore + 6) {
                centreX = bestX;
                centreZ = bestZ;
                centreVersion++;
                resolveBands();
                SURFACE_CACHE.clear();
            }
        }

        private void lockCentre(int x, int z, boolean reset) {
            centreX = x;
            centreZ = z;
            locked = true;
            centreVersion++;
            if (reset) {
                phase = Phase.WAITING;
                greenRing = 0;
                lastConfirmedGreenRing = 0;
                cycleIndex = -1;
                phasePredicted = false;
                referenceCount = 0;
                lastRedCount = 0;
            }
            resolveBands();
        }

        private boolean handleTerracotta(long tick) {
            int total = greens.size() + reds.size();
            long sinceStart = tick - cycleStartTick;
            boolean continuation = cycleIndex >= 0 && greenRing != 0 && phase == Phase.TERRACOTTA
                    && !phasePredicted && sinceStart <= CONTINUATION_TICKS;
            boolean replacing = cycleIndex >= 0 && (greenRing == 0 || phasePredicted);

            // Always evaluate ring selection against clean formula bands so accumulated noise never shifts a ring by ±1!
            fillFormulaHistograms(greens, greenHist);
            fillFormulaHistograms(reds, redHist);
            int redRing = ringSum(redHist);
            int margin = pickRingTerracotta(redRing);
            int candidateRing = pickedRing;

            // If WorldScan did a full snapshot while waiting for a new wave (replacing == true),
            // make sure it's not just reading the old green ring while the other rings are still COAL/REDSTONE
            if (replacing && candidateRing == lastConfirmedGreenRing && redRing < 4) {
                return false;
            }

            if (!continuation && !replacing) {
                // Accept any new ring immediately if candidateRing != greenRing or if we are in REDSTONE/COAL!
                // Only ignore duplicate packets for the exact same ring within the first 8 ticks of the wave.
                if (cycleIndex >= 0 && phase == Phase.TERRACOTTA && candidateRing == greenRing && sinceStart < 8L) {
                    return false;
                }
                if (cycleIndex >= MAX_CYCLES) return false;
            }

            if (!continuation) {
                int minCells = greens.size() >= 1 ? 3 : Math.max(5, Math.min(8, (int) (referenceCount * 0.15)));
                if (total < minCells) return false;
            }

            int ring = (continuation && candidateRing == greenRing) ? greenRing : candidateRing;
            int consistent = greenHist[ring] + redRing - redHist[ring];

            double minConsistency = hasForeignOverlap ? 0.55 : 0.42;
            if (consistent < total * minConsistency) return false;
            if (!continuation && margin <= 0) return false;

            if (!continuation || candidateRing != greenRing) {
                if (!replacing && !continuation) cycleIndex++;
                greenRing = ring;
                lastConfirmedGreenRing = ring;
                phase = Phase.TERRACOTTA;
                phasePredicted = false;
                cycleStartTick = tick;
                lastRedCount = 0;
                if (total > referenceCount) referenceCount = total;
                SURFACE_CACHE.clear();
            }

            lastRedCount += reds.size();
            resolveBands();
            return true;
        }

        private boolean handleStage(Phase target, IntArrayList cells, long tick) {
            long stageTick = target == Phase.REDSTONE ? redstoneTick : coalTick;
            if (phase == target && !phasePredicted && greenRing != 0 && tick - stageTick <= CONTINUATION_TICKS) {
                return true;
            }

            if (phase == Phase.WAITING && target == Phase.REDSTONE && cells.size() >= 8) {
                fillFormulaHistograms(cells, redHist);
                int ringCells = ringSum(redHist);
                if (ringCells >= 6 && pickRingStage(ringCells) >= Math.max(1, (int) (cells.size() * 0.05))) {
                    int ring = pickedRing;
                    int consistent = ringCells - redHist[ring];
                    if (consistent >= cells.size() * 0.55) {
                        cycleIndex = 0;
                        greenRing = ring;
                        lastConfirmedGreenRing = ring;
                        phase = Phase.REDSTONE;
                        phasePredicted = false;
                        redstoneTick = tick;
                        cycleStartTick = tick - REDSTONE_OFFSET;
                        lastRedCount = Math.max(lastRedCount, cells.size());
                        return true;
                    }
                }
                return false;
            }

            Phase from = target == Phase.REDSTONE ? Phase.TERRACOTTA : Phase.REDSTONE;
            if (phase != from && !(phase == target && phasePredicted)) return false;

            long since = tick - (target == Phase.REDSTONE ? cycleStartTick : redstoneTick);
            int minDelay = target == Phase.REDSTONE ? 10 : 8;
            if (since < minDelay) return false;

            int minCells = Math.max(5, (int) (lastRedCount * 0.16));
            if (cells.size() < minCells) return false;

            fillFormulaHistograms(cells, redHist);
            int ringCells = ringSum(redHist);
            boolean inferred = (greenRing == 0);
            if (inferred && (ringCells < 6 || pickRingStage(ringCells) < cells.size() * 0.05)) {
                return false;
            }
            int ring = inferred ? pickedRing : greenRing;
            int consistent = ringCells - redHist[ring];
            if (consistent < cells.size() * 0.55) return false;

            greenRing = ring;
            lastConfirmedGreenRing = ring;
            phase = target;
            phasePredicted = false;
            if (target == Phase.REDSTONE) redstoneTick = tick;
            else coalTick = tick;
            return true;
        }

        private int pickRingTerracotta(int redRing) {
            int best = Integer.MIN_VALUE;
            int second = Integer.MIN_VALUE;
            int gRingSum = ringSum(greenHist);
            for (int k = 1; k <= 4; k++) {
                int gIn = greenHist[k];
                int gOut = gRingSum - gIn;
                int rIn = redHist[k];
                int rOut = redRing - rIn;
                int score = gIn * 5 - gOut * 2 + rOut * 2 - rIn * 4;
                if (score > best) {
                    second = best;
                    best = score;
                    pickedRing = k;
                } else if (score > second) {
                    second = score;
                }
            }
            pickedConsistent = best;
            return best - second;
        }

        private int pickRingStage(int ringCells) {
            int best = -1;
            int second = -1;
            for (int k = 1; k <= 4; k++) {
                int consistent = ringCells - redHist[k];
                if (consistent > best) {
                    second = best;
                    best = consistent;
                    pickedRing = k;
                } else if (consistent > second) {
                    second = consistent;
                }
            }
            pickedConsistent = best;
            return best - second;
        }

        private void resolveBands() {
            System.arraycopy(ManiaGeometry.OFFSET_FORMULA, 0, columnBand, 0, ManiaGeometry.OFFSET_COUNT);
        }

        private void fillFormulaHistograms(IntArrayList cells, int[] hist) {
            Arrays.fill(hist, 0);
            for (int j = 0, n = cells.size(); j < n; j++) {
                hist[ManiaGeometry.OFFSET_FORMULA[cells.getInt(j)]]++;
            }
        }

        private static int ringSum(int[] hist) {
            return hist[1] + hist[2] + hist[3] + hist[4];
        }
    }

    // =========================================================================
    // SurfaceCache
    // =========================================================================
    private static final class SurfaceCache {
        private final boolean[] valid = new boolean[ManiaGeometry.OFFSET_COUNT];
        final ManiaBlock[] types = new ManiaBlock[ManiaGeometry.OFFSET_COUNT];
        final double[] tops = new double[ManiaGeometry.OFFSET_COUNT];
        @SuppressWarnings("unchecked")
        final List<AABB>[] tints = new List[ManiaGeometry.OFFSET_COUNT];

        private final BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();
        private ManiaSession owner = null;
        private int version = -1;
        private int arenaFloorY = Integer.MIN_VALUE;

        SurfaceCache() {
            Arrays.fill(types, ManiaBlock.NONE);
            Arrays.fill(tints, Collections.emptyList());
        }

        void sync(ManiaSession s, int floorBlockY) {
            if (s == owner && s.centreVersion == version && floorBlockY == arenaFloorY) return;
            owner = s;
            version = s.centreVersion;
            arenaFloorY = floorBlockY;
            Arrays.fill(valid, false);
        }

        void invalidate(ManiaSession s, int x, int z) {
            if (s != owner) return;
            int i = ManiaGeometry.offsetIndex(x - s.centreX, z - s.centreZ);
            if (i >= 0) valid[i] = false;
        }

        void ensure(int i, Level level, int x, int z, double floorRefY) {
            if (!valid[i]) compute(i, level, x, z, floorRefY);
        }

        void clear() {
            owner = null;
            Arrays.fill(valid, false);
        }

        /**
         * Fast, zero-allocation check that a player can stand/walk on the block at (x, y, z):
         * allows stairs and steep basement staircases where (y + 1) or (y + 2) is either empty,
         * a non-full block (such as an upside-down stair or slab), or has >= 0.5 clearance!
         */
        boolean hasTwoBlocksHeadroom(Level level, int x, int y, int z) {
            pos.set(x, y + 1, z);
            BlockState s1 = level.getBlockState(pos);
            VoxelShape sh1 = s1.getCollisionShape(level, pos);
            if (!sh1.isEmpty()) {
                // Reject if (y + 1) is a full 1x1x1 solid wall block, unless it has >= 0.5 clearance
                if (s1.isCollisionShapeFullBlock(level, pos)
                        || (sh1.max(Direction.Axis.Y) > 0.5 && sh1.min(Direction.Axis.Y) < 0.5)) {
                    return false;
                }
            }
            pos.set(x, y + 2, z);
            BlockState s2 = level.getBlockState(pos);
            VoxelShape sh2 = s2.getCollisionShape(level, pos);
            if (!sh2.isEmpty()) {
                if (s2.isCollisionShapeFullBlock(level, pos) && sh2.min(Direction.Axis.Y) < 0.5) {
                    return false;
                }
            }
            return true;
        }

        private void compute(int i, Level level, int x, int z, double floorRefY) {
            double top = floorRefY;
            ManiaBlock type = ManiaBlock.NONE;
            List<AABB> tint = Collections.emptyList();

            // Pass 1: Look for a walkable Mania block OR a Mania block underneath a walkable staircase/slab/floor block (+1 to +3 Y)
            boolean foundWalkable = false;
            for (int y = arenaFloorY + 7; y >= arenaFloorY - 7; y--) {
                pos.set(x, y, z);
                BlockState state = level.getBlockState(pos);
                ManiaBlock mb = ManiaBlock.of(state);
                if (mb == ManiaBlock.NONE) continue;
                VoxelShape shape = state.getCollisionShape(level, pos);
                if (shape.isEmpty()) continue;

                // Case 1A: Check if there is a walkable stair/slab/surface block 1..3 blocks above this Mania block
                for (int dy = 3; dy >= 1; dy--) {
                    int sy = y + dy;
                    pos.set(x, sy, z);
                    BlockState aboveState = level.getBlockState(pos);
                    VoxelShape aboveShape = aboveState.getCollisionShape(level, pos);
                    if (!aboveShape.isEmpty() && hasTwoBlocksHeadroom(level, x, sy, z)) {
                        top = sy + aboveShape.max(Direction.Axis.Y);
                        type = mb;
                        if (hasTwoBlocksHeadroom(level, x, y, z)) {
                            List<AABB> combined = new ArrayList<>(4);
                            combined.addAll(tintBoxes(shape, x, y, z));
                            combined.addAll(tintBoxes(aboveShape, x, sy, z));
                            tint = combined;
                        } else {
                            // Mania block is buried under the staircase; highlight the walkable stair itself!
                            tint = tintBoxes(aboveShape, x, sy, z);
                        }
                        foundWalkable = true;
                        break;
                    }
                }
                if (foundWalkable) break;

                // Case 1B: The Mania block itself is walkable
                if (hasTwoBlocksHeadroom(level, x, y, z)) {
                    top = y + shape.max(Direction.Axis.Y);
                    type = mb;
                    tint = tintBoxes(shape, x, y, z);
                    foundWalkable = true;
                    break;
                }
            }

            // Pass 2: If no walkable Mania block was found (e.g., staircase/gravel/stone bricks where Mania blocks
            // were clipped or buried in walls), find the walkable surface (stairs, slabs, gravel, floor) closest
            // to the arena/staircase level!
            if (!foundWalkable) {
                int bestY = Integer.MIN_VALUE;
                int bestDist = Integer.MAX_VALUE;
                for (int y = arenaFloorY - 6; y <= arenaFloorY + 6; y++) {
                    pos.set(x, y, z);
                    BlockState state = level.getBlockState(pos);
                    VoxelShape shape = state.getCollisionShape(level, pos);
                    if (shape.isEmpty()) continue;
                    if (!hasTwoBlocksHeadroom(level, x, y, z)) continue;

                    int dist = Math.abs(y - arenaFloorY);
                    if (dist < bestDist) {
                        bestDist = dist;
                        bestY = y;
                    }
                }
                if (bestY != Integer.MIN_VALUE) {
                    pos.set(x, bestY, z);
                    BlockState state = level.getBlockState(pos);
                    VoxelShape shape = state.getCollisionShape(level, pos);
                    top = bestY + shape.max(Direction.Axis.Y);
                    type = ManiaBlock.of(state);
                    tint = tintBoxes(shape, x, bestY, z);
                }
            }

            tops[i] = top;
            types[i] = type;
            tints[i] = tint;
            valid[i] = true;
        }

        private static List<AABB> tintBoxes(VoxelShape shape, int x, int y, int z) {
            List<AABB> raw = shape.toAabbs();
            if (raw.isEmpty()) return Collections.emptyList();
            // Slightly expand each 3D collision AABB outward on X/Y/Z so ALL faces
            // (both horizontal top treads AND vertical side/riser faces on stairs, slabs, and blocks)
            // render cleanly outside the block geometry without being occluded by depth test!
            List<AABB> out = new ArrayList<>(raw.size());
            for (int i = 0, n = raw.size(); i < n; i++) {
                AABB b = raw.get(i);
                out.add(new AABB(
                        x + b.minX - 0.005,
                        y + b.minY - 0.005,
                        z + b.minZ - 0.005,
                        x + b.maxX + 0.005,
                        y + b.maxY + 0.007,
                        z + b.maxZ + 0.005
                ));
            }
            return out;
        }
    }

    // =========================================================================
    // WorldScan fallback
    // =========================================================================
    private static final class WorldScan {
        final int originX;
        final int originZ;
        private final int[] columnX;
        private final int[] columnZ;
        private final ManiaBlock[] lastType;
        private final int[] lastY;
        private final BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();
        private int[] levels = new int[0];
        private int levelsPlayerY = Integer.MIN_VALUE;
        private int levelsBossY = Integer.MIN_VALUE;

        WorldScan(int originX, int originZ, int bossY) {
            this.originX = originX;
            this.originZ = originZ;
            int r = ManiaGeometry.CAPTURE_RADIUS;
            IntArrayList xs = new IntArrayList();
            IntArrayList zs = new IntArrayList();
            for (int dx = -r; dx <= r; dx++) {
                for (int dz = -r; dz <= r; dz++) {
                    if (dx * dx + dz * dz <= r * r) {
                        xs.add(dx);
                        zs.add(dz);
                    }
                }
            }
            this.columnX = xs.toIntArray();
            this.columnZ = zs.toIntArray();
            this.lastType = new ManiaBlock[columnX.length];
            Arrays.fill(this.lastType, ManiaBlock.NONE);
            this.lastY = new int[columnX.length];
        }

        void scan(Level level, int playerY, int bossY, ManiaSession s, long tick, List<ManiaUpdate> out) {
            if (playerY != levelsPlayerY || bossY != levelsBossY) {
                levelsPlayerY = playerY;
                levelsBossY = bossY;
                IntArrayList lv = new IntArrayList(16);
                for (int d = 5; d >= -5; d--) {
                    lv.add(playerY + d);
                }
                for (int d = 5; d >= -5; d--) {
                    int y = bossY + d;
                    if (!lv.contains(y)) lv.add(y);
                }
                levels = lv.toIntArray();
            }

            boolean forceFullSnapshot = (!s.locked || s.cycleIndex < 0 || s.greenRing == 0 || s.phasePredicted);

            for (int i = 0; i < columnX.length; i++) {
                int x = originX + columnX[i];
                int z = originZ + columnZ[i];
                if (s.locked) {
                    int dx = x - s.centreX;
                    int dz = z - s.centreZ;
                    if (dx * dx + dz * dz > ManiaGeometry.PATTERN_RADIUS_SQ) continue;
                }
                ManiaBlock type = ManiaBlock.NONE;
                int foundY = 0;
                for (int li = 0; li < levels.length; li++) {
                    int y = levels[li];
                    ManiaBlock found = ManiaBlock.of(level.getBlockState(pos.set(x, y, z)));
                    if (found != ManiaBlock.NONE) {
                        type = found;
                        foundY = y;
                        break;
                    }
                }
                if (!(forceFullSnapshot && type != ManiaBlock.NONE) && type == lastType[i]) continue;
                out.add(new ManiaUpdate(tick, x, type == ManiaBlock.NONE ? lastY[i] : foundY, z, type));
                lastType[i] = type;
                if (type != ManiaBlock.NONE) lastY[i] = foundY;
            }
        }
    }
}
