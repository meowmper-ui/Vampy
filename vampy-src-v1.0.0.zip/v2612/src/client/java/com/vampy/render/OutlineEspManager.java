package com.vampy.render;

import com.vampy.config.VampyConfig;
import it.unimi.dsi.fastutil.ints.Int2IntOpenHashMap;
import it.unimi.dsi.fastutil.longs.LongOpenHashSet;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.Style;
import net.minecraft.network.chat.TextColor;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.ItemLore;

import java.util.List;
import java.util.Locale;

public final class OutlineEspManager {
    private static final Int2IntOpenHashMap MOB_OUTLINES = new Int2IntOpenHashMap(64);
    private static final Int2IntOpenHashMap ITEM_OUTLINES = new Int2IntOpenHashMap(64);
    private static final LongOpenHashSet ITEM_BLOCK_POSITIONS = new LongOpenHashSet(32);
    private static volatile boolean hasMobOutlines = false;
    private static volatile boolean hasItemOutlines = false;
    private static long lastItemScanTick = -1L;

    static {
        MOB_OUTLINES.defaultReturnValue(0);
        ITEM_OUTLINES.defaultReturnValue(0);
    }

    private OutlineEspManager() {
    }

    public static void beginFrame() {
        // Больше не сбрасываем каждый кадр: обновление идет по тикам!
    }

    public static void clear() {
        MOB_OUTLINES.clear();
        ITEM_OUTLINES.clear();
        ITEM_BLOCK_POSITIONS.clear();
        hasMobOutlines = false;
        hasItemOutlines = false;
    }

    public static void clearMobOutlines() {
        if (hasMobOutlines) {
            MOB_OUTLINES.clear();
            hasMobOutlines = false;
        }
    }

    public static void setMobOutline(Entity entity, int rgbColor) {
        if (entity == null) return;
        MOB_OUTLINES.put(entity.getId(), rgbColor | 0xFF000000);
        hasMobOutlines = true;
    }

    public static boolean hasAnyOutlines() {
        return hasMobOutlines || hasItemOutlines;
    }

    public static boolean isThroughWallItemPos(BlockPos pos) {
        return hasItemOutlines && pos != null && ITEM_BLOCK_POSITIONS.contains(pos.asLong());
    }

    public static int getOutlineColorFast(int entityId) {
        if (hasMobOutlines) {
            int c = MOB_OUTLINES.get(entityId);
            if (c != 0) return c;
        }
        if (hasItemOutlines) {
            return ITEM_OUTLINES.get(entityId);
        }
        return 0;
    }

    public static Integer getOutlineColor(Entity entity) {
        if (entity == null) return null;
        int c = getOutlineColorFast(entity.getId());
        return c != 0 ? c : null;
    }

    public static void updateItems(Minecraft client) {
        if (client == null || client.level == null || client.player == null
                || !VampyConfig.isItemRarityOutline()
                || !SlayerProfitTracker.isInSlayerLocation()) {
            if (hasItemOutlines) {
                ITEM_OUTLINES.clear();
                ITEM_BLOCK_POSITIONS.clear();
                hasItemOutlines = false;
            }
            return;
        }
        long tick = client.level.getGameTime();
        if (tick == lastItemScanTick) {
            return; // Обновляем максимум 1 раз в тик (20 раз/сек вместо 300 раз/сек!)
        }
        lastItemScanTick = tick;

        ITEM_OUTLINES.clear();
        ITEM_BLOCK_POSITIONS.clear();
        double maxDist = VampyConfig.getRenderDistance();
        double maxDistSq = maxDist * maxDist;

        for (Entity entity : client.level.entitiesForRendering()) {
            if (!(entity instanceof ItemEntity itemEntity)) continue;
            if (itemEntity.distanceToSqr(client.player) > maxDistSq) continue;
            ItemStack stack = itemEntity.getItem();
            if (stack == null || stack.isEmpty()) continue;
            int rarityColor = detectRarityColor(stack);
            if (rarityColor != 0) {
                ITEM_OUTLINES.put(itemEntity.getId(), rarityColor | 0xFF000000);
                ITEM_BLOCK_POSITIONS.add(itemEntity.blockPosition().asLong());
            }
        }
        hasItemOutlines = !ITEM_OUTLINES.isEmpty();
    }

    private static int detectRarityColor(ItemStack stack) {
        try {
            ItemLore lore = stack.get(DataComponents.LORE);
            if (lore != null) {
                List<Component> lines = lore.lines();
                for (int i = lines.size() - 1; i >= 0; i--) {
                    String raw = SkyblockCombatFeatures.fastStripFormatting(lines.get(i).getString()).toUpperCase(Locale.ROOT);
                    if (raw.contains("DIVINE")) return 0x33B5FF;
                    if (raw.contains("MYTHIC")) return 0xFF55FF;
                    if (raw.contains("LEGENDARY")) return 0xFFAA00;
                    if (raw.contains("EPIC")) return 0xAA00AA;
                    if (raw.contains("RARE")) return 0x5555FF;
                    if (raw.contains("UNCOMMON")) return 0x55FF55;
                    if (raw.contains("SPECIAL")) return 0xFF5555;
                    if (raw.contains("COMMON")) return 0xFFFFFF;
                }
            }
            Style style = stack.getHoverName().getStyle();
            TextColor tc = style.getColor();
            if (tc != null) return tc.getValue();
            ChatFormatting fmt = stack.getRarity().color();
            if (fmt != null && fmt.getColor() != null) return fmt.getColor();
        } catch (Throwable ignored) {}
        return 0xFFFFFF;
    }
}
