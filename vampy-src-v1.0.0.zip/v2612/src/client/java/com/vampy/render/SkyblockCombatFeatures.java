package com.vampy.render;

import com.vampy.config.VampyConfig;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.multiplayer.PlayerInfo;
import net.minecraft.core.component.DataComponents;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.CustomData;
import net.minecraft.world.phys.Vec3;

import it.unimi.dsi.fastutil.ints.Int2IntOpenHashMap;
import it.unimi.dsi.fastutil.longs.LongOpenHashSet;
import net.minecraft.core.BlockPos;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class SkyblockCombatFeatures {
    private static final Map<String, Long> COOLDOWN_END_MS = new ConcurrentHashMap<>();
    private static final Map<String, Long> COOLDOWN_DURATION_MS = Map.of(
        "HOLY_ICE", 4000L,
        "WEIRD_TUBA", 20000L,
        "WEIRDER_TUBA", 20000L,
        "WAND_OF_ATONEMENT", 7000L,
        "WAND_OF_RESTORATION", 7000L,
        "WAND_OF_MENDING", 7000L,
        "WAND_OF_HEALING", 7000L,
        "GYROKINETIC_WAND", 10000L,
        "VOODOO_DOLL", 5000L,
        "JINGLE_BELLS", 3000L
    );

    // Цвета обводки:
    // Босс (обычное состояние) = темно-красный (0xFF990000)
    // Мобы под стейк и босс под стейк = ярко-красный (0xFFFF2222)
    private static final int BOSS_OUTLINE_DARK_RED = 0xFF990000;
    private static final int STEAKABLE_BRIGHT_RED = 0xFFFF2222;

    private static final Pattern HP_PATTERN = Pattern.compile("([0-9][0-9,.]*[kKmMbB]?)\\s*/\\s*([0-9][0-9,.]*[kKmMbB]?)\\s*[❤♥]");
    private static volatile boolean bossCanSteakNow = false;

    // ЖЕСТКАЯ ПРИВЯЗКА UUID: standUUID -> bodyUUID, чтобы хайлайт НЕ прыгал на пробегающих мобов/игроков
    private static final Map<UUID, UUID> STAND_TO_BODY_UUID = new HashMap<>();
    private static final Map<UUID, Entity> ENTITY_BY_UUID_CACHE = new HashMap<>();
    // O(1) таблица цветов для EntityOutlineMixin.getBossOutlineColor(entity) -> 0 нагрузки в рендере!
    private static final Map<UUID, Integer> OUTLINE_COLOR_BY_UUID = new ConcurrentHashMap<>();
    private static final Int2IntOpenHashMap FAST_OUTLINE_BY_ID = new Int2IntOpenHashMap(32);
    private static final LongOpenHashSet THROUGH_WALL_BLOCK_POSITIONS = new LongOpenHashSet(32);
    private static volatile boolean hasFastOutlines = false;
    private static volatile boolean hasThroughWallPositions = false;
    private static UUID lastAttackedEntityUuid = null;
    private static long lastAttackTimeMs = 0L;

    private SkyblockCombatFeatures() {}

    public static void register() {
        // Все хуки уже вызываются из VampyClient, EntityOutlineMixin, ChatStackingMixin и WarningHudRenderer
    }

    public static void renderWorldBoxes(Minecraft client, Object gizmos) {}

    public static boolean needsWorldRender() {
        return false;
    }

    public static void onChatMessage(String raw) {
        // Обработка сообщений чата при необходимости
    }

    public static void onItemUsed(Minecraft client, InteractionHand hand) {
        if (client == null || client.player == null) return;
        if (VampyConfig.isItemCooldownOverlay()) {
            triggerCooldownIfApplicable(client.player.getItemInHand(hand));
        }
    }

    public static void onPlayerAttackEntity(Entity entity) {
        if (entity != null) {
            lastAttackedEntityUuid = entity.getUUID();
            lastAttackTimeMs = System.currentTimeMillis();
        }
    }

    public static void onLeftClickSwing(Minecraft client) {
        if (client == null || client.player == null) return;
        if (VampyConfig.isItemCooldownOverlay()) {
            ItemStack held = client.player.getMainHandItem();
            String id = getSkyblockItemId(held);
            if ("GYROKINETIC_WAND".equalsIgnoreCase(id)) {
                triggerCooldownIfApplicable(held);
            }
        }
    }

    public static boolean hasActiveBossOutlines() {
        return hasFastOutlines;
    }

    public static boolean isThroughWallOutlinedPos(BlockPos pos) {
        return hasThroughWallPositions && pos != null && THROUGH_WALL_BLOCK_POSITIONS.contains(pos.asLong());
    }

    public static int getFastBossOutlineColor(int entityId) {
        return hasFastOutlines ? FAST_OUTLINE_BY_ID.get(entityId) : 0;
    }

    public static Integer getBossOutlineColor(Entity entity) {
        if (entity == null || !hasFastOutlines) return null;
        int c = FAST_OUTLINE_BY_ID.get(entity.getId());
        return c != 0 ? c : null;
    }

    public static boolean isBossSteakReady() {
        return bossCanSteakNow && WarningHudRenderer.isAllowedBossSteakReady(Minecraft.getInstance());
    }

    public static void tick(Minecraft client) {
        OutlineEspManager.updateItems(client);
        updateOutlinesAndSteakState(client);
    }

    public static void updateOutlinesAndSteakState(Minecraft client) {
        if (client == null || client.level == null || client.player == null) {
            bossCanSteakNow = false;
            hasFastOutlines = false;
            hasThroughWallPositions = false;
            FAST_OUTLINE_BY_ID.clear();
            THROUGH_WALL_BLOCK_POSITIONS.clear();
            STAND_TO_BODY_UUID.clear();
            ENTITY_BY_UUID_CACHE.clear();
            OUTLINE_COLOR_BY_UUID.clear();
            return;
        }

        boolean inRift = SlayerProfitTracker.isInRift();
        boolean inSlayer = SlayerProfitTracker.isInSlayerLocation();
        boolean wantSteakMobs = inRift && VampyConfig.isSteakableHighlight();
        boolean wantBossHighlight = inSlayer && VampyConfig.isSlayerBossHighlight();
        boolean wantBossSteakAlert = inRift && VampyConfig.isBossSteakAlert();
        boolean hasPartyMembers = VampyConfig.isPartyMemberGlow() && !LootshareBossTracker.getPartyMemberIgns().isEmpty();

        if (!wantSteakMobs && !wantBossHighlight && !wantBossSteakAlert && !hasPartyMembers) {
            bossCanSteakNow = false;
            hasFastOutlines = false;
            hasThroughWallPositions = false;
            FAST_OUTLINE_BY_ID.clear();
            THROUGH_WALL_BLOCK_POSITIONS.clear();
            OUTLINE_COLOR_BY_UUID.clear();
            return;
        }

        // Fast-path outside Slayer locations (e.g. Dungeons, Hub, Islands):
        // Never iterate all world entities or rebuild NearbyEntityCache; only outline party members via level.players() O(P)!
        if (!wantSteakMobs && !wantBossHighlight && !wantBossSteakAlert) {
            FAST_OUTLINE_BY_ID.clear();
            THROUGH_WALL_BLOCK_POSITIONS.clear();
            if (hasPartyMembers) {
                for (Player p : client.level.players()) {
                    if (isPartyMemberHumanEntity(client, p, null)) {
                        String pName = p.getGameProfile() != null && p.getGameProfile().name() != null
                                ? p.getGameProfile().name().trim()
                                : fastStripFormatting(p.getName().getString()).trim();
                        int pCol = LootshareBossTracker.resolvePartyMemberColor(client, pName);
                        FAST_OUTLINE_BY_ID.put(p.getId(), pCol);
                        THROUGH_WALL_BLOCK_POSITIONS.add(p.blockPosition().asLong());
                    }
                }
            }
            hasFastOutlines = !FAST_OUTLINE_BY_ID.isEmpty();
            hasThroughWallPositions = !THROUGH_WALL_BLOCK_POSITIONS.isEmpty();
            bossCanSteakNow = false;
            return;
        }

        ENTITY_BY_UUID_CACHE.clear();
        List<LivingEntity> candidates = new ArrayList<>(64);
        List<ArmorStand> stands = new ArrayList<>(64);

        for (Entity ent : client.level.entitiesForRendering()) {
            ENTITY_BY_UUID_CACHE.put(ent.getUUID(), ent);
            if (ent instanceof ArmorStand as) {
                if (as.hasCustomName() && as.getCustomName() != null) {
                    stands.add(as);
                }
            } else if (ent instanceof LivingEntity le && ent != client.player && le.isAlive()) {
                // Exclude real online players (UUID v4) from ever being locked as a boss/mob body!
                // Hypixel NPCs (including Bloodfiend and Vampire mobs) always use UUID v2.
                if (le instanceof Player p && isRealOnlinePlayer(client, p)) {
                    continue;
                }
                if (le.isInvisible() && !(le instanceof net.minecraft.world.entity.ambient.Bat)) {
                    continue;
                }
                candidates.add(le);
            }
        }

        // Очищаем протухшие привязки UUID (а также случайно захваченных реальных игроков)
        STAND_TO_BODY_UUID.entrySet().removeIf(e -> {
            Entity s = ENTITY_BY_UUID_CACHE.get(e.getKey());
            Entity b = ENTITY_BY_UUID_CACHE.get(e.getValue());
            if (!(s instanceof ArmorStand) || !(b instanceof LivingEntity le) || !s.isAlive() || !le.isAlive()) {
                return true;
            }
            if (le instanceof Player p && isRealOnlinePlayer(client, p)) {
                return true;
            }
            double dx = s.getX() - b.getX();
            double dz = s.getZ() - b.getZ();
            return (dx * dx + dz * dz) > 4.0;
        });

        Set<UUID> claimedBodies = new HashSet<>(STAND_TO_BODY_UUID.values());
        FAST_OUTLINE_BY_ID.clear();
        THROUGH_WALL_BLOCK_POSITIONS.clear();
        boolean foundSteakableBoss = false;

        List<Entity> cachedEntities = NearbyEntityCache.getEntities(client);
        List<Entity> allowedAnchors = WarningHudRenderer.findAllowedBossAnchors(cachedEntities);
        boolean ownQuestSidebar = WarningHudRenderer.hasSlayTheBossOnSidebar(client) && !WarningHudRenderer.isHelpingOtherBoss();

        // Outline party members via level.players() O(P) using configured Party Member Color (or Dungeon Class color)
        if (hasPartyMembers) {
            for (Player p : client.level.players()) {
                if (isPartyMemberHumanEntity(client, p, stands)) {
                    String pName = p.getGameProfile() != null && p.getGameProfile().name() != null
                            ? p.getGameProfile().name().trim()
                            : fastStripFormatting(p.getName().getString()).trim();
                    int pCol = LootshareBossTracker.resolvePartyMemberColor(client, pName);
                    FAST_OUTLINE_BY_ID.put(p.getId(), pCol);
                    THROUGH_WALL_BLOCK_POSITIONS.add(p.blockPosition().asLong());
                }
            }
        }

        for (int i = 0, n = stands.size(); i < n; i++) {
            ArmorStand stand = stands.get(i);
            if (stand.distanceToSqr(client.player) > 4096.0) continue;

            String rawName = stand.getCustomName().getString();
            String clean = fastStripFormatting(rawName);
            boolean isBloodfiend = containsIgnoreCaseFast(clean, "bloodfiend");
            boolean isZombieBoss = containsIgnoreCaseFast(clean, "revenant horror") || containsIgnoreCaseFast(clean, "atoned horror");
            boolean isSpiderBoss = containsIgnoreCaseFast(clean, "tarantula broodfather");
            boolean isWolfBoss = containsIgnoreCaseFast(clean, "sven packmaster");
            boolean isEndermanBoss = containsIgnoreCaseFast(clean, "voidgloom seraph");
            boolean isBlazeBoss = containsIgnoreCaseFast(clean, "inferno demonlord");
            boolean isGenericSlayerBoss = containsIgnoreCaseFast(clean, "slayer boss");
            boolean isSlayerBoss = isBloodfiend || isZombieBoss || isSpiderBoss || isWolfBoss || isEndermanBoss || isBlazeBoss || isGenericSlayerBoss;

            boolean hasSteakSymbol = clean.contains("🥩")
                || clean.indexOf('\u26A1') >= 0
                || rawName.contains("🥩")
                || rawName.indexOf('\u26A1') >= 0
                || rawName.indexOf('\uD83E') >= 0;
            boolean isThrallOrFledgling = !isSlayerBoss && (
                containsIgnoreCaseFast(clean, "thrall")
                || containsIgnoreCaseFast(clean, "fledgling")
                || containsIgnoreCaseFast(clean, "vampire")
                || containsIgnoreCaseFast(clean, "packouden")
                || hasSteakSymbol
            );
            if (!isSlayerBoss && !isThrallOrFledgling) continue;

            if (isSlayerBoss) {
                // Strictly only highlight our own boss or a boss we are actively lootsharing (3+ hits)!
                // Never highlight unhit bosses belonging to randoms or party members!
                boolean allowedBoss = isMyOrAssistedBossFast(client, stand, cachedEntities, allowedAnchors, ownQuestSidebar);
                if (!allowedBoss) {
                    continue;
                }

                LivingEntity body = resolveLockedBodyForStand(client, stand, candidates, stands, claimedBodies, true);

                boolean canSteak = isBloodfiend && hasSteakSymbol;
                if (!canSteak && isBloodfiend) {
                    double hpRatio = parseHpRatio(clean);
                    canSteak = (hpRatio > 0.0 && hpRatio <= 0.201);
                }
                if (canSteak && stand.distanceToSqr(client.player) <= 900.0) {
                    foundSteakableBoss = true;
                }

                if (wantBossHighlight) {
                    int col = canSteak ? STEAKABLE_BRIGHT_RED : BOSS_OUTLINE_DARK_RED;
                    if (body != null) {
                        FAST_OUTLINE_BY_ID.put(body.getId(), col);
                        THROUGH_WALL_BLOCK_POSITIONS.add(body.blockPosition().asLong());
                    }
                    if (isBloodfiend) {
                        for (int bi = 0, bn = candidates.size(); bi < bn; bi++) {
                            LivingEntity cand = candidates.get(bi);
                            if (cand instanceof net.minecraft.world.entity.ambient.Bat && cand.isAlive()) {
                                double dx = cand.getX() - stand.getX();
                                double dz = cand.getZ() - stand.getZ();
                                double dy = Math.abs(cand.getY() - stand.getY());
                                if (dx * dx + dz * dz <= 16.0 && dy <= 10.0) {
                                    FAST_OUTLINE_BY_ID.put(cand.getId(), col);
                                    THROUGH_WALL_BLOCK_POSITIONS.add(cand.blockPosition().asLong());
                                }
                            }
                        }
                    }
                }
            } else if (wantSteakMobs && isThrallOrFledgling) {
                boolean canSteakMob = hasSteakSymbol;
                if (!canSteakMob) {
                    double hpRatio = parseHpRatio(clean);
                    canSteakMob = (hpRatio > 0.0 && hpRatio <= 0.201);
                }
                if (!canSteakMob) continue;

                LivingEntity body = resolveLockedBodyForStand(client, stand, candidates, stands, claimedBodies, false);
                if (body == null) {
                    continue;
                }
                double distSq = body.distanceToSqr(client.player);
                if (distSq <= 2304.0 && hasLineOfSightToMob(client, body, stand)) {
                    FAST_OUTLINE_BY_ID.put(body.getId(), STEAKABLE_BRIGHT_RED);
                }
            }
        }

        hasFastOutlines = !FAST_OUTLINE_BY_ID.isEmpty();
        hasThroughWallPositions = !THROUGH_WALL_BLOCK_POSITIONS.isEmpty();
        bossCanSteakNow = foundSteakableBoss;
    }

    private static boolean hasLineOfSightToMob(Minecraft client, LivingEntity body, ArmorStand stand) {
        if (client == null || client.player == null || client.level == null || body == null) return false;
        if (client.player.hasLineOfSight(body)) return true;
        if (stand != null && client.player.hasLineOfSight(stand)) return true;

        Vec3 eye = client.player.getEyePosition();
        double bx = body.getX();
        double by = body.getY();
        double bz = body.getZ();
        double h = Math.max(0.9, body.getBbHeight());
        double r = Math.max(0.28, body.getBbWidth() * 0.45);

        double[] sampleYs = new double[]{
            by + h * 0.88,
            by + h * 0.55,
            by + h * 0.25,
            stand != null ? stand.getY() + 0.15 : by + h * 1.02
        };
        double[][] horizOffsets = new double[][]{
            {0.0, 0.0},
            {r, 0.0},
            {-r, 0.0},
            {0.0, r},
            {0.0, -r}
        };

        for (double sy : sampleYs) {
            for (double[] off : horizOffsets) {
                Vec3 target = new Vec3(bx + off[0], sy, bz + off[1]);
                var hit = client.level.clip(new net.minecraft.world.level.ClipContext(
                    eye,
                    target,
                    net.minecraft.world.level.ClipContext.Block.COLLIDER,
                    net.minecraft.world.level.ClipContext.Fluid.NONE,
                    client.player
                ));
                if (hit.getType() == net.minecraft.world.phys.HitResult.Type.MISS
                        || hit.getLocation().distanceToSqr(target) <= 0.36) {
                    return true;
                }
            }
        }
        return false;
    }

    private static boolean isMyOrAssistedBossFast(Minecraft client, net.minecraft.world.entity.decoration.ArmorStand stand, List<Entity> cachedEntities, List<Entity> allowedAnchors, boolean ownQuestSidebar) {
        if (stand == null) return false;
        if (ownQuestSidebar && WarningHudRenderer.isMyOwnBossAnchor(stand)) return true;
        if (WarningHudRenderer.isHelpedBossAnchor(stand)) return true;

        Vec3 pos = stand.position();
        Entity colAnchor = WarningHudRenderer.findBossAnchorInColumn(cachedEntities, pos, 2.5);
        if (colAnchor != null) {
            if ((ownQuestSidebar && WarningHudRenderer.isMyOwnBossAnchor(colAnchor))
                    || WarningHudRenderer.isHelpedBossAnchor(colAnchor)) {
                return true;
            }
        }

        for (int i = 0, n = allowedAnchors.size(); i < n; i++) {
            Entity a = allowedAnchors.get(i);
            if (a != null) {
                double dx = a.getX() - pos.x;
                double dz = a.getZ() - pos.z;
                double dy = Math.abs(a.getY() - pos.y);
                if (dx * dx + dz * dz <= 6.25 && dy <= 3.5) {
                    return true;
                }
            }
        }
        return false;
    }

    private static LivingEntity resolveLockedBodyForStand(Minecraft client, ArmorStand stand, List<LivingEntity> candidates, List<ArmorStand> allStands, Set<UUID> claimedBodies, boolean isBoss) {
        UUID standId = stand.getUUID();
        UUID lockedBodyId = STAND_TO_BODY_UUID.get(standId);
        if (lockedBodyId != null) {
            Entity existing = ENTITY_BY_UUID_CACHE.get(lockedBodyId);
            if (existing instanceof LivingEntity le && le.isAlive()) {
                if (!isBoss || !hasRegularVampireNametagAbove(le, allStands)) {
                    return le;
                }
            }
            STAND_TO_BODY_UUID.remove(standId);
        }

        Vec3 pos = stand.position();
        LivingEntity best = null;
        double bestScore = Double.MAX_VALUE;
        double maxHorizSq = isBoss ? 2.25 : 1.5;
        double maxVertDiff = isBoss ? 3.5 : 2.2;

        for (int i = 0, n = candidates.size(); i < n; i++) {
            LivingEntity le = candidates.get(i);
            if (!isBoss && claimedBodies.contains(le.getUUID())) continue;
            if (!isBoss && le instanceof Player p && isRealOnlinePlayer(client, p)) continue;
            if (isBoss && le instanceof Player p && isDefinitelyHumanPlayer(client, p)) continue;
            if (isBoss && hasRegularVampireNametagAbove(le, allStands)) continue;

            double dx = le.getX() - pos.x;
            double dz = le.getZ() - pos.z;
            double horizSq = dx * dx + dz * dz;
            if (horizSq > maxHorizSq) continue;

            double headY = le.getY() + le.getBbHeight();
            double dy = Math.abs(pos.y - headY);
            if (dy > maxVertDiff) continue;

            double score = horizSq * 6.0 + dy;
            if (score < bestScore) {
                bestScore = score;
                best = le;
            }
        }

        if (best != null) {
            STAND_TO_BODY_UUID.put(standId, best.getUUID());
            claimedBodies.add(best.getUUID());
        }
        return best;
    }

    private static boolean hasRegularVampireNametagAbove(LivingEntity le, List<ArmorStand> allStands) {
        if (le == null || allStands == null) return false;
        double lx = le.getX();
        double lz = le.getZ();
        double headY = le.getY() + le.getBbHeight();
        for (int i = 0, n = allStands.size(); i < n; i++) {
            ArmorStand st = allStands.get(i);
            double dx = st.getX() - lx;
            double dz = st.getZ() - lz;
            double dy = st.getY() - headY;
            if (dx * dx + dz * dz <= 0.49 && dy >= -0.4 && dy <= 0.85) {
                String clean = fastStripFormatting(st.getCustomName().getString());
                if (containsIgnoreCaseFast(clean, "fledgling")
                        || containsIgnoreCaseFast(clean, "thrall")
                        || containsIgnoreCaseFast(clean, "packouden")) {
                    return true;
                }
            }
        }
        return false;
    }

    private static boolean isDefinitelyHumanPlayer(Minecraft client, Player p) {
        if (p == client.player) return true;
        if (p.getUUID().version() != 4) return false;
        if (client.getConnection() == null) return false;
        PlayerInfo info = client.getConnection().getPlayerInfo(p.getUUID());
        return info != null;
    }

    public static boolean isPartyMemberHumanEntity(Minecraft client, Player p, List<ArmorStand> stands) {
        if (client == null || p == null || p == client.player || !p.isAlive() || p.isInvisible()) return false;

        String rawProfileName = p.getGameProfile() != null && p.getGameProfile().name() != null
                ? p.getGameProfile().name().trim()
                : "";
        String displayClean = fastStripFormatting(p.getName().getString()).trim();

        boolean matchedParty = false;
        if (!rawProfileName.isEmpty() && LootshareBossTracker.isPartyMember(rawProfileName)) {
            matchedParty = true;
        } else if (!displayClean.isEmpty() && LootshareBossTracker.isPartyMember(displayClean)) {
            matchedParty = true;
        }
        if (!matchedParty) {
            return false;
        }

        // Exclude any NPC entity that is locked as a boss/mob body or has a boss/mob nametag directly above its head
        if (STAND_TO_BODY_UUID.containsValue(p.getUUID())) {
            return false;
        }
        Iterable<Entity> standSource = stands != null
                ? (Iterable<Entity>) (Iterable<?>) stands
                : (SlayerProfitTracker.isInStillgoreChateau() && client.level != null ? client.level.entitiesForRendering() : null);
        if (standSource != null) {
            for (Entity ent : standSource) {
                if (!(ent instanceof ArmorStand st) || !st.hasCustomName() || st.getCustomName() == null) continue;
                double dx = st.getX() - p.getX();
                double dz = st.getZ() - p.getZ();
                double dy = st.getY() - (p.getY() + p.getBbHeight());
                if (dx * dx + dz * dz <= 0.81 && dy >= -0.8 && dy <= 1.4) {
                    String stClean = fastStripFormatting(st.getCustomName().getString());
                    if (containsIgnoreCaseFast(stClean, "bloodfiend")
                            || containsIgnoreCaseFast(stClean, "slayer boss")
                            || containsIgnoreCaseFast(stClean, "spawned by")
                            || containsIgnoreCaseFast(stClean, "thrall")
                            || containsIgnoreCaseFast(stClean, "fledgling")
                            || stClean.contains("❤")
                            || stClean.contains("♥")) {
                        return false;
                    }
                }
            }
        }
        return true;
    }

    private static boolean isRealOnlinePlayer(Minecraft client, Player p) {
        if (p == client.player) return true;
        // На Hypixel у NPC (включая Bloodfiend и стейк-вампиров) UUID имеет version() == 2, либо ping <= 1 в табе!
        // У настоящих лицензионных игроков Mojang UUID всегда имеет version() == 4 и живой пинг в табе!
        return isDefinitelyHumanPlayer(client, p);
    }

    public static void triggerCooldownIfApplicable(ItemStack stack) {
        if (stack == null || stack.isEmpty()) return;
        String sbId = getSkyblockItemId(stack);
        String cleanName = fastStripFormatting(stack.getHoverName().getString()).toUpperCase(Locale.ROOT);

        String matchedKey = null;
        long duration = 0L;
        for (Map.Entry<String, Long> e : COOLDOWN_DURATION_MS.entrySet()) {
            String key = e.getKey();
            String human = key.replace('_', ' ');
            if ((sbId != null && sbId.equalsIgnoreCase(key)) || cleanName.contains(human)) {
                matchedKey = key;
                duration = e.getValue();
                break;
            }
        }
        if (matchedKey != null && duration > 0L) {
            long now = System.currentTimeMillis();
            Long existing = COOLDOWN_END_MS.get(matchedKey);
            if (existing == null || now >= existing) {
                COOLDOWN_END_MS.put(matchedKey, now + duration);
            }
        }
    }

    public static void renderHud(GuiGraphicsExtractor graphics, DeltaTracker deltaTracker) {
        Minecraft client = Minecraft.getInstance();
        if (client.player == null || client.level == null) return;

        if (VampyConfig.isItemCooldownOverlay() && !COOLDOWN_END_MS.isEmpty()) {
            renderHotbarCooldowns(client, graphics);
        }
    }

    public static void renderHud(Minecraft client, GuiGraphicsExtractor graphics) {
        if (client == null || client.player == null || client.level == null) return;
        if (VampyConfig.isItemCooldownOverlay() && !COOLDOWN_END_MS.isEmpty()) {
            renderHotbarCooldowns(client, graphics);
        }
    }

    private static void renderHotbarCooldowns(Minecraft client, GuiGraphicsExtractor graphics) {
        long now = System.currentTimeMillis();
        COOLDOWN_END_MS.entrySet().removeIf(e -> now >= e.getValue());
        if (COOLDOWN_END_MS.isEmpty()) return;

        int sw = client.getWindow().getGuiScaledWidth();
        int sh = client.getWindow().getGuiScaledHeight();
        int baseX = sw / 2 - 90;
        int baseY = sh - 19;
        Font font = client.font;

        for (int slot = 0; slot < 9; slot++) {
            ItemStack stack = client.player.getInventory().getItem(slot);
            if (stack == null || stack.isEmpty()) continue;

            String sbId = getSkyblockItemId(stack);
            String cleanName = fastStripFormatting(stack.getHoverName().getString()).toUpperCase(Locale.ROOT);

            Long endMs = null;
            for (Map.Entry<String, Long> e : COOLDOWN_DURATION_MS.entrySet()) {
                String key = e.getKey();
                String human = key.replace('_', ' ');
                if ((sbId != null && sbId.equalsIgnoreCase(key)) || cleanName.contains(human)) {
                    endMs = COOLDOWN_END_MS.get(key);
                    break;
                }
            }

            if (endMs != null && endMs > now) {
                double remSec = (endMs - now) / 1000.0;
                String txt = remSec >= 10.0
                    ? String.format(Locale.US, "%.0fs", remSec)
                    : String.format(Locale.US, "%.1fs", remSec);
                int slotX = baseX + slot * 20 + 2;
                int slotY = baseY;

                graphics.fill(slotX - 1, slotY - 1, slotX + 17, slotY + 17, 0x88000000);
                int tw = font.width(txt);
                graphics.text(font, txt, slotX + 8 - tw / 2, slotY + 4, 0xFFFFAA00, true);
            }
        }
    }

    private static double parseHpRatio(String clean) {
        Matcher m = HP_PATTERN.matcher(clean);
        if (!m.find()) return -1.0;
        double cur = parseCompactNumber(m.group(1));
        double max = parseCompactNumber(m.group(2));
        if (cur < 0 || max <= 0) return -1.0;
        return cur / max;
    }

    private static double parseCompactNumber(String s) {
        if (s == null || s.isEmpty()) return -1.0;
        s = s.replace(",", "").trim().toUpperCase(Locale.ROOT);
        double mult = 1.0;
        if (s.endsWith("K")) { mult = 1_000.0; s = s.substring(0, s.length() - 1); }
        else if (s.endsWith("M")) { mult = 1_000_000.0; s = s.substring(0, s.length() - 1); }
        else if (s.endsWith("B")) { mult = 1_000_000_000.0; s = s.substring(0, s.length() - 1); }
        try {
            return Double.parseDouble(s) * mult;
        } catch (NumberFormatException e) {
            return -1.0;
        }
    }

    private static String getSkyblockItemId(ItemStack stack) {
        return com.vampy.item.SkyblockItemIds.from(stack);
    }

    public static String fastStripFormatting(String s) {
        if (s == null || s.isEmpty()) return "";
        if (s.indexOf('§') < 0) return s;
        StringBuilder sb = new StringBuilder(s.length());
        for (int i = 0, n = s.length(); i < n; i++) {
            char c = s.charAt(i);
            if (c == '§' && i + 1 < n) {
                i++;
                continue;
            }
            sb.append(c);
        }
        return sb.toString();
    }

    private static boolean containsIgnoreCaseFast(String haystack, String needleLower) {
        if (haystack == null) return false;
        int nLen = needleLower.length();
        int max = haystack.length() - nLen;
        if (max < 0) return false;
        for (int i = 0; i <= max; i++) {
            if (haystack.regionMatches(true, i, needleLower, 0, nLen)) {
                return true;
            }
        }
        return false;
    }
}
