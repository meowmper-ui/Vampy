package com.vampy.render;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.vampy.VampyMod;
import com.vampy.config.VampyConfig;
import com.vampy.price.AhLowestBinCache;
import com.vampy.screen.HudDragScreen;
import java.io.Reader;
import java.io.Writer;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.fabricmc.fabric.api.client.item.v1.ItemTooltipCallback;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.ChatFormatting;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.ChatScreen;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.core.component.DataComponents;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.chat.Style;
import net.minecraft.resources.Identifier;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.CustomData;
import net.minecraft.world.scores.DisplaySlot;
import net.minecraft.world.scores.Objective;
import net.minecraft.world.scores.PlayerScoreEntry;
import net.minecraft.world.scores.Scoreboard;

public final class SlayerProfitTracker {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path SAVE_PATH = FabricLoader.getInstance().getConfigDir().resolve("vampy-profit-tracker.json");
    private static final Path VAMPADDONS_SAVE_PATH = FabricLoader.getInstance().getConfigDir().resolve("vampaddons-profit-tracker.json");
    private static final Path LEGACY_SAVE_PATH = FabricLoader.getInstance().getConfigDir().resolve("riftthraller-profit-tracker.json");
    private static final Path MULTI_SAVE_PATH = FabricLoader.getInstance().getConfigDir().resolve("vampy-multislayer-profit.json");
    private static final Path VAMPADDONS_MULTI_SAVE_PATH = FabricLoader.getInstance().getConfigDir().resolve("vampaddons-multislayer-profit.json");
    private static final Path PRICE_CACHE_PATH = FabricLoader.getInstance().getConfigDir().resolve("vampy-price-cache.json");
    public static final Identifier HUD_ID = Identifier.fromNamespaceAndPath(VampyMod.MOD_ID, "slayer_profit_hud");

    private static final int PAD_X = 6;
    private static final int PAD_Y = 5;
    private static final int LINE_STEP = 10;
    private static final long ACTIVE_COMBAT_WINDOW_MS = 90_000L;
    private static final long AFK_TIMEOUT_MS = 60_000L;
    private static final String DEFAULT_PROFILE_KEY = "Riftstalker Bloodfiend V";

    public enum BossCategory {
        VAMPIRE("Riftstalker Bloodfiend", "Vampire", "Chateau Time"),
        REVENANT("Revenant Horror", "Revenant", "Slayer Time"),
        TARANTULA("Tarantula Broodfather", "Tarantula", "Slayer Time"),
        SVEN("Sven Packmaster", "Sven", "Slayer Time"),
        VOIDGLOOM("Voidgloom Seraph", "Voidgloom", "Slayer Time"),
        INFERNO("Inferno Demonlord", "Inferno", "Slayer Time");

        public final String canonicalBossName;
        public final String shortLabel;
        public final String timeLabel;

        BossCategory(String canonicalBossName, String shortLabel, String timeLabel) {
            this.canonicalBossName = canonicalBossName;
            this.shortLabel = shortLabel;
            this.timeLabel = timeLabel;
        }

        public static BossCategory fromProfileKey(String profileKey) {
            if (profileKey == null || profileKey.isBlank()) return VAMPIRE;
            String lower = profileKey.toLowerCase(Locale.ROOT);
            if (lower.contains("revenant") || lower.contains("atoned")) return REVENANT;
            if (lower.contains("tarantula") || lower.contains("broodfather") || lower.contains("conjoined")) return TARANTULA;
            if (lower.contains("sven") || lower.contains("packmaster")) return SVEN;
            if (lower.contains("voidgloom") || lower.contains("seraph")) return VOIDGLOOM;
            if (lower.contains("inferno") || lower.contains("demonlord")) return INFERNO;
            return VAMPIRE;
        }
    }

    public enum DropType {
        // ==================== VAMPIRE SLAYER ====================
        COVEN_SEAL(BossCategory.VAMPIRE, "COVEN_SEAL", "Coven Seal", ChatFormatting.GREEN, "ENCHANTED_REDSTONE", 0L),
        QUANTUM_BOOK_BUNDLE(BossCategory.VAMPIRE, "QUANTUM_BOOK_BUNDLE", "Quantum (Bundle)", ChatFormatting.GREEN, "ENCHANTMENT_QUANTUM_3", 375_000L),
        SOULTWIST_RUNE(BossCategory.VAMPIRE, "SOULTWIST_RUNE", "Soultwist Rune I", ChatFormatting.DARK_PURPLE, "SOULTWIST_RUNE;1", 50_000L),
        BUBBA_BLISTER(BossCategory.VAMPIRE, "BUBBA_BLISTER", "Bubba Blister", ChatFormatting.GOLD, "BUBBA_BLISTER", 250_000L),
        FANGTASTIC_CHOCOLATE_CHIP(BossCategory.VAMPIRE, "FANGTASTIC_CHOCOLATE_CHIP", "Fang-tastic Chip", ChatFormatting.GOLD, "CHOCOLATE_CHIP", 300_000L),
        GUARDIAN_LUCKY_BLOCK(BossCategory.VAMPIRE, "GUARDIAN_LUCKY_BLOCK", "Guardian Lucky Block", ChatFormatting.GOLD, "GUARDIAN_LUCKY_BLOCK", 1_500_000L),
        MCGRUBBERS_BURGER(BossCategory.VAMPIRE, "MCGRUBBERS_BURGER", "McGrubber's Burger", ChatFormatting.DARK_PURPLE, "MCGRUBBER_BURGER", 0L),
        UNFANGED_VAMPIRE_PART(BossCategory.VAMPIRE, "UNFANGED_VAMPIRE_PART", "Unfanged Vampire Part", ChatFormatting.GOLD, "VAMPIRE_DENTIST_RELIC", 145_000_000L),
        THE_ONE_IV(BossCategory.VAMPIRE, "THE_ONE_IV", "The One IV (Bundle)", ChatFormatting.GOLD, "ENCHANTMENT_ULTIMATE_THE_ONE_4", 15_000_000L),
        SANGRIA_DYE(BossCategory.VAMPIRE, "SANGRIA_DYE", "Sangria Dye", ChatFormatting.DARK_RED, "DYE_SANGRIA", 100_000_000L),

        // ==================== REVENANT HORROR (ZOMBIE SLAYER) ====================
        REVENANT_FLESH(BossCategory.REVENANT, "REVENANT_FLESH", "Revenant Flesh", ChatFormatting.GREEN, "REVENANT_FLESH", 5L),
        FOUL_FLESH(BossCategory.REVENANT, "FOUL_FLESH", "Foul Flesh", ChatFormatting.BLUE, "FOUL_FLESH", 25_000L),
        REVENANT_VISCERA(BossCategory.REVENANT, "REVENANT_VISCERA", "Revenant Viscera", ChatFormatting.BLUE, "REVENANT_VISCERA", 40_000L),
        PESTILENCE_RUNE(BossCategory.REVENANT, "PESTILENCE_RUNE", "Pestilence Rune I", ChatFormatting.DARK_GREEN, "PESTILENCE_RUNE;1", 5_000L),
        UNDEAD_CATALYST(BossCategory.REVENANT, "UNDEAD_CATALYST", "Undead Catalyst", ChatFormatting.BLUE, "UNDEAD_CATALYST", 10_000L),
        REVENANT_CATALYST(BossCategory.REVENANT, "REVENANT_CATALYST", "Revenant Catalyst", ChatFormatting.DARK_PURPLE, "REVENANT_CATALYST", 25_000L),
        REVENANT_SHARD(BossCategory.REVENANT, "REVENANT_SHARD", "Revenant Shard", ChatFormatting.DARK_PURPLE, "SHARD_REVENANT", 150_000L),
        SMITE_VI(BossCategory.REVENANT, "SMITE_VI", "Smite VI", ChatFormatting.DARK_PURPLE, "ENCHANTMENT_SMITE_6", 10_000L),
        BEHEADED_HORROR(BossCategory.REVENANT, "BEHEADED_HORROR", "Beheaded Horror", ChatFormatting.DARK_PURPLE, "BEHEADED_HORROR", 150_000L),
        SNAKE_RUNE(BossCategory.REVENANT, "SNAKE_RUNE", "Snake Rune I", ChatFormatting.GREEN, "SNAKE_RUNE;1", 50_000L),
        FESTERING_MAGGOT(BossCategory.REVENANT, "FESTERING_MAGGOT", "Festering Maggot", ChatFormatting.DARK_PURPLE, "FESTERING_MAGGOT", 300_000L),
        SCYTHE_BLADE(BossCategory.REVENANT, "SCYTHE_BLADE", "Scythe Blade", ChatFormatting.GOLD, "SCYTHE_BLADE", 3_500_000L),
        SHREDDED_SINEW(BossCategory.REVENANT, "SHREDDED_SINEW", "Shredded Sinew", ChatFormatting.GOLD, "SHARD_OF_THE_SHREDDED", 9_500_000L),
        SEVERED_HAND(BossCategory.REVENANT, "SEVERED_HAND", "Severed Hand", ChatFormatting.GOLD, "SEVERED_HAND", 12_000_000L),
        WARDEN_HEART(BossCategory.REVENANT, "WARDEN_HEART", "Warden Heart", ChatFormatting.GOLD, "WARDEN_HEART", 160_000_000L),
        REV_PARAGON_SHARD(BossCategory.REVENANT, "REV_PARAGON_SHARD", "Paragon Shard", ChatFormatting.GOLD, "SHARD_PARAGON", 1_000_000L),
        MATCHA_DYE(BossCategory.REVENANT, "MATCHA_DYE", "Matcha Dye", ChatFormatting.GREEN, "DYE_MATCHA", 80_000_000L),

        // ==================== TARANTULA BROODFATHER (SPIDER SLAYER) ====================
        TARANTULA_WEB(BossCategory.TARANTULA, "TARANTULA_WEB", "Tarantula Web", ChatFormatting.GREEN, "TARANTULA_WEB", 100L),
        TARANTULA_SILK(BossCategory.TARANTULA, "TARANTULA_SILK", "Tarantula Silk", ChatFormatting.BLUE, "TARANTULA_SILK", 35_000L),
        TOXIC_ARROW_POISON(BossCategory.TARANTULA, "TOXIC_ARROW_POISON", "Toxic Arrow Poison", ChatFormatting.GREEN, "TOXIC_ARROW_POISON", 2_000L),
        BITE_RUNE(BossCategory.TARANTULA, "BITE_RUNE", "Bite Rune I", ChatFormatting.GREEN, "BITE_RUNE;1", 10_000L),
        PRIMORDIAL_SHARD(BossCategory.TARANTULA, "PRIMORDIAL_SHARD", "Primordial Shard", ChatFormatting.DARK_PURPLE, "SHARD_PRIMORDIAL", 250_000L),
        SPIDER_CATALYST(BossCategory.TARANTULA, "SPIDER_CATALYST", "Spider Catalyst", ChatFormatting.BLUE, "SPIDER_CATALYST", 15_000L),
        TARANTULA_CATALYST(BossCategory.TARANTULA, "TARANTULA_CATALYST", "Tarantula Catalyst", ChatFormatting.DARK_PURPLE, "TARANTULA_CATALYST", 100_000L),
        DARKNESS_WITHIN_RUNE(BossCategory.TARANTULA, "DARKNESS_WITHIN_RUNE", "Darkness Within Rune I", ChatFormatting.DARK_PURPLE, "DARKNESS_WITHIN_RUNE;1", 250_000L),
        BANE_OF_ARTHROPODS_VI(BossCategory.TARANTULA, "BANE_OF_ARTHROPODS_VI", "Bane of Arthropods VI", ChatFormatting.DARK_PURPLE, "ENCHANTMENT_BANE_OF_ARTHROPODS_6", 10_000L),
        FLY_SWATTER(BossCategory.TARANTULA, "FLY_SWATTER", "Fly Swatter", ChatFormatting.GOLD, "FLY_SWATTER", 300_000L),
        TARANTULA_TALISMAN(BossCategory.TARANTULA, "TARANTULA_TALISMAN", "Tarantula Talisman", ChatFormatting.DARK_PURPLE, "TARANTULA_TALISMAN", 1_500_000L),
        VIAL_OF_VENOM(BossCategory.TARANTULA, "VIAL_OF_VENOM", "Vial of Venom", ChatFormatting.DARK_PURPLE, "VIAL_OF_VENOM", 500_000L),
        SHRIVELED_WASP(BossCategory.TARANTULA, "SHRIVELED_WASP", "Shriveled Wasp", ChatFormatting.GOLD, "SHRIVELED_WASP", 3_000_000L),
        DIGESTED_MOSQUITO(BossCategory.TARANTULA, "DIGESTED_MOSQUITO", "Digested Mosquito", ChatFormatting.GOLD, "DIGESTED_MOSQUITO", 2_500_000L),
        ENSNARED_SNAIL(BossCategory.TARANTULA, "ENSNARED_SNAIL", "Ensnared Snail", ChatFormatting.GOLD, "ENSNARED_SNAIL", 8_000_000L),
        PRIMORDIAL_EYE(BossCategory.TARANTULA, "PRIMORDIAL_EYE", "Primordial Eye", ChatFormatting.GOLD, "PRIMORDIAL_EYE", 85_000_000L),
        TARA_PARAGON_SHARD(BossCategory.TARANTULA, "TARA_PARAGON_SHARD", "Paragon Shard", ChatFormatting.GOLD, "SHARD_PARAGON", 1_000_000L),
        BRICK_RED_DYE(BossCategory.TARANTULA, "BRICK_RED_DYE", "Brick Red Dye", ChatFormatting.RED, "DYE_BRICK_RED", 60_000_000L),

        // ==================== SVEN PACKMASTER (WOLF SLAYER) ====================
        WOLF_TOOTH(BossCategory.SVEN, "WOLF_TOOTH", "Wolf Tooth", ChatFormatting.GREEN, "WOLF_TOOTH", 100L),
        HAMSTER_WHEEL(BossCategory.SVEN, "HAMSTER_WHEEL", "Hamster Wheel", ChatFormatting.BLUE, "HAMSTER_WHEEL", 20_000L),
        SPIRIT_RUNE(BossCategory.SVEN, "SPIRIT_RUNE", "Spirit Rune I", ChatFormatting.AQUA, "SPIRIT_RUNE;1", 10_000L),
        CRITICAL_VI(BossCategory.SVEN, "CRITICAL_VI", "Critical VI", ChatFormatting.DARK_PURPLE, "ENCHANTMENT_CRITICAL_6", 150_000L),
        FURBALL(BossCategory.SVEN, "FURBALL", "Furball", ChatFormatting.BLUE, "FURBALL", 80_000L),
        RED_CLAW_EGG(BossCategory.SVEN, "RED_CLAW_EGG", "Red Claw Egg", ChatFormatting.DARK_PURPLE, "RED_CLAW_EGG", 500_000L),
        COUTURE_RUNE(BossCategory.SVEN, "COUTURE_RUNE", "Couture Rune I", ChatFormatting.GOLD, "COUTURE_RUNE;1", 150_000L),
        GRIZZLY_SALMON(BossCategory.SVEN, "GRIZZLY_SALMON", "Grizzly Salmon", ChatFormatting.BLUE, "GRIZZLY_BAIT", 1_200_000L),
        OVERFLUX_CAPACITOR(BossCategory.SVEN, "OVERFLUX_CAPACITOR", "Overflux Capacitor", ChatFormatting.DARK_PURPLE, "OVERFLUX_CAPACITOR", 45_000_000L),
        SVEN_PARAGON_SHARD(BossCategory.SVEN, "SVEN_PARAGON_SHARD", "Paragon Shard", ChatFormatting.GOLD, "SHARD_PARAGON", 1_000_000L),
        CELESTE_DYE(BossCategory.SVEN, "CELESTE_DYE", "Celeste Dye", ChatFormatting.AQUA, "DYE_CELESTE", 60_000_000L),

        // ==================== VOIDGLOOM SERAPH (ENDERMAN SLAYER) ====================
        NULL_SPHERE(BossCategory.VOIDGLOOM, "NULL_SPHERE", "Null Sphere", ChatFormatting.GREEN, "NULL_SPHERE", 10L),
        TWILIGHT_ARROW_POISON(BossCategory.VOIDGLOOM, "TWILIGHT_ARROW_POISON", "Twilight Arrow Poison", ChatFormatting.BLUE, "TWILIGHT_ARROW_POISON", 2_500L),
        ENDERSNAKE_RUNE(BossCategory.VOIDGLOOM, "ENDERSNAKE_RUNE", "Endersnake Rune I", ChatFormatting.DARK_PURPLE, "ENDERSNAKE_RUNE;1", 10_000L),
        NULL_ATOM(BossCategory.VOIDGLOOM, "NULL_ATOM", "Null Atom", ChatFormatting.BLUE, "NULL_ATOM", 25_000L),
        MANA_STEAL_I(BossCategory.VOIDGLOOM, "MANA_STEAL_I", "Mana Steal I", ChatFormatting.BLUE, "ENCHANTMENT_MANA_STEAL_1", 10_000L),
        TRANSMISSION_TUNER(BossCategory.VOIDGLOOM, "TRANSMISSION_TUNER", "Transmission Tuner", ChatFormatting.DARK_PURPLE, "TRANSMISSION_TUNER", 40_000L),
        SMARTY_PANTS_I(BossCategory.VOIDGLOOM, "SMARTY_PANTS_I", "Smarty Pants I", ChatFormatting.DARK_PURPLE, "ENCHANTMENT_SMARTY_PANTS_1", 80_000L),
        HAZMAT_ENDERMAN(BossCategory.VOIDGLOOM, "HAZMAT_ENDERMAN", "Hazmat Enderman", ChatFormatting.GOLD, "HAZMAT_ENDERMAN", 50_000L),
        END_RUNE(BossCategory.VOIDGLOOM, "END_RUNE", "End Rune I", ChatFormatting.DARK_PURPLE, "END_RUNE;1", 50_000L),
        SUMMONING_EYE(BossCategory.VOIDGLOOM, "SUMMONING_EYE", "Summoning Eye", ChatFormatting.DARK_PURPLE, "SUMMONING_EYE", 900_000L),
        SINFUL_DICE(BossCategory.VOIDGLOOM, "SINFUL_DICE", "Sinful Dice", ChatFormatting.DARK_PURPLE, "SINFUL_DICE", 1_000_000L),
        ETHERWARP_MERGER(BossCategory.VOIDGLOOM, "ETHERWARP_MERGER", "Etherwarp Merger", ChatFormatting.DARK_PURPLE, "ETHERWARP_MERGER", 250_000L),
        POCKET_ESPRESSO_MACHINE(BossCategory.VOIDGLOOM, "POCKET_ESPRESSO_MACHINE", "Pocket Espresso Machine", ChatFormatting.GREEN, "POCKET_ESPRESSO_MACHINE", 50_000L),
        HANDY_BLOOD_CHALICE(BossCategory.VOIDGLOOM, "HANDY_BLOOD_CHALICE", "Handy Blood Chalice", ChatFormatting.WHITE, "HANDY_BLOOD_CHALICE", 2_000_000L),
        VOID_CONQUEROR_SKIN(BossCategory.VOIDGLOOM, "VOID_CONQUEROR_SKIN", "Void Conqueror Skin", ChatFormatting.DARK_PURPLE, "PET_SKIN_ENDERMAN_SLAYER", 15_000_000L),
        JUDGEMENT_CORE(BossCategory.VOIDGLOOM, "JUDGEMENT_CORE", "Judgement Core", ChatFormatting.GOLD, "JUDGEMENT_CORE", 260_000_000L),
        ENCHANT_RUNE(BossCategory.VOIDGLOOM, "ENCHANT_RUNE", "Enchant Rune I", ChatFormatting.GRAY, "ENCHANT_RUNE;1", 2_500_000L),
        ENDER_ARTIFACT_UPGRADER(BossCategory.VOIDGLOOM, "ENDER_ARTIFACT_UPGRADER", "Ender Artifact Upgrader", ChatFormatting.DARK_PURPLE, "EXCEEDINGLY_RARE_ENDER_ARTIFACT_UPGRADER", 5_000_000L),
        END_STONE_IDOL(BossCategory.VOIDGLOOM, "END_STONE_IDOL", "End Stone Idol", ChatFormatting.GOLD, "ENDSTONE_IDOL", 30_000_000L),
        VOID_PARAGON_SHARD(BossCategory.VOIDGLOOM, "VOID_PARAGON_SHARD", "Paragon Shard", ChatFormatting.GOLD, "SHARD_PARAGON", 1_000_000L),
        BYZANTIUM_DYE(BossCategory.VOIDGLOOM, "BYZANTIUM_DYE", "Byzantium Dye", ChatFormatting.DARK_PURPLE, "DYE_BYZANTIUM", 75_000_000L),

        // ==================== INFERNO DEMONLORD (BLAZE SLAYER) ====================
        DERELICT_ASHE(BossCategory.INFERNO, "DERELICT_ASHE", "Derelict Ashe", ChatFormatting.GREEN, "DERELICT_ASHE", 200L),
        ENCHANTED_BLAZE_POWDER(BossCategory.INFERNO, "ENCHANTED_BLAZE_POWDER", "Enchanted Blaze Powder", ChatFormatting.GREEN, "ENCHANTED_BLAZE_POWDER", 2_000L),
        LAVATEARS_RUNE(BossCategory.INFERNO, "LAVATEARS_RUNE", "Lavatears Rune I", ChatFormatting.RED, "LAVATEARS_RUNE;1", 25_000L),
        WISPS_ICE_WATER(BossCategory.INFERNO, "WISPS_ICE_WATER", "Wisp's Ice Water", ChatFormatting.BLUE, "POTION_WISP_ICE;1", 25_000L),
        BUNDLE_OF_MAGMA_ARROWS(BossCategory.INFERNO, "BUNDLE_OF_MAGMA_ARROWS", "Bundle of Magma Arrows", ChatFormatting.BLUE, "ARROW_BUNDLE_MAGMA", 50_000L),
        MANA_DISINTEGRATOR(BossCategory.INFERNO, "MANA_DISINTEGRATOR", "Mana Disintegrator", ChatFormatting.BLUE, "MANA_DISINTEGRATOR", 80_000L),
        SCORCHED_BOOKS(BossCategory.INFERNO, "SCORCHED_BOOKS", "Scorched Books", ChatFormatting.DARK_PURPLE, "SCORCHED_BOOKS", 250_000L),
        INFERNO_DEMONLORD_SHARD(BossCategory.INFERNO, "INFERNO_DEMONLORD_SHARD", "Inferno Demonlord Shard", ChatFormatting.DARK_PURPLE, "SHARD_HELLWISP", 250_000L),
        KELVIN_INVERTER(BossCategory.INFERNO, "KELVIN_INVERTER", "Kelvin Inverter", ChatFormatting.BLUE, "KELVIN_INVERTER", 60_000L),
        BLAZE_ROD_DISTILLATE(BossCategory.INFERNO, "BLAZE_ROD_DISTILLATE", "Blaze Rod Distillate", ChatFormatting.BLUE, "BLAZE_ROD_DISTILLATE", 20_000L),
        GLOWSTONE_DISTILLATE(BossCategory.INFERNO, "GLOWSTONE_DISTILLATE", "Glowstone Distillate", ChatFormatting.BLUE, "GLOWSTONE_DUST_DISTILLATE", 20_000L),
        MAGMA_CREAM_DISTILLATE(BossCategory.INFERNO, "MAGMA_CREAM_DISTILLATE", "Magma Cream Distillate", ChatFormatting.BLUE, "MAGMA_CREAM_DISTILLATE", 20_000L),
        NETHER_WART_DISTILLATE(BossCategory.INFERNO, "NETHER_WART_DISTILLATE", "Nether Wart Distillate", ChatFormatting.BLUE, "NETHER_STALK_DISTILLATE", 20_000L),
        GABAGOOL_DISTILLATE(BossCategory.INFERNO, "GABAGOOL_DISTILLATE", "Gabagool Distillate", ChatFormatting.BLUE, "CRUDE_GABAGOOL_DISTILLATE", 40_000L),
        SCORCHED_POWER_CRYSTAL(BossCategory.INFERNO, "SCORCHED_POWER_CRYSTAL", "Scorched Power Crystal", ChatFormatting.GOLD, "SCORCHED_POWER_CRYSTAL", 400_000L),
        ARCHFIEND_DICE(BossCategory.INFERNO, "ARCHFIEND_DICE", "Archfiend Dice", ChatFormatting.DARK_PURPLE, "ARCHFIEND_DICE", 6_500_000L),
        FIRE_ASPECT_III(BossCategory.INFERNO, "FIRE_ASPECT_III", "Fire Aspect III", ChatFormatting.DARK_PURPLE, "ENCHANTMENT_FIRE_ASPECT_3", 250_000L),
        FIERY_BURST_RUNE(BossCategory.INFERNO, "FIERY_BURST_RUNE", "Fiery Burst Rune I", ChatFormatting.GOLD, "FIERY_BURST_RUNE;1", 5_000_000L),
        FLAWED_OPAL_GEMSTONE(BossCategory.INFERNO, "FLAWED_OPAL_GEMSTONE", "Flawed Opal Gemstone", ChatFormatting.GREEN, "FLAWED_OPAL_GEM", 1_500L),
        DUPLEX_I(BossCategory.INFERNO, "DUPLEX_I", "Duplex I", ChatFormatting.GOLD, "ENCHANTMENT_ULTIMATE_REITERATE_1", 10_000_000L),
        HIGH_CLASS_ARCHFIEND_DICE(BossCategory.INFERNO, "HIGH_CLASS_ARCHFIEND_DICE", "High Class Archfiend Dice", ChatFormatting.GOLD, "HIGH_CLASS_ARCHFIEND_DICE", 55_000_000L),
        WILSONS_ENGINEERING_PLANS(BossCategory.INFERNO, "WILSONS_ENGINEERING_PLANS", "Wilson's Plans", ChatFormatting.GOLD, "WILSON_ENGINEERING_PLANS", 45_000_000L),
        SUBZERO_INVERTER(BossCategory.INFERNO, "SUBZERO_INVERTER", "Subzero Inverter", ChatFormatting.GOLD, "SUBZERO_INVERTER", 15_000_000L),
        INF_PARAGON_SHARD(BossCategory.INFERNO, "INF_PARAGON_SHARD", "Paragon Shard", ChatFormatting.GOLD, "SHARD_PARAGON", 1_000_000L),
        FLAME_DYE(BossCategory.INFERNO, "FLAME_DYE", "Flame Dye", ChatFormatting.GOLD, "DYE_FLAME", 80_000_000L);

        public final BossCategory category;
        public final String key;
        public final String displayName;
        public final ChatFormatting color;
        public final String priceLookupId;
        public final long fallbackCoins;

        DropType(BossCategory category, String key, String displayName, ChatFormatting color, String priceLookupId, long fallbackCoins) {
            this.category = category;
            this.key = key;
            this.displayName = displayName;
            this.color = color;
            this.priceLookupId = priceLookupId;
            this.fallbackCoins = fallbackCoins;
        }

        public static List<DropType> forCategory(BossCategory cat) {
            List<DropType> out = new ArrayList<>();
            for (DropType dt : values()) {
                if (dt.category == cat) out.add(dt);
            }
            return out;
        }
    }

    public enum ViewMode {
        SESSION("Session"),
        TOTAL("Lifetime");
        public final String label;
        ViewMode(String label) { this.label = label; }
    }

    public static final class StatsBucket {
        public int bossesSpawned = 0;
        public int bossesKilled = 0;
        public int manualBossesKilled = 0;
        public int bossesFailed = 0;
        public long activePlaytimeMs = 0L;
        public Map<String, Integer> drops = new HashMap<>();

        public int getDropCount(DropType type) { return drops.getOrDefault(type.key, 0); }
        public void addDrop(DropType type, int amount) {
            if (type == null) return;
            int next = Math.max(0, getDropCount(type) + amount);
            if (next == 0) drops.remove(type.key);
            else drops.put(type.key, next);
        }
        public int totalCompleted() { return bossesKilled + bossesFailed; }
        public double winratePercent() {
            int total = totalCompleted();
            return total <= 0 ? 100.0 : (bossesKilled * 100.0) / total;
        }
        public long totalValueCoins() {
            return totalValueCoinsForCategory(null);
        }
        public long totalValueCoinsForCategory(BossCategory cat) {
            long sum = 0L;
            for (DropType type : DropType.values()) {
                if (cat != null && type.category != cat) continue;
                if (VampyConfig.isProfitDropHidden(type.key)) continue;
                int count = getDropCount(type);
                if (count > 0) sum += count * getUnitPrice(type);
            }
            return sum;
        }
        public long coinsPerHour() {
            return coinsPerHourForCategory(null);
        }
        public long coinsPerHourForCategory(BossCategory cat) {
            if (activePlaytimeMs < 5_000L) return 0L;
            double hours = activePlaytimeMs / 3_600_000.0;
            return Math.round(totalValueCoinsForCategory(cat) / hours);
        }
        public double bossesPerHour() {
            if (activePlaytimeMs < 5_000L) return 0.0;
            double hours = activePlaytimeMs / 3_600_000.0;
            int timedKills = Math.max(0, bossesKilled - manualBossesKilled);
            return timedKills / hours;
        }
    }

    private static final class ClickZone {
        final double x1, y1, x2, y2;
        final DropType dropType;
        final boolean modeToggle;
        final boolean priceTypeToggle;
        ClickZone(double x1, double y1, double x2, double y2, DropType dropType, boolean modeToggle, boolean priceTypeToggle) {
            this.x1 = x1; this.y1 = y1; this.x2 = x2; this.y2 = y2;
            this.dropType = dropType;
            this.modeToggle = modeToggle;
            this.priceTypeToggle = priceTypeToggle;
        }
        boolean contains(double mx, double my) {
            return mx >= x1 && mx <= x2 && my >= y1 && my <= y2;
        }
    }

    private static final Map<String, StatsBucket> totalBucketsByProfile = new ConcurrentHashMap<>();
    private static final Map<String, StatsBucket> sessionBucketsByProfile = new ConcurrentHashMap<>();
    private static final Map<BossCategory, String> lastProfileByCategory = new EnumMap<>(BossCategory.class);
    private static String activeProfileKey = DEFAULT_PROFILE_KEY;
    private static ViewMode currentMode = ViewMode.SESSION;

    static {
        for (BossCategory cat : BossCategory.values()) {
            lastProfileByCategory.put(cat, defaultProfileForCategory(cat));
        }
    }

    // Отдельный кэш для Bazaar Insta-Sell, Bazaar Insta-Buy и AH LowestBIN
    private static final Map<String, Long> bzInstaSellPrices = new ConcurrentHashMap<>();
    private static final Map<String, Long> bzInstaBuyPrices = new ConcurrentHashMap<>();
    private static final Map<String, Long> ahLowestBinPrices = new ConcurrentHashMap<>();
    private static long lastPriceFetchMs = 0L;
    private static boolean fetchingPrices = false;

    private static long lastSlayerActivityMs = 0L;
    private static long lastBossKillWindowUntilMs = 0L;
    private static long lastTickTimeMs = 0L;
    private static String lastDropFingerprint = "";
    private static long lastDropFingerprintMs = 0L;
    private static final Map<DropType, Integer> lastInventoryCounts = new EnumMap<>(DropType.class);
    private static boolean inventoryBaselineInitialized = false;
    private static long lastScreenOpenTimeMs = 0L;
    private static final List<ClickZone> activeClickZones = new ArrayList<>();
    private static double lastHudX1, lastHudY1, lastHudX2, lastHudY2;

    private static double lastPlayerX = Double.NaN, lastPlayerY = Double.NaN, lastPlayerZ = Double.NaN;
    private static float lastPlayerYaw = Float.NaN, lastPlayerPitch = Float.NaN;
    private static long lastMovementMs = 0L;
    private static boolean cachedInRift = false;
    private static boolean cachedInChateau = false;
    private static BossCategory cachedLocationCategory = null;
    private static Object lastKnownLevel = null;
    public static boolean isInRift() { return cachedInRift || cachedInChateau; }
    public static boolean isInStillgoreChateau() { return cachedInChateau; }
    public static boolean isInSlayerLocation() { return cachedLocationCategory != null || cachedInChateau || cachedInRift || cachedQuestActive; }
    public static BossCategory getCurrentLocationCategory() { return cachedLocationCategory; }
    private static boolean cachedQuestActive = false;
    private static long lastScoreboardCheckMs = 0L;

    private static final Pattern BUNDLE_TIER_PATTERN = Pattern.compile("(Quantum|The One)\\s+(III|II|IV|V|I|1|2|3|4|5)\\b", Pattern.CASE_INSENSITIVE);
    private static final Pattern COUNT_PREFIX_PATTERN = Pattern.compile("(?:(\\d+)x\\s+|\\+(\\d+)\\s+|\\((\\d+)x\\))", Pattern.CASE_INSENSITIVE);
    private static final Pattern SACK_PICKUP_PATTERN = Pattern.compile("\\+([\\d,]+)\\s+([A-Za-z'\\- ]+?)(?:\\s*\\(|$)", Pattern.CASE_INSENSITIVE);

    private static final Map<String, String[]> BAZAAR_ALIASES = Map.ofEntries(
        Map.entry("CHOCOLATE_CHIP", new String[]{"CHOCOLATE_CHIP", "FANG_TASTIC_CHOCOLATE_CHIP", "FANGTASTIC_CHOCOLATE_CHIP"}),
        Map.entry("MCGRUBBER_BURGER", new String[]{"MCGRUBBER_BURGER", "MCGRUBBERS_BURGER"}),
        Map.entry("BUBBA_BLISTER", new String[]{"BUBBA_BLISTER"}),
        Map.entry("ENCHANTMENT_QUANTUM_3", new String[]{"ENCHANTMENT_QUANTUM_3"}),
        Map.entry("ENCHANTMENT_ULTIMATE_THE_ONE_4", new String[]{"ENCHANTMENT_ULTIMATE_THE_ONE_4"}),
        Map.entry("SOULTWIST_RUNE;1", new String[]{"RUNE_SOULTWIST_1", "SOULTWIST_RUNE;1"}),
        Map.entry("SHARD_OF_THE_SHREDDED", new String[]{"SHARD_OF_THE_SHREDDED", "SHREDDED_SINEW"}),
        Map.entry("ENCHANTMENT_ULTIMATE_REITERATE_1", new String[]{"ENCHANTMENT_ULTIMATE_REITERATE_1", "ENCHANTMENT_ULTIMATE_DUPLEX_1", "ENCHANTMENT_DUPLEX_1"}),
        Map.entry("SHARD_HELLWISP", new String[]{"SHARD_HELLWISP", "INFERNO_DEMONLORD_SHARD"})
    );

    private SlayerProfitTracker() {}

    public static void register() {
        load();
        loadPriceCache();
        refreshPricesAsync();
        HudElementRegistry.attachElementBefore(VanillaHudElements.PLAYER_LIST, HUD_ID, SlayerProfitTracker::renderHud);
        ScreenEvents.AFTER_INIT.register((client, screen, scaledWidth, scaledHeight) -> {
            if (screen instanceof ChatScreen || screen instanceof AbstractContainerScreen<?>) {
                ScreenEvents.afterExtract(screen).register((scr, context, mouseX, mouseY, tickDelta) -> {
                    renderOnScreen(context);
                });
            }
        });
        ItemTooltipCallback.EVENT.register((stack, tooltipContext, tooltipType, lines) -> appendBundlePriceTooltip(stack, lines));
    }

    public static void onWorldChange() {
        cachedInRift = false;
        cachedInChateau = false;
        cachedLocationCategory = null;
        cachedQuestActive = false;
        lastScoreboardCheckMs = 0L;
        inventoryBaselineInitialized = false;
    }

    public static void notifyDetectedBossWithTier(String canonicalBossWithTier) {
        if (canonicalBossWithTier == null || canonicalBossWithTier.isBlank()) return;
        String normalized = normalizeProfileKey(canonicalBossWithTier);
        if (normalized == null) return;
        BossCategory detectedCat = BossCategory.fromProfileKey(normalized);
        lastProfileByCategory.put(detectedCat, normalized);
        // Switch active profile only if we are currently in that Slayer's respective location
        if (cachedLocationCategory == detectedCat && !normalized.equals(activeProfileKey)) {
            activeProfileKey = normalized;
        }
    }

    private static String resolveTargetProfileKey(String bossWithTier) {
        if (bossWithTier != null && !bossWithTier.isBlank()) {
            String normalized = normalizeProfileKey(bossWithTier);
            if (normalized != null) {
                BossCategory detectedCat = BossCategory.fromProfileKey(normalized);
                lastProfileByCategory.put(detectedCat, normalized);
                if (cachedLocationCategory == null || cachedLocationCategory == detectedCat) {
                    activeProfileKey = normalized;
                    return normalized;
                }
            }
        }
        if (cachedLocationCategory != null && getActiveCategory() != cachedLocationCategory) {
            activeProfileKey = lastProfileByCategory.getOrDefault(
                    cachedLocationCategory,
                    defaultProfileForCategory(cachedLocationCategory)
            );
        }
        return activeProfileKey;
    }

    private static String normalizeProfileKey(String raw) {
        if (raw == null || raw.isBlank()) return DEFAULT_PROFILE_KEY;
        String parsed = SlayerTimerTracker.parseCanonicalBossAndTier(raw);
        if (parsed != null) return parsed;
        String t = raw.trim();
        if (t.endsWith(" I") || t.endsWith(" II") || t.endsWith(" III") || t.endsWith(" IV") || t.endsWith(" V")) {
            return t;
        }
        return DEFAULT_PROFILE_KEY;
    }

    public static String getActiveProfileKey() {
        return activeProfileKey;
    }

    public static BossCategory getActiveCategory() {
        return BossCategory.fromProfileKey(activeProfileKey);
    }

    public static String getActiveTierRoman() {
        if (activeProfileKey == null) return "V";
        int idx = activeProfileKey.lastIndexOf(' ');
        if (idx > 0 && idx + 1 < activeProfileKey.length()) {
            return activeProfileKey.substring(idx + 1).trim();
        }
        return "V";
    }

    public static String getActiveTrackerHeaderTitle() {
        BossCategory cat = getActiveCategory();
        String tier = getActiveTierRoman();
        return cat.shortLabel + " " + tier + " Tracker ";
    }

    public static DropType findDropType(String query) {
        if (query == null || query.isBlank()) return null;
        String q = query.trim().toLowerCase(Locale.ROOT).replace('-', '_').replace(' ', '_');
        BossCategory activeCat = getActiveCategory();
        // First pass: prefer drops in the currently active boss category
        for (DropType dt : DropType.values()) {
            if (dt.category == activeCat && (dt.key.toLowerCase(Locale.ROOT).equals(q)
                    || dt.key.toLowerCase(Locale.ROOT).contains(q)
                    || dt.displayName.toLowerCase(Locale.ROOT).replace(' ', '_').contains(q))) {
                return dt;
            }
        }
        for (DropType dt : DropType.values()) {
            if (dt.key.toLowerCase(Locale.ROOT).equals(q)
                    || dt.key.toLowerCase(Locale.ROOT).contains(q)
                    || dt.displayName.toLowerCase(Locale.ROOT).replace(' ', '_').contains(q)) {
                return dt;
            }
        }
        return null;
    }

    public static boolean isCategoryTrackerEnabled(BossCategory category) {
        if (category == null) return false;
        return switch (category) {
            case VAMPIRE -> VampyConfig.isTrackVampireSlayer();
            case REVENANT -> VampyConfig.isTrackZombieSlayer();
            case TARANTULA -> VampyConfig.isTrackSpiderSlayer();
            case SVEN -> VampyConfig.isTrackWolfSlayer();
            case VOIDGLOOM -> VampyConfig.isTrackEndermanSlayer();
            case INFERNO -> VampyConfig.isTrackBlazeSlayer();
        };
    }

    public static boolean shouldRenderTracker() {
        if (!VampyConfig.isSlayerProfitTrackerEnabled()) return false;
        Minecraft client = Minecraft.getInstance();
        if (client == null || client.level == null || client.player == null) return false;
        if (lastKnownLevel != null && client.level != lastKnownLevel) {
            return false;
        }
        return cachedLocationCategory != null
                && getActiveCategory() == cachedLocationCategory
                && isCategoryTrackerEnabled(cachedLocationCategory);
    }

    public static boolean handleMouseClick(double mouseX, double mouseY, int button) {
        Minecraft client = Minecraft.getInstance();
        if (!shouldRenderTracker()) return false;
        if (!isInteractiveScreenOpen(client)) return false;
        if (mouseX < lastHudX1 || mouseX > lastHudX2 || mouseY < lastHudY1 || mouseY > lastHudY2) return false;

        float scale = (float) Math.clamp(VampyConfig.getSlayerProfitScale(), 0.5, 3.0);
        for (ClickZone cz : activeClickZones) {
            if (cz.contains(mouseX, mouseY)) {
                if (cz.modeToggle) {
                    if (button == 1) {
                        VampyConfig.setBazaarUseInstaBuy(!VampyConfig.isBazaarUseInstaBuy());
                    } else {
                        toggleViewMode();
                    }
                    return true;
                }
                if (cz.priceTypeToggle) {
                    VampyConfig.setBazaarUseInstaBuy(!VampyConfig.isBazaarUseInstaBuy());
                    return true;
                }
                if (cz.dropType != null) {
                    double prefixWidth = 34.0 * scale;
                    double relX = mouseX - cz.x1;
                    if (button == 2) {
                        VampyConfig.toggleProfitDropHidden(cz.dropType.key);
                        return true;
                    }
                    if (relX <= prefixWidth) {
                        if (button == 1 || relX < (prefixWidth * 0.5)) {
                            modifyDropBoth(cz.dropType, -1);
                        } else {
                            modifyDropBoth(cz.dropType, 1);
                        }
                    } else {
                        if (button == 0) {
                            modifyDropBoth(cz.dropType, 1);
                        } else if (button == 1) {
                            VampyConfig.toggleProfitDropHidden(cz.dropType.key);
                        }
                    }
                    return true;
                }
            }
        }
        return false;
    }

    public static ViewMode viewMode() { return currentMode; }
    public static void toggleViewMode() {
        currentMode = (currentMode == ViewMode.SESSION) ? ViewMode.TOTAL : ViewMode.SESSION;
    }

    private static StatsBucket getSessionBucket(String profileKey) {
        String key = normalizeProfileKey(profileKey);
        return sessionBucketsByProfile.computeIfAbsent(key, k -> new StatsBucket());
    }

    private static StatsBucket getTotalBucket(String profileKey) {
        String key = normalizeProfileKey(profileKey);
        return totalBucketsByProfile.computeIfAbsent(key, k -> new StatsBucket());
    }

    public static StatsBucket activeBucket() {
        return currentMode == ViewMode.SESSION ? sessionBucket() : totalBucket();
    }
    public static StatsBucket sessionBucket() { return getSessionBucket(activeProfileKey); }
    public static StatsBucket totalBucket() { return getTotalBucket(activeProfileKey); }

    public static void resetSession() {
        StatsBucket sb = sessionBucket();
        sb.bossesSpawned = 0;
        sb.bossesKilled = 0;
        sb.bossesFailed = 0;
        sb.activePlaytimeMs = 0L;
        sb.drops.clear();
        lastSlayerActivityMs = 0L;
    }

    public static void resetTotal() {
        totalBucketsByProfile.put(activeProfileKey, new StatsBucket());
        resetSession();
        save();
    }

    public static void onPlayerHitMob(net.minecraft.world.entity.Entity target) {
        if (target == null) return;
        if (cachedLocationCategory != null && (cachedInChateau || cachedQuestActive)) {
            markSlayerActivity();
        }
    }

    public static void markSlayerActivity() {
        long now = System.currentTimeMillis();
        if (lastTickTimeMs == 0L) lastTickTimeMs = now;
        lastSlayerActivityMs = now;
        lastMovementMs = now;
    }

    private static String detectTabListArea(Minecraft client) {
        if (client == null || client.getConnection() == null) return "";
        try {
            for (net.minecraft.client.multiplayer.PlayerInfo info : client.getConnection().getOnlinePlayers()) {
                Component disp = info.getTabListDisplayName();
                if (disp == null) continue;
                String clean = ChatFormatting.stripFormatting(disp.getString());
                if (clean == null || clean.isEmpty()) continue;
                String lower = clean.replace('\u00A0', ' ').trim().toLowerCase(Locale.ROOT);
                if (lower.startsWith("area:")) {
                    return lower.substring(5).trim();
                }
                if (lower.startsWith("dungeon:")) {
                    return "dungeon: " + lower.substring(8).trim();
                }
            }
        } catch (Throwable ignored) {}
        return "";
    }

    private static BossCategory classifyZoneLine(String zoneLower, String tabAreaLower, BossCategory questBossCat) {
        if (zoneLower == null || zoneLower.isEmpty()) return null;
        if (zoneLower.contains("the catacombs (") || zoneLower.contains("kuudra")) {
            return null;
        }
        // 1. VAMPIRE SLAYER: Stillgore Château, Oubliette & Fairylosopher Tower in The Rift
        if (zoneLower.contains("stillgore")
                || zoneLower.contains("château")
                || zoneLower.contains("chateau")
                || zoneLower.contains("chât")
                || zoneLower.contains("oubliette")
                || zoneLower.contains("fairylosopher")) {
            return BossCategory.VAMPIRE;
        }
        // 2. REVENANT HORROR: Graveyard, Coal Mine, Crypts (and Catacombs Entrance inside Hub Crypts)
        if (zoneLower.contains("graveyard")
                || zoneLower.contains("coal mine")
                || zoneLower.contains("crypt")
                || zoneLower.contains("catacombs entrance")) {
            return BossCategory.REVENANT;
        }
        // 3. TARANTULA BROODFATHER: Spider's Den & all its sub-locations
        if (zoneLower.contains("spider's den")
                || zoneLower.contains("spiders den")
                || zoneLower.contains("spider mound")
                || zoneLower.contains("arachne")
                || zoneLower.contains("gravel mines")
                || zoneLower.contains("grandma's house")
                || zoneLower.contains("grandmas house")
                || zoneLower.contains("archaeologist's camp")
                || zoneLower.contains("archaeologists camp")) {
            return BossCategory.TARANTULA;
        }
        // 4. SVEN PACKMASTER: Hub Ruins / Castle & Park Howling Cave / Soul Cave / Spirit Cave
        if (zoneLower.contains("howling cave")
                || zoneLower.contains("soul cave")
                || zoneLower.contains("spirit cave")
                || (zoneLower.contains("ruins") && !zoneLower.contains("ashfang"))
                || (zoneLower.contains("castle") && (tabAreaLower.isEmpty() || tabAreaLower.contains("hub")))) {
            return BossCategory.SVEN;
        }
        // 5. VOIDGLOOM SERAPH: The End, Dragon's Nest, Void Sepulture, Void Slate, Zealot Bruiser Hideout
        if (zoneLower.contains("the end")
                || zoneLower.contains("dragon's nest")
                || zoneLower.contains("dragons nest")
                || zoneLower.contains("void sepulture")
                || zoneLower.contains("void slate")
                || zoneLower.contains("bruiser hideout")) {
            return BossCategory.VOIDGLOOM;
        }
        // 6. INFERNO DEMONLORD: Crimson Isle Blaze Slayer & combat areas
        if (zoneLower.contains("smoldering tomb")
                || zoneLower.contains("the tomb")
                || zoneLower.contains("stronghold")
                || zoneLower.contains("bastion")
                || zoneLower.contains("burning desert")
                || zoneLower.contains("crimson isle")
                || zoneLower.contains("crimson fields")
                || zoneLower.contains("blazing volcano")
                || zoneLower.contains("wasteland")
                || zoneLower.contains("ruins of ashfang")
                || zoneLower.contains("forgotten skull")
                || zoneLower.contains("magma chamber")
                || zoneLower.contains("plhlegblast")
                || zoneLower.contains("courtyard")
                || zoneLower.contains("matriarch")
                || zoneLower.contains("aura's lab")
                || zoneLower.contains("auras lab")) {
            return BossCategory.INFERNO;
        }
        if ((tabAreaLower.contains("crimson isle") || tabAreaLower.equals("crimson")) && questBossCat == BossCategory.INFERNO) {
            return BossCategory.INFERNO;
        }
        return null;
    }

    private static void updateScoreboardState(Minecraft client, long now) {
        if (client.level != lastKnownLevel) {
            lastKnownLevel = client.level;
            onWorldChange();
        }
        if (now - lastScoreboardCheckMs < 150L) return;
        lastScoreboardCheckMs = now;
        if (client.level == null) {
            onWorldChange();
            return;
        }
        Scoreboard sb = client.level.getScoreboard();
        Objective obj = sb.getDisplayObjective(DisplaySlot.SIDEBAR);
        if (obj == null) {
            cachedInRift = false;
            cachedInChateau = false;
            cachedLocationCategory = null;
            cachedQuestActive = false;
            return;
        }
        boolean riftFound = false;
        boolean chateauFound = false;
        boolean questFound = false;
        String detectedBossOnSidebar = null;
        List<String> symbolZoneLines = new ArrayList<>(2);
        List<String> fallbackLinesBeforeCurrency = new ArrayList<>(6);
        boolean seenCurrencyOrObjective = false;

        List<PlayerScoreEntry> entries = new ArrayList<>(sb.listPlayerScores(obj));
        entries.sort(java.util.Comparator.comparingInt(PlayerScoreEntry::value).reversed());

        for (PlayerScoreEntry entry : entries) {
            String clean = SlayerTimerTracker.plainLine(sb, entry);
            if (clean == null || clean.isEmpty()) continue;
            String parsedBoss = SlayerTimerTracker.parseCanonicalBossAndTier(clean);
            if (parsedBoss != null) {
                detectedBossOnSidebar = parsedBoss;
                questFound = true;
            }
            String lower = clean.toLowerCase(Locale.ROOT);
            if (lower.contains("purse:") || lower.contains("piggy:") || lower.contains("motes:")
                    || lower.contains("slayer quest") || lower.contains("objective")) {
                seenCurrencyOrObjective = true;
            }
            if (clean.indexOf('⏣') >= 0 || clean.indexOf('ф') >= 0 || clean.indexOf('❂') >= 0) {
                symbolZoneLines.add(lower);
            } else if (!seenCurrencyOrObjective) {
                fallbackLinesBeforeCurrency.add(lower);
            }
            if (lower.contains("stillgore") || lower.contains("château") || lower.contains("chateau")
                    || lower.contains("chât") || lower.contains("oubliette") || lower.contains("fairylosopher")) {
                chateauFound = true;
                riftFound = true;
            }
            if (lower.contains("rift") || lower.contains("dreadfarm") || lower.contains("village plaza") || lower.contains("west village") || lower.contains("lumina")) {
                riftFound = true;
            }
            if (lower.contains("slayer quest") || lower.contains("slay the boss") || lower.contains("boss slain")) {
                questFound = true;
            }
        }

        String tabAreaLower = detectTabListArea(client);
        BossCategory questBossCat = detectedBossOnSidebar != null ? BossCategory.fromProfileKey(detectedBossOnSidebar) : null;
        BossCategory resolvedLocationCat = null;
        boolean zoneIsTransientNone = false;

        List<String> linesToCheck = !symbolZoneLines.isEmpty() ? symbolZoneLines : fallbackLinesBeforeCurrency;
        for (String zoneLine : linesToCheck) {
            String strippedSymbol = zoneLine.replace('⏣', ' ').replace('ф', ' ').replace('❂', ' ').trim();
            if (strippedSymbol.equals("none")) {
                zoneIsTransientNone = true;
                continue;
            }
            BossCategory matched = classifyZoneLine(zoneLine, tabAreaLower, questBossCat);
            if (matched != null) {
                resolvedLocationCat = matched;
                break;
            }
        }

        if (resolvedLocationCat == null) {
            if (tabAreaLower.contains("spider's den") || tabAreaLower.contains("spiders den")) {
                resolvedLocationCat = BossCategory.TARANTULA;
            } else if (tabAreaLower.equals("the end")) {
                resolvedLocationCat = BossCategory.VOIDGLOOM;
            } else if (zoneIsTransientNone && cachedLocationCategory != null) {
                // Keep current location category across 0.5s mid-air "⏣ None" transitions on the same island
                resolvedLocationCat = cachedLocationCategory;
            }
        }

        cachedInRift = riftFound || tabAreaLower.contains("rift");
        cachedInChateau = (resolvedLocationCat == BossCategory.VAMPIRE) || chateauFound;
        cachedLocationCategory = resolvedLocationCat;
        cachedQuestActive = questFound;

        if (detectedBossOnSidebar != null) {
            notifyDetectedBossWithTier(detectedBossOnSidebar);
        }
        if (cachedLocationCategory != null && getActiveCategory() != cachedLocationCategory) {
            activeProfileKey = lastProfileByCategory.getOrDefault(
                    cachedLocationCategory,
                    defaultProfileForCategory(cachedLocationCategory)
            );
        }
    }

    public static void tick(Minecraft client) {
        long now = System.currentTimeMillis();
        if (now - lastPriceFetchMs > 300_000L && !fetchingPrices) {
            refreshPricesAsync();
        }
        if (client.screen != null && !(client.screen instanceof ChatScreen)) {
            lastScreenOpenTimeMs = now;
        }
        if (client.player == null || client.level == null) {
            lastKnownLevel = null;
            onWorldChange();
            lastTickTimeMs = now;
            return;
        }

        double px = client.player.getX();
        double py = client.player.getY();
        double pz = client.player.getZ();
        float yaw = client.player.getYRot();
        float pitch = client.player.getXRot();
        if (Double.isNaN(lastPlayerX)
                || Math.abs(px - lastPlayerX) > 0.03
                || Math.abs(py - lastPlayerY) > 0.03
                || Math.abs(pz - lastPlayerZ) > 0.03
                || Math.abs(yaw - lastPlayerYaw) > 0.3f
                || Math.abs(pitch - lastPlayerPitch) > 0.3f
                || client.player.swinging) {
            lastPlayerX = px;
            lastPlayerY = py;
            lastPlayerZ = pz;
            lastPlayerYaw = yaw;
            lastPlayerPitch = pitch;
            lastMovementMs = now;
        }

        updateScoreboardState(client, now);

        boolean notAfk = (now - lastMovementMs) <= AFK_TIMEOUT_MS;
        boolean slayerActive = lastSlayerActivityMs > 0L && (now - lastSlayerActivityMs) <= AFK_TIMEOUT_MS;

        if (lastTickTimeMs > 0L
                && cachedLocationCategory != null
                && getActiveCategory() == cachedLocationCategory
                && isCategoryTrackerEnabled(cachedLocationCategory)
                && (cachedInChateau || cachedQuestActive)
                && slayerActive
                && notAfk) {
            long delta = Math.clamp(now - lastTickTimeMs, 0L, 1_000L);
            sessionBucket().activePlaytimeMs += delta;
            totalBucket().activePlaytimeMs += delta;
        }
        lastTickTimeMs = now;

        // Rule from user:
        // - For Vampire Slayer: drops are counted STRICTLY from chat announcements only!
        // - For all non-Vampire Slayers (Revenant, Tarantula, Sven, Voidgloom, Inferno): also count floor/inventory pickups only when in their respective location!
        if (cachedLocationCategory != null
                && cachedLocationCategory != BossCategory.VAMPIRE
                && isCategoryTrackerEnabled(cachedLocationCategory)) {
            scanInventoryForDrops(client, now);
        } else {
            updateInventoryBaseline(client);
            inventoryBaselineInitialized = true;
        }
    }

    public static void recordBossSpawned() {
        recordBossSpawned(activeProfileKey);
    }

    public static void recordBossSpawned(String bossWithTier) {
        String targetKey = resolveTargetProfileKey(bossWithTier);
        markSlayerActivity();
        getSessionBucket(targetKey).bossesSpawned++;
        getTotalBucket(targetKey).bossesSpawned++;
        save();
    }

    public static void recordBossKill() {
        recordBossKill(activeProfileKey);
    }

    public static void recordBossKill(String bossWithTier) {
        String targetKey = resolveTargetProfileKey(bossWithTier);
        markSlayerActivity();
        lastBossKillWindowUntilMs = System.currentTimeMillis() + 12_000L;
        getSessionBucket(targetKey).bossesKilled++;
        getTotalBucket(targetKey).bossesKilled++;
        save();
    }

    public static void recordBossFail() {
        recordBossFail(activeProfileKey);
    }

    public static void recordBossFail(String bossWithTier) {
        String targetKey = resolveTargetProfileKey(bossWithTier);
        markSlayerActivity();
        getSessionBucket(targetKey).bossesFailed++;
        getTotalBucket(targetKey).bossesFailed++;
        save();
    }

    public static void modifyKillsBoth(int delta) {
        StatsBucket tot = totalBucket();
        int timedKills = Math.max(0, tot.bossesKilled - tot.manualBossesKilled);
        int nextTotal = Math.max(0, tot.bossesKilled + delta);
        tot.bossesKilled = nextTotal;
        tot.manualBossesKilled = Math.max(0, nextTotal - timedKills);
        save();
    }

    public static void setKillsActive(int value) {
        StatsBucket tot = totalBucket();
        int v = Math.max(0, value);
        int timedKills = Math.max(0, tot.bossesKilled - tot.manualBossesKilled);
        tot.bossesKilled = v;
        tot.manualBossesKilled = Math.max(0, v - timedKills);
        save();
    }

    public static void modifyFailsBoth(int delta) {
        StatsBucket tot = totalBucket();
        tot.bossesFailed = Math.max(0, tot.bossesFailed + delta);
        save();
    }

    public static void setFailsActive(int value) {
        StatsBucket tot = totalBucket();
        tot.bossesFailed = Math.max(0, value);
        save();
    }

    public static void forceModifyKills(int delta) {
        StatsBucket tot = totalBucket();
        tot.bossesKilled = Math.max(0, tot.bossesKilled + delta);
        if (tot.manualBossesKilled > tot.bossesKilled) {
            tot.manualBossesKilled = tot.bossesKilled;
        }
        save();
    }

    public static void forceSetKills(int value) {
        StatsBucket tot = totalBucket();
        tot.bossesKilled = Math.max(0, value);
        tot.manualBossesKilled = 0;
        save();
    }

    public static void forceModifyFails(int delta) {
        StatsBucket tot = totalBucket();
        tot.bossesFailed = Math.max(0, tot.bossesFailed + delta);
        save();
    }

    public static void forceSetFails(int value) {
        StatsBucket tot = totalBucket();
        tot.bossesFailed = Math.max(0, value);
        save();
    }

    public static void forceModifyTimeMs(long deltaMs) {
        StatsBucket tot = totalBucket();
        tot.activePlaytimeMs = Math.max(0L, tot.activePlaytimeMs + deltaMs);
        save();
    }

    public static void forceSetTimeMs(long valueMs) {
        StatsBucket tot = totalBucket();
        tot.activePlaytimeMs = Math.max(0L, valueMs);
        save();
    }

    public static long getTotalPlaytimeMs() {
        return totalBucket().activePlaytimeMs;
    }

    public static void forceModifyDrop(DropType type, int delta) {
        if (type == null || delta == 0) return;
        totalBucket().addDrop(type, delta);
        save();
        Minecraft client = Minecraft.getInstance();
        if (client.player != null) {
            updateInventoryBaseline(client);
        }
    }

    public static void forceSetDrop(DropType type, int value) {
        if (type == null) return;
        int v = Math.max(0, value);
        if (v == 0) totalBucket().drops.remove(type.key);
        else totalBucket().drops.put(type.key, v);
        save();
        Minecraft client = Minecraft.getInstance();
        if (client.player != null) {
            updateInventoryBaseline(client);
        }
    }

    public static void setDropActive(DropType type, int value) {
        if (type == null) return;
        int v = Math.max(0, value);
        activeBucket().drops.put(type.key, v);
        save();
        Minecraft client = Minecraft.getInstance();
        if (client.player != null) {
            updateInventoryBaseline(client);
        }
    }

    public static void modifyDropBoth(DropType type, int delta) {
        if (type == null || delta == 0) return;
        lastDropFingerprint = type.key + ":" + Math.abs(delta);
        lastDropFingerprintMs = System.currentTimeMillis();
        sessionBucket().addDrop(type, delta);
        totalBucket().addDrop(type, delta);
        save();
        Minecraft client = Minecraft.getInstance();
        if (client.player != null) {
            updateInventoryBaseline(client);
        }
    }

    private static final Map<DropType, Long> lastDropRecordedByTypeMs = new EnumMap<>(DropType.class);

    public static void recordDrop(DropType type, int amount, String sourceTag) {
        if (type == null || amount <= 0) return;
        if (!isCategoryTrackerEnabled(type.category)) return;
        // Strict rule: Vampire drops NEVER come from floor/inventory ("inv"), only from "chat"
        if (type.category == BossCategory.VAMPIRE && "inv".equals(sourceTag)) {
            return;
        }
        long now = System.currentTimeMillis();
        Long prevTypeMs = lastDropRecordedByTypeMs.get(type);
        if (prevTypeMs != null && (now - prevTypeMs) < 3_500L) {
            return;
        }
        String fp = type.key + ":" + amount;
        if (fp.equals(lastDropFingerprint) && (now - lastDropFingerprintMs) < 3_500L) {
            return;
        }
        lastDropRecordedByTypeMs.put(type, now);
        lastDropFingerprint = fp;
        lastDropFingerprintMs = now;
        markSlayerActivity();

        // Ensure drop goes to the matching boss profile (if we are already on that boss category, use activeProfileKey;
        // otherwise use last-used or default tier for that boss category)
        String targetProfileKey = activeProfileKey;
        if (BossCategory.fromProfileKey(targetProfileKey) != type.category) {
            String detected = SlayerTimerTracker.getCurrentBossWithTier();
            if (detected != null && BossCategory.fromProfileKey(detected) == type.category) {
                targetProfileKey = normalizeProfileKey(detected);
                lastProfileByCategory.put(type.category, targetProfileKey);
                if (cachedLocationCategory == type.category) {
                    activeProfileKey = targetProfileKey;
                }
            } else {
                targetProfileKey = lastProfileByCategory.getOrDefault(type.category, defaultProfileForCategory(type.category));
            }
        }

        getSessionBucket(targetProfileKey).addDrop(type, amount);
        getTotalBucket(targetProfileKey).addDrop(type, amount);
        save();
        if ("chat".equals(sourceTag)) {
            lastInventoryCounts.put(type, lastInventoryCounts.getOrDefault(type, 0) + amount);
        }
    }

    private static String defaultProfileForCategory(BossCategory category) {
        return switch (category) {
            case VAMPIRE -> "Riftstalker Bloodfiend V";
            case REVENANT -> "Revenant Horror V";
            case TARANTULA -> "Tarantula Broodfather V";
            case SVEN -> "Sven Packmaster IV";
            case VOIDGLOOM -> "Voidgloom Seraph IV";
            case INFERNO -> "Inferno Demonlord IV";
        };
    }

    private static boolean isPlayerChatLine(String clean) {
        if (clean == null || clean.isEmpty()) return true;
        String lower = clean.toLowerCase(Locale.ROOT);
        if (lower.startsWith("party >")
                || lower.startsWith("guild >")
                || lower.startsWith("co-op >")
                || lower.startsWith("officer >")
                || lower.startsWith("from ")
                || lower.startsWith("to ")
                || lower.startsWith("[vampy]")) {
            return true;
        }
        int colonIdx = clean.indexOf(": ");
        if (colonIdx > 0) {
            String beforeColon = clean.substring(0, colonIdx);
            String beforeLower = beforeColon.toLowerCase(Locale.ROOT);
            boolean isServerDropHeader = beforeLower.contains("drop!")
                    || beforeLower.contains("rngesus")
                    || beforeLower.contains("dye")
                    || beforeLower.contains("[sacks]");
            if (!isServerDropHeader) {
                return true;
            }
        }
        return false;
    }

    public static void onChatComponent(Component content) {
        if (content == null || !isInSlayerLocation()) return;
        String raw = content.getString();
        if (raw == null || raw.isBlank()) return;
        String clean = ChatFormatting.stripFormatting(raw).trim();
        if (isPlayerChatLine(clean)) return;
        String lower = clean.toLowerCase(Locale.ROOT);
        if (lower.startsWith("rngesus descends!") || lower.startsWith("robbed!") || lower.startsWith("burger!?") || lower.startsWith("burger...")) {
            return;
        }
        // Check if this is a "[Sacks] +64 items" message with hover text listing token/occasion drops for non-Vampire Slayers
        if (getActiveCategory() != BossCategory.VAMPIRE && lower.contains("[sacks]") && (System.currentTimeMillis() <= lastBossKillWindowUntilMs || cachedQuestActive)) {
            parseSackHoverDrops(content);
        }
        if (lower.contains("enchanted book bundle") && lower.contains("drop!")) {
            boolean isGold = hasGoldStyleOnBundle(content) || raw.contains("\u00a76");
            recordDrop(isGold ? DropType.THE_ONE_IV : DropType.QUANTUM_BOOK_BUNDLE, 1, "chat");
            return;
        }
        onChatMessage(raw);
    }

    private static void parseSackHoverDrops(Component root) {
        BossCategory cat = getActiveCategory();
        if (cat == BossCategory.VAMPIRE) return;
        root.visit((style, text) -> {
            if (style != null && style.getHoverEvent() instanceof net.minecraft.network.chat.HoverEvent.ShowText showText) {
                Component hoverComp = showText.value();
                if (hoverComp != null) {
                    String hoverPlain = ChatFormatting.stripFormatting(hoverComp.getString());
                    if (hoverPlain != null) {
                        for (String line : hoverPlain.split("\n")) {
                            Matcher m = SACK_PICKUP_PATTERN.matcher(line.trim());
                            if (m.find()) {
                                try {
                                    int amt = Integer.parseInt(m.group(1).replace(",", ""));
                                    String itemName = m.group(2).trim();
                                    DropType dt = matchDropByName(itemName, cat);
                                    if (dt != null && dt.category != BossCategory.VAMPIRE && amt > 0) {
                                        recordDrop(dt, amt, "sack");
                                    }
                                } catch (NumberFormatException ignored) {}
                            }
                        }
                    }
                }
            }
            return java.util.Optional.empty();
        }, Style.EMPTY);
    }

    private static boolean hasGoldStyleOnBundle(Component root) {
        final boolean[] foundGold = {false};
        root.visit((style, text) -> {
            if (text != null && text.toLowerCase(Locale.ROOT).contains("enchanted book bundle")) {
                if (style != null && style.getColor() != null) {
                    int rgb = style.getColor().getValue() & 0xFFFFFF;
                    int r = (rgb >> 16) & 0xFF;
                    int g = (rgb >> 8) & 0xFF;
                    int b = rgb & 0xFF;
                    if (Math.abs(r - 0xFF) <= 48 && Math.abs(g - 0xAA) <= 48 && b <= 64) {
                        foundGold[0] = true;
                    }
                }
            }
            return java.util.Optional.empty();
        }, Style.EMPTY);
        return foundGold[0];
    }

    public static void onChatMessage(String rawText) {
        if (rawText == null || rawText.isBlank() || !isInSlayerLocation()) return;
        String clean = ChatFormatting.stripFormatting(rawText).trim();
        if (isPlayerChatLine(clean)) return;
        String lower = clean.toLowerCase(Locale.ROOT);

        if (lower.contains("slayer quest complete") || lower.contains("nice! slayer boss slain")) {
            markSlayerActivity();
            lastBossKillWindowUntilMs = System.currentTimeMillis() + 12_000L;
        }

        if (lower.startsWith("rngesus descends!") || lower.startsWith("robbed!") || lower.startsWith("burger!?") || lower.startsWith("burger...")) {
            return;
        }

        boolean isOfficialDropAnnouncement = lower.startsWith("rare drop!")
                || lower.startsWith("very rare drop!")
                || lower.startsWith("crazy rare drop!")
                || lower.startsWith("insane drop!")
                || lower.startsWith("rarest drop!")
                || lower.startsWith("rngesus incarnate!")
                || lower.startsWith("pray to rngesus")
                || lower.contains("rarest drop!")
                || lower.contains("crazy rare drop!")
                || lower.contains("insane drop!")
                || lower.contains("very rare drop!")
                || lower.contains("rare drop!")
                || lower.contains("rngesus incarnate!")
                || lower.contains("pray to rngesus")
                || ((lower.contains("sangria dye") || lower.contains("matcha dye") || lower.contains("brick red dye")
                     || lower.contains("celeste dye") || lower.contains("byzantium dye") || lower.contains("flame dye"))
                    && (lower.contains("drop!") || lower.contains("found a") || lower.contains("dye")));
        if (!isOfficialDropAnnouncement) return;

        int qty = 1;
        Matcher m = COUNT_PREFIX_PATTERN.matcher(clean);
        if (m.find()) {
            String g = m.group(1) != null ? m.group(1) : (m.group(2) != null ? m.group(2) : m.group(3));
            try { qty = Integer.parseInt(g); } catch (NumberFormatException ignored) {}
        }

        if (lower.contains("enchanted book bundle")) {
            String rawLower = rawText.toLowerCase(Locale.ROOT);
            int bundleIdx = rawLower.indexOf("enchanted book bundle");
            String beforeBundle = bundleIdx > 0 ? rawLower.substring(0, bundleIdx) : rawLower;
            if (beforeBundle.contains("\u00a76")) {
                recordDrop(DropType.THE_ONE_IV, qty, "chat");
            } else {
                recordDrop(DropType.QUANTUM_BOOK_BUNDLE, qty, "chat");
            }
            return;
        }

        DropType matched = matchDropByName(lower, getActiveCategory());
        if (matched != null) {
            recordDrop(matched, qty, "chat");
        }
    }

    private static DropType matchDropByName(String text, BossCategory activeCat) {
        if (text == null || text.isEmpty()) return null;
        String lower = text.toLowerCase(Locale.ROOT);

        // Vampire Slayer
        if (lower.contains("sangria dye")) return DropType.SANGRIA_DYE;
        if (lower.contains("unfanged vampire part")) return DropType.UNFANGED_VAMPIRE_PART;
        if (lower.contains("the one iv") || lower.contains("the one 4")) return DropType.THE_ONE_IV;
        if (lower.contains("mcgrubber's burger") || lower.contains("mcgrubbers burger")) return DropType.MCGRUBBERS_BURGER;
        if (lower.contains("guardian lucky block")) return DropType.GUARDIAN_LUCKY_BLOCK;
        if (lower.contains("fang-tastic chocolate chip") || lower.contains("fangtastic chocolate chip")) return DropType.FANGTASTIC_CHOCOLATE_CHIP;
        if (lower.contains("bubba blister")) return DropType.BUBBA_BLISTER;
        if (lower.contains("soultwist rune")) return DropType.SOULTWIST_RUNE;
        if (lower.contains("quantum")) return DropType.QUANTUM_BOOK_BUNDLE;
        if (lower.contains("coven seal")) return DropType.COVEN_SEAL;

        // Revenant Horror
        if (lower.contains("warden heart")) return DropType.WARDEN_HEART;
        if (lower.contains("severed hand") || lower.contains("smite vii") || lower.contains("smite 7")) return DropType.SEVERED_HAND;
        if (lower.contains("shredded sinew") || lower.contains("shard of the shredded")) return DropType.SHREDDED_SINEW;
        if (lower.contains("scythe blade")) return DropType.SCYTHE_BLADE;
        if (lower.contains("festering maggot")) return DropType.FESTERING_MAGGOT;
        if (lower.contains("snake rune")) return DropType.SNAKE_RUNE;
        if (lower.contains("beheaded horror")) return DropType.BEHEADED_HORROR;
        if (lower.contains("smite vi") || lower.contains("smite 6")) return DropType.SMITE_VI;
        if (lower.contains("revenant shard")) return DropType.REVENANT_SHARD;
        if (lower.contains("revenant catalyst")) return DropType.REVENANT_CATALYST;
        if (lower.contains("undead catalyst")) return DropType.UNDEAD_CATALYST;
        if (lower.contains("pestilence rune")) return DropType.PESTILENCE_RUNE;
        if (lower.contains("revenant viscera")) return DropType.REVENANT_VISCERA;
        if (lower.contains("foul flesh")) return DropType.FOUL_FLESH;
        if (lower.contains("revenant flesh")) return DropType.REVENANT_FLESH;
        if (lower.contains("matcha dye")) return DropType.MATCHA_DYE;

        // Tarantula Broodfather (including Tier 5!)
        if (lower.contains("primordial eye")) return DropType.PRIMORDIAL_EYE;
        if (lower.contains("ensnared snail") || lower.contains("bane of arthropods vii") || lower.contains("bane of arthropods 7")) return DropType.ENSNARED_SNAIL;
        if (lower.contains("digested mosquito")) return DropType.DIGESTED_MOSQUITO;
        if (lower.contains("shriveled wasp")) return DropType.SHRIVELED_WASP;
        if (lower.contains("vial of venom")) return DropType.VIAL_OF_VENOM;
        if (lower.contains("tarantula talisman")) return DropType.TARANTULA_TALISMAN;
        if (lower.contains("fly swatter")) return DropType.FLY_SWATTER;
        if (lower.contains("bane of arthropods vi") || lower.contains("bane of arthropods 6")) return DropType.BANE_OF_ARTHROPODS_VI;
        if (lower.contains("darkness within rune")) return DropType.DARKNESS_WITHIN_RUNE;
        if (lower.contains("tarantula catalyst")) return DropType.TARANTULA_CATALYST;
        if (lower.contains("spider catalyst")) return DropType.SPIDER_CATALYST;
        if (lower.contains("primordial shard")) return DropType.PRIMORDIAL_SHARD;
        if (lower.contains("bite rune")) return DropType.BITE_RUNE;
        if (lower.contains("toxic arrow poison")) return DropType.TOXIC_ARROW_POISON;
        if (lower.contains("tarantula silk")) return DropType.TARANTULA_SILK;
        if (lower.contains("tarantula web")) return DropType.TARANTULA_WEB;
        if (lower.contains("brick red dye")) return DropType.BRICK_RED_DYE;

        // Sven Packmaster
        if (lower.contains("overflux capacitor")) return DropType.OVERFLUX_CAPACITOR;
        if (lower.contains("grizzly salmon") || lower.contains("grizzly bait")) return DropType.GRIZZLY_SALMON;
        if (lower.contains("couture rune")) return DropType.COUTURE_RUNE;
        if (lower.contains("red claw egg")) return DropType.RED_CLAW_EGG;
        if (lower.contains("furball")) return DropType.FURBALL;
        if (lower.contains("critical vi") || lower.contains("critical 6")) return DropType.CRITICAL_VI;
        if (lower.contains("spirit rune")) return DropType.SPIRIT_RUNE;
        if (lower.contains("hamster wheel")) return DropType.HAMSTER_WHEEL;
        if (lower.contains("wolf tooth")) return DropType.WOLF_TOOTH;
        if (lower.contains("celeste dye")) return DropType.CELESTE_DYE;

        // Voidgloom Seraph
        if (lower.contains("end stone idol") || lower.contains("ender slayer vii") || lower.contains("ender slayer 7")) return DropType.END_STONE_IDOL;
        if (lower.contains("exceedingly rare ender artifact upgrader") || lower.contains("ender artifact upgrader")) return DropType.ENDER_ARTIFACT_UPGRADER;
        if (lower.contains("enchant rune")) return DropType.ENCHANT_RUNE;
        if (lower.contains("judgement core")) return DropType.JUDGEMENT_CORE;
        if (lower.contains("void conqueror")) return DropType.VOID_CONQUEROR_SKIN;
        if (lower.contains("handy blood chalice")) return DropType.HANDY_BLOOD_CHALICE;
        if (lower.contains("pocket espresso machine")) return DropType.POCKET_ESPRESSO_MACHINE;
        if (lower.contains("etherwarp merger")) return DropType.ETHERWARP_MERGER;
        if (lower.contains("sinful dice")) return DropType.SINFUL_DICE;
        if (lower.contains("summoning eye")) return DropType.SUMMONING_EYE;
        if (lower.contains("end rune")) return DropType.END_RUNE;
        if (lower.contains("hazmat enderman")) return DropType.HAZMAT_ENDERMAN;
        if (lower.contains("smarty pants i") || lower.contains("smarty pants 1")) return DropType.SMARTY_PANTS_I;
        if (lower.contains("transmission tuner")) return DropType.TRANSMISSION_TUNER;
        if (lower.contains("mana steal i") || lower.contains("mana steal 1")) return DropType.MANA_STEAL_I;
        if (lower.contains("null atom")) return DropType.NULL_ATOM;
        if (lower.contains("endersnake rune")) return DropType.ENDERSNAKE_RUNE;
        if (lower.contains("twilight arrow poison")) return DropType.TWILIGHT_ARROW_POISON;
        if (lower.contains("null sphere")) return DropType.NULL_SPHERE;
        if (lower.contains("byzantium dye")) return DropType.BYZANTIUM_DYE;

        // Inferno Demonlord
        if (lower.contains("subzero inverter")) return DropType.SUBZERO_INVERTER;
        if (lower.contains("wilson's engineering plans") || lower.contains("wilsons engineering plans")) return DropType.WILSONS_ENGINEERING_PLANS;
        if (lower.contains("high class archfiend dice")) return DropType.HIGH_CLASS_ARCHFIEND_DICE;
        if (lower.contains("duplex i") || lower.contains("duplex 1")) return DropType.DUPLEX_I;
        if (lower.contains("flawed opal")) return DropType.FLAWED_OPAL_GEMSTONE;
        if (lower.contains("fiery burst rune")) return DropType.FIERY_BURST_RUNE;
        if (lower.contains("fire aspect iii") || lower.contains("fire aspect 3")) return DropType.FIRE_ASPECT_III;
        if (lower.contains("archfiend dice")) return DropType.ARCHFIEND_DICE;
        if (lower.contains("scorched power crystal")) return DropType.SCORCHED_POWER_CRYSTAL;
        if (lower.contains("gabagool distillate")) return DropType.GABAGOOL_DISTILLATE;
        if (lower.contains("nether wart distillate") || lower.contains("nether stalk distillate")) return DropType.NETHER_WART_DISTILLATE;
        if (lower.contains("magma cream distillate")) return DropType.MAGMA_CREAM_DISTILLATE;
        if (lower.contains("glowstone distillate") || lower.contains("glowstone dust distillate")) return DropType.GLOWSTONE_DISTILLATE;
        if (lower.contains("blaze rod distillate")) return DropType.BLAZE_ROD_DISTILLATE;
        if (lower.contains("kelvin inverter")) return DropType.KELVIN_INVERTER;
        if (lower.contains("inferno demonlord shard")) return DropType.INFERNO_DEMONLORD_SHARD;
        if (lower.contains("scorched books")) return DropType.SCORCHED_BOOKS;
        if (lower.contains("mana disintegrator")) return DropType.MANA_DISINTEGRATOR;
        if (lower.contains("bundle of magma arrows")) return DropType.BUNDLE_OF_MAGMA_ARROWS;
        if (lower.contains("wisp's ice-flavored water") || lower.contains("wisps ice-flavored water")) return DropType.WISPS_ICE_WATER;
        if (lower.contains("lavatears rune")) return DropType.LAVATEARS_RUNE;
        if (lower.contains("enchanted blaze powder")) return DropType.ENCHANTED_BLAZE_POWDER;
        if (lower.contains("derelict ashe")) return DropType.DERELICT_ASHE;
        if (lower.contains("flame dye")) return DropType.FLAME_DYE;

        // Shared Paragon Shard (assign to currently active Slayer category)
        if (lower.contains("paragon shard")) {
            return switch (activeCat != null ? activeCat : getActiveCategory()) {
                case REVENANT -> DropType.REV_PARAGON_SHARD;
                case TARANTULA -> DropType.TARA_PARAGON_SHARD;
                case SVEN -> DropType.SVEN_PARAGON_SHARD;
                case VOIDGLOOM -> DropType.VOID_PARAGON_SHARD;
                case INFERNO -> DropType.INF_PARAGON_SHARD;
                default -> DropType.TARA_PARAGON_SHARD;
            };
        }

        return null;
    }

    private static void updateInventoryBaseline(Minecraft client) {
        Map<DropType, Integer> current = countInventoryDrops(client);
        for (DropType type : DropType.values()) {
            lastInventoryCounts.put(type, current.getOrDefault(type, 0));
        }
    }

    private static Map<DropType, Integer> countInventoryDrops(Minecraft client) {
        Map<DropType, Integer> current = new EnumMap<>(DropType.class);
        if (client.player == null) return current;
        var inv = client.player.getInventory();
        for (int i = 0; i < inv.getContainerSize(); i++) {
            ItemStack stack = inv.getItem(i);
            if (stack.isEmpty()) continue;
            DropType matched = identifyDropStack(stack);
            if (matched != null) {
                current.put(matched, current.getOrDefault(matched, 0) + stack.getCount());
            }
        }
        if (client.player.containerMenu != null) {
            ItemStack carried = client.player.containerMenu.getCarried();
            if (carried != null && !carried.isEmpty()) {
                DropType matched = identifyDropStack(carried);
                if (matched != null) {
                    current.put(matched, current.getOrDefault(matched, 0) + carried.getCount());
                }
            }
        }
        return current;
    }

    private static void scanInventoryForDrops(Minecraft client, long now) {
        boolean containerOpenOrRecent = (client.screen != null && !(client.screen instanceof ChatScreen))
                || (now - lastScreenOpenTimeMs < 1500L);
        boolean combatRecentlyActive = cachedQuestActive || (now <= lastBossKillWindowUntilMs) || (now - lastSlayerActivityMs <= ACTIVE_COMBAT_WINDOW_MS);
        if (containerOpenOrRecent || !combatRecentlyActive) {
            updateInventoryBaseline(client);
            inventoryBaselineInitialized = true;
            return;
        }
        Map<DropType, Integer> current = countInventoryDrops(client);
        if (!inventoryBaselineInitialized) {
            for (DropType type : DropType.values()) {
                lastInventoryCounts.put(type, current.getOrDefault(type, 0));
            }
            inventoryBaselineInitialized = true;
            return;
        }
        BossCategory activeCat = getActiveCategory();
        for (DropType type : DropType.values()) {
            int prev = lastInventoryCounts.getOrDefault(type, 0);
            int cur = current.getOrDefault(type, 0);
            if (cur > prev && type.category != BossCategory.VAMPIRE && type.category == activeCat) {
                recordDrop(type, cur - prev, "inv");
            }
            lastInventoryCounts.put(type, cur);
        }
    }

    public static DropType identifyDropStack(ItemStack stack) {
        if (stack == null || stack.isEmpty()) return null;
        String skyblockId = getSkyblockItemId(stack);
        String cleanName = ChatFormatting.stripFormatting(stack.getHoverName().getString());
        String lowerName = cleanName == null ? "" : cleanName.toLowerCase(Locale.ROOT);
        BossCategory activeCat = getActiveCategory();

        if (lowerName.contains("enchanted book bundle") || (skyblockId != null && skyblockId.contains("BOOK_BUNDLE"))) {
            String loreBlob = getStackLoreText(stack).toLowerCase(Locale.ROOT);
            if (loreBlob.contains("the one") || (skyblockId != null && skyblockId.contains("THE_ONE"))) return DropType.THE_ONE_IV;
            if (loreBlob.contains("quantum") || (skyblockId != null && skyblockId.contains("QUANTUM"))) return DropType.QUANTUM_BOOK_BUNDLE;
        }
        if (lowerName.contains("enchanted book") || "ENCHANTED_BOOK".equals(skyblockId)) {
            String loreBlob = getStackLoreText(stack).toLowerCase(Locale.ROOT);
            DropType bookDrop = matchDropByName(loreBlob, activeCat);
            if (bookDrop != null) return bookDrop;
        }
        if (skyblockId != null && !skyblockId.isEmpty()) {
            for (DropType dt : DropType.values()) {
                if (dt.category == activeCat && (dt.priceLookupId.equalsIgnoreCase(skyblockId) || dt.key.equalsIgnoreCase(skyblockId))) {
                    return dt;
                }
            }
            for (DropType dt : DropType.values()) {
                if (dt.priceLookupId.equalsIgnoreCase(skyblockId) || dt.key.equalsIgnoreCase(skyblockId)) {
                    return dt;
                }
            }
        }
        return matchDropByName(lowerName, activeCat);
    }

    public static String getSkyblockItemId(ItemStack stack) {
        String id = com.vampy.item.SkyblockItemIds.from(stack);
        return id != null ? id : "";
    }

    public static String getStackLoreText(ItemStack stack) {
        StringBuilder sb = new StringBuilder();
        try {
            var lore = stack.get(DataComponents.LORE);
            if (lore != null) {
                for (Component line : lore.lines()) {
                    sb.append(ChatFormatting.stripFormatting(line.getString())).append('\n');
                }
            }
        } catch (Throwable ignored) {}
        return sb.toString();
    }

    public static void appendBundlePriceTooltip(ItemStack stack, List<Component> tooltipLines) {
        if (stack == null || stack.isEmpty() || tooltipLines == null) return;
        String cleanName = ChatFormatting.stripFormatting(stack.getHoverName().getString());
        String skyblockId = getSkyblockItemId(stack);
        boolean isBundle = (cleanName != null && cleanName.toLowerCase(Locale.ROOT).contains("enchanted book bundle"))
                || (skyblockId != null && skyblockId.contains("BOOK_BUNDLE"));
        if (!isBundle) return;

        StringBuilder fullText = new StringBuilder();
        for (Component c : tooltipLines) {
            fullText.append(ChatFormatting.stripFormatting(c.getString())).append('\n');
        }
        String tooltipBlob = fullText.toString();
        Matcher m = BUNDLE_TIER_PATTERN.matcher(tooltipBlob);
        if (!m.find()) return;

        String enchantName = m.group(1);
        String tierStr = m.group(2).toUpperCase(Locale.ROOT);
        int tier = switch (tierStr) {
            case "I", "1" -> 1;
            case "II", "2" -> 2;
            case "III", "3" -> 3;
            case "IV", "4" -> 4;
            case "V", "5" -> 5;
            default -> 4;
        };

        String rawEnchant = enchantName.toUpperCase(Locale.ROOT).replace(' ', '_');
        String enchantId = rawEnchant.contains("THE_ONE")
                ? ("ENCHANTMENT_ULTIMATE_THE_ONE_" + tier)
                : ("ENCHANTMENT_" + rawEnchant + "_" + tier);

        int booksPerBundle = 1;
        Matcher qtyMatcher = Pattern.compile("(?i)\\b(\\d+)\\s+of\\s+the\\s+following|\\b(\\d+)x\\s+" + Pattern.quote(enchantName)).matcher(tooltipBlob);
        if (qtyMatcher.find()) {
            String num = qtyMatcher.group(1) != null ? qtyMatcher.group(1) : qtyMatcher.group(2);
            try {
                int parsed = Integer.parseInt(num);
                if (parsed >= 1 && parsed <= 16) booksPerBundle = parsed;
            } catch (NumberFormatException ignored) {}
        }

        long singleBookFallback = enchantId.contains("THE_ONE") ? 15_000_000L : (tier >= 3 ? 300_000L : 200_000L);
        long singleBookPrice = lookupBazaarOrAhPrice(enchantId, singleBookFallback);
        long bundleValue = singleBookPrice * booksPerBundle;
        int stackCount = Math.max(1, stack.getCount());
        String modeTag = VampyConfig.isBazaarUseInstaBuy() ? "Insta-Buy" : "Insta-Sell";

        tooltipLines.add(Component.empty());
        if (booksPerBundle > 1) {
            tooltipLines.add(Component.literal("* Bundle Value (" + booksPerBundle + "x " + enchantName + " " + tierStr + ", " + modeTag + "): ").withStyle(ChatFormatting.LIGHT_PURPLE)
                    .append(Component.literal(formatCoins(bundleValue)).withStyle(ChatFormatting.GOLD))
                    .append(Component.literal(" (" + formatCoins(singleBookPrice) + " each)").withStyle(ChatFormatting.GRAY)));
        } else {
            tooltipLines.add(Component.literal("* Unwrapped Book (" + modeTag + "): ").withStyle(ChatFormatting.LIGHT_PURPLE)
                    .append(Component.literal(formatCoins(bundleValue)).withStyle(ChatFormatting.GOLD))
                    .append(Component.literal(" (" + enchantName + " " + tierStr + ")").withStyle(ChatFormatting.GRAY)));
        }
        if (stackCount > 1) {
            tooltipLines.add(Component.literal("  Stack Total (" + stackCount + " bundles): ").withStyle(ChatFormatting.GRAY)
                    .append(Component.literal(formatCoins(bundleValue * stackCount)).withStyle(ChatFormatting.YELLOW)));
        }
    }

    private static long lookupBazaarOrAhPrice(String id, long fallback) {
        boolean instaBuy = VampyConfig.isBazaarUseInstaBuy();
        Map<String, Long> primaryBz = instaBuy ? bzInstaBuyPrices : bzInstaSellPrices;
        Map<String, Long> secondaryBz = instaBuy ? bzInstaSellPrices : bzInstaBuyPrices;

        Long bz = primaryBz.get(id);
        if (bz != null && bz > 0) return bz;
        bz = secondaryBz.get(id);
        if (bz != null && bz > 0) return bz;

        Long ah = AhLowestBinCache.getLowestBin(id);
        if (ah != null && ah > 0) return ah;
        Long cachedAh = ahLowestBinPrices.get(id);
        if (cachedAh != null && cachedAh > 0) return cachedAh;
        return fallback;
    }

    public static long getUnitPrice(DropType type) {
        if (type == DropType.COVEN_SEAL || type == DropType.MCGRUBBERS_BURGER) return 0L;
        if (type == DropType.UNFANGED_VAMPIRE_PART) {
            double pct = VampyConfig.getUnfangedRelicPercent();
            long relicPrice = lookupBazaarOrAhPrice("VAMPIRE_DENTIST_RELIC", type.fallbackCoins);
            return Math.round(relicPrice * (pct / 100.0));
        }
        if (type == DropType.QUANTUM_BOOK_BUNDLE) {
            return lookupBazaarOrAhPrice("ENCHANTMENT_QUANTUM_3", 375_000L);
        }
        return lookupBazaarOrAhPrice(type.priceLookupId, type.fallbackCoins);
    }

    public static void loadPriceCache() {
        if (!Files.exists(PRICE_CACHE_PATH)) return;
        try (Reader r = Files.newBufferedReader(PRICE_CACHE_PATH, StandardCharsets.UTF_8)) {
            JsonObject obj = JsonParser.parseReader(r).getAsJsonObject();
            if (obj.has("bzInstaSell")) {
                for (Map.Entry<String, JsonElement> e : obj.getAsJsonObject("bzInstaSell").entrySet()) {
                    long v = e.getValue().getAsLong();
                    if (v > 0) bzInstaSellPrices.put(e.getKey(), v);
                }
            }
            if (obj.has("bzInstaBuy")) {
                for (Map.Entry<String, JsonElement> e : obj.getAsJsonObject("bzInstaBuy").entrySet()) {
                    long v = e.getValue().getAsLong();
                    if (v > 0) bzInstaBuyPrices.put(e.getKey(), v);
                }
            }
            if (obj.has("ahLowestBin")) {
                for (Map.Entry<String, JsonElement> e : obj.getAsJsonObject("ahLowestBin").entrySet()) {
                    long v = e.getValue().getAsLong();
                    if (v > 0) ahLowestBinPrices.put(e.getKey(), v);
                }
            }
        } catch (Throwable ignored) {}
    }

    public static void savePriceCache() {
        try {
            Files.createDirectories(PRICE_CACHE_PATH.getParent());
            JsonObject root = new JsonObject();
            root.addProperty("updatedAt", System.currentTimeMillis());

            JsonObject sellObj = new JsonObject();
            for (var e : bzInstaSellPrices.entrySet()) sellObj.addProperty(e.getKey(), e.getValue());
            root.add("bzInstaSell", sellObj);

            JsonObject buyObj = new JsonObject();
            for (var e : bzInstaBuyPrices.entrySet()) buyObj.addProperty(e.getKey(), e.getValue());
            root.add("bzInstaBuy", buyObj);

            JsonObject ahObj = new JsonObject();
            for (var e : ahLowestBinPrices.entrySet()) ahObj.addProperty(e.getKey(), e.getValue());
            root.add("ahLowestBin", ahObj);

            try (Writer w = Files.newBufferedWriter(PRICE_CACHE_PATH, StandardCharsets.UTF_8)) {
                GSON.toJson(root, w);
            }
        } catch (Throwable ignored) {}
    }

    public static void refreshPricesAsync() {
        fetchingPrices = true;
        lastPriceFetchMs = System.currentTimeMillis();
        CompletableFuture.runAsync(() -> {
            try {
                HttpClient client = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(6)).build();

                // 1. Hypixel SkyBlock Bazaar API
                try {
                    HttpRequest bzReq = HttpRequest.newBuilder()
                            .uri(URI.create("https://api.hypixel.net/v2/skyblock/bazaar"))
                            .timeout(Duration.ofSeconds(8))
                            .GET()
                            .build();
                    HttpResponse<String> bzResp = client.send(bzReq, HttpResponse.BodyHandlers.ofString());
                    if (bzResp.statusCode() == 200) {
                        parseBazaarPrices(bzResp.body());
                    }
                } catch (Throwable ignored) {}

                // 2. Elite / Moulberry LowestBIN API
                for (String url : new String[]{"https://api.eliteskyblock.com/resources/auctions/neu", "https://moulberry.codes/lowestbin.json"}) {
                    try {
                        HttpRequest lbinReq = HttpRequest.newBuilder()
                                .uri(URI.create(url))
                                .timeout(Duration.ofSeconds(8))
                                .GET()
                                .build();
                        HttpResponse<String> lbinResp = client.send(lbinReq, HttpResponse.BodyHandlers.ofString());
                        if (lbinResp.statusCode() == 200) {
                            parseLowestBinPrices(lbinResp.body());
                            break;
                        }
                    } catch (Throwable ignored) {}
                }

                savePriceCache();
            } catch (Throwable ignored) {
            } finally {
                fetchingPrices = false;
            }
        });
    }

    private static void parseBazaarPrices(String body) {
        try {
            JsonObject root = JsonParser.parseString(body).getAsJsonObject();
            if (!root.has("products")) return;
            JsonObject products = root.getAsJsonObject("products");

            for (DropType t : DropType.values()) {
                String primaryId = t.priceLookupId;
                String[] candidates = BAZAAR_ALIASES.getOrDefault(primaryId, new String[]{primaryId});
                for (String cid : candidates) {
                    if (products.has(cid)) {
                        JsonObject prod = products.getAsJsonObject(cid);
                        long sellP = extractBazaarInstaSell(prod);
                        long buyP = extractBazaarInstaBuy(prod);
                        if (sellP > 0) {
                            bzInstaSellPrices.put(primaryId, sellP);
                            bzInstaSellPrices.put(cid, sellP);
                        }
                        if (buyP > 0) {
                            bzInstaBuyPrices.put(primaryId, buyP);
                            bzInstaBuyPrices.put(cid, buyP);
                        }
                        if (sellP > 0 || buyP > 0) break;
                    }
                }
            }
            for (int tier = 1; tier <= 5; tier++) {
                for (String prefix : new String[]{"ENCHANTMENT_QUANTUM_", "ENCHANTMENT_ULTIMATE_THE_ONE_", "ENCHANTMENT_THE_ONE_"}) {
                    String id = prefix + tier;
                    if (products.has(id)) {
                        JsonObject prod = products.getAsJsonObject(id);
                        long sellP = extractBazaarInstaSell(prod);
                        long buyP = extractBazaarInstaBuy(prod);
                        if (sellP > 0) bzInstaSellPrices.put(id, sellP);
                        if (buyP > 0) bzInstaBuyPrices.put(id, buyP);
                    }
                }
            }
        } catch (Throwable ignored) {}
    }

    private static long extractBazaarInstaSell(JsonObject prod) {
        if (prod == null) return 0L;
        if (prod.has("sell_summary") && prod.getAsJsonArray("sell_summary").size() > 0) {
            double v = prod.getAsJsonArray("sell_summary").get(0).getAsJsonObject().get("pricePerUnit").getAsDouble();
            if (v > 0) return Math.round(v);
        }
        if (prod.has("quick_status")) {
            JsonObject qs = prod.getAsJsonObject("quick_status");
            if (qs.has("sellPrice") && qs.get("sellPrice").getAsDouble() > 0) {
                return Math.round(qs.get("sellPrice").getAsDouble());
            }
        }
        return 0L;
    }

    private static long extractBazaarInstaBuy(JsonObject prod) {
        if (prod == null) return 0L;
        if (prod.has("buy_summary") && prod.getAsJsonArray("buy_summary").size() > 0) {
            double v = prod.getAsJsonArray("buy_summary").get(0).getAsJsonObject().get("pricePerUnit").getAsDouble();
            if (v > 0) return Math.round(v);
        }
        if (prod.has("quick_status")) {
            JsonObject qs = prod.getAsJsonObject("quick_status");
            if (qs.has("buyPrice") && qs.get("buyPrice").getAsDouble() > 0) {
                return Math.round(qs.get("buyPrice").getAsDouble());
            }
        }
        return 0L;
    }

    private static void parseLowestBinPrices(String body) {
        try {
            JsonObject rootObj = JsonParser.parseString(body).getAsJsonObject();
            JsonObject root = rootObj.has("items") && rootObj.get("items").isJsonObject()
                    ? rootObj.getAsJsonObject("items")
                    : rootObj;
            for (DropType dt : DropType.values()) {
                String id = dt.priceLookupId;
                if (root.has(id) && root.get(id).isJsonPrimitive()) {
                    long val = Math.round(root.get(id).getAsDouble());
                    if (val > 0) {
                        ahLowestBinPrices.put(id, val);
                    }
                }
            }
            if (root.has("VAMPIRE_DENTIST_RELIC") && root.get("VAMPIRE_DENTIST_RELIC").isJsonPrimitive()) {
                long v = Math.round(root.get("VAMPIRE_DENTIST_RELIC").getAsDouble());
                if (v > 0) ahLowestBinPrices.put("VAMPIRE_DENTIST_RELIC", v);
            }
        } catch (Throwable ignored) {}
    }

    public static Style getWinrateStyle(double wr) {
        if (wr < 75.0) return Style.EMPTY.withColor(ChatFormatting.RED);
        if (wr < 90.0) return Style.EMPTY.withColor(ChatFormatting.YELLOW);
        if (wr < 98.0) return Style.EMPTY.withColor(ChatFormatting.GREEN);
        return Style.EMPTY.withColor(0x55FFFF);
    }

    public static boolean isInteractiveScreenOpen(Minecraft client) {
        if (client == null || client.screen == null) return false;
        return client.screen instanceof ChatScreen || client.screen instanceof AbstractContainerScreen<?>;
    }

    public static void renderHud(GuiGraphicsExtractor context, DeltaTracker tickCounter) {
        Minecraft client = Minecraft.getInstance();
        if (client.options.hideGui) return;
        if (client.screen instanceof HudDragScreen) return;
        if (isInteractiveScreenOpen(client)) return;
        if (!shouldRenderTracker()) return;

        int sw = context.guiWidth();
        int sh = context.guiHeight();
        int x = (int) Math.round(VampyConfig.getSlayerProfitHudX() * sw);
        int y = (int) Math.round(VampyConfig.getSlayerProfitHudY() * sh);
        float scale = (float) VampyConfig.getSlayerProfitScale();

        renderPanel(context, client.font, x, y, activeBucket(), currentMode, false, scale);
    }

    public static void renderOnScreen(GuiGraphicsExtractor context) {
        Minecraft client = Minecraft.getInstance();
        if (client.options.hideGui) return;
        if (!isInteractiveScreenOpen(client)) return;
        if (!shouldRenderTracker()) return;

        int sw = context.guiWidth();
        int sh = context.guiHeight();
        int x = (int) Math.round(VampyConfig.getSlayerProfitHudX() * sw);
        int y = (int) Math.round(VampyConfig.getSlayerProfitHudY() * sh);
        float scale = (float) VampyConfig.getSlayerProfitScale();

        renderPanel(context, client.font, x, y, activeBucket(), currentMode, true, scale);
    }

    public static void renderSample(GuiGraphicsExtractor context, Font font, int x, int y) {
        float scale = (float) VampyConfig.getSlayerProfitScale();
        StatsBucket sample = new StatsBucket();
        sample.bossesSpawned = 44;
        sample.bossesKilled = 42;
        sample.bossesFailed = 1;
        sample.activePlaytimeMs = 3_600_000L;
        BossCategory cat = getActiveCategory();
        if (cat == BossCategory.VAMPIRE) {
            sample.addDrop(DropType.UNFANGED_VAMPIRE_PART, 1);
            sample.addDrop(DropType.THE_ONE_IV, 2);
            sample.addDrop(DropType.MCGRUBBERS_BURGER, 1);
            sample.addDrop(DropType.COVEN_SEAL, 630);
        } else {
            List<DropType> catDrops = DropType.forCategory(cat);
            if (!catDrops.isEmpty()) sample.addDrop(catDrops.get(0), 640);
            if (catDrops.size() > 1) sample.addDrop(catDrops.get(1), 12);
        }
        renderPanel(context, font, x, y, sample, currentMode, false, scale);
    }

    public static int panelWidth(Font font) {
        float scale = (float) VampyConfig.getSlayerProfitScale();
        return Math.round(220 * scale);
    }

    public static int panelHeight(Font font) {
        float scale = (float) VampyConfig.getSlayerProfitScale();
        return Math.round((PAD_Y * 2 + 10 * LINE_STEP) * scale);
    }

    private static void renderPanel(GuiGraphicsExtractor context, Font font, int x, int y, StatsBucket bucket, ViewMode mode, boolean interactive, float scale) {
        List<Component> lines = new ArrayList<>();
        List<DropType> lineDropTypes = new ArrayList<>();

        BossCategory activeCat = getActiveCategory();
        boolean vampStyle = (VampyConfig.getGuiStyle() == VampyConfig.GuiStyle.VAMP);
        boolean instaBuy = VampyConfig.isBazaarUseInstaBuy();
        String bzTag = instaBuy ? " [BZ: Buy]" : " [BZ: Sell]";

        MutableComponent title = Component.literal(getActiveTrackerHeaderTitle())
                .withStyle(vampStyle ? ChatFormatting.RED : ChatFormatting.WHITE, ChatFormatting.BOLD)
                .append(Component.literal("[" + mode.label + "]").withStyle(interactive ? ChatFormatting.AQUA : (vampStyle ? ChatFormatting.YELLOW : ChatFormatting.GRAY)));
        if (interactive) {
            title.append(Component.literal(bzTag).withStyle(ChatFormatting.GREEN));
        }
        lines.add(title);
        lineDropTypes.add(null);

        long cph = bucket.coinsPerHourForCategory(activeCat);
        long totalCoins = bucket.totalValueCoinsForCategory(activeCat);
        MutableComponent profitLine = Component.literal("Profit/hr: ").withStyle(ChatFormatting.GRAY)
                .append(Component.literal(formatCoins(cph) + "/hr").withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD))
                .append(Component.literal(" (" + formatCoins(totalCoins) + ")").withStyle(ChatFormatting.YELLOW));
        if (!interactive) {
            profitLine.append(Component.literal(instaBuy ? " [Buy]" : " [Sell]").withStyle(ChatFormatting.DARK_GRAY));
        }
        lines.add(profitLine);
        lineDropTypes.add(null);

        double sessionWr = sessionBucket().winratePercent();
        double totalWr = totalBucket().winratePercent();

        lines.add(Component.literal("Bosses: ").withStyle(ChatFormatting.GRAY)
                .append(Component.literal(bucket.bossesKilled + "W").withStyle(ChatFormatting.GREEN))
                .append(Component.literal(" / ").withStyle(ChatFormatting.DARK_GRAY))
                .append(Component.literal(bucket.bossesFailed + "L").withStyle(ChatFormatting.RED))
                .append(Component.literal(String.format(Locale.ROOT, " (%.1f/hr)", bucket.bossesPerHour())).withStyle(ChatFormatting.AQUA)));
        lineDropTypes.add(null);

        lines.add(Component.literal("Winrate: ").withStyle(ChatFormatting.GRAY)
                .append(Component.literal("S: ").withStyle(ChatFormatting.DARK_GRAY))
                .append(Component.literal(String.format(Locale.ROOT, "%.1f%%", sessionWr)).withStyle(getWinrateStyle(sessionWr)))
                .append(Component.literal(" | ").withStyle(ChatFormatting.DARK_GRAY))
                .append(Component.literal("T: ").withStyle(ChatFormatting.DARK_GRAY))
                .append(Component.literal(String.format(Locale.ROOT, "%.1f%%", totalWr)).withStyle(getWinrateStyle(totalWr))));
        lineDropTypes.add(null);

        lines.add(Component.literal(activeCat.timeLabel + ": ").withStyle(ChatFormatting.GRAY)
                .append(Component.literal(formatDuration(bucket.activePlaytimeMs)).withStyle(ChatFormatting.WHITE)));
        lineDropTypes.add(null);

        List<DropType> sortedTypes = DropType.forCategory(activeCat);
        sortedTypes.sort((a, b) -> {
            long valA = (long) bucket.getDropCount(a) * getUnitPrice(a);
            long valB = (long) bucket.getDropCount(b) * getUnitPrice(b);
            int cmp = Long.compare(valB, valA);
            if (cmp != 0) return cmp;
            int countCmp = Integer.compare(bucket.getDropCount(b), bucket.getDropCount(a));
            if (countCmp != 0) return countCmp;
            return Integer.compare(a.ordinal(), b.ordinal());
        });

        boolean anyDropsShown = false;
        for (DropType type : sortedTypes) {
            boolean hidden = VampyConfig.isProfitDropHidden(type.key);
            if (hidden && !interactive) continue;

            int count = bucket.getDropCount(type);
            if (!interactive && count <= 0) {
                continue;
            }
            anyDropsShown = true;
            long val = count * getUnitPrice(type);
            String valSuffix = val > 0 ? " (" + formatCoins(val) + ")" : "";

            MutableComponent row = Component.empty();
            if (interactive) {
                row.append(Component.literal("[-/+] ").withStyle(hidden ? ChatFormatting.DARK_RED : ChatFormatting.DARK_GRAY));
            } else {
                row.append(Component.literal("- ").withStyle(ChatFormatting.DARK_GRAY));
            }

            if (hidden) {
                Style strikeGray = Style.EMPTY.withColor(ChatFormatting.DARK_GRAY).withStrikethrough(true);
                row.append(Component.literal(type.displayName + ": " + count + valSuffix).withStyle(strikeGray));
            } else {
                row.append(Component.literal(type.displayName + ": ").withStyle(type.color))
                   .append(Component.literal(String.valueOf(count)).withStyle(count > 0 ? ChatFormatting.WHITE : ChatFormatting.DARK_GRAY));
                if (!valSuffix.isEmpty()) {
                    row.append(Component.literal(valSuffix).withStyle(ChatFormatting.GOLD));
                }
            }
            lines.add(row);
            lineDropTypes.add(type);
        }

        if (!anyDropsShown) {
            lines.add(Component.literal("- No drops yet").withStyle(ChatFormatting.DARK_GRAY));
            lineDropTypes.add(null);
        }

        int maxW = 175;
        for (Component line : lines) {
            maxW = Math.max(maxW, font.width(line));
        }

        int boxW = maxW + PAD_X * 2;
        int boxH = lines.size() * LINE_STEP + PAD_Y * 2;

        float s = Math.clamp(scale <= 0f ? 1.0f : scale, 0.5f, 3.0f);
        lastHudX1 = x;
        lastHudY1 = y;
        lastHudX2 = x + boxW * s;
        lastHudY2 = y + boxH * s;

        var pose = context.pose();
        pose.pushMatrix();
        pose.translate(x, y);
        pose.scale(s, s);

        if (vampStyle) {
            context.fill(0, 0, boxW, boxH, interactive ? 0xE6120912 : 0xC80D070E);
            context.fill(0, 0, boxW, 1, 0xFFE03050);
            context.fill(0, boxH - 1, boxW, boxH, 0xFFE03050);
            context.fill(0, 1, 1, boxH - 1, 0xFFE03050);
            context.fill(boxW - 1, 1, boxW, boxH - 1, 0xFFE03050);
        } else {
            context.fill(0, 0, boxW, boxH, interactive ? 0xC0000000 : 0x90000000);
            context.fill(0, 0, boxW, 1, 0x70FFFFFF);
            context.fill(0, boxH - 1, boxW, boxH, 0x45FFFFFF);
            context.fill(0, 1, 1, boxH - 1, 0x45FFFFFF);
            context.fill(boxW - 1, 1, boxW, boxH - 1, 0x45FFFFFF);
        }

        activeClickZones.clear();
        int ty = PAD_Y;
        for (int i = 0; i < lines.size(); i++) {
            Component line = lines.get(i);
            DropType dt = lineDropTypes.get(i);
            context.text(font, line, PAD_X, ty, 0xFFFFFFFF, true);
            if (i == 0) {
                activeClickZones.add(new ClickZone(
                        x, y + (ty - 1) * s,
                        x + boxW * s, y + (ty + LINE_STEP - 1) * s,
                        null, true, false
                ));
            } else if (i == 1) {
                activeClickZones.add(new ClickZone(
                        x, y + (ty - 1) * s,
                        x + boxW * s, y + (ty + LINE_STEP - 1) * s,
                        null, false, true
                ));
            } else if (dt != null) {
                activeClickZones.add(new ClickZone(
                        x, y + (ty - 1) * s,
                        x + boxW * s, y + (ty + LINE_STEP - 1) * s,
                        dt, false, false
                ));
            }
            ty += LINE_STEP;
        }

        pose.popMatrix();
    }

    public static String formatCoins(long coins) {
        long abs = Math.abs(coins);
        String sign = coins < 0 ? "-" : "";
        if (abs >= 1_000_000_000L) return String.format(Locale.ROOT, "%s%.2fB", sign, abs / 1_000_000_000.0);
        if (abs >= 1_000_000L) return String.format(Locale.ROOT, "%s%.2fM", sign, abs / 1_000_000.0);
        if (abs >= 1_000L) return String.format(Locale.ROOT, "%s%.1fK", sign, abs / 1_000.0);
        return sign + abs;
    }

    public static String formatDuration(long ms) {
        long totalSec = Math.max(0L, ms / 1000L);
        long days = totalSec / 86400L;
        long hrs = (totalSec % 86400L) / 3600L;
        long mins = (totalSec % 3600L) / 60L;
        long secs = totalSec % 60L;
        if (days > 0) return String.format(Locale.ROOT, "%dd %dh %02dm %02ds", days, hrs, mins, secs);
        if (hrs > 0) return String.format(Locale.ROOT, "%dh %02dm %02ds", hrs, mins, secs);
        return String.format(Locale.ROOT, "%dm %02ds", mins, secs);
    }

    private static StatsBucket readBucketFromPath(Path path) {
        if (path == null || !Files.exists(path)) return null;
        try (Reader reader = Files.newBufferedReader(path, StandardCharsets.UTF_8)) {
            StatsBucket b = GSON.fromJson(reader, StatsBucket.class);
            if (b != null) {
                if (b.drops == null) b.drops = new HashMap<>();
                return b;
            }
        } catch (Exception ignored) {}
        return null;
    }

    private static long scoreBucket(StatsBucket b) {
        if (b == null) return -1L;
        long dropSum = 0L;
        if (b.drops != null) {
            for (Integer v : b.drops.values()) {
                if (v != null && v > 0) dropSum += v;
            }
        }
        return (long) b.bossesKilled * 1_000_000L + (b.activePlaytimeMs / 1000L) + dropSum * 1_000L + b.bossesFailed * 100L;
    }

    public static void load() {
        // 1. Load legacy / Vampire V single-bucket file first so existing Vampire V progress is 100% preserved
        StatsBucket newBucket = readBucketFromPath(SAVE_PATH);
        if (newBucket == null) newBucket = readBucketFromPath(VAMPADDONS_SAVE_PATH);
        StatsBucket legacyBucket = readBucketFromPath(LEGACY_SAVE_PATH);
        long newScore = scoreBucket(newBucket);
        long legacyScore = scoreBucket(legacyBucket);

        StatsBucket bestVampBucket = (legacyScore > newScore && legacyBucket != null) ? legacyBucket : newBucket;
        if (bestVampBucket != null) {
            totalBucketsByProfile.put(DEFAULT_PROFILE_KEY, bestVampBucket);
        }

        // 2. Load multi-slayer per-boss+tier file
        Path multiTarget = Files.exists(MULTI_SAVE_PATH) ? MULTI_SAVE_PATH : (Files.exists(VAMPADDONS_MULTI_SAVE_PATH) ? VAMPADDONS_MULTI_SAVE_PATH : null);
        if (multiTarget != null) {
            try (Reader r = Files.newBufferedReader(multiTarget, StandardCharsets.UTF_8)) {
                JsonObject root = JsonParser.parseReader(r).getAsJsonObject();
                if (root.has("activeProfile")) {
                    String ap = normalizeProfileKey(root.get("activeProfile").getAsString());
                    if (ap != null) {
                        activeProfileKey = ap;
                        lastProfileByCategory.put(BossCategory.fromProfileKey(ap), ap);
                    }
                }
                if (root.has("lastProfilesByCategory") && root.get("lastProfilesByCategory").isJsonObject()) {
                    JsonObject lastObj = root.getAsJsonObject("lastProfilesByCategory");
                    for (BossCategory cat : BossCategory.values()) {
                        if (lastObj.has(cat.name())) {
                            String lp = normalizeProfileKey(lastObj.get(cat.name()).getAsString());
                            if (lp != null && BossCategory.fromProfileKey(lp) == cat) {
                                lastProfileByCategory.put(cat, lp);
                            }
                        }
                    }
                }
                if (root.has("profiles") && root.get("profiles").isJsonObject()) {
                    JsonObject profs = root.getAsJsonObject("profiles");
                    for (Map.Entry<String, JsonElement> e : profs.entrySet()) {
                        String key = normalizeProfileKey(e.getKey());
                        StatsBucket parsed = GSON.fromJson(e.getValue(), StatsBucket.class);
                        if (parsed != null) {
                            if (parsed.drops == null) parsed.drops = new HashMap<>();
                            StatsBucket existing = totalBucketsByProfile.get(key);
                            if (existing == null || scoreBucket(parsed) >= scoreBucket(existing)) {
                                totalBucketsByProfile.put(key, parsed);
                            }
                        }
                    }
                }
            } catch (Throwable ignored) {}
        }
        for (BossCategory cat : BossCategory.values()) {
            String bestKeyForCat = lastProfileByCategory.get(cat);
            long bestScore = bestKeyForCat != null ? scoreBucket(totalBucketsByProfile.get(bestKeyForCat)) : -1L;
            if (bestScore <= 0L) {
                for (Map.Entry<String, StatsBucket> e : totalBucketsByProfile.entrySet()) {
                    if (BossCategory.fromProfileKey(e.getKey()) == cat) {
                        long sc = scoreBucket(e.getValue());
                        if (sc > bestScore) {
                            bestScore = sc;
                            bestKeyForCat = e.getKey();
                        }
                    }
                }
                if (bestKeyForCat != null) {
                    lastProfileByCategory.put(cat, bestKeyForCat);
                }
            }
        }
        save();
    }

    public static void save() {
        try {
            Files.createDirectories(SAVE_PATH.getParent());
            StatsBucket vampBucket = getTotalBucket(DEFAULT_PROFILE_KEY);
            try (Writer writer = Files.newBufferedWriter(SAVE_PATH, StandardCharsets.UTF_8)) {
                GSON.toJson(vampBucket, writer);
            }
            try (Writer writer2 = Files.newBufferedWriter(LEGACY_SAVE_PATH, StandardCharsets.UTF_8)) {
                GSON.toJson(vampBucket, writer2);
            }

            JsonObject multiRoot = new JsonObject();
            multiRoot.addProperty("activeProfile", activeProfileKey);
            JsonObject lastObj = new JsonObject();
            for (BossCategory cat : BossCategory.values()) {
                String lp = lastProfileByCategory.getOrDefault(cat, defaultProfileForCategory(cat));
                lastObj.addProperty(cat.name(), lp);
            }
            multiRoot.add("lastProfilesByCategory", lastObj);
            JsonObject profs = new JsonObject();
            for (Map.Entry<String, StatsBucket> e : totalBucketsByProfile.entrySet()) {
                profs.add(e.getKey(), GSON.toJsonTree(e.getValue()));
            }
            multiRoot.add("profiles", profs);
            try (Writer writer3 = Files.newBufferedWriter(MULTI_SAVE_PATH, StandardCharsets.UTF_8)) {
                GSON.toJson(multiRoot, writer3);
            }
        } catch (Exception ignored) {}
    }
}
