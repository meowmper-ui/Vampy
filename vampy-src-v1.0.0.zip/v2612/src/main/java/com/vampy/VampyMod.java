package com.vampy;

import com.vampy.config.VampyConfig;
import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class VampyMod implements ModInitializer {
    public static final String MOD_ID = "vampy";
    public static final String MOD_NAME = "Vampy";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        VampyConfig.load();
    }
}
