package com.vampy.chat;

import java.util.Locale;
import java.util.regex.Pattern;

/**
 * Shared chat text normalization for stacking keys and hide rules
 * (strip {@code (xN)} suffix, collapse whitespace).
 */
public final class ChatTextPatterns {
    private static final Pattern STACK_SUFFIX = Pattern.compile("\\s*\\(x(\\d+)\\)\\s*$");

    /** Hypixel SkyBlock stash spam (items / materials / overflow). */
    private static final Pattern STASH_COUNT =
            Pattern.compile("you have .+ stashed away!?", Pattern.CASE_INSENSITIVE);
    private static final Pattern STASH_TYPES =
            Pattern.compile("this totals .+ materials stashed", Pattern.CASE_INSENSITIVE);
    private static final Pattern STASH_PICKUP =
            Pattern.compile(">>>\\s*click here to pick them up!\\s*<<<", Pattern.CASE_INSENSITIVE);
    private static final Pattern STASH_OVERFLOW =
            Pattern.compile("didn't fit in your inventory.*(?:material )?stash", Pattern.CASE_INSENSITIVE);

    private ChatTextPatterns() {
    }

    /** True for Hypixel stash notification lines (plain text, formatting already stripped). */
    public static boolean isStashMessage(String text) {
        String key = stackKey(text);
        if (key.isEmpty()) return false;
        String lower = key.toLowerCase(Locale.ROOT);
        if (STASH_COUNT.matcher(lower).find()) return true;
        if (STASH_TYPES.matcher(lower).find()) return true;
        if (STASH_PICKUP.matcher(lower).find()) return true;
        if (STASH_OVERFLOW.matcher(lower).find()) return true;
        if (lower.contains("added to your material stash")) return true;
        return false;
    }

    public static String normalize(String text) {
        if (text == null) return "";
        return text.replace('\u00A0', ' ').replaceAll("\\s+", " ").trim();
    }

    /** Normalized plain text with any existing (xN) stripped — matching key for stack/hide. */
    public static String stackKey(String text) {
        return STACK_SUFFIX.matcher(normalize(text)).replaceFirst("").trim();
    }

    public static boolean isBlankOrOrphanCount(String text) {
        if (text == null) return true;
        String normalized = normalize(text);
        if (normalized.isEmpty()) return true;
        return STACK_SUFFIX.matcher(normalized).matches();
    }

    public static int parseStackCount(String text) {
        var m = STACK_SUFFIX.matcher(normalize(text));
        if (m.find()) {
            try {
                return Math.max(1, Integer.parseInt(m.group(1)));
            } catch (Exception ignored) {
            }
        }
        return 1;
    }

    /**
     * Hypixel private / party chat — never stack these (repeats are intentional).
     * Matches {@code From}/{@code To} whispers and {@code Party >} lines.
     */
    public static boolean isWhisperOrPartyMessage(String text) {
        String key = stackKey(text);
        if (key.isEmpty()) return false;
        // Strip legacy color codes if present in plain getString() output.
        String plain = key.replaceAll("§.", "").trim();
        if (plain.regionMatches(true, 0, "From ", 0, 5)) return true;
        if (plain.regionMatches(true, 0, "To ", 0, 3)) return true;
        if (plain.regionMatches(true, 0, "Party > ", 0, 8)) return true;
        return false;
    }

    /** True if the component contains hard line breaks (banner / multi-line chat). */
    public static boolean isMultilineMessage(String text) {
        if (text == null || text.isEmpty()) return false;
        return text.indexOf('\n') >= 0 || text.indexOf('\r') >= 0;
    }

    /**
     * Decorative Hypixel bar lines ({@code ▬▬▬…} / dashes). These repeat across
     * many announcements, so stacking them to {@code (x40)} shreds banner layout.
     */
    public static boolean isSeparatorLine(String text) {
        if (text == null || text.isEmpty()) return false;
        String plain = text.replace('\u00A0', ' ').replaceAll("§.", "").trim();
        plain = STACK_SUFFIX.matcher(plain).replaceFirst("").trim();
        if (plain.length() < 3) return false;
        String compact = plain.replace(" ", "");
        if (compact.length() < 3) return false;
        int bars = 0;
        for (int i = 0; i < compact.length(); i++) {
            char c = compact.charAt(i);
            if (c == '▬' || c == '━' || c == '─' || c == '═'
                    || c == '-' || c == '=' || c == '•' || c == '‧' || c == '_') {
                bars++;
            }
        }
        return bars * 5 >= compact.length() * 4; // >= 80% bar characters
    }

    /**
     * Messages that must never receive an {@code (xN)} suffix — whispers/party,
     * hard multi-line components, and separator bars.
     */
    public static boolean shouldNeverStack(String text) {
        if (isWhisperOrPartyMessage(text)) return true;
        if (isMultilineMessage(text)) return true;
        if (isSeparatorLine(text)) return true;
        return false;
    }
}
