package com.vampy.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.vampy.VampyMod;
import com.vampy.chat.ChatTextPatterns;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

public final class VampyConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path CONFIG_PATH = FabricLoader.getInstance()
            .getConfigDir()
            .resolve(VampyMod.MOD_ID + ".json");
    private static final Path LEGACY_CONFIG_PATH = FabricLoader.getInstance()
            .getConfigDir()
            .resolve("vampaddons.json");

    public static final double DEFAULT_RENDER_DISTANCE = 128.0;
    private static double renderDistance = DEFAULT_RENDER_DISTANCE;

    private static boolean warningsEnabled = true;
    private static final Map<String, String> warningRules = new LinkedHashMap<>();
    private static final Map<String, Integer> warningColors = new LinkedHashMap<>();
    private static double warningSize = 4.0;
    private static String warningPreview = "SNEAK";

    private static final Map<String, String> DEFAULT_TEXT_REPLACEMENTS = Map.of();
    private static final Map<String, String> textReplacements = new LinkedHashMap<>();

    private static final String TWINCLAW_CRIT_KEY_LEGACY = "TWINCLAW <=0.8s";
    private static final String TWINCLAW_CRIT_KEY = "TWINCLAW <0.8s";
    private static final String TWINCLAW_CRIT_DISPLAY_LEGACY_WASH = "WASH YO FACE";
    private static final String TWINCLAW_CRIT_DEFAULT_DISPLAY = "SPLASH YO FACE";

    private static final Map<String, String> DEFAULT_WARNING_RULES = Map.of(
            "Click up", "Click up",
            "Click down", "Click down",
            "Sneak", "Sneak",
            "Jump", "Jump",
            "TWINCLAW", "TWINCLAW",
            TWINCLAW_CRIT_KEY, TWINCLAW_CRIT_DEFAULT_DISPLAY,
            "Mania Over", "Mania Over"
    );

    static {
        warningRules.putAll(DEFAULT_WARNING_RULES);
        warningColors.put("Click up", -65292);
        warningColors.put("Click down", -16773121);
        warningColors.put("Sneak", -16711685);
        warningColors.put("Jump", -1245440);
        warningColors.put("TWINCLAW", -57779);
        warningColors.put(TWINCLAW_CRIT_KEY, -13454150);
        warningColors.put("Mania Over", -65536);
        for (Map.Entry<String, String> rule : DEFAULT_WARNING_RULES.entrySet()) {
            if (rule.getKey().toLowerCase().contains("twinclaw")
                    || rule.getKey().equalsIgnoreCase("Mania Over")) continue;
            textReplacements.put(rule.getKey(), rule.getValue());
        }
    }

    // Blood Ichor helper (master: ESP + tracer + timer HUD)
    private static boolean ichorHelper = true;
    private static boolean ichorEsp = true;
    private static boolean ichorTracer = true;
    private static boolean ichorTimer = true;
    private static double ichorHudX = 0.5;
    private static double ichorHudY = 0.18;
    private static double ichorHudScale = 1.0;
    private static String ichorMatch = "ichor";
    public static final int DEFAULT_ICHOR_ESP_COLOR = 0xFFAA0000;
    private static int ichorEspColor = DEFAULT_ICHOR_ESP_COLOR;

    // Killer Spring helper (master: ESP + tracer + timer HUD)
    private static boolean killerSpringHelper = true;
    private static boolean killerSpringEsp = true;
    private static boolean killerSpringTracer = true;
    private static boolean killerSpringTimer = true;
    private static double killerSpringHudX = 0.5;
    private static double killerSpringHudY = 0.30;
    private static double killerSpringHudScale = 1.0;
    public static final int DEFAULT_KILLER_SPRING_ESP_COLOR = 0xFF00FF00;
    private static int killerSpringEspColor = DEFAULT_KILLER_SPRING_ESP_COLOR;

    // Effigy assistance
    private static boolean effigyEnabled = true;

    // Auto show block outline waypoints from chat coordinates (off by default)
    private static boolean autoChatWaypoints = false;

    // Mania Helper (safe spot ring ground highlight & status HUD)
    private static boolean maniaHelper = true;
    private static String maniaRenderStyle = "block_tint";
    private static double maniaSquareSize = 1.0;
    private static int maniaRenderRadius = 30;
    private static boolean maniaSafeOnly = true;
    private static boolean maniaOnlyDifferent = false;
    private static final int LEGACY_MANIA_SAFE_COLOR = 0x992EE88A;
    public static final int DEFAULT_MANIA_SAFE_COLOR = 0x9948D690;
    public static final int DEFAULT_MANIA_TERRACOTTA_COLOR = 0x80B4533C;
    public static final int DEFAULT_MANIA_REDSTONE_COLOR = 0x80FF2020;
    public static final int DEFAULT_MANIA_COAL_COLOR = 0x991A1A1A;
    private static int maniaSafeColor = DEFAULT_MANIA_SAFE_COLOR;
    private static int maniaTerracottaColor = DEFAULT_MANIA_TERRACOTTA_COLOR;
    private static int maniaRedstoneColor = DEFAULT_MANIA_REDSTONE_COLOR;
    private static int maniaCoalColor = DEFAULT_MANIA_COAL_COLOR;
    private static boolean maniaHudEnabled = true;
    private static double maniaHudX = 0.5;
    private static double maniaHudY = 0.36;
    private static double maniaHudScale = 1.0;

    // Rift time reminder
    private static boolean riftTimeReminder = true;

    // Slayer kill / quest timers + personal bests
    private static boolean slayerTimersEnabled = true;
    private static boolean slayerProfitTrackerEnabled = true;
    private static boolean slayerProfitSessionOnly = false;
    private static double slayerProfitHudX = 0.015;
    private static double slayerProfitHudY = 0.28;
    private static double slayerProfitScale = 1.0;
    private static long slayerKillPbMs = -1L;
    private static long slayerQuestPbMs = -1L;
    private static final Map<String, Long> slayerKillPbs = new LinkedHashMap<>();
    private static final Map<String, Long> slayerQuestPbs = new LinkedHashMap<>();

    // QoL: FPS / TPS / Ping HUD
    public static final int DEFAULT_PERF_HUD_COLOR = 0xFFB0403C;
    private static boolean perfHudEnabled = false;
    private static int perfHudColor = DEFAULT_PERF_HUD_COLOR;
    private static double perfHudScale = 1.0;
    private static double perfHudX = 0.02;
    private static double perfHudY = 0.02;

    // QoL: player model scale, POV cycle skip, 3rd-person crosshair
    private static double selfPlayerScale = 1.0;
    private static double otherPlayerScale = 1.0;
    private static boolean skipFaceView = false;
    private static boolean thirdPersonCrosshair = false;

    public static final int DEFAULT_CROSSHAIR_COLOR = 0xFFFFFFFF;
    private static String crosshairStyle = "cross";
    private static boolean customCrosshair = false;
    private static int crosshairColor = DEFAULT_CROSSHAIR_COLOR;
    private static boolean crosshairChroma = false;
    private static double crosshairScale = 1.0;

    private static boolean chatCtrlClickCopy = false;
    private static boolean chatStacking = false;
    private static boolean hideStashMessages = false;
    private static final List<String> hiddenChatMessages = new ArrayList<>();
    private static boolean persistentChatHistory = false;
    private static boolean partyInviteCommands = false;
    private static boolean partyChatCommands = false;
    private static boolean partyFunCommands = false;
    private static final LinkedHashSet<String> partyCmdDisabled = new LinkedHashSet<>();

    private static boolean itemRarityOutline = false;
    private static boolean ahLowestBin = false;
    private static boolean scrollableTooltips = true;
    private static boolean tradeValueOverlay = false;
    private static final List<CommandHotkeyEntry> commandHotkeys = new ArrayList<>();
    private static int commandHotkeyGeneration = 0;

    private static final java.util.regex.Pattern WARNING_TIMER_PATTERN =
            java.util.regex.Pattern.compile("(\\d+\\.?\\d*)s");
    public static final float DROPPED_ITEM_SCALE = 1.5f;

    private static boolean clearOverlays = false;
    private static boolean particlesOnlyHearts = false;
    private static boolean fullbright = false;
    private static boolean showQolTab = false;
    private static String guiStyle = GuiStyle.VAMP.getId();
    public static final int DEFAULT_WARNING_COLOR = 0xFFFF5555;

    private static final Map<java.util.UUID, String> entityNameCache = new LinkedHashMap<java.util.UUID, String>() {
        @Override
        protected boolean removeEldestEntry(Map.Entry<java.util.UUID, String> eldest) {
            return size() > 2000;
        }
    };

    private static boolean itemCooldownOverlay = true;
    private static boolean steakableHighlight = true;
    private static boolean slayerBossHighlight = true;
    private static boolean bossSteakAlert = true;
    private static boolean lootshareBossCallout = true;
    private static double unfangedRelicPercent = 85.0;
    private static final Set<String> hiddenProfitDrops = new LinkedHashSet<>();
    private static boolean bazaarUseInstaBuy = false;
    private static double hotbarCdX = -1.0;
    private static double hotbarCdY = -1.0;
    private static double hotbarCdScale = 1.0;
    private static boolean websocketEnabled = true;

    // Party Member Highlight & Dungeon Class Colors
    public static final int DEFAULT_PARTY_MEMBER_COLOR = 0xFF33B5FF;
    public static final int DEFAULT_CLASS_HEALER_COLOR = 0xFFFF55FF;
    public static final int DEFAULT_CLASS_MAGE_COLOR = 0xFF55FFFF;
    public static final int DEFAULT_CLASS_BERSERK_COLOR = 0xFFFF5555;
    public static final int DEFAULT_CLASS_ARCHER_COLOR = 0xFFFFAA00;
    public static final int DEFAULT_CLASS_TANK_COLOR = 0xFF55FF55;

    private static int partyMemberColor = DEFAULT_PARTY_MEMBER_COLOR;
    private static boolean partyMemberGlow = true;
    private static boolean dungeonClassColors = true;
    private static int classHealerColor = DEFAULT_CLASS_HEALER_COLOR;
    private static int classMageColor = DEFAULT_CLASS_MAGE_COLOR;
    private static int classBerserkColor = DEFAULT_CLASS_BERSERK_COLOR;
    private static int classArcherColor = DEFAULT_CLASS_ARCHER_COLOR;
    private static int classTankColor = DEFAULT_CLASS_TANK_COLOR;

    // Per-Slayer Profit Tracker Toggles (no tier split)
    private static boolean trackVampireSlayer = true;
    private static boolean trackZombieSlayer = true;
    private static boolean trackSpiderSlayer = true;
    private static boolean trackWolfSlayer = true;
    private static boolean trackEndermanSlayer = true;
    private static boolean trackBlazeSlayer = true;
    private static Boolean cachedSimpleOnlyBuild = null;

    private VampyConfig() {
    }

    public static void load() {
        Path targetPath = Files.exists(CONFIG_PATH) ? CONFIG_PATH : (Files.exists(LEGACY_CONFIG_PATH) ? LEGACY_CONFIG_PATH : null);
        if (targetPath == null) {
            save();
            return;
        }

        boolean migratedTwinclawCrit = false;
        try (Reader reader = Files.newBufferedReader(targetPath)) {
            com.google.gson.JsonElement element = com.google.gson.JsonParser.parseReader(reader);
            if (element == null || !element.isJsonObject()) {
                return;
            }

            com.google.gson.JsonObject obj = element.getAsJsonObject();

            if (obj.has("warningsEnabled")) {
                warningsEnabled = obj.get("warningsEnabled").getAsBoolean();
            }

            if (obj.has("warningRules")) {
                warningRules.clear();
                warningRules.putAll(DEFAULT_WARNING_RULES);
                com.google.gson.JsonElement rulesElem = obj.get("warningRules");
                if (rulesElem.isJsonObject()) {
                    for (Map.Entry<String, com.google.gson.JsonElement> entry : rulesElem.getAsJsonObject().entrySet()) {
                        String rawTrigger = entry.getKey().trim();
                        String trigger = normalizeTwinclawCritKey(rawTrigger);
                        String display = normalizeTwinclawCritDisplay(entry.getValue().getAsString());
                        if (!rawTrigger.equals(trigger) || !display.equals(entry.getValue().getAsString())) {
                            migratedTwinclawCrit = true;
                        }
                        if (!trigger.isEmpty()) warningRules.put(trigger, display);
                    }
                }
                migratedTwinclawCrit |= migrateLegacyTwinclawCritRules();
            }

            if (obj.has("warningColors")) {
                warningColors.clear();
                com.google.gson.JsonElement colorsElem = obj.get("warningColors");
                if (colorsElem.isJsonObject()) {
                    Map<String, String> displayToTrigger = new LinkedHashMap<>();
                    for (Map.Entry<String, String> e : DEFAULT_TEXT_REPLACEMENTS.entrySet()) {
                        displayToTrigger.put(e.getValue(), e.getKey());
                    }
                    for (Map.Entry<String, com.google.gson.JsonElement> entry : colorsElem.getAsJsonObject().entrySet()) {
                        String key = entry.getKey();
                        int color = DEFAULT_WARNING_COLOR;
                        try { color = entry.getValue().getAsInt(); } catch (Exception ignored) {}
                        String trigger = displayToTrigger.getOrDefault(key, key);
                        if (trigger.equalsIgnoreCase("Mania Over")) trigger = "Mania Over";
                        String normalized = normalizeTwinclawCritKey(trigger);
                        if (!normalized.equals(trigger)) migratedTwinclawCrit = true;
                        trigger = normalized;
                        warningColors.put(trigger, color);
                    }
                }
                migratedTwinclawCrit |= migrateLegacyTwinclawCritColors();
            }

            if (obj.has("warningSize")) {
                warningSize = obj.get("warningSize").getAsDouble();
            }

            if (obj.has("warningPreview")) {
                warningPreview = obj.get("warningPreview").getAsString();
            }

            if (obj.has("textReplacements")) {
                textReplacements.clear();
                com.google.gson.JsonElement repElem = obj.get("textReplacements");
                if (repElem.isJsonObject()) {
                    for (Map.Entry<String, com.google.gson.JsonElement> entry : repElem.getAsJsonObject().entrySet()) {
                        String trigger = entry.getKey().trim();
                        String replacement = entry.getValue().getAsString();
                        if (!trigger.isEmpty()) textReplacements.put(trigger, replacement);
                    }
                }
            }

            syncTextReplacementsFromWarningRules();

            if (obj.has("ichorEsp")) ichorEsp = obj.get("ichorEsp").getAsBoolean();
            if (obj.has("ichorTracer")) ichorTracer = obj.get("ichorTracer").getAsBoolean();
            if (obj.has("ichorTimer")) ichorTimer = obj.get("ichorTimer").getAsBoolean();
            if (obj.has("ichorHelper")) ichorHelper = obj.get("ichorHelper").getAsBoolean();
            else ichorHelper = ichorEsp || ichorTracer || ichorTimer;
            applyIchorHelper(ichorHelper);
            if (obj.has("ichorHudX")) ichorHudX = obj.get("ichorHudX").getAsDouble();
            if (obj.has("ichorHudY")) ichorHudY = obj.get("ichorHudY").getAsDouble();
            if (obj.has("ichorHudScale")) ichorHudScale = Math.max(0.5, Math.min(3.0, obj.get("ichorHudScale").getAsDouble()));
            if (obj.has("ichorEspColor")) ichorEspColor = obj.get("ichorEspColor").getAsInt();
            if (obj.has("ichorMatch")) ichorMatch = obj.get("ichorMatch").getAsString();

            if (obj.has("killerSpringEsp")) killerSpringEsp = obj.get("killerSpringEsp").getAsBoolean();
            if (obj.has("killerSpringTracer")) killerSpringTracer = obj.get("killerSpringTracer").getAsBoolean();
            if (obj.has("killerSpringTimer")) killerSpringTimer = obj.get("killerSpringTimer").getAsBoolean();
            if (obj.has("killerSpringHelper")) killerSpringHelper = obj.get("killerSpringHelper").getAsBoolean();
            else killerSpringHelper = killerSpringEsp || killerSpringTracer || killerSpringTimer;
            applyKillerSpringHelper(killerSpringHelper);
            if (obj.has("killerSpringHudX")) killerSpringHudX = obj.get("killerSpringHudX").getAsDouble();
            if (obj.has("killerSpringHudY")) killerSpringHudY = obj.get("killerSpringHudY").getAsDouble();
            if (obj.has("killerSpringHudScale")) killerSpringHudScale = Math.max(0.5, Math.min(3.0, obj.get("killerSpringHudScale").getAsDouble()));
            if (obj.has("killerSpringEspColor")) killerSpringEspColor = obj.get("killerSpringEspColor").getAsInt();

            if (obj.has("effigyEnabled")) effigyEnabled = obj.get("effigyEnabled").getAsBoolean();
            if (obj.has("autoChatWaypoints")) autoChatWaypoints = obj.get("autoChatWaypoints").getAsBoolean();
            if (obj.has("maniaHelper")) maniaHelper = obj.get("maniaHelper").getAsBoolean();
            if (obj.has("maniaRenderStyle")) maniaRenderStyle = obj.get("maniaRenderStyle").getAsString();
            if (obj.has("maniaSquareSize")) maniaSquareSize = Math.max(0.1, Math.min(1.0, obj.get("maniaSquareSize").getAsDouble()));
            if (obj.has("maniaRenderRadius")) {
                int loadedRadius = obj.get("maniaRenderRadius").getAsInt();
                // Migrate legacy small default radii (<= 15) to 30 so the entire Mania ring pattern is always rendered!
                maniaRenderRadius = loadedRadius <= 15 ? 30 : Math.max(16, Math.min(30, loadedRadius));
            }
            if (obj.has("maniaSafeOnly")) maniaSafeOnly = obj.get("maniaSafeOnly").getAsBoolean();
            if (obj.has("maniaOnlyDifferent")) maniaOnlyDifferent = obj.get("maniaOnlyDifferent").getAsBoolean();
            if (obj.has("maniaSafeColor")) {
                int loadedSafeColor = obj.get("maniaSafeColor").getAsInt();
                if ((loadedSafeColor & 0xFFFFFF) == (LEGACY_MANIA_SAFE_COLOR & 0xFFFFFF)) {
                    maniaSafeColor = DEFAULT_MANIA_SAFE_COLOR;
                    migratedTwinclawCrit = true;
                } else {
                    maniaSafeColor = loadedSafeColor;
                }
            }
            if (obj.has("maniaTerracottaColor")) maniaTerracottaColor = obj.get("maniaTerracottaColor").getAsInt();
            if (obj.has("maniaRedstoneColor")) maniaRedstoneColor = obj.get("maniaRedstoneColor").getAsInt();
            if (obj.has("maniaCoalColor")) maniaCoalColor = obj.get("maniaCoalColor").getAsInt();
            if (obj.has("maniaHudEnabled")) maniaHudEnabled = obj.get("maniaHudEnabled").getAsBoolean();
            if (obj.has("maniaHudX")) maniaHudX = obj.get("maniaHudX").getAsDouble();
            if (obj.has("maniaHudY")) maniaHudY = obj.get("maniaHudY").getAsDouble();
            if (obj.has("maniaHudScale")) maniaHudScale = Math.max(0.5, Math.min(3.0, obj.get("maniaHudScale").getAsDouble()));
            if (obj.has("lootshareBossCallout")) lootshareBossCallout = obj.get("lootshareBossCallout").getAsBoolean();
            if (obj.has("riftTimeReminder")) riftTimeReminder = obj.get("riftTimeReminder").getAsBoolean();
            if (obj.has("slayerTimersEnabled")) slayerTimersEnabled = obj.get("slayerTimersEnabled").getAsBoolean();
            if (obj.has("slayerProfitTrackerEnabled")) slayerProfitTrackerEnabled = obj.get("slayerProfitTrackerEnabled").getAsBoolean();
            if (obj.has("slayerProfitSessionOnly")) slayerProfitSessionOnly = obj.get("slayerProfitSessionOnly").getAsBoolean();
            if (obj.has("slayerProfitHudX")) slayerProfitHudX = obj.get("slayerProfitHudX").getAsDouble();
            if (obj.has("slayerProfitHudY")) slayerProfitHudY = obj.get("slayerProfitHudY").getAsDouble();
            if (obj.has("slayerProfitScale")) slayerProfitScale = Math.max(0.5, Math.min(2.5, obj.get("slayerProfitScale").getAsDouble()));
            if (obj.has("slayerKillPbMs")) slayerKillPbMs = obj.get("slayerKillPbMs").getAsLong();
            if (obj.has("slayerQuestPbMs")) slayerQuestPbMs = obj.get("slayerQuestPbMs").getAsLong();
            slayerKillPbs.clear();
            if (obj.has("slayerKillPbs") && obj.get("slayerKillPbs").isJsonObject()) {
                for (Map.Entry<String, com.google.gson.JsonElement> e : obj.getAsJsonObject("slayerKillPbs").entrySet()) {
                    try {
                        long v = e.getValue().getAsLong();
                        if (v >= 0L) slayerKillPbs.put(normalizeBossPbKey(e.getKey()), v);
                    } catch (Exception ignored) {}
                }
            }
            if (slayerKillPbMs >= 0L) {
                slayerKillPbs.putIfAbsent(normalizeBossPbKey("Riftstalker Bloodfiend V"), slayerKillPbMs);
            }
            slayerQuestPbs.clear();
            if (obj.has("slayerQuestPbs") && obj.get("slayerQuestPbs").isJsonObject()) {
                for (Map.Entry<String, com.google.gson.JsonElement> e : obj.getAsJsonObject("slayerQuestPbs").entrySet()) {
                    try {
                        long v = e.getValue().getAsLong();
                        if (v >= 0L) slayerQuestPbs.put(normalizeBossPbKey(e.getKey()), v);
                    } catch (Exception ignored) {}
                }
            }
            if (slayerQuestPbMs >= 0L) {
                slayerQuestPbs.putIfAbsent(normalizeBossPbKey("Riftstalker Bloodfiend V"), slayerQuestPbMs);
            }

            if (obj.has("selfPlayerScale")) selfPlayerScale = obj.get("selfPlayerScale").getAsDouble();
            if (obj.has("otherPlayerScale")) otherPlayerScale = obj.get("otherPlayerScale").getAsDouble();
            if (obj.has("skipFaceView")) skipFaceView = obj.get("skipFaceView").getAsBoolean();
            if (obj.has("thirdPersonCrosshair")) thirdPersonCrosshair = obj.get("thirdPersonCrosshair").getAsBoolean();
            if (obj.has("crosshairStyle")) crosshairStyle = CrosshairStyle.fromId(obj.get("crosshairStyle").getAsString()).getId();
            if (obj.has("customCrosshair")) customCrosshair = obj.get("customCrosshair").getAsBoolean();
            if (obj.has("crosshairColor")) crosshairColor = obj.get("crosshairColor").getAsInt();
            if (obj.has("crosshairChroma")) crosshairChroma = obj.get("crosshairChroma").getAsBoolean();
            if (obj.has("crosshairScale")) crosshairScale = Math.max(0.25, Math.min(3.0, obj.get("crosshairScale").getAsDouble()));

            if (obj.has("perfHudEnabled")) perfHudEnabled = obj.get("perfHudEnabled").getAsBoolean();
            if (obj.has("perfHudColor")) perfHudColor = obj.get("perfHudColor").getAsInt();
            if (obj.has("perfHudScale")) perfHudScale = Math.max(0.5, Math.min(3.0, obj.get("perfHudScale").getAsDouble()));
            if (obj.has("perfHudX")) {
                double v = obj.get("perfHudX").getAsDouble();
                perfHudX = v < 0 ? 0 : (v > 1 ? 1 : v);
            }
            if (obj.has("perfHudY")) {
                double v = obj.get("perfHudY").getAsDouble();
                perfHudY = v < 0 ? 0 : (v > 1 ? 1 : v);
            }

            if (obj.has("chatCtrlClickCopy")) chatCtrlClickCopy = obj.get("chatCtrlClickCopy").getAsBoolean();
            if (obj.has("chatStacking")) chatStacking = obj.get("chatStacking").getAsBoolean();
            if (obj.has("hideStashMessages")) hideStashMessages = obj.get("hideStashMessages").getAsBoolean();
            if (obj.has("hiddenChatMessages")) {
                hiddenChatMessages.clear();
                com.google.gson.JsonArray arr = obj.getAsJsonArray("hiddenChatMessages");
                for (var elem : arr) {
                    String pattern = ChatTextPatterns.stackKey(elem.getAsString());
                    if (!pattern.isEmpty() && !hiddenChatMessages.contains(pattern)) {
                        hiddenChatMessages.add(pattern);
                    }
                }
            }
            if (obj.has("persistentChatHistory")) persistentChatHistory = obj.get("persistentChatHistory").getAsBoolean();
            if (obj.has("partyInviteCommands")) partyInviteCommands = obj.get("partyInviteCommands").getAsBoolean();
            if (obj.has("partyChatCommands")) partyChatCommands = obj.get("partyChatCommands").getAsBoolean();
            if (obj.has("partyFunCommands")) partyFunCommands = obj.get("partyFunCommands").getAsBoolean();
            if (obj.has("partyCmdDisabled")) {
                partyCmdDisabled.clear();
                for (var elem : obj.getAsJsonArray("partyCmdDisabled")) {
                    String id = elem.getAsString().trim().toLowerCase();
                    if (id.isEmpty()) continue;
                    if ("wt".equals(id)) id = "w";
                    partyCmdDisabled.add(id);
                }
            }

            if (obj.has("itemRarityOutline")) itemRarityOutline = obj.get("itemRarityOutline").getAsBoolean();
            if (obj.has("ahLowestBin")) ahLowestBin = obj.get("ahLowestBin").getAsBoolean();
            if (obj.has("scrollableTooltips")) scrollableTooltips = obj.get("scrollableTooltips").getAsBoolean();
            if (obj.has("tradeValueOverlay")) tradeValueOverlay = obj.get("tradeValueOverlay").getAsBoolean();

            commandHotkeys.clear();
            if (obj.has("commandHotkeys")) {
                CommandHotkeyEntry[] arr = GSON.fromJson(obj.get("commandHotkeys"), CommandHotkeyEntry[].class);
                if (arr != null) {
                    for (CommandHotkeyEntry e : arr) {
                        if (e != null) commandHotkeys.add(e.copy());
                    }
                }
            }
            commandHotkeyGeneration++;

            if (obj.has("clearOverlays")) clearOverlays = obj.get("clearOverlays").getAsBoolean();
            if (obj.has("particlesOnlyHearts")) particlesOnlyHearts = obj.get("particlesOnlyHearts").getAsBoolean();
            if (obj.has("fullbright")) fullbright = obj.get("fullbright").getAsBoolean();
            if (obj.has("showQolTab")) showQolTab = obj.get("showQolTab").getAsBoolean();
            if (obj.has("guiStyle")) guiStyle = GuiStyle.fromId(obj.get("guiStyle").getAsString()).getId();
            if (obj.has("renderDistance")) {
                renderDistance = Math.min(obj.get("renderDistance").getAsDouble(), DEFAULT_RENDER_DISTANCE);
            }
            if (obj.has("itemCooldownOverlay")) itemCooldownOverlay = obj.get("itemCooldownOverlay").getAsBoolean();
            if (obj.has("steakableHighlight")) steakableHighlight = obj.get("steakableHighlight").getAsBoolean();
            if (obj.has("slayerBossHighlight")) slayerBossHighlight = obj.get("slayerBossHighlight").getAsBoolean();
            if (obj.has("bossSteakAlert")) bossSteakAlert = obj.get("bossSteakAlert").getAsBoolean();
            if (obj.has("unfangedRelicPercent")) unfangedRelicPercent = Math.clamp(obj.get("unfangedRelicPercent").getAsDouble(), 0.0, 100.0);
            if (obj.has("bazaarUseInstaBuy")) bazaarUseInstaBuy = obj.get("bazaarUseInstaBuy").getAsBoolean();
            if (obj.has("hotbarCdX")) hotbarCdX = obj.get("hotbarCdX").getAsDouble();
            if (obj.has("hotbarCdY")) hotbarCdY = obj.get("hotbarCdY").getAsDouble();
            if (obj.has("hotbarCdScale")) hotbarCdScale = Math.clamp(obj.get("hotbarCdScale").getAsDouble(), 0.5, 3.0);
            if (obj.has("hiddenProfitDrops") && obj.get("hiddenProfitDrops").isJsonArray()) {
                hiddenProfitDrops.clear();
                for (var elem : obj.getAsJsonArray("hiddenProfitDrops")) {
                    hiddenProfitDrops.add(elem.getAsString());
                }
            }
            if (obj.has("websocketEnabled")) websocketEnabled = obj.get("websocketEnabled").getAsBoolean();
            if (obj.has("partyMemberColor")) partyMemberColor = obj.get("partyMemberColor").getAsInt() | 0xFF000000;
            if (obj.has("partyMemberGlow")) partyMemberGlow = obj.get("partyMemberGlow").getAsBoolean();
            if (obj.has("dungeonClassColors")) dungeonClassColors = obj.get("dungeonClassColors").getAsBoolean();
            if (obj.has("classHealerColor")) classHealerColor = obj.get("classHealerColor").getAsInt() | 0xFF000000;
            if (obj.has("classMageColor")) classMageColor = obj.get("classMageColor").getAsInt() | 0xFF000000;
            if (obj.has("classBerserkColor")) classBerserkColor = obj.get("classBerserkColor").getAsInt() | 0xFF000000;
            if (obj.has("classArcherColor")) classArcherColor = obj.get("classArcherColor").getAsInt() | 0xFF000000;
            if (obj.has("classTankColor")) classTankColor = obj.get("classTankColor").getAsInt() | 0xFF000000;
            if (obj.has("trackVampireSlayer")) trackVampireSlayer = obj.get("trackVampireSlayer").getAsBoolean();
            if (obj.has("trackZombieSlayer")) trackZombieSlayer = obj.get("trackZombieSlayer").getAsBoolean();
            if (obj.has("trackSpiderSlayer")) trackSpiderSlayer = obj.get("trackSpiderSlayer").getAsBoolean();
            if (obj.has("trackWolfSlayer")) trackWolfSlayer = obj.get("trackWolfSlayer").getAsBoolean();
            if (obj.has("trackEndermanSlayer")) trackEndermanSlayer = obj.get("trackEndermanSlayer").getAsBoolean();
            if (obj.has("trackBlazeSlayer")) trackBlazeSlayer = obj.get("trackBlazeSlayer").getAsBoolean();
        } catch (Exception exception) {
            VampyMod.LOGGER.error("Failed to load Vampy config", exception);
        }
        if (migratedTwinclawCrit) {
            save();
        }
    }

    private static String normalizeTwinclawCritKey(String trigger) {
        return TWINCLAW_CRIT_KEY_LEGACY.equals(trigger) ? TWINCLAW_CRIT_KEY : trigger;
    }

    private static String normalizeTwinclawCritDisplay(String display) {
        if (TWINCLAW_CRIT_KEY_LEGACY.equals(display)
                || TWINCLAW_CRIT_KEY.equals(display)
                || TWINCLAW_CRIT_DISPLAY_LEGACY_WASH.equals(display)) {
            return TWINCLAW_CRIT_DEFAULT_DISPLAY;
        }
        return display;
    }

    private static boolean migrateLegacyTwinclawCritRules() {
        boolean changed = false;
        if (warningRules.containsKey(TWINCLAW_CRIT_KEY_LEGACY)) {
            String display = normalizeTwinclawCritDisplay(warningRules.remove(TWINCLAW_CRIT_KEY_LEGACY));
            if (!warningRules.containsKey(TWINCLAW_CRIT_KEY)
                    || TWINCLAW_CRIT_KEY.equals(warningRules.get(TWINCLAW_CRIT_KEY))
                    || TWINCLAW_CRIT_KEY_LEGACY.equals(warningRules.get(TWINCLAW_CRIT_KEY))
                    || TWINCLAW_CRIT_DISPLAY_LEGACY_WASH.equals(warningRules.get(TWINCLAW_CRIT_KEY))) {
                warningRules.put(TWINCLAW_CRIT_KEY, display);
            }
            changed = true;
        }
        String current = warningRules.get(TWINCLAW_CRIT_KEY);
        if (TWINCLAW_CRIT_KEY_LEGACY.equals(current)
                || TWINCLAW_CRIT_KEY.equals(current)
                || TWINCLAW_CRIT_DISPLAY_LEGACY_WASH.equals(current)) {
            warningRules.put(TWINCLAW_CRIT_KEY, TWINCLAW_CRIT_DEFAULT_DISPLAY);
            changed = true;
        }
        return changed;
    }

    private static boolean migrateLegacyTwinclawCritColors() {
        if (!warningColors.containsKey(TWINCLAW_CRIT_KEY_LEGACY)) return false;
        Integer color = warningColors.remove(TWINCLAW_CRIT_KEY_LEGACY);
        if (color != null && !warningColors.containsKey(TWINCLAW_CRIT_KEY)) {
            warningColors.put(TWINCLAW_CRIT_KEY, color);
        }
        return true;
    }

    public static byte[] createUndoSnapshot() {
        save();
        try {
            if (!Files.exists(CONFIG_PATH)) {
                return new byte[0];
            }
            return Files.readAllBytes(CONFIG_PATH);
        } catch (IOException exception) {
            VampyMod.LOGGER.error("Failed to snapshot Vampy config", exception);
            return null;
        }
    }

    public static void restoreUndoSnapshot(byte[] data) {
        if (data == null) {
            return;
        }
        try {
            Files.createDirectories(CONFIG_PATH.getParent());
            Files.write(CONFIG_PATH, data);
            load();
        } catch (IOException exception) {
            VampyMod.LOGGER.error("Failed to restore Vampy config snapshot", exception);
        }
    }

    public static void save() {
        ConfigData data = new ConfigData();
        data.renderDistance = renderDistance;
        data.warningsEnabled = warningsEnabled;
        data.warningRules = new LinkedHashMap<>(warningRules);
        data.warningColors = new LinkedHashMap<>(warningColors);
        data.warningSize = warningSize;
        data.warningPreview = warningPreview;
        data.textReplacements = new LinkedHashMap<>(textReplacements);
        data.ichorHelper = ichorHelper;
        data.ichorEsp = ichorEsp;
        data.ichorTracer = ichorTracer;
        data.ichorTimer = ichorTimer;
        data.ichorHudX = ichorHudX;
        data.ichorHudY = ichorHudY;
        data.ichorHudScale = ichorHudScale;
        data.ichorEspColor = ichorEspColor;
        data.ichorMatch = ichorMatch;
        data.killerSpringHelper = killerSpringHelper;
        data.killerSpringEsp = killerSpringEsp;
        data.killerSpringTracer = killerSpringTracer;
        data.killerSpringTimer = killerSpringTimer;
        data.killerSpringHudX = killerSpringHudX;
        data.killerSpringHudY = killerSpringHudY;
        data.killerSpringHudScale = killerSpringHudScale;
        data.killerSpringEspColor = killerSpringEspColor;
        data.effigyEnabled = effigyEnabled;
        data.autoChatWaypoints = autoChatWaypoints;
        data.maniaHelper = maniaHelper;
        data.maniaRenderStyle = maniaRenderStyle;
        data.maniaSquareSize = maniaSquareSize;
        data.maniaRenderRadius = maniaRenderRadius;
        data.maniaSafeOnly = maniaSafeOnly;
        data.maniaOnlyDifferent = maniaOnlyDifferent;
        data.maniaSafeColor = maniaSafeColor;
        data.maniaTerracottaColor = maniaTerracottaColor;
        data.maniaRedstoneColor = maniaRedstoneColor;
        data.maniaCoalColor = maniaCoalColor;
        data.maniaHudEnabled = maniaHudEnabled;
        data.maniaHudX = maniaHudX;
        data.maniaHudY = maniaHudY;
        data.maniaHudScale = maniaHudScale;
        data.lootshareBossCallout = lootshareBossCallout;
        data.riftTimeReminder = riftTimeReminder;
        data.slayerTimersEnabled = slayerTimersEnabled;
        data.slayerProfitTrackerEnabled = slayerProfitTrackerEnabled;
        data.slayerProfitSessionOnly = slayerProfitSessionOnly;
        data.slayerProfitHudX = slayerProfitHudX;
        data.slayerProfitHudY = slayerProfitHudY;
        data.slayerProfitScale = slayerProfitScale;
        data.slayerKillPbMs = slayerKillPbMs;
        data.slayerQuestPbMs = slayerQuestPbMs;
        data.slayerKillPbs = new LinkedHashMap<>(slayerKillPbs);
        data.slayerQuestPbs = new LinkedHashMap<>(slayerQuestPbs);
        data.selfPlayerScale = selfPlayerScale;
        data.otherPlayerScale = otherPlayerScale;
        data.skipFaceView = skipFaceView;
        data.thirdPersonCrosshair = thirdPersonCrosshair;
        data.crosshairStyle = crosshairStyle;
        data.customCrosshair = customCrosshair;
        data.crosshairColor = crosshairColor;
        data.crosshairChroma = crosshairChroma;
        data.crosshairScale = crosshairScale;
        data.perfHudEnabled = perfHudEnabled;
        data.perfHudColor = perfHudColor;
        data.perfHudScale = perfHudScale;
        data.perfHudX = perfHudX;
        data.perfHudY = perfHudY;
        data.chatCtrlClickCopy = chatCtrlClickCopy;
        data.chatStacking = chatStacking;
        data.hideStashMessages = hideStashMessages;
        data.hiddenChatMessages = new ArrayList<>();
        for (String s : hiddenChatMessages) {
            String pattern = ChatTextPatterns.stackKey(s);
            if (!pattern.isEmpty()) data.hiddenChatMessages.add(pattern);
        }
        data.persistentChatHistory = persistentChatHistory;
        data.partyInviteCommands = partyInviteCommands;
        data.partyChatCommands = partyChatCommands;
        data.partyFunCommands = partyFunCommands;
        data.partyCmdDisabled = new ArrayList<>(partyCmdDisabled);
        data.itemRarityOutline = itemRarityOutline;
        data.ahLowestBin = ahLowestBin;
        data.scrollableTooltips = scrollableTooltips;
        data.tradeValueOverlay = tradeValueOverlay;
        data.commandHotkeys = new ArrayList<>();
        for (CommandHotkeyEntry e : commandHotkeys) {
            data.commandHotkeys.add(e.copy());
        }
        data.clearOverlays = clearOverlays;
        data.particlesOnlyHearts = particlesOnlyHearts;
        data.fullbright = fullbright;
        data.showQolTab = showQolTab;
        data.guiStyle = guiStyle;
        data.itemCooldownOverlay = itemCooldownOverlay;
        data.steakableHighlight = steakableHighlight;
        data.slayerBossHighlight = slayerBossHighlight;
        data.bossSteakAlert = bossSteakAlert;
        data.unfangedRelicPercent = unfangedRelicPercent;
        data.bazaarUseInstaBuy = bazaarUseInstaBuy;
        data.hotbarCdX = hotbarCdX;
        data.hotbarCdY = hotbarCdY;
        data.hotbarCdScale = hotbarCdScale;
        data.hiddenProfitDrops = new ArrayList<>(hiddenProfitDrops);
        data.websocketEnabled = websocketEnabled;
        data.partyMemberColor = partyMemberColor;
        data.partyMemberGlow = partyMemberGlow;
        data.dungeonClassColors = dungeonClassColors;
        data.classHealerColor = classHealerColor;
        data.classMageColor = classMageColor;
        data.classBerserkColor = classBerserkColor;
        data.classArcherColor = classArcherColor;
        data.classTankColor = classTankColor;
        data.trackVampireSlayer = trackVampireSlayer;
        data.trackZombieSlayer = trackZombieSlayer;
        data.trackSpiderSlayer = trackSpiderSlayer;
        data.trackWolfSlayer = trackWolfSlayer;
        data.trackEndermanSlayer = trackEndermanSlayer;
        data.trackBlazeSlayer = trackBlazeSlayer;

        try {
            Files.createDirectories(CONFIG_PATH.getParent());
            try (Writer writer = Files.newBufferedWriter(CONFIG_PATH)) {
                GSON.toJson(data, writer);
            }
        } catch (IOException exception) {
            VampyMod.LOGGER.error("Failed to save Vampy config", exception);
        }
    }

    public static double getRenderDistance() { return renderDistance; }
    public static void setRenderDistance(double value) {
        renderDistance = Math.max(16.0, Math.min(value, DEFAULT_RENDER_DISTANCE));
        save();
    }

    public static String getCachedEntityName(java.util.UUID uuid) {
        return entityNameCache.getOrDefault(uuid, "");
    }

    public static void cacheEntityName(java.util.UUID uuid, String name) {
        if (uuid != null && name != null && !name.isEmpty()) {
            entityNameCache.put(uuid, name);
        }
    }

    public static boolean isWarningsEnabled() { return warningsEnabled; }
    public static void setWarningsEnabled(boolean value) { warningsEnabled = value; save(); }

    public static double getWarningSize() { return warningSize; }
    public static void setWarningSize(double value) { warningSize = value; save(); }

    public static String getWarningPreview() { return warningPreview; }
    public static void setWarningPreview(String value) { warningPreview = value != null ? value : ""; save(); }

    public static Map<String, String> getWarningRules() {
        migrateLegacyTwinclawCritRules();
        Map<String, String> copy = new LinkedHashMap<>();
        for (Map.Entry<String, String> e : warningRules.entrySet()) {
            String key = normalizeTwinclawCritKey(e.getKey());
            if (TWINCLAW_CRIT_KEY_LEGACY.equals(e.getKey())) continue;
            copy.put(key, normalizeTwinclawCritDisplay(e.getValue()));
        }
        return copy;
    }

    public static List<String> getWarningRuleKeys() {
        List<String> keys = new ArrayList<>();
        for (String key : warningRules.keySet()) {
            String normalized = normalizeTwinclawCritKey(key);
            if (TWINCLAW_CRIT_KEY_LEGACY.equals(key)) {
                if (!keys.contains(TWINCLAW_CRIT_KEY)) keys.add(TWINCLAW_CRIT_KEY);
                continue;
            }
            if (!keys.contains(normalized)) keys.add(normalized);
        }
        return keys;
    }

    public static void setWarningRule(String trigger, String display) {
        if (trigger != null && !trigger.isEmpty()) {
            String key = normalizeTwinclawCritKey(trigger);
            String value = normalizeTwinclawCritDisplay(display != null ? display : "");
            if (!key.equals(trigger)) warningRules.remove(TWINCLAW_CRIT_KEY_LEGACY);
            warningRules.put(key, value);
            if (!isBuiltInBossWarning(key)) {
                textReplacements.put(key, value);
            }
            save();
        }
    }

    public static void removeWarningRule(String trigger) {
        warningRules.remove(trigger);
        save();
    }

    public static void setWarningRulesFromKeys(List<String> keys) {
        warningRules.keySet().retainAll(keys);
        for (String key : keys) {
            if (!warningRules.containsKey(key)) {
                warningRules.put(key, "");
            }
        }
        save();
    }

    public static String getWarningDisplay(String trigger) {
        if (trigger == null) return "";
        String key = normalizeTwinclawCritKey(trigger);
        if (warningRules.containsKey(key)) return warningRules.get(key);
        if (TWINCLAW_CRIT_KEY.equals(key) && warningRules.containsKey(TWINCLAW_CRIT_KEY_LEGACY)) {
            return normalizeTwinclawCritDisplay(warningRules.get(TWINCLAW_CRIT_KEY_LEGACY));
        }
        return warningRules.getOrDefault(trigger, "");
    }

    public static String resolveWarningDisplay(String trigger) {
        String key = normalizeTwinclawCritKey(trigger);
        String display = getWarningDisplay(key);
        if (display == null || display.isEmpty()) {
            display = getWarningDisplay(TWINCLAW_CRIT_KEY_LEGACY.equals(trigger) ? TWINCLAW_CRIT_KEY_LEGACY : trigger);
        }
        if (display == null || display.isEmpty()) display = key;
        return normalizeTwinclawCritDisplay(display);
    }

    public static boolean isBuiltInBossWarning(String trigger) {
        if (trigger == null) return false;
        String lower = trigger.toLowerCase();
        return (lower.contains("twinclaw")) || lower.equals("mania over");
    }

    public static Map<String, Integer> getWarningColors() { return new LinkedHashMap<>(warningColors); }

    public static int getWarningColor(String trigger) {
        if (trigger != null) {
            String key = normalizeTwinclawCritKey(trigger);
            if (warningColors.containsKey(key)) {
                return warningColors.get(key);
            }
            if (TWINCLAW_CRIT_KEY.equals(key) && warningColors.containsKey(TWINCLAW_CRIT_KEY_LEGACY)) {
                return warningColors.get(TWINCLAW_CRIT_KEY_LEGACY);
            }
            if (warningColors.containsKey(trigger)) {
                return warningColors.get(trigger);
            }
        }
        if (trigger != null && trigger.equalsIgnoreCase("Mania Over")) {
            Integer c = warningColors.get("Mania Over");
            if (c != null) return c;
            c = warningColors.get("MANIA OVER");
            if (c != null) return c;
        }
        return DEFAULT_WARNING_COLOR;
    }

    public static void setWarningColor(String trigger, int color) {
        if (trigger != null && !trigger.isEmpty()) {
            String key = normalizeTwinclawCritKey(trigger);
            if (!key.equals(trigger)) warningColors.remove(TWINCLAW_CRIT_KEY_LEGACY);
            warningColors.put(key, color);
            save();
        }
    }

    private static void syncTextReplacementsFromWarningRules() {
        for (Map.Entry<String, String> rule : warningRules.entrySet()) {
            if (isBuiltInBossWarning(rule.getKey())) continue;
            textReplacements.put(rule.getKey(), rule.getValue() == null ? "" : rule.getValue());
        }
    }

    public static final class Warning {
        public final String text;
        public final int color;
        public Warning(String text, int color) { this.text = text; this.color = color; }
    }

    public static List<Warning> checkWarnings(List<Entity> entities) {
        if (!warningsEnabled || warningRules.isEmpty() || entities == null) return List.of();
        List<Warning> warnings = new ArrayList<>();
        java.util.Set<String> seen = new java.util.HashSet<>();

        for (Entity entity : entities) {
            if (!entity.hasCustomName() || entity.getCustomName() == null) continue;
            String nameText = entity.getCustomName().getString();
            if (nameText.isEmpty()) continue;
            String lowerName = nameText.toLowerCase(Locale.ROOT);

            for (Map.Entry<String, String> rule : warningRules.entrySet()) {
                String trigger = rule.getKey();
                String lowerTrigger = trigger.toLowerCase(Locale.ROOT);
                int triggerIdx = lowerName.indexOf(lowerTrigger);
                if (triggerIdx < 0) continue;

                double timerSeconds = -1;
                String timerStr = "";
                java.util.regex.Matcher matcher = WARNING_TIMER_PATTERN.matcher(nameText);
                while (matcher.find()) {
                    if (matcher.start() >= triggerIdx) {
                        timerStr = matcher.group(1) + "s";
                        try { timerSeconds = Double.parseDouble(matcher.group(1)); } catch (Exception ignored) {}
                        break;
                    }
                }

                if (isBuiltInBossWarning(trigger)) continue;

                String popupText = resolveWarningDisplay(trigger);
                for (Map.Entry<String, String> repl : textReplacements.entrySet()) {
                    if (popupText.toLowerCase().contains(repl.getKey().toLowerCase())) {
                        popupText = popupText.replace(repl.getKey(), repl.getValue());
                        popupText = popupText.replace(repl.getKey().toLowerCase(), repl.getValue());
                        break;
                    }
                }

                if (timerSeconds > 0) {
                    popupText = popupText + " " + timerStr;
                }

                if (seen.add(popupText)) {
                    warnings.add(new Warning(popupText, getWarningColor(trigger)));
                }
            }
        }
        return warnings;
    }

    public static Map<String, String> getTextReplacements() { return textReplacements; }
    public static List<String> getTextReplacementKeys() { return new ArrayList<>(textReplacements.keySet()); }
    public static String getTextReplacement(String trigger) { return textReplacements.getOrDefault(trigger, ""); }

    public static void setTextReplacement(String trigger, String replacement) {
        if (trigger == null || trigger.isEmpty()) return;
        textReplacements.put(trigger, replacement == null ? "" : replacement);
        save();
    }

    public static void setTextReplacementKeys(List<String> list) {
        textReplacements.keySet().removeIf(key -> !list.contains(key));
        for (String trigger : list) {
            String trimmed = trigger.trim();
            if (!trimmed.isEmpty() && !textReplacements.containsKey(trimmed)) {
                textReplacements.put(trimmed, DEFAULT_TEXT_REPLACEMENTS.getOrDefault(trimmed, ""));
            }
        }
        save();
    }

    // --- Blood Ichor helper ---
    public static boolean isIchorHelper() { return ichorHelper; }
    public static void setIchorHelper(boolean v) { applyIchorHelper(v); save(); }
    private static void applyIchorHelper(boolean v) {
        ichorHelper = v;
        ichorEsp = v;
        ichorTracer = v;
        ichorTimer = v;
    }
    public static boolean isIchorEsp() { return ichorHelper; }
    public static void setIchorEsp(boolean v) { setIchorHelper(v); }
    public static boolean isIchorTracer() { return ichorHelper; }
    public static void setIchorTracer(boolean v) { setIchorHelper(v); }
    public static boolean isIchorTimer() { return ichorHelper; }
    public static void setIchorTimer(boolean v) { setIchorHelper(v); }
    public static double getIchorHudX() { return ichorHudX; }
    public static void setIchorHudX(double v) { ichorHudX = v; save(); }
    public static double getIchorHudY() { return ichorHudY; }
    public static void setIchorHudY(double v) { ichorHudY = v; save(); }
    public static double getIchorHudScale() { return ichorHudScale; }
    public static void setIchorHudScale(double v) {
        ichorHudScale = Math.max(0.5, Math.min(3.0, Math.round(v * 20.0) / 20.0));
        save();
    }
    public static int getIchorEspColor() { return ichorEspColor; }
    public static void setIchorEspColor(int v) { ichorEspColor = v; save(); }

    // --- Killer Spring helper ---
    public static boolean isKillerSpringHelper() { return killerSpringHelper; }
    public static void setKillerSpringHelper(boolean v) { applyKillerSpringHelper(v); save(); }
    private static void applyKillerSpringHelper(boolean v) {
        killerSpringHelper = v;
        killerSpringEsp = v;
        killerSpringTracer = v;
        killerSpringTimer = v;
    }
    public static boolean isKillerSpringEsp() { return killerSpringHelper; }
    public static void setKillerSpringEsp(boolean v) { setKillerSpringHelper(v); }
    public static boolean isKillerSpringTracer() { return killerSpringHelper; }
    public static void setKillerSpringTracer(boolean v) { setKillerSpringHelper(v); }
    public static boolean isKillerSpringTimer() { return killerSpringHelper; }
    public static void setKillerSpringTimer(boolean v) { setKillerSpringHelper(v); }
    public static double getKillerSpringHudX() { return killerSpringHudX; }
    public static void setKillerSpringHudX(double v) { killerSpringHudX = v; save(); }
    public static double getKillerSpringHudY() { return killerSpringHudY; }
    public static void setKillerSpringHudY(double v) { killerSpringHudY = v; save(); }
    public static double getKillerSpringHudScale() { return killerSpringHudScale; }
    public static void setKillerSpringHudScale(double v) {
        killerSpringHudScale = Math.max(0.5, Math.min(3.0, Math.round(v * 20.0) / 20.0));
        save();
    }
    public static int getKillerSpringEspColor() { return killerSpringEspColor; }
    public static void setKillerSpringEspColor(int v) { killerSpringEspColor = v; save(); }

    public static void setIchorHudPos(double x, double y) { ichorHudX = x; ichorHudY = y; }
    public static void setKillerSpringHudPos(double x, double y) { killerSpringHudX = x; killerSpringHudY = y; }
    public static void setPerfHudPos(double x, double y) { perfHudX = x; perfHudY = y; }

    // --- Performance HUD ---
    public static boolean isPerfHudEnabled() { return perfHudEnabled; }
    public static void setPerfHudEnabled(boolean v) { perfHudEnabled = v; save(); }
    public static int getPerfHudColor() { return perfHudColor; }
    public static void setPerfHudColor(int v) { perfHudColor = v; save(); }
    public static double getPerfHudScale() { return perfHudScale; }
    public static void setPerfHudScale(double v) {
        perfHudScale = Math.max(0.5, Math.min(3.0, v));
        save();
    }
    public static double getPerfHudX() { return perfHudX; }
    public static double getPerfHudY() { return perfHudY; }
    public static String getIchorMatch() { return ichorMatch; }
    public static void setIchorMatch(String v) { ichorMatch = v; save(); }

    public static boolean isEffigyEnabled() { return effigyEnabled; }
    public static void setEffigyEnabled(boolean v) { effigyEnabled = v; save(); }

    public static boolean isAutoChatWaypoints() { return autoChatWaypoints; }
    public static void setAutoChatWaypoints(boolean v) { autoChatWaypoints = v; save(); }

    public static boolean isManiaHelper() { return maniaHelper; }
    public static void setManiaHelper(boolean v) { maniaHelper = v; save(); }
    public static String getManiaRenderStyle() { return "block_tint".equalsIgnoreCase(maniaRenderStyle) ? "block_tint" : "plane"; }
    public static void setManiaRenderStyle(String v) { maniaRenderStyle = ("block_tint".equalsIgnoreCase(v) ? "block_tint" : "plane"); save(); }
    public static double getManiaSquareSize() { return Math.max(0.1, Math.min(1.0, maniaSquareSize)); }
    public static void setManiaSquareSize(double v) { maniaSquareSize = Math.max(0.1, Math.min(1.0, Math.round(v * 20.0) / 20.0)); save(); }
    public static int getManiaRenderRadius() { return Math.max(3, Math.min(30, maniaRenderRadius)); }
    public static void setManiaRenderRadius(int v) { maniaRenderRadius = Math.max(3, Math.min(30, v)); save(); }
    public static boolean isManiaSafeOnly() { return maniaSafeOnly; }
    public static void setManiaSafeOnly(boolean v) { maniaSafeOnly = v; save(); }
    public static boolean isManiaOnlyDifferent() { return maniaOnlyDifferent; }
    public static void setManiaOnlyDifferent(boolean v) { maniaOnlyDifferent = v; save(); }
    public static int getManiaSafeColor() { return maniaSafeColor; }
    public static void setManiaSafeColor(int v) { maniaSafeColor = v; save(); }
    public static int getManiaTerracottaColor() { return maniaTerracottaColor; }
    public static void setManiaTerracottaColor(int v) { maniaTerracottaColor = v; save(); }
    public static int getManiaRedstoneColor() { return maniaRedstoneColor; }
    public static void setManiaRedstoneColor(int v) { maniaRedstoneColor = v; save(); }
    public static int getManiaCoalColor() { return maniaCoalColor; }
    public static void setManiaCoalColor(int v) { maniaCoalColor = v; save(); }
    public static boolean isManiaHudEnabled() { return maniaHudEnabled; }
    public static void setManiaHudEnabled(boolean v) { maniaHudEnabled = v; save(); }
    public static double getManiaHudX() { return maniaHudX; }
    public static double getManiaHudY() { return maniaHudY; }
    public static void setManiaHudPos(double x, double y) { maniaHudX = x; maniaHudY = y; }
    public static double getManiaHudScale() { return maniaHudScale; }
    public static void setManiaHudScale(double v) { maniaHudScale = Math.max(0.5, Math.min(3.0, Math.round(v * 20.0) / 20.0)); save(); }

    public static boolean isRiftTimeReminder() { return riftTimeReminder; }
    public static void setRiftTimeReminder(boolean v) { riftTimeReminder = v; save(); }

    public static boolean isSlayerTimersEnabled() { return slayerTimersEnabled; }
    public static void setSlayerTimersEnabled(boolean v) { slayerTimersEnabled = v; save(); }
    public static boolean isSlayerProfitTrackerEnabled() { return slayerProfitTrackerEnabled; }
    public static void setSlayerProfitTrackerEnabled(boolean v) { slayerProfitTrackerEnabled = v; save(); }
    public static boolean isSlayerProfitSessionOnly() { return slayerProfitSessionOnly; }
    public static void setSlayerProfitSessionOnly(boolean v) { slayerProfitSessionOnly = v; save(); }
    public static double getSlayerProfitHudX() { return slayerProfitHudX; }
    public static double getSlayerProfitHudY() { return slayerProfitHudY; }
    public static void setSlayerProfitHudPos(double x, double y) { slayerProfitHudX = x; slayerProfitHudY = y; }
    public static double getSlayerProfitScale() { return slayerProfitScale; }
    public static void setSlayerProfitScale(double v) {
        slayerProfitScale = Math.max(0.5, Math.min(2.5, Math.round(v * 20.0) / 20.0));
        save();
    }

    private static String normalizeBossPbKey(String bossName) {
        if (bossName == null || bossName.isEmpty()) return "riftstalker bloodfiend v";
        return bossName.trim().replaceAll("\\s+", " ").toLowerCase(Locale.ROOT);
    }

    public static long getSlayerKillPbMs() {
        return getSlayerKillPbMs("Riftstalker Bloodfiend V");
    }

    public static long getSlayerKillPbMs(String bossName) {
        String key = normalizeBossPbKey(bossName);
        Long pb = slayerKillPbs.get(key);
        return pb != null ? pb : -1L;
    }

    public static long getSlayerQuestPbMs() {
        return getSlayerQuestPbMs("Riftstalker Bloodfiend V");
    }

    public static long getSlayerQuestPbMs(String bossName) {
        String key = normalizeBossPbKey(bossName);
        Long pb = slayerQuestPbs.get(key);
        return pb != null ? pb : -1L;
    }

    public static boolean offerSlayerKillPb(long ms) {
        return offerSlayerKillPb("Riftstalker Bloodfiend V", ms);
    }

    public static boolean offerSlayerKillPb(String bossName, long ms) {
        if (ms < 0L) return false;
        String key = normalizeBossPbKey(bossName);
        Long prev = slayerKillPbs.get(key);
        if (prev == null || prev < 0L || ms < prev) {
            slayerKillPbs.put(key, ms);
            if ("riftstalker bloodfiend v".equals(key)) {
                slayerKillPbMs = ms;
            }
            save();
            return true;
        }
        return false;
    }

    public static boolean offerSlayerQuestPb(long ms) {
        return offerSlayerQuestPb("Riftstalker Bloodfiend V", ms);
    }

    public static boolean offerSlayerQuestPb(String bossName, long ms) {
        if (ms < 0L) return false;
        String key = normalizeBossPbKey(bossName);
        Long prev = slayerQuestPbs.get(key);
        if (prev == null || prev < 0L || ms < prev) {
            slayerQuestPbs.put(key, ms);
            if ("riftstalker bloodfiend v".equals(key)) {
                slayerQuestPbMs = ms;
            }
            save();
            return true;
        }
        return false;
    }

    public static void resetSlayerPersonalBests() {
        slayerKillPbMs = -1L;
        slayerQuestPbMs = -1L;
        slayerKillPbs.clear();
        slayerQuestPbs.clear();
        save();
    }

    public static double getSelfPlayerScale() { return selfPlayerScale; }
    public static void setSelfPlayerScale(double value) { selfPlayerScale = value; }

    public static double getOtherPlayerScale() { return otherPlayerScale; }
    public static void setOtherPlayerScale(double value) { otherPlayerScale = value; }

    public static boolean isSkipFaceView() { return skipFaceView; }
    public static void setSkipFaceView(boolean value) { skipFaceView = value; }

    public static boolean isThirdPersonCrosshair() { return thirdPersonCrosshair; }
    public static void setThirdPersonCrosshair(boolean value) { thirdPersonCrosshair = value; }

    public static String getCrosshairStyle() { return crosshairStyle; }
    public static void setCrosshairStyle(String value) {
        crosshairStyle = CrosshairStyle.fromId(value).getId();
    }

    public enum CrosshairStyle {
        CROSS("cross"),
        DOT("dot"),
        CIRCLE("circle"),
        CROSS_DOT("cross_dot"),
        T_SHAPE("t_shape"),
        CORNERS("corners"),
        OPEN_CROSS("open_cross"),
        DIAGONAL_X("diagonal_x"),
        BOX("box"),
        CHEVRONS("chevrons"),
        HOLLOW_CROSS("hollow_cross"),
        TRIPLE_DOT("triple_dot");

        private final String id;

        CrosshairStyle(String id) { this.id = id; }

        public String getId() { return id; }

        public static CrosshairStyle fromId(String id) {
            if (id == null || id.isEmpty()) return CROSS;
            return switch (id) {
                case "dot" -> DOT;
                case "circle", "ring", "target" -> CIRCLE;
                case "cross_dot" -> CROSS_DOT;
                case "t_shape" -> T_SHAPE;
                case "corners" -> CORNERS;
                case "open_cross" -> OPEN_CROSS;
                case "diagonal_x", "x", "diag_x" -> DIAGONAL_X;
                case "box", "square", "hollow_square" -> BOX;
                case "chevrons", "arrows" -> CHEVRONS;
                case "hollow_cross" -> HOLLOW_CROSS;
                case "triple_dot", "dots" -> TRIPLE_DOT;
                case "circle_cross", "dot_ring", "circle_dot" -> CROSS;
                default -> CROSS;
            };
        }
    }

    public static boolean isItemRarityOutline() { return itemRarityOutline; }
    public static void setItemRarityOutline(boolean value) { itemRarityOutline = value; save(); }

    public static boolean isAhLowestBin() { return ahLowestBin; }
    public static void setAhLowestBin(boolean value) {
        ahLowestBin = value;
        save();
    }

    public static boolean isScrollableTooltips() { return scrollableTooltips; }
    public static void setScrollableTooltips(boolean value) {
        scrollableTooltips = value;
        save();
    }

    public static boolean isTradeValueOverlay() { return tradeValueOverlay; }
    public static void setTradeValueOverlay(boolean value) {
        tradeValueOverlay = value;
        save();
    }

    public static List<CommandHotkeyEntry> getCommandHotkeys() {
        List<CommandHotkeyEntry> out = new ArrayList<>();
        for (CommandHotkeyEntry e : commandHotkeys) out.add(e.copy());
        return out;
    }

    public static List<CommandHotkeyEntry> getCommandHotkeysView() {
        return commandHotkeys;
    }

    public static boolean hasCommandHotkeys() {
        return !commandHotkeys.isEmpty();
    }

    public static int getCommandHotkeyGeneration() {
        return commandHotkeyGeneration;
    }

    public static void setCommandHotkeys(List<CommandHotkeyEntry> list) {
        commandHotkeys.clear();
        if (list != null) {
            for (CommandHotkeyEntry e : list) {
                if (e != null) commandHotkeys.add(e.copy());
            }
        }
        commandHotkeyGeneration++;
        save();
    }

    public static Iterable<String> warningRuleKeysView() {
        return warningRules.keySet();
    }

    public static float getDroppedItemScale() { return DROPPED_ITEM_SCALE; }

    public static CrosshairStyle getCrosshairStyleEnum() { return CrosshairStyle.fromId(crosshairStyle); }
    public static void setCrosshairStyleEnum(CrosshairStyle style) {
        crosshairStyle = (style == null ? CrosshairStyle.CROSS : style).getId();
    }

    public static boolean isCustomCrosshair() { return customCrosshair; }
    public static void setCustomCrosshair(boolean value) { customCrosshair = value; }

    public static int getCrosshairColor() { return crosshairColor; }
    public static void setCrosshairColor(int value) { crosshairColor = value; }

    public static boolean isCrosshairChroma() { return crosshairChroma; }
    public static void setCrosshairChroma(boolean value) { crosshairChroma = value; }

    public static double getCrosshairScale() { return crosshairScale; }
    public static void setCrosshairScale(double value) {
        crosshairScale = Math.max(0.25, Math.min(3.0, value));
    }

    public static boolean isChatCtrlClickCopy() { return chatCtrlClickCopy; }
    public static void setChatCtrlClickCopy(boolean value) { chatCtrlClickCopy = value; }

    public static boolean isChatStacking() { return chatStacking; }
    public static void setChatStacking(boolean value) { chatStacking = value; save(); }

    public static boolean isHideStashMessages() { return hideStashMessages; }
    public static void setHideStashMessages(boolean value) { hideStashMessages = value; save(); }

    public static List<String> getHiddenChatMessages() { return new ArrayList<>(hiddenChatMessages); }

    public static void setHiddenChatMessages(List<String> list) {
        hiddenChatMessages.clear();
        if (list != null) {
            for (String s : list) {
                if (s == null) continue;
                if (s.isEmpty()) {
                    hiddenChatMessages.add("");
                    continue;
                }
                String pattern = ChatTextPatterns.stackKey(s);
                if (pattern.isEmpty()) continue;
                if (hiddenChatMessages.stream().noneMatch(p -> p.equalsIgnoreCase(pattern))) {
                    hiddenChatMessages.add(pattern);
                }
            }
        }
        save();
    }

    public static boolean addHiddenChatMessage(String rawOrPattern) {
        String pattern = ChatTextPatterns.stackKey(rawOrPattern);
        if (pattern.isEmpty()) return false;
        if (hiddenChatMessages.stream().anyMatch(p -> p.equalsIgnoreCase(pattern))) {
            return false;
        }
        hiddenChatMessages.add(pattern);
        save();
        return true;
    }

    public static boolean isChatMessageHidden(String raw) {
        if (raw == null) return false;
        String key = ChatTextPatterns.stackKey(raw);
        if (key.isEmpty()) return false;
        if (hideStashMessages && ChatTextPatterns.isStashMessage(key)) return true;
        if (hiddenChatMessages.isEmpty()) return false;
        for (String rule : hiddenChatMessages) {
            if (matchesHiddenChatPattern(key, rule)) return true;
        }
        return false;
    }

    public static boolean matchesHiddenChatPattern(String messageText, String ruleText) {
        String key = ChatTextPatterns.stackKey(messageText);
        String rule = ChatTextPatterns.stackKey(ruleText);
        if (key.isEmpty() || rule.isEmpty()) return false;
        String keyL = key.toLowerCase(java.util.Locale.ROOT);
        String ruleL = rule.toLowerCase(java.util.Locale.ROOT);
        return keyL.equals(ruleL) || keyL.contains(ruleL);
    }

    public static boolean isPersistentChatHistory() { return persistentChatHistory; }
    public static void setPersistentChatHistory(boolean value) { persistentChatHistory = value; save(); }

    public static boolean isPartyInviteCommands() { return partyInviteCommands; }
    public static void setPartyInviteCommands(boolean value) { partyInviteCommands = value; save(); }

    public static boolean isPartyChatCommands() { return partyChatCommands; }
    public static void setPartyChatCommands(boolean value) { partyChatCommands = value; save(); }

    public static boolean isPartyFunCommands() { return partyFunCommands; }
    public static void setPartyFunCommands(boolean value) { partyFunCommands = value; save(); }

    public static boolean isPartyCmdEnabled(String id) {
        if (id == null || id.isEmpty()) return false;
        return !partyCmdDisabled.contains(id.toLowerCase());
    }

    public static void setPartyCmdEnabled(String id, boolean enabled) {
        if (id == null || id.isEmpty()) return;
        String key = id.toLowerCase();
        if (enabled) partyCmdDisabled.remove(key);
        else partyCmdDisabled.add(key);
        save();
    }

    public static Set<String> getPartyCmdDisabled() {
        return new LinkedHashSet<>(partyCmdDisabled);
    }

    public static final String[] PARTY_UTIL_CMD_IDS = {
            "warp", "w", "allinv", "pt", "kick", "promote", "demote",
            "coords", "ping", "tps", "fps", "time",
            "f?", "m?"
    };

    public static final String[] PARTY_FUN_CMD_IDS = {
            "cf", "dice", "8ball", "rps", "flip", "rate", "rizz", "iq", "vibe",
            "roast", "praise", "ship", "cook", "aura", "sigma", "skillissue",
            "sus", "ratio", "gay", "furry", "femboy"
    };

    public static boolean isClearOverlays() { return clearOverlays; }
    public static void setClearOverlays(boolean value) { clearOverlays = value; }

    public static boolean isParticlesOnlyHearts() { return particlesOnlyHearts; }
    public static void setParticlesOnlyHearts(boolean value) { particlesOnlyHearts = value; }

    public static boolean isFullbright() { return fullbright; }
    public static void setFullbright(boolean value) { fullbright = value; save(); }

    public static boolean isShowQolTab() { return showQolTab; }
    public static void setShowQolTab(boolean value) { showQolTab = value; save(); }

    public enum GuiStyle {
        VAMP("vamp_v2"),
        SIMPLIFIED("simplified");

        private final String id;

        GuiStyle(String id) { this.id = id; }

        public String getId() { return id; }

        public static GuiStyle fromId(String id) {
            if (id == null || id.isEmpty()) return VAMP;
            if ("simple".equalsIgnoreCase(id) || "plain".equalsIgnoreCase(id)
                    || "simplified".equalsIgnoreCase(id)) {
                return SIMPLIFIED;
            }
            return VAMP;
        }
    }

    public static boolean isSimpleOnlyBuild() {
        Boolean cached = cachedSimpleOnlyBuild;
        if (cached != null) return cached;
        boolean simpleOnly = VampyConfig.class.getResource("/assets/vampy/textures/gui/chateau_v2_bg.png") == null;
        cachedSimpleOnlyBuild = simpleOnly;
        return simpleOnly;
    }

    public static GuiStyle getGuiStyle() {
        if (isSimpleOnlyBuild()) return GuiStyle.SIMPLIFIED;
        return GuiStyle.fromId(guiStyle);
    }

    public static void setGuiStyle(GuiStyle style) {
        if (isSimpleOnlyBuild()) {
            guiStyle = GuiStyle.SIMPLIFIED.getId();
            save();
            return;
        }
        guiStyle = (style == null ? GuiStyle.VAMP : style).getId();
        save();
    }

    public static void cycleGuiStyle() {
        if (isSimpleOnlyBuild()) {
            setGuiStyle(GuiStyle.SIMPLIFIED);
            return;
        }
        GuiStyle cur = getGuiStyle();
        setGuiStyle(cur == GuiStyle.VAMP ? GuiStyle.SIMPLIFIED : GuiStyle.VAMP);
    }

    public static boolean isIchor(Entity entity) {
        if (entity == null) return false;
        if (entity.hasCustomName() && entity.getCustomName() != null) {
            if (isIchorName(entity.getCustomName().getString())) return true;
        }
        String cached = getCachedEntityName(entity.getUUID());
        return !cached.isEmpty() && isIchorName(cached);
    }

    private static boolean isIchorName(String name) {
        String trimmed = name == null ? "" : name.trim();
        if (trimmed.isEmpty()) return false;
        if (trimmed.matches("\\d+\\.?\\d*s")) return true;
        if (ichorMatch == null || ichorMatch.isEmpty()) return false;
        String lower = trimmed.toLowerCase();
        if (!lower.contains(ichorMatch.toLowerCase())) return false;
        if (isBossAbilityHologram(lower, trimmed)) return false;
        return true;
    }

    private static boolean isBossAbilityHologram(String lower, String trimmed) {
        if (lower.contains("killer spring") || lower.contains("stonewrath")
                || lower.contains("mania") || (lower.contains("twinclaw"))
                || lower.contains("boom")) {
            return true;
        }
        if (trimmed.matches(".*\\d+:\\d{2}.*")) return true;
        int timers = 0;
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("\\d+\\.?\\d*s").matcher(trimmed);
        while (m.find()) {
            if (++timers > 1) return true;
        }
        return false;
    }

    public static boolean isRealPlayer(Entity entity) {
        if (entity == null) return false;
        if (!getEntityTypeId(entity).equals("minecraft:player")) return false;
        return entity.getUUID().version() == 4;
    }

    public static String getEntityTypeId(Entity entity) {
        EntityType<?> type = entity.getType();
        Identifier id = BuiltInRegistries.ENTITY_TYPE.getKey(type);
        return id != null ? id.toString() : "unknown";
    }

    public static boolean isItemCooldownOverlay() { return itemCooldownOverlay; }
    public static void setItemCooldownOverlay(boolean v) { itemCooldownOverlay = v; save(); }

    public static boolean isSteakableHighlight() { return steakableHighlight; }
    public static void setSteakableHighlight(boolean v) { steakableHighlight = v; save(); }

    public static boolean isSlayerBossHighlight() { return slayerBossHighlight; }
    public static void setSlayerBossHighlight(boolean v) { slayerBossHighlight = v; save(); }

    public static boolean isBossSteakAlert() { return bossSteakAlert; }
    public static void setBossSteakAlert(boolean v) { bossSteakAlert = v; save(); }

    public static boolean isLootshareBossCallout() { return lootshareBossCallout; }
    public static void setLootshareBossCallout(boolean v) { lootshareBossCallout = v; save(); }

    public static double getUnfangedRelicPercent() { return Math.clamp(unfangedRelicPercent, 0.0, 100.0); }
    public static void setUnfangedRelicPercent(double v) { unfangedRelicPercent = Math.clamp(v, 0.0, 100.0); save(); }

    public static boolean isProfitDropHidden(String key) { return hiddenProfitDrops.contains(key); }
    public static boolean toggleProfitDropHidden(String key) {
        if (hiddenProfitDrops.contains(key)) { hiddenProfitDrops.remove(key); save(); return false; }
        else { hiddenProfitDrops.add(key); save(); return true; }
    }

    public static boolean isBazaarUseInstaBuy() { return bazaarUseInstaBuy; }
    public static void setBazaarUseInstaBuy(boolean v) { bazaarUseInstaBuy = v; save(); }

    public static double getHotbarCdX() { return hotbarCdX; }
    public static double getHotbarCdY() { return hotbarCdY; }
    public static void setHotbarCdPos(double x, double y) { hotbarCdX = x; hotbarCdY = y; save(); }
    public static void resetHotbarCdPos() { hotbarCdX = -1.0; hotbarCdY = -1.0; save(); }
    public static double getHotbarCdScale() { return Math.clamp(hotbarCdScale, 0.5, 3.0); }
    public static void setHotbarCdScale(double v) { hotbarCdScale = Math.clamp(v, 0.5, 3.0); save(); }

    public static boolean isWebsocketEnabled() { return websocketEnabled; }
    public static void setWebsocketEnabled(boolean v) { websocketEnabled = v; save(); }

    public static int getPartyMemberColor() { return partyMemberColor | 0xFF000000; }
    public static void setPartyMemberColor(int v) { partyMemberColor = v | 0xFF000000; save(); }

    public static boolean isPartyMemberGlow() { return partyMemberGlow; }
    public static void setPartyMemberGlow(boolean v) { partyMemberGlow = v; save(); }

    public static boolean isTrackVampireSlayer() { return trackVampireSlayer; }
    public static void setTrackVampireSlayer(boolean v) { trackVampireSlayer = v; save(); }

    public static boolean isTrackZombieSlayer() { return trackZombieSlayer; }
    public static void setTrackZombieSlayer(boolean v) { trackZombieSlayer = v; save(); }

    public static boolean isTrackSpiderSlayer() { return trackSpiderSlayer; }
    public static void setTrackSpiderSlayer(boolean v) { trackSpiderSlayer = v; save(); }

    public static boolean isTrackWolfSlayer() { return trackWolfSlayer; }
    public static void setTrackWolfSlayer(boolean v) { trackWolfSlayer = v; save(); }

    public static boolean isTrackEndermanSlayer() { return trackEndermanSlayer; }
    public static void setTrackEndermanSlayer(boolean v) { trackEndermanSlayer = v; save(); }

    public static boolean isTrackBlazeSlayer() { return trackBlazeSlayer; }
    public static void setTrackBlazeSlayer(boolean v) { trackBlazeSlayer = v; save(); }

    public static boolean isDungeonClassColors() { return dungeonClassColors; }
    public static void setDungeonClassColors(boolean v) { dungeonClassColors = v; save(); }

    public static int getClassHealerColor() { return classHealerColor | 0xFF000000; }
    public static void setClassHealerColor(int v) { classHealerColor = v | 0xFF000000; save(); }

    public static int getClassMageColor() { return classMageColor | 0xFF000000; }
    public static void setClassMageColor(int v) { classMageColor = v | 0xFF000000; save(); }

    public static int getClassBerserkColor() { return classBerserkColor | 0xFF000000; }
    public static void setClassBerserkColor(int v) { classBerserkColor = v | 0xFF000000; save(); }

    public static int getClassArcherColor() { return classArcherColor | 0xFF000000; }
    public static void setClassArcherColor(int v) { classArcherColor = v | 0xFF000000; save(); }

    public static int getClassTankColor() { return classTankColor | 0xFF000000; }
    public static void setClassTankColor(int v) { classTankColor = v | 0xFF000000; save(); }

    private static final class ConfigData {
        private double renderDistance = DEFAULT_RENDER_DISTANCE;
        private boolean warningsEnabled = true;
        private Map<String, String> warningRules = new LinkedHashMap<>();
        private Map<String, Integer> warningColors = new LinkedHashMap<>();
        private double warningSize = 4.0;
        private String warningPreview = "SNEAK";
        private Map<String, String> textReplacements = new LinkedHashMap<>();
        private boolean ichorHelper = true;
        private boolean ichorEsp = true;
        private boolean ichorTracer = true;
        private boolean ichorTimer = true;
        private double ichorHudX = 0.5;
        private double ichorHudY = 0.18;
        private double ichorHudScale = 1.0;
        private int ichorEspColor = DEFAULT_ICHOR_ESP_COLOR;
        private String ichorMatch = "ichor";
        private boolean killerSpringHelper = true;
        private boolean killerSpringEsp = true;
        private boolean killerSpringTracer = true;
        private boolean killerSpringTimer = true;
        private double killerSpringHudX = 0.5;
        private double killerSpringHudY = 0.30;
        private double killerSpringHudScale = 1.0;
        private int killerSpringEspColor = DEFAULT_KILLER_SPRING_ESP_COLOR;
        private boolean effigyEnabled = true;
        private boolean autoChatWaypoints = false;
        private boolean maniaHelper = true;
        private String maniaRenderStyle = "plane";
        private double maniaSquareSize = 0.5;
        private int maniaRenderRadius = 30;
        private boolean maniaSafeOnly = false;
        private boolean maniaOnlyDifferent = false;
        private int maniaSafeColor = DEFAULT_MANIA_SAFE_COLOR;
        private int maniaTerracottaColor = DEFAULT_MANIA_TERRACOTTA_COLOR;
        private int maniaRedstoneColor = DEFAULT_MANIA_REDSTONE_COLOR;
        private int maniaCoalColor = DEFAULT_MANIA_COAL_COLOR;
        private boolean maniaHudEnabled = true;
        private double maniaHudX = 0.5;
        private double maniaHudY = 0.36;
        private double maniaHudScale = 1.0;
        private boolean lootshareBossCallout = true;
        private boolean riftTimeReminder = true;
        private boolean slayerTimersEnabled = true;
        private boolean slayerProfitTrackerEnabled = true;
        private boolean slayerProfitSessionOnly = false;
        private double slayerProfitHudX = 0.015;
        private double slayerProfitHudY = 0.28;
        private double slayerProfitScale = 1.0;
        private long slayerKillPbMs = -1L;
        private long slayerQuestPbMs = -1L;
        private Map<String, Long> slayerKillPbs = new LinkedHashMap<>();
        private Map<String, Long> slayerQuestPbs = new LinkedHashMap<>();
        private double selfPlayerScale = 1.0;
        private double otherPlayerScale = 1.0;
        private boolean skipFaceView = false;
        private boolean thirdPersonCrosshair = false;
        private String crosshairStyle = "cross";
        private boolean customCrosshair = false;
        private int crosshairColor = DEFAULT_CROSSHAIR_COLOR;
        private boolean crosshairChroma = false;
        private double crosshairScale = 1.0;
        private boolean perfHudEnabled = false;
        private int perfHudColor = DEFAULT_PERF_HUD_COLOR;
        private double perfHudScale = 1.0;
        private double perfHudX = 0.02;
        private double perfHudY = 0.02;
        private boolean chatCtrlClickCopy = false;
        private boolean chatStacking = false;
        private boolean hideStashMessages = false;
        private List<String> hiddenChatMessages = new ArrayList<>();
        private boolean persistentChatHistory = false;
        private boolean partyInviteCommands = false;
        private boolean partyChatCommands = false;
        private boolean partyFunCommands = false;
        private List<String> partyCmdDisabled = new ArrayList<>();
        private boolean itemRarityOutline = false;
        private boolean ahLowestBin = false;
        private boolean scrollableTooltips = true;
        private boolean tradeValueOverlay = false;
        private List<CommandHotkeyEntry> commandHotkeys = new ArrayList<>();
        private boolean clearOverlays = false;
        private boolean particlesOnlyHearts = false;
        private boolean fullbright = false;
        private boolean showQolTab = false;
        private String guiStyle = "vamp_v2";
        private boolean itemCooldownOverlay = true;
        private boolean steakableHighlight = true;
        private boolean slayerBossHighlight = true;
        private boolean bossSteakAlert = true;
        private double unfangedRelicPercent = 85.0;
        private boolean bazaarUseInstaBuy = false;
        private double hotbarCdX = -1.0;
        private double hotbarCdY = -1.0;
        private double hotbarCdScale = 1.0;
        private List<String> hiddenProfitDrops = new ArrayList<>();
        private boolean websocketEnabled = true;
        private int partyMemberColor = DEFAULT_PARTY_MEMBER_COLOR;
        private boolean partyMemberGlow = true;
        private boolean dungeonClassColors = true;
        private int classHealerColor = DEFAULT_CLASS_HEALER_COLOR;
        private int classMageColor = DEFAULT_CLASS_MAGE_COLOR;
        private int classBerserkColor = DEFAULT_CLASS_BERSERK_COLOR;
        private int classArcherColor = DEFAULT_CLASS_ARCHER_COLOR;
        private int classTankColor = DEFAULT_CLASS_TANK_COLOR;
        private boolean trackVampireSlayer = true;
        private boolean trackZombieSlayer = true;
        private boolean trackSpiderSlayer = true;
        private boolean trackWolfSlayer = true;
        private boolean trackEndermanSlayer = true;
        private boolean trackBlazeSlayer = true;
    }
}
