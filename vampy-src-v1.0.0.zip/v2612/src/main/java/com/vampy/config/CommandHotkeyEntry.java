package com.vampy.config;

/**
 * One bindable chat/client command hotkey (SkyOcean-style), with optional modifiers.
 */
public final class CommandHotkeyEntry {
    public String name = "";
    public String key = "";
    public boolean ctrl = false;
    public boolean shift = false;
    public boolean alt = false;
    public boolean enabled = true;
    public String command = "";

    public CommandHotkeyEntry() {
    }

    public CommandHotkeyEntry(String name, String key, boolean enabled, String command) {
        this(name, key, false, false, false, enabled, command);
    }

    public CommandHotkeyEntry(String name, String key, boolean ctrl, boolean shift, boolean alt,
                              boolean enabled, String command) {
        this.name = name == null ? "" : name;
        this.key = key == null ? "" : key;
        this.ctrl = ctrl;
        this.shift = shift;
        this.alt = alt;
        this.enabled = enabled;
        this.command = command == null ? "" : command;
    }

    public CommandHotkeyEntry copy() {
        return new CommandHotkeyEntry(name, key, ctrl, shift, alt, enabled, command);
    }

    public String displayName() {
        if (name != null && !name.isBlank()) return name.trim();
        if (command != null && !command.isBlank()) return command.trim();
        return "Hotkey";
    }
}
